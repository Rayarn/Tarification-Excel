# PrimeLab, étude tarifaire RC auto 2026 : pack pour Claude Code

## Contenu

| Dossier | Rôle |
|---|---|
| `PROMPT_Claude_Code.md` | Le prompt à donner à Claude Code |
| `cahier_des_charges/` | Cahier des charges en Word (.docx), PDF et Markdown (même contenu) |
| `donnees/` | Classeur de départ `PrimeLab_RC_2026_donnees.xlsx` et les mêmes tables en CSV |
| `maquettes/` | Rendu cible des 13 pages (et la variante seuil 5 k€) |
| `formules/` | Les 33 formules (SVG, PNG, manifeste) insérées par le VBA |
| `recette/` | Valeurs attendues, qui font foi pour le moteur |
| `reference/` | Implémentation Python qui a produit la recette (lecture du classeur de départ) |
| `polices/` | Plus Jakarta Sans, licence OFL |

## Mode d'emploi

1. Installer les polices de `polices/` (clic droit, « Installer pour tous les utilisateurs »), puis redémarrer Excel.
2. Décompresser ce pack dans un dossier de travail et ouvrir Claude Code dans ce dossier.
3. Écrire à Claude Code : « Lis PROMPT_Claude_Code.md et exécute-le. »
4. À la fin de la phase 1 : ouvrir `donnees/PrimeLab_RC_2026_donnees.xlsx`, l'enregistrer en `.xlsm`, importer les modules de `src/` (Alt+F11, Fichier, Importer), lancer la macro indiquée, puis `Recette`. Renvoyer le résultat à Claude Code.
5. Même principe pour les phases 2 et 3. Le dossier `formules/` doit rester à côté du classeur.

## Chiffres clés à retrouver

- 25 074 lignes de contrats, 920 sinistres bruts, 884 retenus, exposition 22 326 années-police.
- Classes d'âge 18-24, 25-29, 30-49, 50-74, 75+ ; variables retenues : âge, zone, puissance, usage.
- κ = 1,300 ; θ = 1,018 ; évolution moyenne du tarif + 9,0 % ; équilibre après plafonnement 95,3 %.
