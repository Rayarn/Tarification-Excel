# Notes de réalisation

## Environnement cible réel : Excel 2013 (15.0), Windows français

Le cahier vise Excel 365. Le poste d'exécution dispose d'Excel 2013, qui n'a ni `Range.Formula2`, ni les fonctions
dynamiques (XLOOKUP, FILTER, UNIQUE, LET, TEXTJOIN, TEXTSPLIT), ni l'insertion d'images SVG. Les calculs restent en
formules dans les feuilles de travail ; seules les écritures changent. Le classeur fonctionne aussi sous Excel 365.

| Cahier (365) | Écriture retenue (2013) |
|---|---|
| `.Formula2` | `.Formula` ; `.FormulaArray` pour les formules matricielles (médianes, déviances, φ, contrôles sur plages) |
| `XLOOKUP(x, plage, retour)` | `INDEX(retour, MATCH(x, plage, 0))` ; `XLOOKUP(..., -1)` approché → `LOOKUP(x, bornes, valeurs)` |
| `XLOOKUP(..., 0)` (valeur par défaut) | `IFERROR(INDEX(...), 0)` |
| `MEDIAN(FILTER(...))` | `{=INT(MEDIAN(IF((c_zone=A2)*(c_age_brut<>""),c_age_brut)))}` |
| `ROWS(UNIQUE(c_cle))`, `ROWS(UNIQUE(c_id))` | colonnes triées par le VBA (Qualite!K:L, tri fusion stable), puis `SUMPRODUCT` sur les paires voisines |
| `ROWS(UNIQUE(FILTER(c_id, c_age_brut="")))` | comptage des polices distinctes parmi les lignes « Âge imputé » du Journal |
| `LET(...)` (attendu Poisson, χ²) | expressions développées dans `SUMPRODUCT` ; λ dans la cellule nommée `hist_lam` |
| `MIN(FILTER(cls_Es, ...))` | `{=MIN(IF(cls_var=A2, cls_Es))}` |
| `TEXTJOIN("|", FALSE, AA2:AD2)` | `=AA2&"|"&AB2&"|"&AC2&"|"&AD2` (construite selon les variables retenues) |
| `SUM(SUMIFS(..., TEXTSPLIT(C2,"+")))` | `SUMPRODUCT(SUMIFS(c_expo, c_zone, bornes_zone_mod) * (bornes_zone_classe = B2))` |
| Contrôles 02 sur `FILTER` | `SUMPRODUCT((s_retenu=1)*(COUNTIFS(...)...))` |
| Images SVG des formules | PNG du dossier `formules` (le code tente le SVG si Excel ≥ 2016, repli PNG sinon) |

## Écarts au cahier (limites d'Excel)

- **Feuille « Historique » renommée « Historique_ »** : « Historique » est un nom réservé par Excel en français
  (historique des modifications) ; la création de la feuille échoue (erreur 1004). Toutes les formules et noms pointent
  sur `Historique_`.
- **Impact** : une colonne `ligne` (numéro de ligne dans Contrats, écrit par le VBA lors de la sélection des polices)
  remplace les 4 × 4 630 recherches XLOOKUP sur 25 074 clés ; les colonnes B à L sont des `INDEX(c_xxx, ligne)`.
- **GLM_Frequence / GLM_Cout** : colonne H `var_inv` (diagonale de (X'WX)⁻¹, écrite par l'IRLS) ; l'erreur standard
  E est une formule `=SQRT(H2)` (fréquence) ou `=SQRT(glmc_phi*H2)` (coût), φ étant une formule de la feuille.
- **Nom de colonne** : l'en-tête Sinistres!L est `charge_reval` (cartes « Dans le classeur ») et son nom défini est
  `s_charge_rev`, comme dans toutes les formules du cahier.
- **Décision LRT** : libellé du cahier « Écartée (rapport de vraisemblance) » (la référence Python écrit « test du
  rapport de vraisemblance ») ; le cas ne se produit pas sur les données.
- **Arrondi d'affichage** : R8 impose l'arrondi arithmétique ; 22 500 € s'affiche « 23 k€ » (la maquette, produite
  par un arrondi bancaire, montre « 22 k€ »).
- **Lettres de colonnes de la carte « Dans le classeur »** : A, B, C… dans l'ordre d'affichage, comme les maquettes ;
  la référence de cellule et la formule (FormulaLocal) sont celles de la vraie feuille.

## Choix d'implémentation

- Le VBA ne calcule que le combinatoire et l'itératif : tris (fusion stable, non récursif), regroupement des classes,
  V de Cramér et élimination descendante (IRLS en mémoire), IRLS Poisson et Gamma (Gauss-Jordan à pivot partiel),
  quintiles, liste des graves, journal, bandeau. Tout le reste est en formules.
- Construction découpée en 5 parties (`ConstruireMoteurPartie k`), chacune reprenant l'état depuis les feuilles :
  utile sur un poste lent ou instable. `ConstruireApplication` enchaîne tout.
- Mode silencieux (`ModeSilencieux`) pour l'automatisation : pas de MsgBox, trace `trace_construction.txt`.
- `ExporterCaptures` exporte les 13 pages en PNG (dossier `captures`) pour la comparaison avec les maquettes.
- `outils/verifier_encodage.py` (Windows-1252, CRLF, longueurs), `outils/verifier_vba.py` (identifiants non déclarés,
  appels de procédures privées d'un autre module), `outils/generer_recette.py` (valeurs attendues recopiées des JSON).

## Mesures et limites connues (poste de test : Excel 2013 15.0.4420, Windows 10)

- Recette : 536 indicateurs sur 536 conformes (452 au seuil de 15 000 €, 42 + 42 pour les scénarios 10 000 € et
  5 000 €), mesurée sur le classeur final rouvert, après l'auto-test des interactions (`TesterInteractions`).
- Les 33 contrôles sont verts à 15 000 € ; à 10 000 € seul 10-2 passe au rose ; à 5 000 €, exactement 05-3 et 10-2.
- Durées : moteur 100 à 120 s, pages 21 à 35 s, construction complète 145 à 200 s. La cible de 90 s n'est pas
  atteinte sur ce poste, très lent (enregistrement du classeur : 20 s).
- **Office se ferme de lui-même** sur ce poste (boîte « Microsoft Office ne parvient pas à trouver votre licence…
  va maintenant quitter », 20 s à 4 min après le démarrage). D'où la construction en deux temps :
  `ConstruireMoteur`, enregistrer, puis `ConstruireInterface` (pages, recette, protections, mode application).
- Réimporter des modules dans un classeur déjà construit peut figer Excel 2013 : repartir du `.xlsx` de départ.
- Excel 2013 ne connaît pas la mise à l'échelle automatique des écrans haute densité : le zoom est recalculé à chaque
  navigation (`AjusterZoom`).
- `TesterInteractions` joue toutes les interactions sans clic (puces, seuils, boutons du calculateur, navigation,
  consultation d'une feuille, modes) ; le clic réel sur les formes passe par les mêmes procédures.
