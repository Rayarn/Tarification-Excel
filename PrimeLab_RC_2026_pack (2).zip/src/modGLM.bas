Attribute VB_Name = "modGLM"
Option Explicit
' =====================================================================
' modGLM : �tapes 09 (cellules, IRLS Poisson et Gamma, quintiles,
' ratios CRM) et 10 (sinistres graves, Pareto, coefficient kappa).
' =====================================================================

Public Const F_CELLULES As String = "Cellules"
Public Const F_GLMF As String = "GLM_Frequence"
Public Const F_GLMC As String = "GLM_Cout"

Private Const COL_C_CLASSES As Long = 27       ' AA : premi�re colonne cl_<v> de Contrats
Private Const NB_QUINTILES As Long = 5
Private Const COL_QUINTILES As Long = 15       ' O
Private Const COL_RATIOS_CRM As Long = 20      ' T
Private Const COL_SYNTHESE As Long = 12        ' L
Private Const COL_JOURNAL As Long = 9          ' I
Private Const BASE_CLE_CELLULE As Double = 100
Private Const Z_IC As String = "1.96"
Private Const MULTIPLES_SURVIE As String = "1.5,2,3,5,10"

' ---------------------------------------------------------------------
' Matrice de conception : intercept puis une indicatrice par classe non de r�f�rence
' cc(1..n, 0..6) : indices de classes ; vars(1..nv) : candidates du mod�le
' ---------------------------------------------------------------------
Public Sub MatriceX(cc() As Long, ByVal n As Long, vars() As Long, ByVal nv As Long, x() As Double)
    Dim p As Long, r As Long, k As Long, c As Long, q As Long
    p = 1
    For k = 1 To nv: p = p + gNbCl(vars(k)) - 1: Next k
    ReDim x(1 To n, 1 To p)
    For r = 1 To n
        x(r, 1) = 1
        c = 1
        For k = 1 To nv
            For q = 1 To gNbCl(vars(k))
                If q <> gClRef(vars(k)) Then
                    c = c + 1
                    If cc(r, vars(k)) = q Then x(r, c) = 1
                End If
            Next q
        Next k
    Next r
End Sub

' Produits X'WX et X'Wz
Private Sub ProduitsIRLS(x() As Double, w() As Double, z() As Double, ByVal n As Long, ByVal p As Long, _
                         a() As Double, b() As Double)
    Dim r As Long, i As Long, j As Long, wi As Double
    ReDim a(1 To p, 1 To p): ReDim b(1 To p)
    For r = 1 To n
        wi = w(r)
        For i = 1 To p
            If x(r, i) <> 0 Then
                b(i) = b(i) + x(r, i) * wi * z(r)
                For j = i To p
                    If x(r, j) <> 0 Then a(i, j) = a(i, j) + x(r, i) * wi * x(r, j)
                Next j
            End If
        Next i
    Next r
    For i = 1 To p
        For j = 1 To i - 1: a(i, j) = a(j, i): Next j
    Next i
End Sub

Private Function Lineaire(x() As Double, beta() As Double, ByVal r As Long, ByVal p As Long) As Double
    Dim j As Long, s As Double
    For j = 1 To p
        If x(r, j) <> 0 Then s = s + x(r, j) * beta(j)
    Next j
    Lineaire = s
End Function

Private Sub Resoudre(a() As Double, b() As Double, ByVal p As Long, beta() As Double)
    Dim inv() As Double, i As Long, j As Long
    InverserMatrice a, p, inv
    ReDim beta(1 To p)
    For i = 1 To p
        For j = 1 To p: beta(i) = beta(i) + inv(i, j) * b(j): Next j
    Next i
End Sub

' ---------------------------------------------------------------------
' IRLS Poisson, lien log, offset (section 6.9)
' ---------------------------------------------------------------------
Public Sub AjusterPoisson(x() As Double, y() As Double, off() As Double, ByVal n As Long, beta() As Double, _
                          vinv() As Double, dev As Double, journal() As Double, nit As Long, mu() As Double)
    Dim p As Long, r As Long, t As Long, sy As Double, se As Double, xb As Double
    Dim w() As Double, z() As Double, a() As Double, b() As Double, inv() As Double, devAnc As Double
    Dim itMax As Long, tol As Double
    p = UBound(x, 2): itMax = CLng(Param("iter_max")): tol = CDbl(Param("tolerance"))
    ReDim beta(1 To p): ReDim w(1 To n): ReDim z(1 To n): ReDim mu(1 To n): ReDim journal(1 To itMax)
    For r = 1 To n: sy = sy + y(r): se = se + Exp(off(r)): Next r
    beta(1) = Log(sy / se)
    nit = 0
    For t = 1 To itMax
        For r = 1 To n
            xb = Lineaire(x, beta, r, p)
            mu(r) = Exp(off(r) + xb)
            z(r) = xb + (y(r) - mu(r)) / mu(r)
            w(r) = mu(r)
        Next r
        ProduitsIRLS x, w, z, n, p, a, b
        Resoudre a, b, p, beta
        dev = 0
        For r = 1 To n
            mu(r) = Exp(off(r) + Lineaire(x, beta, r, p))
            If y(r) > 0 Then dev = dev + y(r) * Log(y(r) / mu(r))
            dev = dev - (y(r) - mu(r))
        Next r
        dev = 2 * dev
        nit = t: journal(t) = dev
        If t >= 2 Then
            If Abs(dev - devAnc) / (Abs(dev) + 0.1) < tol Then Exit For
        End If
        devAnc = dev
    Next t
    ProduitsIRLS x, mu, z, n, p, a, b
    InverserMatrice a, p, inv
    ReDim vinv(1 To p)
    For r = 1 To p: vinv(r) = inv(r, r): Next r
End Sub

' ---------------------------------------------------------------------
' IRLS Gamma, lien log, poids a priori w
' ---------------------------------------------------------------------
Public Sub AjusterGamma(x() As Double, y() As Double, wp() As Double, ByVal n As Long, beta() As Double, _
                        vinv() As Double, dev As Double, journal() As Double, nit As Long, mu() As Double)
    Dim p As Long, r As Long, t As Long, swy As Double, sw As Double, eta As Double
    Dim z() As Double, a() As Double, b() As Double, inv() As Double, devAnc As Double
    Dim itMax As Long, tol As Double
    p = UBound(x, 2): itMax = CLng(Param("iter_max")): tol = CDbl(Param("tolerance"))
    ReDim beta(1 To p): ReDim z(1 To n): ReDim mu(1 To n): ReDim journal(1 To itMax)
    For r = 1 To n: swy = swy + wp(r) * y(r): sw = sw + wp(r): Next r
    beta(1) = Log(swy / sw)
    nit = 0
    For t = 1 To itMax
        For r = 1 To n
            eta = Lineaire(x, beta, r, p)
            mu(r) = Exp(eta)
            z(r) = eta + (y(r) - mu(r)) / mu(r)
        Next r
        ProduitsIRLS x, wp, z, n, p, a, b
        Resoudre a, b, p, beta
        dev = 0
        For r = 1 To n
            mu(r) = Exp(Lineaire(x, beta, r, p))
            dev = dev + wp(r) * (-Log(y(r) / mu(r)) + (y(r) - mu(r)) / mu(r))
        Next r
        dev = 2 * dev
        nit = t: journal(t) = dev
        If t >= 2 Then
            If Abs(dev - devAnc) / (Abs(dev) + 0.1) < tol Then Exit For
        End If
        devAnc = dev
    Next t
    ProduitsIRLS x, wp, z, n, p, a, b
    InverserMatrice a, p, inv
    ReDim vinv(1 To p)
    For r = 1 To p: vinv(r) = inv(r, r): Next r
End Sub

' ---------------------------------------------------------------------
' �tape 09 a : colonnes de classes et de cellule dans Contrats
' ---------------------------------------------------------------------
Public Sub Etape09Colonnes()
    Dim ws As Worksheet, vars() As Long, nv As Long, k As Long, v As String, c As Long, n As String
    Dim f As String, ent() As Variant, noms() As Variant
    Set ws = Feuille(F_CONTRATS)
    n = CStr(gLigC)
    nv = VariablesRetenues(vars)
    For k = 1 To nv
        v = Candidate(vars(k))
        c = COL_C_CLASSES + k - 1
        EntetesTable ws, 1, c, Array("cl_" & v)
        DefinirNom "c_cl_" & v, ws.Range(ws.Cells(2, c), ws.Cells(gLigC, c))
        If EstOrdinale(v) Then
            f = "=INDEX(bornes_" & v & "_classe,MATCH(" & ColSource(vars(k)) & "2,bornes_" & v & "_min,1))"
        Else
            f = "=INDEX(bornes_" & v & "_classe,MATCH(" & ColSource(vars(k)) & "2,bornes_" & v & "_mod,0))"
        End If
        ws.Range(ws.Cells(2, c), ws.Cells(gLigC, c)).Formula = f
    Next k
    c = COL_C_CLASSES + nv
    f = "="
    For k = 1 To nv
        If k > 1 Then f = f & "&""|""&"
        f = f & LettreCol(COL_C_CLASSES + k - 1) & "2"
    Next k
    ent = Array("cellule", "freq_pred", "nb_pred", "cout_pred", "pp0", "pp")
    noms = Array("c_cellule", "c_freq_pred", "c_nb_pred", "c_cout_pred", "c_pp0", "c_pp")
    EntetesTable ws, 1, c, ent
    NommerColonnes ws, gLigC, noms, c
    ws.Range(ws.Cells(2, c), ws.Cells(gLigC, c)).Formula = f
End Sub

Public Function ColContrats(ByVal nom As String) As Long
    ColContrats = PlageNom(nom).Column
End Function

' Somme des recherches de coefficients d'un mod�le pour une ligne (une par variable retenue)
Public Function SommeCoefs(ByVal prefixe As String, refs As Variant, vars() As Long, ByVal nv As Long) As String
    Dim k As Long, s As String
    For k = 1 To nv
        s = s & "+IFERROR(INDEX(" & prefixe & "_coef,MATCH(""" & Candidate(vars(k)) & "|""&" & refs(k) & "," & _
            prefixe & "_cle,0)),0)"
    Next k
    SommeCoefs = s
End Function

' ---------------------------------------------------------------------
' �tape 09 b : feuille Cellules (cellules pr�sentes parmi les lignes � E > 0)
' ---------------------------------------------------------------------
Public Sub Etape09Cellules()
    Dim ws As Worksheet, vars() As Long, nv As Long, v As Variant, r As Long, k As Long, i As Long
    Dim d As Object, cle As String, nc As Long, cles() As Double, idx() As Long, lib() As String
    Dim sortie() As Variant, cF As Long, n As String, ent As Variant, cid As Long
    nv = VariablesRetenues(vars)
    v = Feuille(F_CONTRATS).Range(Feuille(F_CONTRATS).Cells(2, COL_C_CLASSES), _
        Feuille(F_CONTRATS).Cells(gLigC, COL_C_CLASSES + nv - 1)).Value2
    Dim expo As Variant
    expo = PlageNom("c_expo").Value2
    Set d = Dico()
    ReDim cles(1 To 1000): ReDim lib(1 To 1000, 1 To nv)
    For r = 1 To UBound(v, 1)
        If expo(r, 1) > 0 Then
            cle = ""
            For k = 1 To nv: cle = cle & CStr(v(r, k)) & "|": Next k
            If Not d.Exists(cle) Then
                nc = nc + 1: d.Add cle, nc
                cles(nc) = 0
                For k = 1 To nv
                    lib(nc, k) = CStr(v(r, k))
                    cles(nc) = cles(nc) * BASE_CLE_CELLULE + IndiceClasseLibelle(vars(k), lib(nc, k))
                Next k
            End If
        End If
    Next r
    ReDim idx(1 To nc)
    For i = 1 To nc: idx(i) = i: Next i
    TriFusion cles, idx, nc
    ReDim sortie(1 To nc, 1 To nv + 1)
    For i = 1 To nc
        cid = idx(i)
        For k = 1 To nv
            sortie(i, k + 1) = "'" & lib(cid, k)
            If k > 1 Then sortie(i, 1) = sortie(i, 1) & "|"
            sortie(i, 1) = sortie(i, 1) & lib(cid, k)
        Next k
        sortie(i, 1) = "'" & sortie(i, 1)
    Next i
    Set ws = NouvelleFeuille(F_CELLULES)
    ReDim ent(0 To nv)
    ent(0) = "cellule"
    For k = 1 To nv: ent(k) = Candidate(vars(k)): Next k
    EntetesTable ws, 1, 1, ent
    ws.Range("A2").Resize(nc, nv + 1).Value2 = sortie
    cF = nv + 2: n = CStr(nc + 1)
    EntetesTable ws, 1, cF, Array("exposition", "e_crm", "nb_sin", "charge_ecr", "nb_pred", "cout_moyen", "cout_pred")
    ws.Range(ws.Cells(2, cF), ws.Cells(nc + 1, cF)).Formula = "=SUMIFS(c_expo,c_cellule,$A2)"
    ws.Range(ws.Cells(2, cF + 1), ws.Cells(nc + 1, cF + 1)).Formula = "=SUMIFS(c_e_crm,c_cellule,$A2)"
    ws.Range(ws.Cells(2, cF + 2), ws.Cells(nc + 1, cF + 2)).Formula = "=SUMIFS(c_nb_sin,c_cellule,$A2)"
    ws.Range(ws.Cells(2, cF + 3), ws.Cells(nc + 1, cF + 3)).Formula = "=SUMIFS(c_charge_ecr,c_cellule,$A2)"
    ws.Range(ws.Cells(2, cF + 5), ws.Cells(nc + 1, cF + 5)).Formula = _
        "=IF(" & LettreCol(cF + 2) & "2>0," & LettreCol(cF + 3) & "2/" & LettreCol(cF + 2) & "2,"""")"
    NommerColonnes ws, nc + 1, Array("cel_cle"), 1
    NommerColonnes ws, nc + 1, Array("cel_E", "cel_Es", "cel_N", "cel_charge", "cel_pred", "cel_cout", "cel_cout_pred"), cF
    ws.Range(ws.Cells(2, cF), ws.Cells(nc + 1, cF + 1)).NumberFormat = FormatExpo()
    ws.Range(ws.Cells(2, cF + 3), ws.Cells(nc + 1, cF + 6)).NumberFormat = FormatMontant()
    ws.Range(ws.Cells(2, cF + 4), ws.Cells(nc + 1, cF + 4)).NumberFormat = "0.000"
End Sub

Public Function IndiceClasseLibelle(ByVal i As Long, ByVal lib As String) As Long
    Dim k As Long
    IndiceClasseLibelle = 0
    For k = 1 To gNbCl(i)
        If gClLib(i, k) = lib Then IndiceClasseLibelle = k: Exit Function
    Next k
End Function

' Lecture des cellules : indices de classes, colonnes F � K
Private Function LireCellules(vars() As Long, ByVal nv As Long, cc() As Long, val As Variant) As Long
    Dim ws As Worksheet, n As Long, lb As Variant, r As Long, k As Long
    Set ws = Feuille(F_CELLULES)
    n = PlageNom("cel_cle").Rows.Count
    lb = ws.Range("A2").Resize(n, nv + 1).Value2
    val = ws.Cells(2, nv + 2).Resize(n, 7).Value2
    ReDim cc(1 To n, 0 To NB_CAND - 1)
    For r = 1 To n
        For k = 1 To nv
            cc(r, vars(k)) = IndiceClasseLibelle(vars(k), CStr(lb(r, k + 1)))
        Next k
    Next r
    LireCellules = n
End Function

' ---------------------------------------------------------------------
' �tape 09 c : ajustements et feuilles GLM_Frequence, GLM_Cout
' ---------------------------------------------------------------------
Public Sub Etape09Modeles()
    Dim vars() As Long, nv As Long, cc() As Long, val As Variant, n As Long, r As Long, x() As Double
    Dim y() As Double, off() As Double, beta() As Double, vinv() As Double, dev As Double, jr() As Double
    Dim nit As Long, mu() As Double
    nv = VariablesRetenues(vars)
    n = LireCellules(vars, nv, cc, val)
    MatriceX cc, n, vars, nv, x
    ReDim y(1 To n): ReDim off(1 To n)
    For r = 1 To n: y(r) = val(r, 3): off(r) = Log(val(r, 2)): Next r
    AjusterPoisson x, y, off, n, beta, vinv, dev, jr, nit, mu
    EcrireModele F_GLMF, "glmf", vars, nv, beta, vinv, jr, nit
    Feuille(F_CELLULES).Range("A2").Offset(0, nv + 5).Resize(n, 1).Formula = _
        "=" & LettreCol(nv + 3) & "2*EXP(glmf_b0" & SommeCoefs("glmf", RefsCellules(nv), vars, nv) & ")"
    AjusterCout vars, nv
    FormulesPredictions vars, nv
    SyntheseFrequence
End Sub

Private Function RefsCellules(ByVal nv As Long) As Variant
    Dim r() As String, k As Long
    ReDim r(1 To nv)
    For k = 1 To nv: r(k) = "$" & LettreCol(k + 1) & "2": Next k
    RefsCellules = r
End Function

Private Function RefsContrats(ByVal nv As Long) As Variant
    Dim r() As String, k As Long
    ReDim r(1 To nv)
    For k = 1 To nv: r(k) = "$" & LettreCol(COL_C_CLASSES + k - 1) & "2": Next k
    RefsContrats = r
End Function

' Gamma sur les cellules sinistr�es (relanc� seul au changement de seuil)
Public Sub AjusterCout(vars() As Long, ByVal nv As Long)
    Dim cc() As Long, val As Variant, n As Long, r As Long, m As Long, x() As Double, cs() As Long
    Dim y() As Double, w() As Double, beta() As Double, vinv() As Double, dev As Double, jr() As Double
    Dim nit As Long, mu() As Double, k As Long
    n = LireCellules(vars, nv, cc, val)
    ReDim cs(1 To n, 0 To NB_CAND - 1): ReDim y(1 To n): ReDim w(1 To n)
    For r = 1 To n
        If val(r, 3) > 0 Then
            m = m + 1
            For k = 0 To NB_CAND - 1: cs(m, k) = cc(r, k): Next k
            y(m) = val(r, 4) / val(r, 3): w(m) = val(r, 3)
        End If
    Next r
    MatriceX cs, m, vars, nv, x
    AjusterGamma x, y, w, m, beta, vinv, dev, jr, nit, mu
    EcrireModele F_GLMC, "glmc", vars, nv, beta, vinv, jr, nit
    Feuille(F_CELLULES).Range("A2").Offset(0, nv + 7).Resize(n, 1).Formula = _
        "=EXP(glmc_g0" & SommeCoefs("glmc", RefsCellules(nv), vars, nv) & ")"
    SyntheseCout
End Sub

' �crit (ou r��crit) une feuille de mod�le : param�tres, journal IRLS
Private Sub EcrireModele(ByVal nomF As String, ByVal pre As String, vars() As Long, ByVal nv As Long, _
                         beta() As Double, vinv() As Double, jr() As Double, ByVal nit As Long)
    Dim ws As Worksheet, p As Long, r As Long, k As Long, q As Long, s() As Variant, j() As Variant
    If FeuilleExiste(nomF) Then Set ws = Feuille(nomF) Else Set ws = NouvelleFeuille(nomF)
    ws.Range("A:J").ClearContents
    p = UBound(beta)
    EntetesTable ws, 1, 1, Array("parametre", "cle", "coefficient", "relativite", "erreur_std", "z", "p_value", "var_inv")
    ReDim s(1 To p, 1 To 2)
    s(1, 1) = "Intercept": s(1, 2) = "Intercept"
    r = 1
    For k = 1 To nv
        For q = 1 To gNbCl(vars(k))
            If q <> gClRef(vars(k)) Then
                r = r + 1
                s(r, 1) = "'" & NomVariable(Candidate(vars(k))) & " " & gClLib(vars(k), q)
                s(r, 2) = "'" & Candidate(vars(k)) & "|" & gClLib(vars(k), q)
            End If
        Next q
    Next k
    ws.Range("A2").Resize(p, 2).Value2 = s
    For r = 1 To p
        ws.Cells(r + 1, 3).Value2 = beta(r)
        ws.Cells(r + 1, 8).Value2 = vinv(r)
    Next r
    ws.Range("D2").Resize(p, 1).Formula = "=EXP(C2)"
    If pre = "glmf" Then
        ws.Range("E2").Resize(p, 1).Formula = "=SQRT(H2)"
    Else
        ws.Range("E2").Resize(p, 1).Formula = "=SQRT(glmc_phi*H2)"
    End If
    ws.Range("F2").Resize(p, 1).Formula = "=C2/E2"
    ws.Range("G2").Resize(p, 1).Formula = "=2*(1-NORM.S.DIST(ABS(F2),TRUE))"
    ws.Range("C2").Resize(p, 1).NumberFormat = "0.000000"
    ws.Range("D2").Resize(p, 1).NumberFormat = FormatRel()
    ws.Range("E2").Resize(p, 3).NumberFormat = FormatCoef()
    If pre = "glmf" Then DefinirNom "glmf_b0", ws.Range("C2") Else DefinirNom "glmc_g0", ws.Range("C2")
    DefinirNom pre & "_cle", ws.Range("B3").Resize(Application.Max(p - 1, 1), 1)
    DefinirNom pre & "_coef", ws.Range("C3").Resize(Application.Max(p - 1, 1), 1)
    DefinirNom pre & "_param", ws.Range("A2").Resize(p, 1)
    EntetesTable ws, 1, COL_JOURNAL, Array("iteration", "deviance")
    ReDim j(1 To nit, 1 To 2)
    For r = 1 To nit: j(r, 1) = r: j(r, 2) = jr(r): Next r
    ws.Cells(2, COL_JOURNAL).Resize(nit, 2).Value2 = j
    DefinirNom pre & "_journal", ws.Cells(2, COL_JOURNAL).Resize(CLng(Param("iter_max")), 1)
End Sub

Public Function NomVariable(ByVal v As String) As String
    Select Case v
        Case "age": NomVariable = "�ge"
        Case "puissance_cv": NomVariable = "puissance"
        Case "anc_permis": NomVariable = "permis"
        Case "anc_vehicule": NomVariable = "v�hicule"
        Case Else: NomVariable = v
    End Select
End Function

' Pr�dictions sur Contrats (AF:AH) et Sinistres (P:Q)
Private Sub FormulesPredictions(vars() As Long, ByVal nv As Long)
    Dim ws As Worksheet, wsn As Worksheet, c As Long, n As String
    Set ws = Feuille(F_CONTRATS): Set wsn = Feuille(F_SINISTRES)
    c = COL_C_CLASSES + nv + 1
    ws.Range(ws.Cells(2, c), ws.Cells(gLigC, c)).Formula = "=U2*EXP(glmf_b0" & SommeCoefs("glmf", RefsContrats(nv), vars, nv) & ")"
    ws.Range(ws.Cells(2, c + 1), ws.Cells(gLigC, c + 1)).Formula = "=P2*" & LettreCol(c) & "2"
    ws.Range(ws.Cells(2, c + 2), ws.Cells(gLigC, c + 2)).Formula = "=EXP(glmc_g0" & SommeCoefs("glmc", RefsContrats(nv), vars, nv) & ")"
    ws.Range(ws.Cells(2, c), ws.Cells(gLigC, c + 1)).NumberFormat = "0.00000"
    ws.Range(ws.Cells(2, c + 2), ws.Cells(gLigC, c + 4)).NumberFormat = FormatMontant()
    n = CStr(gLigS)
    EntetesTable wsn, 1, 16, Array("cellule", "cout_pred")
    NommerColonnes wsn, gLigS, Array("s_cellule", "s_cout_pred"), 16
    wsn.Range("P2:P" & n).Formula = "=IF(K2=1,INDEX(c_cellule,MATCH(I2,c_cle,0)),"""")"
    wsn.Range("Q2:Q" & n).Formula = "=IF(K2=1,INDEX(c_cout_pred,MATCH(I2,c_cle,0)),"""")"
    wsn.Range("Q2:Q" & n).NumberFormat = FormatMontant()
End Sub

Private Sub SyntheseFrequence()
    Dim ws As Worksheet, lib As Variant, frm As Variant, nm As Variant, mat As Variant, i As Long
    Set ws = Feuille(F_GLMF)
    EntetesTable ws, 1, COL_SYNTHESE, Array("indicateur", "valeur")
    lib = Array("D�viance (cellules)", "D�viance nulle (cellules)", "D�viance (lignes)", "D�viance nulle (lignes)", _
        "D�viance expliqu�e (lignes)", "It�rations IRLS", "Param�tres", "Cellules", "Fr�quence de base")
    frm = Array("=2*SUM(IF(cel_N>0,cel_N*LN(cel_N/cel_pred),0)-(cel_N-cel_pred))", _
        "=2*SUM(IF(cel_N>0,cel_N*LN(cel_N/(cel_Es*expl_freq_crm)),0)-(cel_N-cel_Es*expl_freq_crm))", _
        "=2*SUM(IF(c_nb_sin>0,c_nb_sin*LN(c_nb_sin/c_nb_pred),0)-(c_nb_sin-c_nb_pred))", _
        "=2*SUM(IF(c_nb_sin>0,c_nb_sin*LN(c_nb_sin/(c_e_crm*expl_freq_crm)),0)-(c_nb_sin-c_e_crm*expl_freq_crm))", _
        "=1-M4/M5", "=COUNT(glmf_journal)", "=COUNT(GLM_Frequence!C:C)", "=COUNTIF(cel_E,"">0"")", "=EXP(glmf_b0)")
    mat = Array(True, True, True, True, False, False, False, False, False)
    nm = Array("glmf_dev_cel", "glmf_dev0_cel", "glmf_dev_lig", "glmf_dev0_lig", "glmf_dev_expl", "glmf_iter", _
        "glmf_nparam", "glmf_ncel", "glmf_base")
    For i = 0 To UBound(lib)
        ws.Cells(i + 2, COL_SYNTHESE).Value2 = lib(i)
        If mat(i) Then ws.Cells(i + 2, COL_SYNTHESE + 1).FormulaArray = frm(i) Else ws.Cells(i + 2, COL_SYNTHESE + 1).Formula = frm(i)
        DefinirNom CStr(nm(i)), ws.Cells(i + 2, COL_SYNTHESE + 1)
    Next i
    FormaterSynthese ws.Range(ws.Cells(2, COL_SYNTHESE + 1), ws.Cells(UBound(lib) + 2, COL_SYNTHESE + 1))
    RatiosCRM ws
End Sub

Private Sub SyntheseCout()
    Dim ws As Worksheet, lib As Variant, frm As Variant, nm As Variant, mat As Variant, i As Long
    Set ws = Feuille(F_GLMC)
    EntetesTable ws, 1, COL_SYNTHESE, Array("indicateur", "valeur")
    lib = Array("D�viance (cellules)", "D�viance nulle (cellules)", "D�viance (sinistres)", "D�viance nulle (sinistres)", _
        "D�viance expliqu�e (sinistres)", "It�rations IRLS", "Param�tres", "Cellules", "Co�t de base", "Dispersion phi")
    frm = Array("=2*SUM(IF(cel_N>0,cel_N*(-LN(cel_cout/cel_cout_pred)+(cel_cout-cel_cout_pred)/cel_cout_pred),0))", _
        "=2*SUM(IF(cel_N>0,cel_N*(-LN(cel_cout/expl_cout)+(cel_cout-expl_cout)/expl_cout),0))", _
        "=2*SUM(IF(s_retenu=1,-LN(s_charge_ecr/s_cout_pred)+(s_charge_ecr-s_cout_pred)/s_cout_pred,0))", _
        "=2*SUM(IF(s_retenu=1,-LN(s_charge_ecr/expl_cout)+(s_charge_ecr-expl_cout)/expl_cout,0))", _
        "=1-M4/M5", "=COUNT(glmc_journal)", "=COUNT(GLM_Cout!C:C)", "=COUNTIF(cel_N,"">0"")", "=EXP(glmc_g0)", _
        "=SUM(IF(s_retenu=1,((s_charge_ecr-s_cout_pred)/s_cout_pred)^2,0))/(COUNTIF(s_retenu,1)-M8)")
    mat = Array(True, True, True, True, False, False, False, False, False, True)
    nm = Array("glmc_dev_cel", "glmc_dev0_cel", "glmc_dev_sin", "glmc_dev0_sin", "glmc_dev_expl", "glmc_iter", _
        "glmc_nparam", "glmc_ncel", "glmc_base", "glmc_phi")
    For i = 0 To UBound(lib)
        ws.Cells(i + 2, COL_SYNTHESE).Value2 = lib(i)
        If mat(i) Then ws.Cells(i + 2, COL_SYNTHESE + 1).FormulaArray = frm(i) Else ws.Cells(i + 2, COL_SYNTHESE + 1).Formula = frm(i)
        DefinirNom CStr(nm(i)), ws.Cells(i + 2, COL_SYNTHESE + 1)
    Next i
    FormaterSynthese ws.Range(ws.Cells(2, COL_SYNTHESE + 1), ws.Cells(UBound(lib) + 2, COL_SYNTHESE + 1))
End Sub

' Ratios observ� / pr�dit par classe de CRM (Parametres J:K)
Private Sub RatiosCRM(ByVal ws As Worksheet)
    Dim wp As Worksheet, n As Long, r As Long, c As Long
    Set wp = Feuille(F_PARAMETRES)
    n = wp.Cells(wp.Rows.Count, 10).End(xlUp).Row - 1
    c = COL_RATIOS_CRM
    EntetesTable ws, 1, c, Array("classe_crm", "borne", "borne_suivante", "nb_sin", "nb_pred", "ratio")
    For r = 2 To n + 1
        ws.Cells(r, c).Formula = "=Parametres!K" & r
        ws.Cells(r, c + 1).Formula = "=Parametres!J" & r
        If r <= n Then ws.Cells(r, c + 2).Formula = "=Parametres!J" & (r + 1)
    Next r
    ws.Range(ws.Cells(2, c + 3), ws.Cells(n + 1, c + 3)).Formula = "=IF(V2="""",SUMIFS(c_nb_sin,c_crm_c,"">=""&U2)," & _
        "SUMIFS(c_nb_sin,c_crm_c,"">=""&U2,c_crm_c,""<""&V2))"
    ws.Range(ws.Cells(2, c + 4), ws.Cells(n + 1, c + 4)).Formula = "=IF(V2="""",SUMIFS(c_nb_pred,c_crm_c,"">=""&U2)," & _
        "SUMIFS(c_nb_pred,c_crm_c,"">=""&U2,c_crm_c,""<""&V2))"
    ws.Range(ws.Cells(2, c + 5), ws.Cells(n + 1, c + 5)).Formula = "=W2/X2"
    ws.Range(ws.Cells(2, c + 5), ws.Cells(n + 1, c + 5)).NumberFormat = "0.0000"
    DefinirNom "crm_classe", ws.Range(ws.Cells(2, c), ws.Cells(n + 1, c))
    DefinirNom "crm_ratio", ws.Range(ws.Cells(2, c + 5), ws.Cells(n + 1, c + 5))
    AjouterControle 9, 1, "Sinistres pr�dits = sinistres observ�s", "=ABS(SUM(c_nb_pred)-SUM(c_nb_sin))<0.01", _
        False, "=SUM(c_nb_sin)"
    AjouterControle 9, 2, "Convergence IRLS atteinte", "=AND(glmf_iter<iter_max,glmc_iter<iter_max)", False, _
        "=glmf_iter", "=glmc_iter"
    AjouterControle 9, 3, "Observ� / pr�dit dans les bornes par classe de CRM", _
        "=AND(MIN(crm_ratio)>=ratio_crm_min,MAX(crm_ratio)<=ratio_crm_max)", False, "=ratio_crm_min", "=ratio_crm_max"
End Sub

' ---------------------------------------------------------------------
' Quintiles (VBA, valeurs) : tri fusion stable
' ---------------------------------------------------------------------
Public Sub CalculerQuintiles()
    Dim e As Variant, nb As Variant, fp As Variant, np As Variant, n As Long, r As Long, m As Long
    Dim cles() As Double, idx() As Long, ee() As Double, oo() As Double, pp() As Double
    Dim tot As Double, cum As Double, q As Long, sO(1 To 5) As Double, sP(1 To 5) As Double, sW(1 To 5) As Double
    e = PlageNom("c_expo").Value2: nb = PlageNom("c_nb_sin").Value2
    fp = PlageNom("c_freq_pred").Value2: np = PlageNom("c_nb_pred").Value2
    n = UBound(e, 1)
    ReDim cles(1 To n): ReDim idx(1 To n): ReDim ee(1 To n): ReDim oo(1 To n): ReDim pp(1 To n)
    For r = 1 To n
        If e(r, 1) > 0 Then
            m = m + 1
            cles(m) = fp(r, 1): ee(m) = e(r, 1): oo(m) = nb(r, 1): pp(m) = np(r, 1): idx(m) = m
            tot = tot + e(r, 1)
        End If
    Next r
    TriFusion cles, idx, m
    For r = 1 To m
        q = 1 + Int(NB_QUINTILES * (cum + ee(idx(r)) / 2) / tot)
        If q > NB_QUINTILES Then q = NB_QUINTILES
        cum = cum + ee(idx(r))
        sO(q) = sO(q) + oo(idx(r)): sP(q) = sP(q) + pp(idx(r)): sW(q) = sW(q) + ee(idx(r))
    Next r
    EcrireQuintiles Feuille(F_GLMF), "glmf", sO, sP, sW, True
    QuintilesCout
End Sub

Private Sub QuintilesCout()
    Dim ret As Variant, ch As Variant, cp As Variant, n As Long, r As Long, m As Long, q As Long
    Dim cles() As Double, idx() As Long, oo() As Double, sO(1 To 5) As Double, sP(1 To 5) As Double, sW(1 To 5) As Double
    ret = PlageNom("s_retenu").Value2: ch = PlageNom("s_charge_ecr").Value2: cp = PlageNom("s_cout_pred").Value2
    n = UBound(ret, 1)
    ReDim cles(1 To n): ReDim idx(1 To n): ReDim oo(1 To n)
    For r = 1 To n
        If ret(r, 1) = 1 Then
            m = m + 1
            cles(m) = cp(r, 1): oo(m) = ch(r, 1): idx(m) = m
        End If
    Next r
    TriFusion cles, idx, m
    For r = 1 To m
        q = 1 + Int(NB_QUINTILES * (r - 0.5) / m)
        If q > NB_QUINTILES Then q = NB_QUINTILES
        sO(q) = sO(q) + oo(idx(r)): sP(q) = sP(q) + cles(idx(r)): sW(q) = sW(q) + 1
    Next r
    EcrireQuintiles Feuille(F_GLMC), "glmc", sO, sP, sW, False
End Sub

Private Sub EcrireQuintiles(ByVal ws As Worksheet, ByVal pre As String, sO() As Double, sP() As Double, _
                            sW() As Double, ByVal frequence As Boolean)
    Dim s(1 To 5, 1 To 4) As Variant, q As Long
    EntetesTable ws, 1, COL_QUINTILES, Array("quintile", "observe", "predit", "poids")
    For q = 1 To NB_QUINTILES
        s(q, 1) = q
        If sW(q) > 0 Then s(q, 2) = sO(q) / sW(q): s(q, 3) = sP(q) / sW(q)
        s(q, 4) = sW(q)
    Next q
    ws.Cells(2, COL_QUINTILES).Resize(NB_QUINTILES, 4).Value2 = s
    If frequence Then
        ws.Cells(2, COL_QUINTILES + 1).Resize(NB_QUINTILES, 2).NumberFormat = "0.000%"
    Else
        ws.Cells(2, COL_QUINTILES + 1).Resize(NB_QUINTILES, 2).NumberFormat = FormatMontant()
    End If
    DefinirNom pre & "_q_obs", ws.Cells(2, COL_QUINTILES + 1).Resize(NB_QUINTILES, 1)
    DefinirNom pre & "_q_pred", ws.Cells(2, COL_QUINTILES + 2).Resize(NB_QUINTILES, 1)
End Sub

' ---------------------------------------------------------------------
' �tape 10 : sinistres graves
' ---------------------------------------------------------------------
Public Sub Etape10Liste()
    Dim ws As Worksheet, id As Variant, ret As Variant, cr As Variant, u As Double, n As Long, r As Long, m As Long
    Dim cles() As Double, idx() As Long, ids() As String, s() As Variant
    BornesDonnees
    Set ws = Feuille(F_GRAVES)
    ws.Range("A1:F" & gLigS + 1).Clear
    EntetesTable ws, 1, 1, Array("id_sinistre", "garantie", "exercice", "charge_reval", "ln_x_u", "excedent")
    id = PlageNom("s_id").Value2: ret = PlageNom("s_retenu").Value2: cr = PlageNom("s_charge_rev").Value2
    u = CDbl(Param("seuil_ecretement"))
    n = UBound(id, 1)
    ReDim cles(1 To n): ReDim idx(1 To n): ReDim ids(1 To n)
    For r = 1 To n
        If ret(r, 1) = 1 And cr(r, 1) > u Then
            m = m + 1
            cles(m) = -cr(r, 1): ids(m) = CStr(id(r, 1)): idx(m) = m
        End If
    Next r
    If m = 0 Then Exit Sub
    TriFusion cles, idx, m
    ReDim s(1 To m, 1 To 1)
    For r = 1 To m: s(r, 1) = ids(idx(r)): Next r
    ws.Range("A2").Resize(m, 1).Value2 = s
    ws.Range("B2").Resize(m, 1).Formula = "=INDEX(s_garantie,MATCH(A2,s_id,0))"
    ws.Range("C2").Resize(m, 1).Formula = "=INDEX(s_exercice,MATCH(A2,s_id,0))"
    ws.Range("D2").Resize(m, 1).Formula = "=INDEX(s_charge_rev,MATCH(A2,s_id,0))"
    ws.Range("E2").Resize(m, 1).Formula = "=LN(D2/seuil_ecretement)"
    ws.Range("F2").Resize(m, 1).Formula = "=D2-seuil_ecretement"
    ws.Range("D2").Resize(m, 1).NumberFormat = FormatMontant()
    ws.Range("F2").Resize(m, 1).NumberFormat = FormatMontant()
    ws.Range("E2").Resize(m, 1).NumberFormat = FormatCoef()
End Sub

Public Sub Etape10Synthese()
    Dim ws As Worksheet, lib As Variant, frm As Variant, i As Long, n As String, mult As Variant
    Set ws = Feuille(F_GRAVES)
    n = CStr(gLigS)
    DefinirNom "gr_id", ws.Range("A2:A" & n)
    DefinirNom "gr_charge", ws.Range("D2:D" & n)
    DefinirNom "gr_ln", ws.Range("E2:E" & n)
    DefinirNom "gr_excedent", ws.Range("F2:F" & n)
    EntetesTable ws, 1, 13, Array("indicateur", "valeur")
    lib = Array("n_u", "alpha", "alpha_se", "ic_bas", "ic_haut", "e_u", "e_emp", "kappa_emp", "kappa", "ecart_kappa")
    frm = Array("=SUM(s_grave)", "=n_u/SUM(gr_ln)", "=alpha/SQRT(n_u)", "=alpha-" & Z_IC & "*alpha_se", _
        "=alpha+" & Z_IC & "*alpha_se", "=IF(alpha>1,seuil_ecretement/(alpha-1),NA())", "=SUM(gr_excedent)/n_u", _
        "=SUM(s_charge_rev)/SUM(s_charge_ecr)", "=IF(alpha>1,1+n_u*e_u/SUM(s_charge_ecr),kappa_emp)", "=kappa/kappa_emp-1")
    For i = 0 To UBound(lib)
        ws.Cells(i + 2, 13).Value2 = lib(i)
        DefinirNom CStr(lib(i)), ws.Cells(i + 2, 14)
    Next i
    For i = 0 To UBound(lib)
        ws.Cells(i + 2, 14).Formula = frm(i)
    Next i
    FormaterSynthese ws.Range("N2:N11")
    EntetesTable ws, 13, 13, Array("multiple", "x", "observee", "pareto")
    mult = Split(MULTIPLES_SURVIE, ",")
    For i = 0 To UBound(mult)
        ws.Cells(14 + i, 13).Value2 = Val(mult(i))
    Next i
    ws.Range("N14:N18").Formula = "=M14*seuil_ecretement"
    ws.Range("O14:O18").Formula = "=COUNTIF(gr_charge,"">""&N14)/n_u"
    ws.Range("P14:P18").Formula = "=(seuil_ecretement/N14)^alpha"
    ws.Range("O14:P18").NumberFormat = "0.0000"
    DefinirNom "surv_obs", ws.Range("O14:O18")
    DefinirNom "surv_par", ws.Range("P14:P18")
    AjouterControle 10, 1, "Borne basse de l" & Apos() & "IC de alpha au-dessus de 1", "=ic_bas>1"
    AjouterControle 10, 2, "Kappa Pareto proche du kappa empirique", "=ABS(ecart_kappa)<ecart_kappa_max", False, _
        "=ecart_kappa", "=ecart_kappa_max"
    AjouterControle 10, 3, "Survie observ�e proche de la Pareto", "=MAX(ABS(surv_obs-surv_par))<ecart_survie_max", _
        True, "=ecart_survie_max"
End Sub

' Prime pure avant calage (d�pend de kappa) : Contrats pp0
Public Sub FormulePrimePure0()
    Dim ws As Worksheet, c As Long
    Set ws = Feuille(F_CONTRATS)
    c = ColContrats("c_pp0")
    ws.Range(ws.Cells(2, c), ws.Cells(gLigC, c)).Formula = "=" & LettreCol(c - 3) & "2*" & LettreCol(c - 1) & "2*kappa"
End Sub

' Changement de seuil : relance de l'IRLS Gamma et de la liste des graves (6.0)
Public Sub RelancerCoutEtGraves()
    Dim vars() As Long, nv As Long
    BornesDonnees
    If gNbCl(0) = 0 Then ChargerClassesDepuisFeuilles
    nv = VariablesRetenues(vars)
    AjusterCout vars, nv
    Etape10Liste
End Sub
