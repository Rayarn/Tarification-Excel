Attribute VB_Name = "modContenu"
Option Explicit
' =====================================================================
' modContenu : tous les textes affich�s (R12), section 11 du cahier.
' Les valeurs dynamiques sont pass�es en argument, d�j� format�es (R8).
' =====================================================================

Private Const NB_ETAPES As Long = 11

' ---------------------------------------------------------------------
' Marque, groupes, titres, eyebrows
' ---------------------------------------------------------------------
Public Function TexteMarque() As String: TexteMarque = "PrimeLab": End Function
Public Function TexteSousMarque() As String: TexteSousMarque = "�tude tarifaire RC auto 2026": End Function
Public Function TexteBoutonCalculateur() As String: TexteBoutonCalculateur = "Calculateur de prime": End Function
Public Function TitreFormulation() As String: TitreFormulation = "Formulation": End Function
Public Function TitreControles() As String: TitreControles = "Contr�les": End Function
Public Function TexteFermer() As String: TexteFermer = "Fermer": End Function
Public Function TitreDansClasseur() As String: TitreDansClasseur = "Dans le classeur": End Function
Public Function TexteOuvrirOnglet() As String: TexteOuvrirOnglet = "Ouvrir l" & Apos() & "onglet " & Fleche(): End Function
Public Function TexteRetourPage() As String: TexteRetourPage = ChevronG() & " Retour � la page": End Function

Public Function TexteCelluleSelectionnee(ByVal adresse As String) As String
    TexteCelluleSelectionnee = "Cellule " & adresse & " s�lectionn�e"
End Function

Public Function TitreGroupe(ByVal g As Long) As String
    If g = 1 Then TitreGroupe = "PR�PARER LES DONN�ES" Else TitreGroupe = "CONSTRUIRE LE TARIF"
End Function

Public Function TitrePage(ByVal n As Long) As String
    Select Case n
        Case 0: TitrePage = "Tableau de bord"
        Case 1: TitrePage = "Import et exposition"
        Case 2: TitrePage = "Qualit� des donn�es"
        Case 3: TitrePage = "Base de mod�lisation"
        Case 4: TitrePage = "Charge ultime et inflation"
        Case 5: TitrePage = "�cr�tement"
        Case 6: TitrePage = "Analyse exploratoire"
        Case 7: TitrePage = "Classes"
        Case 8: TitrePage = "S�lection des variables"
        Case 9: TitrePage = "Mod�les GLM"
        Case 10: TitrePage = "Sinistres graves"
        Case 11: TitrePage = "R�sultats et impact"
        Case 12: TitrePage = "Calculateur de prime"
    End Select
End Function

Public Function EyebrowPage(ByVal n As Long) As String
    Select Case n
        Case 0
            EyebrowPage = "PORTEFEUILLE AUTOMOBILE " & PointMedian() & " RC " & PointMedian() & " " & _
                Param("annee_debut") & DemiTiret() & Param("annee_fin")
        Case 1 To 5: EyebrowPage = TitreGroupe(1)
        Case 6 To 11: EyebrowPage = TitreGroupe(2)
        Case Else: EyebrowPage = "TARIF RC AUTO 2026"
    End Select
End Function

Public Function TexteEtapeSur(ByVal n As Long) As String
    TexteEtapeSur = "�TAPE " & Format$(n, "00") & " / " & NB_ETAPES
End Function

Public Function IntroPage(ByVal n As Long) As String
    Select Case n
        Case 0: IntroPage = "Performance technique du portefeuille RC, charges � l" & Apos() & "ultime. Base de l" & Apos() & "�tude tarifaire 2026."
        Case 1: IntroPage = "Chargement des tables contrats et sinistres " & Param("annee_debut") & DemiTiret() & Param("annee_fin") & _
            ", typage des colonnes et calcul de l" & Apos() & "exposition de chaque ligne police " & Multiplie() & _
            " exercice sur la p�riode d" & Apos() & "observation."
        Case 2: IntroPage = "Contr�les de compl�tude, de coh�rence et d" & Apos() & "unicit� avant toute agr�gation. " & _
            "Chaque anomalie est corrig�e ou exclue, et trac�e dans l" & Apos() & "onglet Journal."
        Case 3: IntroPage = "Agr�gation des sinistres retenus au niveau ligne police " & Multiplie() & " exercice, puis " & _
            "jointure gauche sur les contrats. Chaque ligne porte exposition, nombre de sinistres et charge."
        Case 4: IntroPage = "D�veloppement des charges vues par Chain Ladder pour estimer la charge ultime de chaque " & _
            "exercice, puis revalorisation au point milieu de la p�riode d" & Apos() & "application du tarif."
        Case 5: IntroPage = "Les sinistres revaloris�s au-del� du seuil u sont plafonn�s pour stabiliser le co�t moyen " & _
            "par segment. L" & Apos() & "exc�dent est isol� puis mutualis� � l" & Apos() & "�tape Sinistres graves."
        Case 6: IntroPage = "Fr�quence et co�t moyen �cr�t� par tranche de chaque variable candidate. La fr�quence " & _
            "� CRM 1,00 retire l" & Apos() & "effet du bonus-malus, appliqu� ensuite en multiplicateur."
        Case 7: IntroPage = "Regroupement des tranches voisines en classes homog�nes et assez expos�es. Deux classes " & _
            "voisines fusionnent tant que leurs fr�quences � CRM 1,00 ne diff�rent pas significativement."
        Case 8: IntroPage = "Chaque variable est d" & Apos() & "abord test�e seule (" & Chi() & "�, V de Cram�r), puis " & _
            "confirm�e dans le GLM par le test du rapport de vraisemblance. Une variable trop li�e � une variable " & _
            "d�j� retenue est �cart�e."
        Case 9: IntroPage = "Deux GLM multiplicatifs ajust�s par IRLS sur les cellules tarifaires : Poisson pour la " & _
            "fr�quence, avec exposition et CRM en offset, Gamma pour le co�t moyen �cr�t�."
        Case 10: IntroPage = "L" & Apos() & "exc�dent au-del� du seuil suit une loi de Pareto estim�e sur les cinq " & _
            "exercices. Il est mutualis� sur tout le portefeuille par un coefficient appliqu� au co�t �cr�t�."
        Case 11: IntroPage = "Assemblage du tarif : base, relativit�s, coefficient graves, calage sur la charge cible, " & _
            "puis chargements. Impact mesur� sur les " & FormatEntier(ValeurNom("n_renouv")) & _
            " polices renouvel�es au 01/01/" & (CLng(Param("annee_fin")) + 1) & "."
        Case 12: IntroPage = "Le tarif issu de l" & Apos() & "�tude, assembl� : relativit�s GLM, coefficient graves, " & _
            "calage et chargements. Modifiez le profil et les hypoth�ses, chaque �tape du calcul se met � jour."
    End Select
End Function

' ---------------------------------------------------------------------
' Libell�s de KPI et sous-textes
' ---------------------------------------------------------------------
Public Function LibelleKPI(ByVal n As Long, ByVal k As Long) As String
    Dim t As Variant
    Select Case n
        Case 0: t = Array("Primes acquises", "Charge ultime", "S/P ultime", "Ratio combin�")
        Case 1: t = Array("Contrats", "Sinistres bruts", "Exposition", "P�riode")
        Case 2: t = Array("Doublons", "Sinistres exclus", "�ges imput�s", "CRM corrig�s")
        Case 3: t = Array("Sinistres rattach�s", "Lignes sinistr�es", "Base de mod�lisation", "Charge rattach�e")
        Case 4: t = Array("Charge vue", "IBNR", "Inflation", "Charge cible")
        Case 5: t = Array("Seuil u", "Sinistres graves", "Charge �cr�t�e", "Exc�dent")
        Case 6: t = Array("Fr�quence brute", "Fr�quence � CRM 1,00", "Co�t moyen �cr�t�", "Prime pure �cr�t�e")
        Case 7: t = Array("Exposition min.", "Classes d" & Apos() & "�ge", "Classes de puissance", "Seuil de fusion")
        Case 8: t = Array("Candidates", "Retenues", "Seuil", "Liaison max.")
        Case 9: t = Array("Fr�quence de base", "Co�t de base �cr�t�", "D�viance expliqu�e", "Param�tres")
        Case 10: t = Array("Sinistres > u", Alpha() & ChrW(770) & " Pareto", "Exc�dent moyen", "Coefficient " & Kappa())
        Case 11: t = Array("Prime pure moyenne", "�volution moyenne", "�quilibre plafonn�", "Prime TTC moyenne")
    End Select
    LibelleKPI = t(k)
End Function

' Sous-textes : a, b = valeurs d�j� format�es
Public Function SousTexteKPI(ByVal n As Long, ByVal k As Long, Optional ByVal a As String = "", _
                             Optional ByVal b As String = "") As String
    Dim s As String
    Select Case n * 10 + k
        Case 0: s = a & " ann�es-police"
        Case 1: s = "dont IBNR " & a
        Case 2: s = "vu � fin " & Param("annee_fin") & " : " & a
        Case 3: s = "dont frais " & a
        Case 10: s = "lignes " & PointMedian() & " " & a & " polices"
        Case 11: s = "avant contr�les"
        Case 12: s = "ann�es-police"
        Case 13: s = a & " exercices"
        Case 20: s = "sinistres supprim�s"
        Case 21: s = "hors p�riode, orphelins, sans suite"
        Case 22: s = "lignes " & PointMedian() & " m�diane de la zone"
        Case 23: s = "ramen�s dans [" & a & " ; " & b & "]"
        Case 30: s = a & " des sinistres retenus"
        Case 31: s = a & " des lignes"
        Case 32: s = "lignes � exposition non nulle"
        Case 33: s = "identique avant et apr�s jointure"
        Case 40: s = a & ", au 31/12/" & Param("annee_fin")
        Case 41: s = a & " de la charge vue"
        Case 42: s = "par an " & PointMedian() & " co�t des sinistres"
        Case 43: s = "ultime revaloris�e " & Int(CDbl(Param("annee_milieu_application")))
        Case 50: s = "modifiable par les puces"
        Case 51: s = a & " des sinistres"
        Case 52: s = "base du mod�le de co�t"
        Case 53: s = a & " de la charge revaloris�e"
        Case 60: s = a & " / " & b
        Case 61: s = "N / " & Sigma() & " E " & Multiplie() & " CRM"
        Case 62: s = "charge �cr�t�e / N"
        Case 63: s = "par ann�e-police"
        Case 70: s = "ann�es-police par classe"
        Case 71, 72: s = "depuis " & a & " tranches"
        Case 73: s = "|z|, niveau 10 % bilat�ral"
        Case 80: s = "le sexe est exclu d" & Apos() & "office"
        Case 81: s = a
        Case 82: s = "sur toutes les p-values"
        Case 83: s = "V entre retenues " & PointMedian() & " " & a
        Case 90: s = "CRM 1,00 " & PointMedian() & " classes de r�f�rence"
        Case 91: s = "classes de r�f�rence"
        Case 92: s = a
        Case 93: s = "par mod�le"
        Case 100: s = "sur " & a & " retenus"
        Case 101: s = "IC 95 % : " & a & " � " & b
        Case 102: s = "u / (" & Alpha() & ChrW(770) & " " & Moins() & " 1)"
        Case 103: s = "empirique : " & a
        Case 110: s = "par ann�e-police " & PointMedian() & " niveau " & Int(CDbl(Param("annee_milieu_application")))
        Case 111: s = "vs tarif en vigueur, avant plafond"
        Case 112: s = "de la prime technique"
        Case 113: s = "actuelle : " & a
    End Select
    SousTexteKPI = Replace(s, " %", Insec() & "%")
End Function

Public Function TexteDevianceModele(ByVal frequence As Boolean) As String
    If frequence Then TexteDevianceModele = "fr�quence, au niveau des lignes" Else _
        TexteDevianceModele = "co�t moyen, au niveau des sinistres"
End Function

' ---------------------------------------------------------------------
' Formules (annexe B) : libell�s affich�s au-dessus des encadr�s
' ---------------------------------------------------------------------
Public Function LibelleFormule(ByVal cle As String) As String
    Select Case cle
        Case "F01a": LibelleFormule = "EXPOSITION D'UNE LIGNE"
        Case "F01b": LibelleFormule = "BORNES DE L'EXERCICE y"
        Case "F01c": LibelleFormule = "EXPOSITION TOTALE"
        Case "F02a": LibelleFormule = "TAUX DE COMPL�TUDE D'UNE COLONNE"
        Case "F02b": LibelleFormule = "R�GLES DE COH�RENCE"
        Case "F02c": LibelleFormule = "BILAN"
        Case "F03a": LibelleFormule = "NOMBRE DE SINISTRES DE LA LIGNE i"
        Case "F03b": LibelleFormule = "CHARGE DE LA LIGNE i"
        Case "F03c": LibelleFormule = "CONTR�LE DE CONSERVATION"
        Case "F04a": LibelleFormule = "FACTEUR DE D�VELOPPEMENT"
        Case "F04b": LibelleFormule = "CHARGE ULTIME DE L'EXERCICE y"
        Case "F04c": LibelleFormule = "REVALORISATION ET CHARGE CIBLE"
        Case "F05a": LibelleFormule = "CHARGE �CR�T�E"
        Case "F05b": LibelleFormule = "EXC�DENT"
        Case "F05c": LibelleFormule = "EXC�S MOYEN EMPIRIQUE"
        Case "F06a": LibelleFormule = "FR�QUENCE DE LA TRANCHE j"
        Case "F06b": LibelleFormule = "FR�QUENCE � CRM 1,00"
        Case "F06c": LibelleFormule = "CO�T MOYEN �CR�T�"
        Case "F07a": LibelleFormule = "CONTRAINTE D'EXPOSITION"
        Case "F07b": LibelleFormule = "TEST DE FUSION DE DEUX CLASSES VOISINES"
        Case "F07c": LibelleFormule = "R�GLE"
        Case "F08a": LibelleFormule = "STATISTIQUE DU " & Chi() & "� (FR�QUENCE � CRM 1,00)"
        Case "F08b": LibelleFormule = "V DE CRAM�R"
        Case "F08c": LibelleFormule = "TEST DU RAPPORT DE VRAISEMBLANCE"
        Case "F09a": LibelleFormule = "FR�QUENCE " & PointMedian() & " POISSON, LIEN LOG"
        Case "F09b": LibelleFormule = "CO�T MOYEN " & PointMedian() & " GAMMA, LIEN LOG"
        Case "F09c": LibelleFormule = "IT�RATION IRLS"
        Case "F10a": LibelleFormule = "QUEUE DE PARETO AU-DEL� DE u"
        Case "F10b": LibelleFormule = "ESTIMATEUR DU MAXIMUM DE VRAISEMBLANCE"
        Case "F10c": LibelleFormule = "COEFFICIENT DE MUTUALISATION"
        Case "F11a": LibelleFormule = "PRIME PURE"
        Case "F11b": LibelleFormule = "PRIME COMMERCIALE"
        Case "F11c": LibelleFormule = "PLAFONNEMENT"
    End Select
End Function

' ---------------------------------------------------------------------
' Contr�les des �tapes : a, b = valeurs dynamiques format�es
' ---------------------------------------------------------------------
Public Function TexteControle(ByVal n As Long, ByVal k As Long, Optional ByVal a As String = "", _
                             Optional ByVal b As String = "") As String
    Dim s As String
    Select Case n * 10 + k
        Case 11: s = "Dates au format date Excel, aucune stock�e en texte"
        Case 12: s = "Une seule ligne par police et par exercice"
        Case 13: s = "Exposition comprise entre 0 et 1 (" & a & " lignes nulles : dates incoh�rentes)"
        Case 21: s = "Cl� (police, date, montant) unique parmi les sinistres retenus"
        Case 22: s = "Chaque sinistre retenu est couvert par une ligne de contrat"
        Case 23: s = "Aucune colonne tarifaire sous 99,5 % de compl�tude"
        Case 31: s = "Jointure gauche : les " & a & " lignes de contrats sont conserv�es"
        Case 32: s = "Somme des N" & ChrW(7522) & " �gale au nombre de sinistres retenus"
        Case 33: s = "Charge totale identique avant et apr�s jointure"
        Case 41: s = "Derni�re diagonale du triangle = charge des sinistres retenus (�cart < 0,5 %)"
        Case 42: s = "Facteurs de d�veloppement d�croissants vers 1"
        Case 43: s = "IBNR positif sur chaque exercice"
        Case 51: s = "Charge �cr�t�e + exc�dent = charge revaloris�e"
        Case 52: s = "Au moins " & b & " sinistres au-dessus de u (" & a & ")"
        Case 53: s = "Exc�dent sous " & b & " de la charge (" & a & ")"
        Case 61: s = "Somme des expositions par tranche = exposition totale"
        Case 62: s = "Somme des sinistres par tranche = sinistres retenus"
        Case 63: s = "Charge �cr�t�e totale = valeur de l" & Apos() & "�tape 05"
        Case 71: s = "Chaque classe d�passe " & a & " ann�es-police"
        Case 72: s = "Classes voisines significativement diff�rentes (|z| " & CarSup() & " " & a & ")"
        Case 73: s = "Classe de r�f�rence = la plus expos�e (" & a & " ans)"
        Case 81: s = "Effectif attendu " & CarSup() & " 5 dans chaque classe"
        Case 82: s = "Aucune paire de variables retenues avec V " & CarSup() & " " & a
        Case 83: s = "Sexe exclu d" & Apos() & "office (arr�t Test-Achats, 2011)"
        Case 91: s = "Sinistres pr�dits = sinistres observ�s (" & a & ")"
        Case 92: s = "Convergence IRLS atteinte (" & a & " et " & b & " it�rations)"
        Case 93: s = "Observ� / pr�dit entre " & a & " et " & b & " par classe de CRM"
        Case 101: s = "Borne basse de l" & Apos() & "IC de " & Alpha() & ChrW(770) & " au-dessus de 1 (esp�rance finie)"
        Case 102: s = Kappa() & " Pareto � moins de " & b & " du " & Kappa() & " empirique (" & a & ")"
        Case 103: s = "Survie observ�e proche de la Pareto (�cart < " & a & ")"
        Case 111: s = Sigma() & " exposition " & Multiplie() & " prime pure = charge cible (calage " & Theta() & ")"
        Case 112: s = "Aucune �volution au-del� de " & ChrW(177) & a & " apr�s plafonnement"
        Case 113: s = "�quilibre apr�s plafonnement " & CarSup() & " " & b & " (" & a & ")"
    End Select
    TexteControle = Replace(s, " %", Insec() & "%")
End Function

' ---------------------------------------------------------------------
' Cartes � Dans le classeur � et graphiques
' ---------------------------------------------------------------------
Public Function MetaFeuille(ByVal n As Long, Optional ByVal a As String = "", Optional ByVal b As String = "") As String
    Select Case n
        Case 1: MetaFeuille = a & " lignes"
        Case 2: MetaFeuille = a & " lignes brutes"
        Case 3: MetaFeuille = a & " lignes sinistr�es"
        Case 4: MetaFeuille = a & " exercices"
        Case 5: MetaFeuille = a & " sinistres retenus"
        Case 6, 7: MetaFeuille = "variable : " & a
        Case 8: MetaFeuille = a & " variables candidates"
        Case 9: MetaFeuille = "IRLS " & PointMedian() & " " & a & " cellules"
        Case 10: MetaFeuille = a & " sinistres > u"
        Case 11: MetaFeuille = Theta() & " = " & a & " " & PointMedian() & " " & Kappa() & " = " & b
    End Select
End Function

Public Function TitreGraphique(ByVal n As Long, Optional ByVal a As String = "") As String
    Select Case n
        Case 0: TitreGraphique = "Primes, sinistres et rentabilit�"
        Case 1: TitreGraphique = "Exposition par exercice"
        Case 2: TitreGraphique = "Compl�tude par colonne"
        Case 3: TitreGraphique = "Lignes par nombre de sinistres"
        Case 4: TitreGraphique = "Charge vue et ultime par exercice"
        Case 5: TitreGraphique = "Part de la charge au-dessus du seuil"
        Case 6: TitreGraphique = "Fr�quence par " & a
        Case 7: TitreGraphique = "Relativit� par " & a
        Case 8: TitreGraphique = "V de Cram�r"
        Case 9: TitreGraphique = a & " observ�e et pr�dite par quintile"
        Case 10: TitreGraphique = "Survie au-del� de x"
        Case 11: TitreGraphique = "�volution de prime des polices renouvel�es"
    End Select
End Function

Public Function NoteGraphique(ByVal n As Long, Optional ByVal a As String = "") As String
    Select Case n
        Case 0: NoteGraphique = "�chelle de gauche en k" & ChrW(8364) & ". Ratio combin� sur l" & Apos() & _
            "�chelle de droite (70" & Insec() & "% � 115" & Insec() & "%)."
        Case 1: NoteGraphique = "ann�es-police"
        Case 2: NoteGraphique = "seuil 99,5" & Insec() & "%"
        Case 5: NoteGraphique = "selon le seuil test�"
        Case 7: NoteGraphique = "base " & a & " = 1,00"
        Case 8: NoteGraphique = "liaison avec la fr�quence � CRM 1,00"
        Case 11: NoteGraphique = "avant plafonnement " & PointMedian() & " % des polices"
    End Select
    NoteGraphique = Replace(NoteGraphique, " %", Insec() & "%")
End Function

Public Function LegendeGraphique(ByVal n As Long, Optional ByVal frequence As Boolean = True) As Variant
    Select Case n
        Case 0: LegendeGraphique = Array("Primes acquises", "Charge ultime", "Ratio combin�")
        Case 3: LegendeGraphique = Array("Observ�", "Poisson")
        Case 4: LegendeGraphique = Array("Vue", "Ultime")
        Case 6: LegendeGraphique = Array("Brute", "� CRM 1,00")
        Case 9: LegendeGraphique = Array(IIf(frequence, "Observ�e", "Observ�"), IIf(frequence, "Pr�dite", "Pr�dit"))
        Case 10: LegendeGraphique = Array("Observ�e", "Pareto")
    End Select
End Function

' Nom affich� d'une variable (puces, cartes, graphiques)
Public Function NomAffiche(ByVal v As String) As String
    Select Case v
        Case "age": NomAffiche = "�ge"
        Case "puissance_cv": NomAffiche = "puissance"
        Case "anc_permis": NomAffiche = "permis"
        Case "anc_vehicule": NomAffiche = "v�hicule"
        Case Else: NomAffiche = v
    End Select
End Function

Public Function NomPuce(ByVal v As String) As String
    NomPuce = Majuscule1(NomAffiche(v))
End Function

' � tranche d'�ge �, � classe de puissance �...
Public Function DesignationVariable(ByVal v As String, ByVal classe As Boolean) As String
    Dim m As String
    If classe Then m = "classe" Else m = "tranche"
    Select Case v
        Case "age": DesignationVariable = m & " d" & Apos() & "�ge"
        Case "zone": DesignationVariable = "zone"
        Case "usage": DesignationVariable = "usage"
        Case "couleur": DesignationVariable = "couleur"
        Case "puissance_cv": DesignationVariable = m & " de puissance"
        Case "anc_permis": DesignationVariable = m & " d" & Apos() & "anciennet� de permis"
        Case Else: DesignationVariable = m & " d" & Apos() & "�ge du v�hicule"
    End Select
End Function

' Libell� d'une tranche ou d'une classe avec son unit� (� 18�24 ans �, � Zone A �, � 5�8 CV �)
Public Function LibelleAvecUnite(ByVal v As String, ByVal lib As String) As String
    Select Case v
        Case "age", "anc_permis", "anc_vehicule": LibelleAvecUnite = Intervalle(lib) & " ans"
        Case "puissance_cv": LibelleAvecUnite = Intervalle(lib) & " CV"
        Case "zone": LibelleAvecUnite = "Zone " & lib
        Case Else: LibelleAvecUnite = lib
    End Select
End Function

Public Function LibelleNbSinistres(ByVal k As Long) As String
    Select Case k
        Case 1: LibelleNbSinistres = "1 sinistre"
        Case 2: LibelleNbSinistres = "2 sinistres"
        Case Else: LibelleNbSinistres = "3 et plus"
    End Select
End Function

Public Function LibelleQuintile(ByVal q As Long) As String
    LibelleQuintile = "Quintile " & q
End Function

Public Function LibelleDecision(ByVal d As String) As String
    If d = "Retenue" Then
        LibelleDecision = "Retenue"
    ElseIf InStr(d, "redondante") > 0 Then
        LibelleDecision = "Redondante"
    ElseIf InStr(d, "non significative") > 0 Then
        LibelleDecision = "Non signif."
    ElseIf InStr(d, "vraisemblance") > 0 Then
        LibelleDecision = "�cart�e (LRT)"
    Else
        LibelleDecision = d
    End If
End Function

' ---------------------------------------------------------------------
' Tableau de bord
' ---------------------------------------------------------------------
Public Function TitreSegments() As String: TitreSegments = "Rentabilit� par segment": End Function

Public Function SousTitreSegments(ByVal annee As Long) As String
    SousTitreSegments = "Exercice " & annee & " " & PointMedian() & " S/P ultime, graves mutualis�s"
End Function

Public Function OngletSegment(ByVal v As String) As String
    Select Case v
        Case "age": OngletSegment = "�ge"
        Case "zone": OngletSegment = "Zone"
        Case "puissance_cv": OngletSegment = "Puissance"
        Case Else: OngletSegment = "Usage"
    End Select
End Function

Public Function EnteteSegments(ByVal k As Long, Optional ByVal cible As String = "") As String
    Select Case k
        Case 0: EnteteSegments = "SEGMENT"
        Case 1: EnteteSegments = "EXPO."
        Case 2: EnteteSegments = "PRIME MOY."
        Case Else: EnteteSegments = "S/P (CIBLE " & cible & ")"
    End Select
End Function

Public Function EyebrowBandeau() As String: EyebrowBandeau = "�TUDE TARIFAIRE 2026": End Function

Public Function TitreAide(ByVal cle As String) As String
    Select Case cle
        Case "kpi0": TitreAide = "Primes acquises"
        Case "kpi1": TitreAide = "Charge ultime"
        Case "kpi2": TitreAide = "S/P ultime"
        Case "kpi3": TitreAide = "Ratio combin�"
        Case "seg": TitreAide = "Rentabilit� par segment"
        Case Else: TitreAide = "PrimeLab"
    End Select
End Function

Public Function TexteAide(ByVal cle As String) As String
    Select Case cle
        Case "kpi0": TexteAide = "Primes hors taxes acquises sur l" & Apos() & "exercice au tarif alors en vigueur : " & _
            "prime annuelle " & Multiplie() & " exposition de chaque ligne."
        Case "kpi1": TexteAide = "Charge vue au 31/12/" & Param("annee_fin") & " multipli�e par le facteur de " & _
            "d�veloppement Chain Ladder de l" & Apos() & "exercice. L" & Apos() & "IBNR est l" & Apos() & _
            "�cart entre charge ultime et charge vue."
        Case "kpi2": TexteAide = "Charge ultime / primes acquises. Le S/P vu sous-estime les exercices r�cents, " & _
            "encore immatures : le tableau de bord raisonne donc � l" & Apos() & "ultime."
        Case "kpi3": TexteAide = "S/P ultime + frais de gestion et d" & Apos() & "acquisition (25 % des primes). " & _
            "Au-del� de 100 %, l" & Apos() & "exercice est techniquement d�ficitaire."
        Case "seg": TexteAide = "La charge ultime de l" & Apos() & "exercice est r�partie entre segments au prorata " & _
            "de leur charge �cr�t�e : les graves sont mutualis�s. S/P cible = (1 " & Moins() & " frais " & _
            Moins() & " marge) / (1 + s�curit�)."
        Case "police_ok": TexteAide = "Police Plus Jakarta Sans d�tect�e : rendu conforme � la charte."
        Case "police_repli": TexteAide = "Plus Jakarta Sans n" & Apos() & "est pas install�e : repli sur Segoe UI. " & _
            "Installer les polices du dossier polices puis reconstruire l" & Apos() & "application."
    End Select
    TexteAide = Replace(TexteAide, " %", Insec() & "%")
End Function

' ---------------------------------------------------------------------
' Bandeau du tableau de bord (6.12)
' ---------------------------------------------------------------------
Public Function DesignationSegment(ByVal dimension As String, ByVal classe As String) As String
    Select Case dimension
        Case "age": DesignationSegment = "les " & Intervalle(classe) & " ans"
        Case "zone": DesignationSegment = "la zone " & classe
        Case "puissance_cv": DesignationSegment = "les " & Intervalle(classe) & " CV"
        Case Else: DesignationSegment = "l" & Apos() & "usage " & LCase$(classe)
    End Select
End Function

Public Function TexteBandeau(ByVal k As Long, noms() As String, valeurs() As Double, ByVal annee As Long, _
                             ByVal cible As Double) As String
    Dim s As String
    Select Case k
        Case 0
            s = "Aucun segment significatif au-dessus du S/P cible en " & annee & ". Consulter l" & Apos() & "�tude."
        Case 1
            s = Majuscule1(noms(1)) & " reste sous-tarif�" & Insec() & ": S/P " & annee & " de " & _
                FormatPct(valeurs(1), 0) & " (cible " & FormatPct(cible, 0) & "). Lancer la r�vision."
        Case Else
            s = Majuscule1(noms(1)) & " et " & noms(2) & " restent sous-tarif�s" & Insec() & ": S/P " & annee & " de " & _
                FormatPct(valeurs(1), 0) & " et " & FormatPct(valeurs(2), 0) & " (cible " & FormatPct(cible, 0) & _
                "). Lancer la r�vision."
    End Select
    TexteBandeau = s
End Function

' ---------------------------------------------------------------------
' Calculateur (11.13)
' ---------------------------------------------------------------------
Public Function TexteCalc(ByVal cle As String, Optional ByVal a As String = "", Optional ByVal b As String = "") As String
    Dim s As String
    Select Case cle
        Case "reinit": s = "R�initialiser"
        Case "profil": s = "Profil de l" & Apos() & "assur�"
        Case "age": s = "�ge du conducteur"
        Case "age_val": s = a & " ans"
        Case "classe_age": s = "Classe " & a & " ans"
        Case "zone": s = "Zone g�ographique"
        Case "cv": s = "Puissance fiscale"
        Case "cv_val": s = a & " CV"
        Case "classe_cv": s = "Classe " & a & " CV"
        Case "usage": s = "Usage"
        Case "crm": s = "Coefficient bonus-malus"
        Case "aide_crm": s = Moins() & " : un an sans sinistre (" & Multiplie() & " 0,95) " & PointMedian() & _
            " + : un sinistre responsable (" & Multiplie() & " 1,25)"
        Case "chargements": s = "Hypoth�ses de chargement"
        Case "ch0": s = "S�curit� (sur prime pure)"
        Case "ch1": s = "Frais de gestion"
        Case "ch2": s = "Frais d" & Apos() & "acquisition"
        Case "ch3": s = "Marge"
        Case "ch4": s = "Taxes"
        Case "eyebrow_ttc": s = "PRIME COMMERCIALE TTC"
        Case "mensuel": s = "soit " & a & " par mois"
        Case "vs_actuel": s = a & " vs tarif actuel"
        Case "vs_moyenne": s = "vs prime moyenne du portefeuille (" & a & ") : " & b
        Case "leg0": s = "Prime pure"
        Case "leg1": s = "S�curit�"
        Case "leg2": s = "Frais"
        Case "leg3": s = "Marge"
        Case "leg4": s = "Taxes"
        Case "mini0": s = "Fr�quence"
        Case "mini1": s = "Co�t moyen"
        Case "mini2": s = "Prime pure"
        Case "mini3": s = "Prime HT"
        Case "ind2": s = "fr�q. " & Multiplie() & " co�t"
        Case "formule": s = "Formule appliqu�e"
        Case "f_pp": s = "PRIME PURE"
        Case "f_ttc": s = "PRIME COMMERCIALE TTC"
        Case "excel_titre": s = "Le m�me calcul dans Excel"
        Case "excel_texte": s = "Onglet Calculateur : chaque montant ci-dessus est une formule de la feuille, " & _
            "lisible en mode administration."
    End Select
    TexteCalc = s
End Function

Public Function LibelleZone(ByVal z As String) As String
    Select Case z
        Case "A": LibelleZone = "Rural"
        Case "B": LibelleZone = "P�riurb."
        Case "C": LibelleZone = "Urbain"
        Case Else: LibelleZone = "Dense"
    End Select
End Function

' ---------------------------------------------------------------------
' Messages
' ---------------------------------------------------------------------
Public Function MessageConstruction(ByVal secondes As Double, ByVal resultat As String) As String
    MessageConstruction = "Application construite en " & FormatNombre(secondes, 0) & " s. " & resultat
End Function

Public Function MessageChargementRefuse() As String
    MessageChargementRefuse = "Chargements refus�s : la somme frais + marge laisserait moins de 5 % de la prime."
End Function
