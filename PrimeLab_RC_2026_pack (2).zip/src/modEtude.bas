Attribute VB_Name = "modEtude"
Option Explicit
' =====================================================================
' modEtude : �tapes 06 (exploratoire), 07 (classes), 08 (s�lection),
' 11 (tarif, impact), tableau de bord (segments) et feuille Calculateur.
' =====================================================================

Public Const F_EXPLORATOIRE As String = "Exploratoire"
Public Const F_BORNES As String = "Bornes"
Public Const F_CLASSES As String = "Classes"
Public Const F_SELECTION As String = "Selection"
Public Const F_ASSOCIATIONS As String = "Associations"
Public Const F_TARIF As String = "Tarif"
Public Const F_IMPACT As String = "Impact"
Public Const F_SEGMENTS As String = "Segments"
Public Const F_CALCULATEUR As String = "Calculateur"

Public Const NB_CAND As Long = 7
Public Const MAX_TR As Long = 10
Private Const LISTE_CANDIDATES As String = "age,zone,puissance_cv,usage,anc_permis,anc_vehicule,couleur"
Private Const LISTE_ORDINALES As String = ",age,puissance_cv,anc_permis,anc_vehicule,"
Private Const LISTE_COL_SOURCE As String = "R,H,I,J,S,T,L"    ' colonne Contrats de chaque candidate
Private Const MOD_ZONE As String = "A,B,C,D"
Private Const MOD_USAGE As String = "Priv�,Trajet,Professionnel"
Private Const MOD_COULEUR As String = "Blanc,Gris,Noir,Bleu,Rouge,Vert"
Private Const BORNE_INFINIE As Double = 1000000000#
Private Const COL_PARAM_TR As Long = 6      ' F : tranches initiales de Parametres
Private Const DECISION_RETENUE As String = "Retenue"
Private Const PART_EXPO_SEGMENT As Double = 0.05
Private Const LISTE_DIM_SEGMENTS As String = "age,zone,puissance_cv,usage"

' R�sultats de l'�tape 07, indic�s par candidate (0 � 6)
Public gNbTr(0 To 6) As Long
Public gTrLib(0 To 6, 1 To 10) As String
Public gTrMin(0 To 6, 1 To 10) As Double
Public gNbCl(0 To 6) As Long
Public gClLib(0 To 6, 1 To 10) As String
Public gClTranches(0 To 6, 1 To 10) As String
Public gClMin(0 To 6, 1 To 10) As Double
Public gClSup(0 To 6, 1 To 10) As Double
Public gClRef(0 To 6) As Long
Public gTrClasse(0 To 6, 1 To 10) As Long

' ---------------------------------------------------------------------
' Candidates
' ---------------------------------------------------------------------
Public Function Candidate(ByVal i As Long) As String
    Candidate = Split(LISTE_CANDIDATES, ",")(i)
End Function

Public Function IndexCandidate(ByVal v As String) As Long
    Dim i As Long
    IndexCandidate = -1
    For i = 0 To NB_CAND - 1
        If Candidate(i) = v Then IndexCandidate = i: Exit Function
    Next i
End Function

Public Function EstOrdinale(ByVal v As String) As Boolean
    EstOrdinale = (InStr(LISTE_ORDINALES, "," & v & ",") > 0)
End Function

Public Function ColSource(ByVal i As Long) As String
    ColSource = Split(LISTE_COL_SOURCE, ",")(i)
End Function

Private Function Modalites(ByVal v As String) As Variant
    Select Case v
        Case "zone": Modalites = Split(MOD_ZONE, ",")
        Case "usage": Modalites = Split(MOD_USAGE, ",")
        Case Else: Modalites = Split(MOD_COULEUR, ",")
    End Select
End Function

' Tranches initiales : Parametres F:H (ordinales) ou constantes (nominales)
Public Sub ChargerTranches()
    Dim wp As Worksheet, v As Variant, i As Long, r As Long, m As Variant, k As Long
    Set wp = Feuille(F_PARAMETRES)
    v = wp.Range(wp.Cells(2, COL_PARAM_TR), wp.Cells(wp.Cells(wp.Rows.Count, COL_PARAM_TR).End(xlUp).Row, COL_PARAM_TR + 2)).Value2
    For i = 0 To NB_CAND - 1
        gNbTr(i) = 0
        If EstOrdinale(Candidate(i)) Then
            For r = 1 To UBound(v, 1)
                If CStr(v(r, 1)) = Candidate(i) Then
                    gNbTr(i) = gNbTr(i) + 1
                    gTrMin(i, gNbTr(i)) = CDbl(v(r, 2))
                    gTrLib(i, gNbTr(i)) = CStr(v(r, 3))
                End If
            Next r
        Else
            m = Modalites(Candidate(i))
            For k = 0 To UBound(m)
                gNbTr(i) = gNbTr(i) + 1
                gTrLib(i, gNbTr(i)) = CStr(m(k))
            Next k
        End If
    Next i
End Sub

' Indice de tranche d'une valeur (ordinale : derni�re borne <= x ; nominale : modalit�)
Public Function IndiceTranche(ByVal i As Long, ByVal x As Variant) As Long
    Dim t As Long
    IndiceTranche = 0
    If EstOrdinale(Candidate(i)) Then
        For t = 1 To gNbTr(i)
            If CDbl(x) >= gTrMin(i, t) Then IndiceTranche = t
        Next t
    Else
        For t = 1 To gNbTr(i)
            If CStr(x) = gTrLib(i, t) Then IndiceTranche = t: Exit Function
        Next t
    End If
End Function

' ---------------------------------------------------------------------
' �tape 06 : analyse exploratoire
' ---------------------------------------------------------------------
Public Sub Etape06()
    Dim ws As Worksheet, i As Long, t As Long, r As Long, r1 As Long, src As String, n As String
    Dim lib As Variant, frm As Variant, nm As Variant
    ChargerTranches
    Set ws = NouvelleFeuille(F_EXPLORATOIRE)
    EntetesTable ws, 1, 1, Array("variable", "tranche", "borne_min", "borne_sup", "exposition", "e_crm", "nb_sin", _
        "charge_ecr", "frequence", "freq_crm", "ic_bas", "ic_haut", "cout_moyen", "prime_pure")
    r = 2
    For i = 0 To NB_CAND - 1
        r1 = r
        src = "c_" & Candidate(i)
        For t = 1 To gNbTr(i)
            ws.Cells(r, 1).Value2 = Candidate(i)
            ws.Cells(r, 2).Value2 = "'" & gTrLib(i, t)
            If EstOrdinale(Candidate(i)) Then
                ws.Cells(r, 3).Value2 = gTrMin(i, t)
                If t < gNbTr(i) Then ws.Cells(r, 4).Value2 = gTrMin(i, t + 1) Else ws.Cells(r, 4).Value2 = BORNE_INFINIE
            End If
            r = r + 1
        Next t
        If EstOrdinale(Candidate(i)) Then
            ws.Range("E" & r1 & ":E" & r - 1).Formula = "=SUMIFS(c_expo," & src & ","">=""&C" & r1 & "," & src & ",""<""&D" & r1 & ")"
            ws.Range("F" & r1 & ":F" & r - 1).Formula = "=SUMIFS(c_e_crm," & src & ","">=""&C" & r1 & "," & src & ",""<""&D" & r1 & ")"
            ws.Range("G" & r1 & ":G" & r - 1).Formula = "=SUMIFS(c_nb_sin," & src & ","">=""&C" & r1 & "," & src & ",""<""&D" & r1 & ")"
            ws.Range("H" & r1 & ":H" & r - 1).Formula = "=SUMIFS(c_charge_ecr," & src & ","">=""&C" & r1 & "," & src & ",""<""&D" & r1 & ")"
        Else
            ws.Range("E" & r1 & ":E" & r - 1).Formula = "=SUMIFS(c_expo," & src & ",B" & r1 & ")"
            ws.Range("F" & r1 & ":F" & r - 1).Formula = "=SUMIFS(c_e_crm," & src & ",B" & r1 & ")"
            ws.Range("G" & r1 & ":G" & r - 1).Formula = "=SUMIFS(c_nb_sin," & src & ",B" & r1 & ")"
            ws.Range("H" & r1 & ":H" & r - 1).Formula = "=SUMIFS(c_charge_ecr," & src & ",B" & r1 & ")"
        End If
    Next i
    n = CStr(r - 1)
    ws.Range("I2:I" & n).Formula = "=IF(E2>0,G2/E2,NA())"
    ws.Range("J2:J" & n).Formula = "=IF(F2>0,G2/F2,NA())"
    ws.Range("K2:K" & n).Formula = "=J2-1.96*SQRT(J2/F2)"
    ws.Range("L2:L" & n).Formula = "=J2+1.96*SQRT(J2/F2)"
    ws.Range("M2:M" & n).Formula = "=IF(G2>0,H2/G2,NA())"
    ws.Range("N2:N" & n).Formula = "=H2/E2"
    ws.Range("E2:F" & n).NumberFormat = FormatExpo()
    ws.Range("H2:H" & n & ",M2:N" & n).NumberFormat = FormatMontant()
    ws.Range("I2:L" & n).NumberFormat = FormatTaux()
    DefinirNom "expl_var", ws.Range("A2:A" & n)
    DefinirNom "expl_tranche", ws.Range("B2:B" & n)
    DefinirNom "expl_E", ws.Range("E2:E" & n)
    DefinirNom "expl_Es", ws.Range("F2:F" & n)
    DefinirNom "expl_N", ws.Range("G2:G" & n)
    DefinirNom "expl_freq_tr", ws.Range("I2:I" & n)
    DefinirNom "expl_freq_crm_tr", ws.Range("J2:J" & n)
    EntetesTable ws, 1, 16, Array("indicateur", "valeur")
    lib = Array("Fr�quence brute", "Fr�quence � CRM 1,00", "Co�t moyen �cr�t�", "Prime pure �cr�t�e", _
                "Nombre de sinistres", "Exposition")
    frm = Array("=SUM(c_nb_sin)/SUM(c_expo)", "=SUM(c_nb_sin)/SUM(c_e_crm)", "=SUM(c_charge_ecr)/SUM(c_nb_sin)", _
                "=SUM(c_charge_ecr)/SUM(c_expo)", "=SUM(c_nb_sin)", "=SUM(c_expo)")
    nm = Array("expl_freq", "expl_freq_crm", "expl_cout", "expl_pp", "expl_n_tot", "expl_e_tot")
    For i = 0 To 5
        ws.Cells(i + 2, 16).Value2 = lib(i)
        ws.Cells(i + 2, 17).Formula = frm(i)
        DefinirNom CStr(nm(i)), ws.Cells(i + 2, 17)
    Next i
    FormaterSynthese ws.Range("Q2:Q7")
    ControlesEtape06 n
End Sub

Private Sub ControlesEtape06(ByVal n As String)
    Dim lst As String
    lst = "{""age"",""zone"",""puissance_cv"",""usage"",""anc_permis"",""anc_vehicule"",""couleur""}"
    AjouterControle 6, 1, "Somme des expositions par tranche = exposition totale", _
        "=MAX(ABS(SUMIF(Exploratoire!A2:A" & n & "," & lst & ",Exploratoire!E2:E" & n & ")-SUM(c_expo)))<1E-6", True
    AjouterControle 6, 2, "Somme des sinistres par tranche = sinistres retenus", _
        "=MAX(ABS(SUMIF(Exploratoire!A2:A" & n & "," & lst & ",Exploratoire!G2:G" & n & ")-SUM(c_nb_sin)))<1E-6", True
    AjouterControle 6, 3, "Charge �cr�t�e totale = valeur de l" & Apos() & "�tape 05", _
        "=MAX(ABS(SUMIF(Exploratoire!A2:A" & n & "," & lst & ",Exploratoire!H2:H" & n & ")-SUM(s_charge_ecr)))<0.01", True
End Sub

' ---------------------------------------------------------------------
' �tape 07 : regroupement en classes (VBA) puis feuilles Bornes et Classes
' ---------------------------------------------------------------------
Public Sub Etape07()
    Dim v As Variant, i As Long, r As Long, t As Long, jr() As Variant, nj As Long
    Dim e() As Double, es() As Double, nn() As Double
    ChargerTranches
    v = Feuille(F_EXPLORATOIRE).Range("A2:G" & (1 + NbLignesExploratoire())).Value2
    ReDim jr(1 To 5, 1 To 200)
    nj = 0
    r = 1
    For i = 0 To NB_CAND - 1
        ReDim e(1 To gNbTr(i)): ReDim es(1 To gNbTr(i)): ReDim nn(1 To gNbTr(i))
        For t = 1 To gNbTr(i)
            e(t) = CDbl(v(r, 5)): es(t) = CDbl(v(r, 6)): nn(t) = CDbl(v(r, 7))
            r = r + 1
        Next t
        Regrouper i, e, es, nn, jr, nj
    Next i
    EcrireBornes
    EcrireClasses jr, nj
End Sub

Public Function NbLignesExploratoire() As Long
    Dim i As Long
    NbLignesExploratoire = 0
    For i = 0 To NB_CAND - 1: NbLignesExploratoire = NbLignesExploratoire + gNbTr(i): Next i
End Function

' Algorithme exact de la section 6.7 (groupes ordonn�s, fusions journalis�es)
Private Sub Regrouper(ByVal i As Long, e() As Double, es() As Double, nn() As Double, jr() As Variant, nj As Long)
    Dim gE() As Double, gEs() As Double, gN() As Double, gP() As Long, gD() As Long, ng As Long
    Dim k As Long, s As Long, j As Long, emin As Double, zmin As Double, z As Double, ordinale As Boolean
    Dim li As Double, ecart As Double, meilleur As Double, rang As Long
    ordinale = EstOrdinale(Candidate(i))
    ng = gNbTr(i)
    ReDim gE(1 To ng): ReDim gEs(1 To ng): ReDim gN(1 To ng): ReDim gP(1 To ng): ReDim gD(1 To ng)
    For k = 1 To ng
        gE(k) = e(k): gEs(k) = es(k): gN(k) = nn(k): gP(k) = k: gD(k) = k
    Next k
    Dim membres() As String: ReDim membres(1 To ng)
    For k = 1 To ng: membres(k) = CStr(k): Next k
    emin = CDbl(Param("exposition_min"))
    rang = 0
    Do
        s = 0
        For k = 1 To ng
            If gE(k) < emin Then
                If s = 0 Then
                    s = k
                ElseIf gE(k) < gE(s) Then
                    s = k
                End If
            End If
        Next k
        If s > 0 And ng > 1 Then
            li = Lam(gN(s), gEs(s))
            j = 0: meilleur = 0
            For k = 1 To ng
                If k <> s And (Not ordinale Or Abs(k - s) = 1) Then
                    ecart = Abs(Lam(gN(k), gEs(k)) - li)
                    If j = 0 Or ecart < meilleur Then j = k: meilleur = ecart
                End If
            Next k
            rang = rang + 1
            AjouterFusion jr, nj, Candidate(i), rang, "exposition", LibelleGroupe(i, membres(s)) & " + " & LibelleGroupe(i, membres(j)), gE(s)
            Fusionner gE, gEs, gN, membres, ng, IIf(s < j, s, j), IIf(s < j, j, s)
        ElseIf ordinale And ng >= 2 Then
            zmin = -1: s = 0
            For k = 1 To ng - 1
                z = ZStat(gN(k), gEs(k), gN(k + 1), gEs(k + 1))
                If s = 0 Or z < zmin Then zmin = z: s = k
            Next k
            If zmin < CDbl(Param("z_fusion")) Then
                rang = rang + 1
                AjouterFusion jr, nj, Candidate(i), rang, "z", LibelleGroupe(i, membres(s)) & " + " & LibelleGroupe(i, membres(s + 1)), zmin
                Fusionner gE, gEs, gN, membres, ng, s, s + 1
            Else
                Exit Do
            End If
        Else
            Exit Do
        End If
    Loop
    EnregistrerClasses i, gE, membres, ng
End Sub

Private Function Lam(ByVal n As Double, ByVal es As Double) As Double
    If es > 0 Then Lam = n / es Else Lam = 0
End Function

Private Function ZStat(ByVal n1 As Double, ByVal es1 As Double, ByVal n2 As Double, ByVal es2 As Double) As Double
    Dim l1 As Double, l2 As Double, den As Double
    l1 = Lam(n1, es1): l2 = Lam(n2, es2)
    den = 0
    If es1 > 0 And es2 > 0 Then den = Sqr(l1 / es1 + l2 / es2)
    If den = 0 Then ZStat = 0 Else ZStat = Abs(l1 - l2) / den
End Function

' Fusionne le groupe b dans le groupe a (a < b), le groupe fusionn� prend la position a
Private Sub Fusionner(gE() As Double, gEs() As Double, gN() As Double, membres() As String, ng As Long, _
                      ByVal a As Long, ByVal b As Long)
    Dim k As Long
    gE(a) = gE(a) + gE(b): gEs(a) = gEs(a) + gEs(b): gN(a) = gN(a) + gN(b)
    membres(a) = membres(a) & "," & membres(b)
    For k = b To ng - 1
        gE(k) = gE(k + 1): gEs(k) = gEs(k + 1): gN(k) = gN(k + 1): membres(k) = membres(k + 1)
    Next k
    ng = ng - 1
End Sub

Private Sub AjouterFusion(jr() As Variant, nj As Long, ByVal v As String, ByVal rang As Long, _
                          ByVal motif As String, ByVal groupes As String, ByVal critere As Double)
    nj = nj + 1
    jr(1, nj) = v: jr(2, nj) = rang: jr(3, nj) = motif: jr(4, nj) = groupes: jr(5, nj) = critere
End Sub

' Libell� d'un groupe � partir de ses membres (liste d'indices de tranches)
Private Function LibelleGroupe(ByVal i As Long, ByVal membres As String) As String
    Dim m As Variant, k As Long, s As String
    m = Split(membres, ",")
    If EstOrdinale(Candidate(i)) Then
        LibelleGroupe = LibelleFusion(gTrLib(i, CLng(m(0))), gTrLib(i, CLng(m(UBound(m)))))
    Else
        For k = 0 To UBound(m)
            If k > 0 Then s = s & "+"
            s = s & gTrLib(i, CLng(m(k)))
        Next k
        LibelleGroupe = s
    End If
End Function

' R�gle des libell�s ordinaux (6.7) : borne basse du premier membre, borne haute du dernier
Public Function LibelleFusion(ByVal premier As String, ByVal dernier As String) As String
    Dim lo As String, hi As String, sansBas As Boolean, ouvert As Boolean, p As Long
    If Left$(premier, 1) = CarInf() Then
        sansBas = True
    ElseIf Right$(premier, 1) = "+" Then
        lo = Left$(premier, Len(premier) - 1)
    Else
        p = InStr(premier, "-")
        If p > 0 Then lo = Left$(premier, p - 1) Else lo = premier
    End If
    If Right$(dernier, 1) = "+" Then
        ouvert = True
    ElseIf Left$(dernier, 1) = CarInf() Then
        hi = Mid$(dernier, 2)
    Else
        p = InStr(dernier, "-")
        If p > 0 Then hi = Mid$(dernier, p + 1) Else hi = dernier
    End If
    If sansBas And ouvert Then
        LibelleFusion = "Toutes"
    ElseIf sansBas Then
        LibelleFusion = CarInf() & hi
    ElseIf ouvert Then
        LibelleFusion = lo & "+"
    ElseIf lo = hi Then
        LibelleFusion = lo
    Else
        LibelleFusion = lo & "-" & hi
    End If
End Function

Private Sub EnregistrerClasses(ByVal i As Long, gE() As Double, membres() As String, ByVal ng As Long)
    Dim k As Long, m As Variant, q As Long, s As String
    gNbCl(i) = ng
    gClRef(i) = 1
    For k = 1 To ng
        If gE(k) > gE(gClRef(i)) Then gClRef(i) = k
        gClLib(i, k) = LibelleGroupe(i, membres(k))
        m = Split(membres(k), ",")
        s = ""
        For q = 0 To UBound(m)
            gTrClasse(i, CLng(m(q))) = k
            If q > 0 Then s = s & "+"
            s = s & gTrLib(i, CLng(m(q)))
        Next q
        gClTranches(i, k) = s
        If EstOrdinale(Candidate(i)) Then gClMin(i, k) = gTrMin(i, CLng(m(0)))
    Next k
    For k = 1 To ng
        If k < ng Then gClSup(i, k) = gClMin(i, k + 1) Else gClSup(i, k) = BORNE_INFINIE
    Next k
End Sub

Private Sub EcrireBornes()
    Dim ws As Worksheet, i As Long, t As Long, r As Long, r1 As Long, v As String
    Set ws = NouvelleFeuille(F_BORNES)
    EntetesTable ws, 1, 1, Array("variable", "tranche_min", "tranche", "classe")
    r = 2
    For i = 0 To NB_CAND - 1
        r1 = r
        v = Candidate(i)
        For t = 1 To gNbTr(i)
            ws.Cells(r, 1).Value2 = v
            If EstOrdinale(v) Then ws.Cells(r, 2).Value2 = gTrMin(i, t) Else ws.Cells(r, 2).Value2 = "'" & gTrLib(i, t)
            ws.Cells(r, 3).Value2 = "'" & gTrLib(i, t)
            ws.Cells(r, 4).Value2 = "'" & gClLib(i, gTrClasse(i, t))
            r = r + 1
        Next t
        If EstOrdinale(v) Then
            DefinirNom "bornes_" & v & "_min", ws.Range("B" & r1 & ":B" & r - 1)
        Else
            DefinirNom "bornes_" & v & "_mod", ws.Range("C" & r1 & ":C" & r - 1)
        End If
        DefinirNom "bornes_" & v & "_classe", ws.Range("D" & r1 & ":D" & r - 1)
    Next i
End Sub

Private Sub EcrireClasses(jr() As Variant, ByVal nj As Long)
    Dim ws As Worksheet, i As Long, k As Long, r As Long, r1 As Long, v As String, src As String, n As String
    Dim refRow As Long, s() As Variant
    Set ws = NouvelleFeuille(F_CLASSES)
    EntetesTable ws, 1, 1, Array("variable", "classe", "tranches", "borne_min", "borne_sup", "exposition", _
        "e_crm", "nb_sin", "freq_crm", "relativite", "z_suivante", "reference")
    r = 2
    For i = 0 To NB_CAND - 1
        r1 = r
        v = Candidate(i): src = "c_" & v
        refRow = r1 + gClRef(i) - 1
        For k = 1 To gNbCl(i)
            ws.Cells(r, 1).Value2 = v
            ws.Cells(r, 2).Value2 = "'" & gClLib(i, k)
            ws.Cells(r, 3).Value2 = "'" & gClTranches(i, k)
            If EstOrdinale(v) Then
                ws.Cells(r, 4).Value2 = gClMin(i, k)
                ws.Cells(r, 5).Value2 = gClSup(i, k)
            End If
            ws.Cells(r, 12).Value2 = (k = gClRef(i))
            r = r + 1
        Next k
        If EstOrdinale(v) Then
            ws.Range("F" & r1 & ":F" & r - 1).Formula = "=SUMIFS(c_expo," & src & ","">=""&D" & r1 & "," & src & ",""<""&E" & r1 & ")"
            ws.Range("G" & r1 & ":G" & r - 1).Formula = "=SUMIFS(c_e_crm," & src & ","">=""&D" & r1 & "," & src & ",""<""&E" & r1 & ")"
            ws.Range("H" & r1 & ":H" & r - 1).Formula = "=SUMIFS(c_nb_sin," & src & ","">=""&D" & r1 & "," & src & ",""<""&E" & r1 & ")"
            ws.Range("K" & r1 & ":K" & r - 1).Formula = "=IF(A" & (r1 + 1) & "=A" & r1 & ",ABS(I" & r1 & "-I" & (r1 + 1) & _
                ")/SQRT(I" & r1 & "/G" & r1 & "+I" & (r1 + 1) & "/G" & (r1 + 1) & "),"""")"
        Else
            ws.Range("F" & r1 & ":F" & r - 1).Formula = "=SUMPRODUCT(SUMIFS(c_expo," & src & ",bornes_" & v & "_mod)*(bornes_" & v & "_classe=B" & r1 & "))"
            ws.Range("G" & r1 & ":G" & r - 1).Formula = "=SUMPRODUCT(SUMIFS(c_e_crm," & src & ",bornes_" & v & "_mod)*(bornes_" & v & "_classe=B" & r1 & "))"
            ws.Range("H" & r1 & ":H" & r - 1).Formula = "=SUMPRODUCT(SUMIFS(c_nb_sin," & src & ",bornes_" & v & "_mod)*(bornes_" & v & "_classe=B" & r1 & "))"
        End If
        ws.Range("J" & r1 & ":J" & r - 1).Formula = "=I" & r1 & "/$I$" & refRow
    Next i
    n = CStr(r - 1)
    ws.Range("I2:I" & n).Formula = "=H2/G2"
    ws.Range("F2:G" & n).NumberFormat = FormatExpo()
    ws.Range("I2:I" & n).NumberFormat = FormatTaux()
    ws.Range("J2:K" & n).NumberFormat = FormatRel()
    DefinirNom "cls_var", ws.Range("A2:A" & n)
    DefinirNom "cls_classe", ws.Range("B2:B" & n)
    DefinirNom "cls_E", ws.Range("F2:F" & n)
    DefinirNom "cls_Es", ws.Range("G2:G" & n)
    DefinirNom "cls_N", ws.Range("H2:H" & n)
    DefinirNom "cls_rel", ws.Range("J2:J" & n)
    DefinirNom "cls_z", ws.Range("K2:K" & n)
    DefinirNom "cls_ref", ws.Range("L2:L" & n)
    EntetesTable ws, 1, 14, Array("variable", "rang", "motif", "groupes_fusionnes", "critere")
    If nj > 0 Then
        ReDim s(1 To nj, 1 To 5)
        For k = 1 To nj
            For i = 1 To 5: s(k, i) = jr(i, k): Next i
            s(k, 4) = "'" & s(k, 4)
        Next k
        ws.Range("N2").Resize(nj, 5).Value2 = s
    End If
    SyntheseClasses ws, n
End Sub

Private Sub SyntheseClasses(ByVal ws As Worksheet, ByVal n As String)
    Dim lib As Variant, frm As Variant, nm As Variant, i As Long
    EntetesTable ws, 1, 20, Array("indicateur", "valeur")
    lib = Array("Classes d" & Apos() & "�ge", "Tranches d" & Apos() & "�ge", "Classes de puissance", _
                "Tranches de puissance", "Classe de r�f�rence (�ge)")
    frm = Array("=COUNTIF(cls_var,""age"")", "=COUNTIF(expl_var,""age"")", "=COUNTIF(cls_var,""puissance_cv"")", _
                "=COUNTIF(expl_var,""puissance_cv"")", "")
    nm = Array("cls_nb_age", "cls_nb_tr_age", "cls_nb_cv", "cls_nb_tr_cv", "cls_ref_age")
    For i = 0 To 4
        ws.Cells(i + 2, 20).Value2 = lib(i)
        If Len(frm(i)) > 0 Then ws.Cells(i + 2, 21).Formula = frm(i)
        DefinirNom CStr(nm(i)), ws.Cells(i + 2, 21)
    Next i
    ws.Range("U6").FormulaArray = "=INDEX(cls_classe,MATCH(1,(cls_var=""age"")*cls_ref,0))"
    For i = 0 To NB_CAND - 1
        ws.Cells(i + 7, 20).Value2 = "Classes de " & Candidate(i)
        ws.Cells(i + 7, 21).Formula = "=COUNTIF(cls_var,""" & Candidate(i) & """)"
        DefinirNom "cls_n_" & Candidate(i), ws.Cells(i + 7, 21)
    Next i
    FormaterSynthese ws.Range("U2:U" & NB_CAND + 6)
    AjouterControle 7, 1, "Chaque classe d�passe exposition_min", "=MIN(cls_E)>=exposition_min", False, "=exposition_min"
    AjouterControle 7, 2, "Classes voisines significativement diff�rentes", "=MIN(cls_z)>=z_fusion", False, "=z_fusion"
    AjouterControle 7, 3, "Classe de r�f�rence = la plus expos�e", _
        "=AND(SUMPRODUCT(--cls_ref)=" & NB_CAND & ",SUMPRODUCT(cls_ref*(COUNTIFS(cls_var,cls_var,cls_E,"">""&cls_E)>0))=0)", _
        False, "=cls_ref_age"
End Sub

' Indice de classe d'une valeur brute
Public Function IndiceClasse(ByVal i As Long, ByVal x As Variant) As Long
    Dim t As Long
    t = IndiceTranche(i, x)
    If t = 0 Then IndiceClasse = 0 Else IndiceClasse = gTrClasse(i, t)
End Function

' Recharge les classes depuis les feuilles Bornes et Classes (apr�s une r�ouverture)
Public Sub ChargerClassesDepuisFeuilles()
    Dim vb As Variant, vc As Variant, i As Long, r As Long, k As Long, t As Long
    ChargerTranches
    vc = Feuille(F_CLASSES).Range("A2:L" & PlageNom("cls_var").Rows.Count + 1).Value2
    For i = 0 To NB_CAND - 1
        k = 0
        For r = 1 To UBound(vc, 1)
            If CStr(vc(r, 1)) = Candidate(i) Then
                k = k + 1
                gClLib(i, k) = CStr(vc(r, 2)): gClTranches(i, k) = CStr(vc(r, 3))
                If EstOrdinale(Candidate(i)) Then gClMin(i, k) = CDbl(vc(r, 4)): gClSup(i, k) = CDbl(vc(r, 5))
                If CBool(vc(r, 12)) Then gClRef(i) = k
            End If
        Next r
        gNbCl(i) = k
    Next i
    vb = Feuille(F_BORNES).Range("A2:D" & NbLignesExploratoire() + 1).Value2
    r = 1
    For i = 0 To NB_CAND - 1
        For t = 1 To gNbTr(i)
            For k = 1 To gNbCl(i)
                If gClLib(i, k) = CStr(vb(r, 4)) Then gTrClasse(i, t) = k
            Next k
            r = r + 1
        Next t
    Next i
End Sub

' ---------------------------------------------------------------------
' �tape 08 : s�lection des variables
' ---------------------------------------------------------------------
Public Sub Etape08Formules()
    Dim ws As Worksheet, i As Long, r As Long, d As String
    Set ws = NouvelleFeuille(F_SELECTION)
    EntetesTable ws, 1, 1, Array("variable", "chi2", "ddl", "p_value", "v_cramer", "att_min", "delta_d", _
        "ddl_lrt", "p_lrt", "decision")
    For i = 0 To NB_CAND - 1
        ws.Cells(i + 2, 1).Value2 = Candidate(i)
    Next i
    d = CStr(NB_CAND + 1)
    ws.Range("B2:B" & d).Formula = "=SUMPRODUCT((cls_var=A2)*(cls_N-cls_Es*expl_freq_crm)^2/(cls_Es*expl_freq_crm))"
    ws.Range("C2:C" & d).Formula = "=COUNTIF(cls_var,A2)-1"
    ws.Range("D2:D" & d).Formula = "=IF(C2>0,CHISQ.DIST.RT(B2,C2),1)"
    ws.Range("E2:E" & d).Formula = "=SQRT(B2/SUM(c_expo))"
    For r = 2 To NB_CAND + 1
        ws.Cells(r, 6).FormulaArray = "=MIN(IF(cls_var=A" & r & ",cls_Es))*expl_freq_crm"
    Next r
    ws.Range("I2:I" & d).Formula = "=IF(H2>0,CHISQ.DIST.RT(G2,H2),"""")"
    r = NB_CAND + 2
    ws.Cells(r, 1).Value2 = "sexe"
    ws.Range(ws.Cells(r, 2), ws.Cells(r, 9)).Value2 = Tiret()
    ws.Cells(r, 10).Value2 = "Exclue d" & Apos() & "office (r�glementaire)"
    ws.Range("B2:B" & d & ",F2:G" & d).NumberFormat = "0.000"
    ws.Range("D2:E" & d & ",I2:I" & d).NumberFormat = FormatCoef()
    DefinirNom "sel_var", ws.Range("A2:A" & d)
    DefinirNom "sel_v", ws.Range("E2:E" & d)
    DefinirNom "sel_decision", ws.Range("J2:J" & d)
End Sub

' Lignes � exposition non nulle : indice de classe de chaque candidate, E, E x CRM, N
Public Function LireClassesLignes(cls() As Long, e() As Double, es() As Double, nn() As Double) As Long
    Dim v As Variant, r As Long, n As Long, i As Long, col(0 To 6) As Long
    v = Feuille(F_CONTRATS).Range("H2:W" & gLigC).Value2
    For i = 0 To NB_CAND - 1
        col(i) = Feuille(F_CONTRATS).Range(ColSource(i) & "1").Column - 7
    Next i
    ReDim cls(1 To UBound(v, 1), 0 To NB_CAND - 1)
    ReDim e(1 To UBound(v, 1)): ReDim es(1 To UBound(v, 1)): ReDim nn(1 To UBound(v, 1))
    n = 0
    For r = 1 To UBound(v, 1)
        If v(r, 9) > 0 Then
            n = n + 1
            For i = 0 To NB_CAND - 1
                cls(n, i) = IndiceClasse(i, v(r, col(i)))
            Next i
            e(n) = v(r, 9): es(n) = v(r, 15): nn(n) = v(r, 16)
        End If
    Next r
    LireClassesLignes = n
End Function

' V de Cram�r entre deux candidates (table de contingence pond�r�e par l'exposition)
Private Function VCramer(ByVal a As Long, ByVal b As Long, cls() As Long, e() As Double, ByVal n As Long) As Double
    Dim t() As Double, lr() As Double, lc() As Double, tot As Double, r As Long, i As Long, j As Long
    Dim x2 As Double, ex As Double, k As Long
    ReDim t(1 To gNbCl(a), 1 To gNbCl(b)): ReDim lr(1 To gNbCl(a)): ReDim lc(1 To gNbCl(b))
    For r = 1 To n
        t(cls(r, a), cls(r, b)) = t(cls(r, a), cls(r, b)) + e(r)
    Next r
    For i = 1 To gNbCl(a)
        For j = 1 To gNbCl(b)
            lr(i) = lr(i) + t(i, j): lc(j) = lc(j) + t(i, j): tot = tot + t(i, j)
        Next j
    Next i
    For i = 1 To gNbCl(a)
        For j = 1 To gNbCl(b)
            ex = lr(i) * lc(j) / tot
            If ex > 0 Then x2 = x2 + (t(i, j) - ex) ^ 2 / ex
        Next j
    Next i
    k = gNbCl(a)
    If gNbCl(b) < k Then k = gNbCl(b)
    k = k - 1
    If k > 0 Then VCramer = Sqr(x2 / (tot * k)) Else VCramer = 0
End Function

Public Sub Etape08Decisions()
    Dim sel As Variant, dec(0 To 6) As String, vm() As Double, cls() As Long, e() As Double, es() As Double
    Dim nn() As Double, n As Long, i As Long, j As Long, ordre(0 To 6) As Long, no As Long, t As Long
    Dim garde(0 To 6) As Boolean, vmax As Double, w As Long
    sel = Feuille(F_SELECTION).Range("A2:F" & NB_CAND + 1).Value2
    n = LireClassesLignes(cls, e, es, nn)
    ReDim vm(0 To NB_CAND - 1, 0 To NB_CAND - 1)
    For i = 0 To NB_CAND - 1
        For j = i + 1 To NB_CAND - 1
            vm(i, j) = VCramer(i, j, cls, e, n): vm(j, i) = vm(i, j)
        Next j
    Next i
    no = 0
    For i = 0 To NB_CAND - 1
        If sel(i + 1, 3) = 0 Then
            dec(i) = "�cart�e (une seule classe)"
        ElseIf sel(i + 1, 4) >= CDbl(Param("seuil_p")) Then
            dec(i) = "�cart�e (non significative)"
        Else
            j = no
            Do While j > 0
                If sel(ordre(j - 1) + 1, 5) >= sel(i + 1, 5) Then Exit Do
                ordre(j) = ordre(j - 1): j = j - 1
            Loop
            ordre(j) = i: no = no + 1
        End If
    Next i
    For t = 0 To no - 1
        i = ordre(t): vmax = -1: w = -1
        For j = 0 To NB_CAND - 1
            If garde(j) Then
                If vm(i, j) >= CDbl(Param("seuil_v_redondance")) And vm(i, j) > vmax Then vmax = vm(i, j): w = j
            End If
        Next j
        If w >= 0 Then dec(i) = "�cart�e (redondante avec " & Candidate(w) & ")" Else garde(i) = True
    Next t
    EliminationDescendante garde, dec, cls, es, nn, n
    EcrireAssociations vm, dec
End Sub

' �limination descendante par le test du rapport de vraisemblance (IRLS Poisson en m�moire)
Private Sub EliminationDescendante(garde() As Boolean, dec() As String, cls() As Long, es() As Double, _
                                   nn() As Double, ByVal n As Long)
    Dim ws As Worksheet, vars() As Long, nv As Long, i As Long, k As Long, pire As Long, pmax As Double
    Dim dD As Double, ddl As Long, p As Double, dfull As Double, dred As Double, sans() As Long
    Set ws = Feuille(F_SELECTION)
    Do
        nv = 0
        For i = 0 To NB_CAND - 1
            If garde(i) Then
                nv = nv + 1
                ReDim Preserve vars(1 To nv)
                vars(nv) = i
            End If
        Next i
        If nv = 0 Then Exit Do
        dfull = DevianceCellules(vars, nv, vars, nv, cls, es, nn, n)
        pire = 0: pmax = -1
        For k = 1 To nv
            ReDim sans(1 To nv)
            For i = 1 To nv - 1
                If i < k Then sans(i) = vars(i) Else sans(i) = vars(i + 1)
            Next i
            dred = DevianceCellules(vars, nv, sans, nv - 1, cls, es, nn, n)
            dD = dred - dfull: ddl = gNbCl(vars(k)) - 1
            If dD < 0 Then dD = 0
            p = Application.WorksheetFunction.ChiSq_Dist_RT(dD, ddl)
            ws.Cells(vars(k) + 2, 7).Value2 = dD
            ws.Cells(vars(k) + 2, 8).Value2 = ddl
            If p > pmax Then pmax = p: pire = k
        Next k
        If pmax >= CDbl(Param("seuil_p")) Then
            garde(vars(pire)) = False
            dec(vars(pire)) = "�cart�e (rapport de vraisemblance)"
        Else
            Exit Do
        End If
    Loop
    For i = 0 To NB_CAND - 1
        If garde(i) Then dec(i) = DECISION_RETENUE
        ws.Cells(i + 2, 10).Value2 = dec(i)
    Next i
End Sub

' D�viance Poisson d'un mod�le (variables mvars) ajust� sur les cellules des variables cvars
Private Function DevianceCellules(cvars() As Long, ByVal ncv As Long, mvars() As Long, ByVal nmv As Long, _
                                  cls() As Long, es() As Double, nn() As Double, ByVal n As Long) As Double
    Dim d As Object, r As Long, k As Long, cle As String, nc As Long, cid As Long
    Dim cc() As Long, ces() As Double, cn() As Double, x() As Double, off() As Double
    Dim beta() As Double, vinv() As Double, dev As Double, journal() As Double, nit As Long, mu() As Double
    Set d = Dico()
    ReDim cc(1 To n, 0 To NB_CAND - 1): ReDim ces(1 To n): ReDim cn(1 To n)
    For r = 1 To n
        cle = ""
        For k = 1 To ncv: cle = cle & cls(r, cvars(k)) & "|": Next k
        If d.Exists(cle) Then
            cid = d(cle)
        Else
            nc = nc + 1: cid = nc: d.Add cle, cid
            For k = 0 To NB_CAND - 1: cc(cid, k) = cls(r, k): Next k
        End If
        ces(cid) = ces(cid) + es(r): cn(cid) = cn(cid) + nn(r)
    Next r
    ReDim off(1 To nc)
    For r = 1 To nc: off(r) = Log(ces(r)): Next r
    MatriceX cc, nc, mvars, nmv, x
    AjusterPoisson x, cn, off, nc, beta, vinv, dev, journal, nit, mu
    DevianceCellules = dev
End Function

Private Sub EcrireAssociations(vm() As Double, dec() As String)
    Dim ws As Worksheet, i As Long, j As Long, np As Long, d As String, cp As Long
    Set ws = NouvelleFeuille(F_ASSOCIATIONS)
    d = CStr(NB_CAND + 1): cp = NB_CAND + 4
    ws.Range("A1").Value2 = "variable"
    For i = 0 To NB_CAND - 1
        ws.Cells(1, i + 2).Value2 = Candidate(i)
        ws.Cells(i + 2, 1).Value2 = Candidate(i)
        For j = 0 To NB_CAND - 1
            If i <> j Then ws.Cells(i + 2, j + 2).Value2 = vm(i, j)
        Next j
    Next i
    ws.Cells(1, NB_CAND + 2).Value2 = "retenue"
    ws.Range(ws.Cells(2, NB_CAND + 2), ws.Cells(NB_CAND + 1, NB_CAND + 2)).Formula = "=--(Selection!J2=""Retenue"")"
    ws.Cells(NB_CAND + 2, 1).Value2 = "retenue"
    ws.Range(ws.Cells(NB_CAND + 2, 2), ws.Cells(NB_CAND + 2, NB_CAND + 1)).Formula = _
        "=--(INDEX(Selection!$J$2:$J$" & d & ",COLUMN()-1)=""Retenue"")"
    FormaterEntetes ws.Range(ws.Cells(1, 1), ws.Cells(1, NB_CAND + 2)), True
    FormaterEntetes ws.Range(ws.Cells(2, 1), ws.Cells(NB_CAND + 2, 1)), True
    ws.Range(ws.Cells(2, 2), ws.Cells(NB_CAND + 1, NB_CAND + 1)).NumberFormat = "0.0000"
    DefinirNom "assoc_v", ws.Range(ws.Cells(2, 2), ws.Cells(NB_CAND + 1, NB_CAND + 1))
    EntetesTable ws, 1, cp, Array("paire", "v")
    np = 0
    For i = 0 To NB_CAND - 1
        For j = i + 1 To NB_CAND - 1
            If dec(i) = DECISION_RETENUE And dec(j) = DECISION_RETENUE Then
                np = np + 1
                ws.Cells(np + 1, cp).Value2 = Candidate(i) & "|" & Candidate(j)
                ws.Cells(np + 1, cp + 1).Formula = "=INDEX(assoc_v," & (i + 1) & "," & (j + 1) & ")"
            End If
        Next j
    Next i
    If np = 0 Then np = 1
    DefinirNom "assoc_paires", ws.Range(ws.Cells(2, cp), ws.Cells(np + 1, cp))
    DefinirNom "assoc_paires_v", ws.Range(ws.Cells(2, cp + 1), ws.Cells(np + 1, cp + 1))
    ws.Cells(1, cp + 3).Value2 = "v_max_retenues"
    ws.Cells(2, cp + 3).Value2 = "paire_max"
    ws.Cells(1, cp + 4).Formula = "=IFERROR(MAX(assoc_paires_v),0)"
    ws.Cells(2, cp + 4).Formula = "=IFERROR(INDEX(assoc_paires,MATCH(MAX(assoc_paires_v),assoc_paires_v,0)),"""")"
    DefinirNom "assoc_vmax", ws.Cells(1, cp + 4)
    DefinirNom "assoc_paire", ws.Cells(2, cp + 4)
    FormaterSynthese ws.Range(ws.Cells(1, cp + 4), ws.Cells(2, cp + 4))
    AjouterControle 8, 1, "Effectif attendu >= 5 dans chaque classe", "=MIN(Selection!F2:F" & d & ")>=5"
    AjouterControle 8, 2, "Aucune paire de retenues avec V >= seuil", _
        "=MAX(Associations!B2:H8*Associations!I2:I8*Associations!B9:H9)<seuil_v_redondance", True, "=seuil_v_redondance"
    AjouterControle 8, 3, "Sexe exclu d" & Apos() & "office", _
        "=COUNTIFS(Selection!A2:A" & (NB_CAND + 2) & ",""sexe"",Selection!J2:J" & (NB_CAND + 2) & ",""Retenue"")=0"
End Sub

' Variables retenues (indices de candidates), lues dans la feuille Selection
Public Function VariablesRetenues(vars() As Long) As Long
    Dim v As Variant, i As Long, n As Long
    v = Feuille(F_SELECTION).Range("J2:J" & NB_CAND + 1).Value2
    n = 0
    For i = 0 To NB_CAND - 1
        If CStr(v(i + 1, 1)) = DECISION_RETENUE Then
            n = n + 1
            ReDim Preserve vars(1 To n)
            vars(n) = i
        End If
    Next i
    VariablesRetenues = n
End Function

' ---------------------------------------------------------------------
' �tape 11 : tarif (calage theta, chargements) et relativit�s
' ---------------------------------------------------------------------
Public Sub Etape11Tarif()
    Dim ws As Worksheet, lib As Variant, frm As Variant, i As Long, c As Long
    Set ws = NouvelleFeuille(F_TARIF)
    EntetesTable ws, 1, 8, Array("indicateur", "valeur")
    lib = Array("B0", "somme_pp0", "theta", "base_pp", "pp_moy", "chargement", "sp_cible")
    frm = Array("=EXP(glmf_b0)*EXP(glmc_g0)*kappa", "=SUMPRODUCT(c_expo,c_pp0)", "=charge_cible/somme_pp0", _
        "=B0*theta", "=SUMPRODUCT(c_expo,c_pp)/SUM(c_expo)", _
        "=(1+taux_securite)/(1-taux_gestion-taux_acquisition-taux_marge)", _
        "=(1-taux_gestion-taux_acquisition-taux_marge)/(1+taux_securite)")
    For i = 0 To UBound(lib)
        ws.Cells(i + 2, 8).Value2 = lib(i)
        DefinirNom CStr(lib(i)), ws.Cells(i + 2, 9)
    Next i
    For i = 0 To UBound(lib)
        ws.Cells(i + 2, 9).Formula = frm(i)
    Next i
    ws.Range("I2:I3,I5:I6").NumberFormat = FormatMontant()
    ws.Range("I4,I7").NumberFormat = "0.000000"
    ws.Range("I8").NumberFormat = FormatTaux()
    FormaterSynthese ws.Range("I2:I8")
    c = ColContrats("c_pp")
    Feuille(F_CONTRATS).Range(Feuille(F_CONTRATS).Cells(2, c), Feuille(F_CONTRATS).Cells(gLigC, c)).Formula = _
        "=" & LettreCol(c - 1) & "2*theta"
End Sub

' Table des relativit�s (apr�s Impact, pour la colonne evolution)
Public Sub Etape11Relativites()
    Dim ws As Worksheet, vars() As Long, nv As Long, k As Long, q As Long, r As Long, r1 As Long, v As String
    Set ws = Feuille(F_TARIF)
    EntetesTable ws, 1, 1, Array("variable", "classe", "rel_frequence", "rel_cout", "rel_prime_pure", "evolution")
    nv = VariablesRetenues(vars)
    r = 2
    For k = 1 To nv
        v = Candidate(vars(k)): r1 = r
        For q = 1 To gNbCl(vars(k))
            ws.Cells(r, 1).Value2 = v
            ws.Cells(r, 2).Value2 = "'" & gClLib(vars(k), q)
            r = r + 1
        Next q
        ws.Range("F" & r1 & ":F" & r - 1).Formula = "=SUMIFS(i_ht_new,i_cl_" & v & ",B" & r1 & ")/SUMIFS(i_ht_act,i_cl_" & v & ",B" & r1 & ")-1"
    Next k
    ws.Range("C2:C" & r - 1).Formula = "=EXP(IFERROR(INDEX(glmf_coef,MATCH(A2&""|""&B2,glmf_cle,0)),0))"
    ws.Range("D2:D" & r - 1).Formula = "=EXP(IFERROR(INDEX(glmc_coef,MATCH(A2&""|""&B2,glmc_cle,0)),0))"
    ws.Range("E2:E" & r - 1).Formula = "=C2*D2"
    ws.Range("C2:E" & r - 1).NumberFormat = "0.0000"
    ws.Range("F2:F" & r - 1).NumberFormat = FormatTaux()
    DefinirNom "tarif_var", ws.Range("A2:A" & r - 1)
    DefinirNom "tarif_classe", ws.Range("B2:B" & r - 1)
    DefinirNom "tarif_relf", ws.Range("C2:C" & r - 1)
    DefinirNom "tarif_relc", ws.Range("D2:D" & r - 1)
    DefinirNom "tarif_relpp", ws.Range("E2:E" & r - 1)
    DefinirNom "tarif_evol", ws.Range("F2:F" & r - 1)
End Sub

' Impact sur les polices en portefeuille au 31/12/annee_fin
Public Sub Etape11Impact()
    Dim ws As Worksheet, v As Variant, r As Long, m As Long, af As Long, fin As Double, vars() As Long, nv As Long
    Dim s() As Variant, lg() As Variant, n As String, k As Long, c As Long, cK As Long
    af = CLng(Param("annee_fin")): fin = CDbl(DateSerial(af, 12, 31))
    v = Feuille(F_CONTRATS).Range("A2:P" & gLigC).Value2
    For r = 1 To UBound(v, 1)
        If v(r, 2) = af And v(r, 4) = fin And v(r, 16) > 0 Then m = m + 1
    Next r
    ReDim s(1 To m, 1 To 1): ReDim lg(1 To m, 1 To 1)
    m = 0
    For r = 1 To UBound(v, 1)
        If v(r, 2) = af And v(r, 4) = fin And v(r, 16) > 0 Then
            m = m + 1: s(m, 1) = CStr(v(r, 1)) & "|" & af: lg(m, 1) = r
        End If
    Next r
    Set ws = NouvelleFeuille(F_IMPACT)
    nv = VariablesRetenues(vars)
    cK = 7 + nv
    EntetesTable ws, 1, 1, Array("cle", "age", "zone", "puissance_cv", "usage", "crm_c")
    For k = 1 To nv: EntetesTable ws, 1, 6 + k, Array("cl_" & Candidate(vars(k))): Next k
    EntetesTable ws, 1, cK, Array("ht_act", "ht_new", "evol", "evol_p", "ht_cap", "ttc_new", "ligne")
    ws.Range("A2").Resize(m, 1).Value2 = s
    ws.Cells(2, cK + 6).Resize(m, 1).Value2 = lg
    n = CStr(m + 1)
    ws.Range("B2:B" & n).Formula = "=INDEX(c_age,$" & LettreCol(cK + 6) & "2)"
    ws.Range("C2:C" & n).Formula = "=INDEX(c_zone,$" & LettreCol(cK + 6) & "2)"
    ws.Range("D2:D" & n).Formula = "=INDEX(c_puissance_cv,$" & LettreCol(cK + 6) & "2)"
    ws.Range("E2:E" & n).Formula = "=INDEX(c_usage,$" & LettreCol(cK + 6) & "2)"
    ws.Range("F2:F" & n).Formula = "=INDEX(c_crm_c,$" & LettreCol(cK + 6) & "2)"
    For k = 1 To nv
        c = 6 + k
        ws.Range(ws.Cells(2, c), ws.Cells(m + 1, c)).Formula = "=INDEX(c_cl_" & Candidate(vars(k)) & ",$" & LettreCol(cK + 6) & "2)"
        DefinirNom "i_cl_" & Candidate(vars(k)), ws.Range(ws.Cells(2, c), ws.Cells(m + 1, c))
    Next k
    ImpactFormules ws, cK, m
End Sub

Private Sub ImpactFormules(ByVal ws As Worksheet, ByVal cK As Long, ByVal m As Long)
    Dim L As String, n As String
    n = CStr(m + 1)
    L = LettreCol(cK)
    ws.Range(L & "2:" & L & n).Formula = "=base_actuelle*LOOKUP(B2,ta_age_min,ta_age_rel)*" & _
        "INDEX(ta_zone_rel,MATCH(C2,ta_zone_mod,0))*LOOKUP(D2,ta_cv_min,ta_cv_rel)*" & _
        "INDEX(ta_usage_rel,MATCH(E2,ta_usage_mod,0))*F2"
    ws.Range(ws.Cells(2, cK + 1), ws.Cells(m + 1, cK + 1)).Formula = "=INDEX(c_pp,$" & LettreCol(cK + 6) & "2)*chargement"
    ws.Range(ws.Cells(2, cK + 2), ws.Cells(m + 1, cK + 2)).Formula = "=" & LettreCol(cK + 1) & "2/" & L & "2-1"
    ws.Range(ws.Cells(2, cK + 3), ws.Cells(m + 1, cK + 3)).Formula = _
        "=MIN(MAX(" & LettreCol(cK + 2) & "2,-plafond_evolution),plafond_evolution)"
    ws.Range(ws.Cells(2, cK + 4), ws.Cells(m + 1, cK + 4)).Formula = "=" & L & "2*(1+" & LettreCol(cK + 3) & "2)"
    ws.Range(ws.Cells(2, cK + 5), ws.Cells(m + 1, cK + 5)).Formula = "=" & LettreCol(cK + 1) & "2*(1+taux_taxe)"
    ws.Range(ws.Cells(2, cK), ws.Cells(m + 1, cK + 1)).NumberFormat = FormatMontant()
    ws.Range(ws.Cells(2, cK + 4), ws.Cells(m + 1, cK + 5)).NumberFormat = FormatMontant()
    ws.Range(ws.Cells(2, cK + 2), ws.Cells(m + 1, cK + 3)).NumberFormat = FormatTaux()
    NommerColonnes ws, m + 1, Array("i_cle"), 1
    NommerColonnes ws, m + 1, Array("i_ht_act", "i_ht_new", "i_evol", "i_evol_p", "i_ht_cap", "i_ttc_new", "i_ligne"), cK
    ImpactSynthese ws, cK + 8
End Sub

Private Sub ImpactSynthese(ByVal ws As Worksheet, ByVal c As Long)
    Dim lib As Variant, frm As Variant, i As Long, dl As Variant, df As Variant
    EntetesTable ws, 1, c, Array("indicateur", "valeur")
    lib = Array("n_renouv", "evol_moy", "equilibre", "ttc_moy", "ttc_moy_act", "evol_max_p")
    frm = Array("=COUNTA(i_cle)", "=SUM(i_ht_new)/SUM(i_ht_act)-1", "=SUM(i_ht_cap)/SUM(i_ht_new)", _
        "=AVERAGE(i_ttc_new)", "=AVERAGE(i_ht_act)*(1+taux_taxe)", "=MAX(ABS(i_evol_p))")
    For i = 0 To UBound(lib)
        ws.Cells(i + 2, c).Value2 = lib(i)
        DefinirNom CStr(lib(i)), ws.Cells(i + 2, c + 1)
    Next i
    For i = 0 To UBound(lib)
        If i = UBound(lib) Then ws.Cells(i + 2, c + 1).FormulaArray = frm(i) Else ws.Cells(i + 2, c + 1).Formula = frm(i)
    Next i
    FormaterSynthese ws.Range(ws.Cells(2, c + 1), ws.Cells(UBound(lib) + 2, c + 1))
    EntetesTable ws, 10, c, Array("tranche_evolution", "nb_polices", "part")
    dl = Array("< -10 %", "-10 � -5 %", "-5 � 0 %", "0 � +5 %", "+5 � +10 %", "> +10 %")
    df = Array("=COUNTIF(i_evol,""<""&-0.1)", "=COUNTIFS(i_evol,"">=""&-0.1,i_evol,""<""&-0.05)", _
        "=COUNTIFS(i_evol,"">=""&-0.05,i_evol,""<""&0)", "=COUNTIFS(i_evol,"">=""&0,i_evol,""<""&0.05)", _
        "=COUNTIFS(i_evol,"">=""&0.05,i_evol,""<=""&0.1)", "=COUNTIF(i_evol,"">""&0.1)")
    For i = 0 To 5
        ws.Cells(11 + i, c).Value2 = "'" & dl(i)
        ws.Cells(11 + i, c + 1).Formula = df(i)
        ws.Cells(11 + i, c + 2).Formula = "=" & LettreCol(c + 1) & (11 + i) & "/n_renouv"
    Next i
    ws.Range(ws.Cells(11, c + 2), ws.Cells(16, c + 2)).NumberFormat = FormatTaux()
    DefinirNom "disl_tranche", ws.Range(ws.Cells(11, c), ws.Cells(16, c))
    DefinirNom "disl_part", ws.Range(ws.Cells(11, c + 2), ws.Cells(16, c + 2))
    AjouterControle 11, 1, "Calage theta : somme E x PP = charge cible", "=ABS(SUMPRODUCT(c_expo,c_pp)/charge_cible-1)<1E-9"
    AjouterControle 11, 2, "Aucune �volution au-del� du plafond", "=MAX(ABS(i_evol_p))<=plafond_evolution+1E-12", True, _
        "=plafond_evolution"
    AjouterControle 11, 3, "�quilibre apr�s plafonnement >= equilibre_min", "=equilibre>=equilibre_min", False, _
        "=equilibre", "=equilibre_min"
End Sub

' ---------------------------------------------------------------------
' Tableau de bord : feuille Segments et bandeau
' ---------------------------------------------------------------------
Public Sub ConstruireSegments()
    Dim ws As Worksheet, a0 As Long, a1 As Long, y As Long, d As Variant, j As Long, i As Long, k As Long
    Dim r As Long, r1 As Long, dims As Variant, v As String
    Set ws = NouvelleFeuille(F_SEGMENTS)
    EntetesTable ws, 1, 1, Array("exercice", "dimension", "classe", "exposition", "primes", "charge_ecr", "charge", "sp", "prime_moy")
    a0 = CLng(Param("annee_debut")): a1 = CLng(Param("annee_fin"))
    dims = Split(LISTE_DIM_SEGMENTS, ",")
    r = 2
    For y = a0 To a1
        For j = 0 To UBound(dims)
            v = dims(j): i = IndexCandidate(v)
            If NomExiste("c_cl_" & v) Then
                r1 = r
                For k = 1 To gNbCl(i)
                    ws.Cells(r, 1).Value2 = y: ws.Cells(r, 2).Value2 = v: ws.Cells(r, 3).Value2 = "'" & gClLib(i, k)
                    r = r + 1
                Next k
                ws.Range("D" & r1 & ":D" & r - 1).Formula = "=SUMIFS(c_expo,c_exercice,A" & r1 & ",c_cl_" & v & ",C" & r1 & ")"
                ws.Range("E" & r1 & ":E" & r - 1).Formula = "=SUMIFS(c_prime,c_exercice,A" & r1 & ",c_cl_" & v & ",C" & r1 & ")"
                ws.Range("F" & r1 & ":F" & r - 1).Formula = "=SUMIFS(c_charge_ecr,c_exercice,A" & r1 & ",c_cl_" & v & ",C" & r1 & ")"
            End If
        Next j
    Next y
    ws.Range("G2:G" & r - 1).Formula = "=INDEX(hist_ult,MATCH(A2,hist_exercice,0))*F2/SUMIFS(c_charge_ecr,c_exercice,A2)"
    ws.Range("H2:H" & r - 1).Formula = "=G2/E2"
    ws.Range("I2:I" & r - 1).Formula = "=E2/D2"
    ws.Range("D2:D" & r - 1).NumberFormat = FormatExpo()
    ws.Range("E2:G" & r - 1 & ",I2:I" & r - 1).NumberFormat = FormatMontant()
    ws.Range("H2:H" & r - 1).NumberFormat = FormatTaux()
    NommerColonnes ws, r - 1, Array("seg_annee", "seg_dim", "seg_classe", "seg_expo", "seg_primes", "seg_charge_ecr", _
        "seg_charge", "seg_sp", "seg_prime_moy"), 1
    EntetesTable ws, 1, 11, Array("exercice", "bandeau")
    For y = a0 To a1
        ws.Cells(y - a0 + 2, 11).Formula = "=annee_debut+" & (y - a0)
    Next y
    DefinirNom "seg_bandeau_annee", ws.Range("K2:K" & (a1 - a0 + 2))
    DefinirNom "seg_bandeau", ws.Range("L2:L" & (a1 - a0 + 2))
End Sub

' Messages du bandeau (VBA, valeurs), un par exercice (section 6.12)
Public Sub CalculerBandeaux()
    Dim ws As Worksheet, v As Variant, he As Variant, a0 As Long, a1 As Long, y As Long, r As Long, m As Long
    Dim cles() As Double, idx() As Long, desig() As String, sps() As Double, cible As Double, eY As Double
    Dim noms() As String, valeurs() As Double, k As Long
    Set ws = Feuille(F_SEGMENTS)
    v = ws.Range("A2:H" & PlageNom("seg_annee").Rows.Count + 1).Value2
    he = PlageNom("hist_expo").Value2
    a0 = CLng(Param("annee_debut")): a1 = CLng(Param("annee_fin"))
    cible = CDbl(ValeurNom("sp_cible"))
    For y = a0 To a1
        eY = he(y - a0 + 1, 1)
        m = 0
        ReDim cles(1 To UBound(v, 1)): ReDim idx(1 To UBound(v, 1)): ReDim desig(1 To UBound(v, 1)): ReDim sps(1 To UBound(v, 1))
        For r = 1 To UBound(v, 1)
            If v(r, 1) = y And EstNombre(v(r, 8)) Then
                If v(r, 4) >= PART_EXPO_SEGMENT * eY And v(r, 8) > cible Then
                    m = m + 1
                    cles(m) = -v(r, 8): idx(m) = m: sps(m) = v(r, 8)
                    desig(m) = DesignationSegment(CStr(v(r, 2)), CStr(v(r, 3)))
                End If
            End If
        Next r
        TriFusion cles, idx, m
        k = m: If k > 2 Then k = 2
        ReDim noms(1 To 2): ReDim valeurs(1 To 2)
        For r = 1 To k: noms(r) = desig(idx(r)): valeurs(r) = sps(idx(r)): Next r
        ws.Cells(y - a0 + 2, 12).Value2 = TexteBandeau(k, noms, valeurs, y, cible)
    Next y
End Sub

' ---------------------------------------------------------------------
' Feuille Calculateur (6.13)
' ---------------------------------------------------------------------
Public Sub ConstruireCalculateur()
    Dim ws As Worksheet, lib As Variant, nm As Variant, i As Long
    Set ws = NouvelleFeuille(F_CALCULATEUR)
    EntetesTable ws, 1, 1, Array("element", "valeur")
    lib = Array("age", "zone", "puissance_cv", "usage", "crm", "", "securite", "gestion", "acquisition", "marge", "taxes")
    nm = Array("calc_age", "calc_zone", "calc_cv", "calc_usage", "calc_crm", "", "calc_securite", "calc_gestion", _
        "calc_acquisition", "calc_marge", "calc_taxes")
    For i = 0 To UBound(lib)
        If Len(lib(i)) > 0 Then
            ws.Cells(i + 2, 1).Value2 = lib(i)
            DefinirNom CStr(nm(i)), ws.Cells(i + 2, 2)
        End If
    Next i
    ReinitialiserEntrees
    FormulesCalculateur ws
    ws.Range("B2:B12").Interior.Color = Feuille(F_PARAMETRES).Range("A1").Interior.Color
End Sub

Public Sub ReinitialiserEntrees()
    Dim ws As Worksheet
    Set ws = Feuille(F_CALCULATEUR)
    ws.Range("B2").Value2 = Param("defaut_age")
    ws.Range("B3").Value2 = Param("defaut_zone")
    ws.Range("B4").Value2 = Param("defaut_cv")
    ws.Range("B5").Value2 = Param("defaut_usage")
    ws.Range("B6").Value2 = Param("defaut_crm")
    ws.Range("B8").Value2 = Param("taux_securite")
    ws.Range("B9").Value2 = Param("taux_gestion")
    ws.Range("B10").Value2 = Param("taux_acquisition")
    ws.Range("B11").Value2 = Param("taux_marge")
    ws.Range("B12").Value2 = Param("taux_taxe")
End Sub

Private Sub FormulesCalculateur(ByVal ws As Worksheet)
    Dim lib As Variant, frm As Variant, i As Long, vars() As Long, nv As Long, k As Long, sf As String, sc As String
    Dim src As Variant, cl As Variant, v As String
    nv = VariablesRetenues(vars)
    src = Array("B2", "B3", "B4", "B5")
    cl = Array("B14", "B15", "B16", "B17")
    For k = 1 To nv
        v = Candidate(vars(k))
        i = IndexCandidate(v)
        If i <= 3 Then
            sf = sf & "+IFERROR(INDEX(glmf_coef,MATCH(""" & v & "|""&" & cl(i) & ",glmf_cle,0)),0)"
            sc = sc & "+IFERROR(INDEX(glmc_coef,MATCH(""" & v & "|""&" & cl(i) & ",glmc_cle,0)),0)"
        End If
    Next k
    lib = Array("cl_age", "cl_zone", "cl_puissance_cv", "cl_usage", "freq_base", "cout_base", "rf", "rc", "freq", _
        "cout", "pp", "ht", "ttc", "mensuel", "mt_securite", "mt_frais", "mt_marge", "mt_taxes", "ht_act", _
        "vs_actuel", "vs_moyenne")
    frm = Array(FormuleClasseCalc("age", "B2"), FormuleClasseCalc("zone", "B3"), FormuleClasseCalc("puissance_cv", "B4"), _
        FormuleClasseCalc("usage", "B5"), "=EXP(glmf_b0)", "=EXP(glmc_g0)", "=EXP(0" & sf & ")", "=EXP(0" & sc & ")", _
        "=B18*B20*B6", "=B19*B21*kappa*theta", "=B22*B23", "=B24*(1+B8)/(1-B9-B10-B11)", "=B25*(1+B12)", "=B26/12", _
        "=B24*B8", "=B25*(B9+B10)", "=B25*B11", "=B25*B12", _
        "=base_actuelle*LOOKUP(B2,ta_age_min,ta_age_rel)*INDEX(ta_zone_rel,MATCH(B3,ta_zone_mod,0))*" & _
        "LOOKUP(B4,ta_cv_min,ta_cv_rel)*INDEX(ta_usage_rel,MATCH(B5,ta_usage_mod,0))*B6", _
        "=B25/B32-1", "=B26/ttc_moy-1")
    For i = 0 To UBound(lib)
        ws.Cells(i + 14, 1).Value2 = lib(i)
        ws.Cells(i + 14, 2).Formula = frm(i)
        DefinirNom "calc_" & lib(i), ws.Cells(i + 14, 2)
    Next i
    ws.Range("B18,B22").NumberFormat = "0.0000%"
    ws.Range("B19,B23:B32").NumberFormat = FormatMontant()
    ws.Range("B20:B21").NumberFormat = "0.0000"
    ws.Range("B33:B34").NumberFormat = FormatTaux()
    FormaterSynthese ws.Range("B14:B34")
    AjusterColonnes ws
End Sub

Private Function FormuleClasseCalc(ByVal v As String, ByVal cel As String) As String
    If Not NomExiste("bornes_" & v & "_classe") Then
        FormuleClasseCalc = "="""""
    ElseIf EstOrdinale(v) Then
        FormuleClasseCalc = "=INDEX(bornes_" & v & "_classe,MATCH(" & cel & ",bornes_" & v & "_min,1))"
    Else
        FormuleClasseCalc = "=INDEX(bornes_" & v & "_classe,MATCH(" & cel & ",bornes_" & v & "_mod,0))"
    End If
End Function
