Attribute VB_Name = "modDesign"
Option Explicit
' =====================================================================
' modDesign : charte graphique (section 8), primitives de dessin,
' barre lat�rale, en-t�tes, cartes, graphiques en barres, bulles.
' =====================================================================

' --- Couleurs (8.1) ---
Public Const C_VIOLET As Long = 16141931
Public Const C_VIOLET_FONCE As Long = 15218262
Public Const C_VIOLET_CLAIR As Long = 16772079
Public Const C_VIOLET_PALE As Long = 16773363
Public Const C_LAVANDE As Long = 16765401
Public Const C_LAVANDE_MOYEN As Long = 16755385
Public Const C_FORMULE_FOND As Long = 16775674
Public Const C_FORMULE_BORD As Long = 16772079
Public Const C_ENCRE As Long = 3020055
Public Const C_ENCRE_2 As Long = 6310218
Public Const C_GRIS_1 As Long = 9665404
Public Const C_GRIS_2 As Long = 11573915
Public Const C_FOND As Long = 16512758
Public Const C_BORD As Long = 16051180
Public Const C_BORD_2 As Long = 15721958
Public Const C_LIGNE As Long = 16183280
Public Const C_PISTE As Long = 16315123
Public Const C_ROSE As Long = 8928470
Public Const C_ROSE_FONCE As Long = 7286978
Public Const C_ROSE_TEXTE As Long = 7614393
Public Const C_ROSE_CLAIR As Long = 16116989
Public Const C_VERT As Long = 6657562
Public Const C_VERT_CLAIR As Long = 15660773
Public Const C_EXCEL As Long = 5077535
Public Const C_EXCEL_CLAIR As Long = 15660264
Public Const C_FEUILLE_ENTETE As Long = 16513015
Public Const C_FEUILLE_TITRE As Long = 16710651
Public Const C_FEUILLE_LIGNE As Long = 16117487
Public Const C_BLANC As Long = 16777215
Public Const C_PILE_SECURITE As Long = 13345781
Public Const C_PILE_FRAIS As Long = 12378255
Public Const C_PILE_MARGE As Long = 16755385
Public Const C_PILE_TAXES As Long = 9422335
Public Const SANS As Long = -1

' --- R�les typographiques (8.2) ---
Public Const F_REG As Long = 1
Public Const F_MED As Long = 2
Public Const F_SEMI As Long = 3
Public Const F_BOLD As Long = 4
Public Const F_XBOLD As Long = 5
Public Const F_MONO As Long = 6
Public Const F_SYM As Long = 7
Public Const F_MATH As Long = 8
Public Const F_ICONE As Long = 9
Private Const POLICE_JAKARTA As String = "Plus Jakarta Sans"
Private Const POLICE_JAKARTA_MED As String = "Plus Jakarta Sans Medium"
Private Const POLICE_JAKARTA_SEMI As String = "Plus Jakarta Sans SemiBold"
Private Const POLICE_JAKARTA_XBOLD As String = "Plus Jakarta Sans ExtraBold"
Private Const POLICE_REPLI As String = "Segoe UI"
Private Const POLICE_REPLI_SEMI As String = "Segoe UI Semibold"
Private Const POLICE_MONO As String = "Consolas"
Private Const POLICE_SYM As String = "Segoe UI Symbol"
Private Const POLICE_MATH As String = "Cambria Math"
Private Const POLICE_ICONE As String = "Times New Roman"
Private Const FICHIER_POLICE As String = "PlusJakartaSans-ExtraBold.ttf"

' --- Alignements ---
Public Const AL_G As Long = 1
Public Const AL_C As Long = 2
Public Const AL_D As Long = 3

' --- Canevas (section 9) ---
Public Const CANEVAS_L As Double = 960
Public Const CANEVAS_H As Double = 540
Private Const GRILLE_COLS As Long = 48
Private Const GRILLE_LIGNES As Long = 36
Private Const CELLULE_L As Double = 20
Private Const CELLULE_H As Double = 15
Private Const FACTEUR_MESURE As Double = 0.58
Private Const LARGEUR_TEXTE_MAX As Double = 700

' --- Barre lat�rale (10.1) ---
Private Const SB_L As Double = 176
Private Const SB_ENTREE_L As Double = 10
Private Const SB_ENTREE_W As Double = 156
Private Const SB_PAS As Double = 21
Private Const SB_T_GROUPE1 As Double = 88
Private Const SB_T_ETAPES1 As Double = 99
Private Const SB_T_GROUPE2 As Double = 212
Private Const SB_T_ETAPES2 As Double = 223
Private Const SB_T_CALC As Double = 494

' --- Bulles (12.3) ---
Private Const BULLE_W As Double = 250
Private Const BULLE_MARGE As Double = 14
Private Const BULLE_DELAI As String = "00:00:08"

Private mJakarta As Long          ' -1 inconnu, 0 repli, 1 install�e
Private mBulleProchaine As Date
Private mBulleFeuille As String

' ---------------------------------------------------------------------
' Polices
' ---------------------------------------------------------------------
Public Function PoliceJakarta() As Boolean
    If mJakarta = 0 Then mJakarta = -1
    If mJakarta = -1 Then
        mJakarta = 0
        If Len(Dir$(Environ$("WINDIR") & "\Fonts\" & FICHIER_POLICE)) > 0 Then mJakarta = 1
        If Len(Dir$(Environ$("LOCALAPPDATA") & "\Microsoft\Windows\Fonts\" & FICHIER_POLICE)) > 0 Then mJakarta = 1
        mJakarta = mJakarta + 10
    End If
    PoliceJakarta = (mJakarta = 11)
End Function

Public Sub ReinitialiserPolice()
    mJakarta = -1
End Sub

Public Sub AppliquerPolice(ByVal f As Object, ByVal role As Long)
    Dim j As Boolean
    j = PoliceJakarta()
    f.Bold = msoFalse: f.Italic = msoFalse
    Select Case role
        Case F_REG: f.Name = IIf(j, POLICE_JAKARTA, POLICE_REPLI)
        Case F_MED: f.Name = IIf(j, POLICE_JAKARTA_MED, POLICE_REPLI)
        Case F_SEMI: f.Name = IIf(j, POLICE_JAKARTA_SEMI, POLICE_REPLI_SEMI)
        Case F_BOLD: f.Name = IIf(j, POLICE_JAKARTA, POLICE_REPLI): f.Bold = msoTrue
        Case F_XBOLD
            If j Then f.Name = POLICE_JAKARTA_XBOLD Else f.Name = POLICE_REPLI: f.Bold = msoTrue
        Case F_MONO: f.Name = POLICE_MONO
        Case F_SYM: f.Name = POLICE_SYM
        Case F_MATH: f.Name = POLICE_MATH
        Case F_ICONE: f.Name = POLICE_ICONE: f.Bold = msoTrue: f.Italic = msoTrue
    End Select
End Sub

' ---------------------------------------------------------------------
' Primitives
' ---------------------------------------------------------------------
Public Function Forme(ByVal ws As Worksheet, ByVal nom As String, ByVal typ As Long, ByVal L As Double, _
                      ByVal T As Double, ByVal W As Double, ByVal H As Double, ByVal fond As Long, _
                      Optional ByVal bord As Long = SANS, Optional ByVal ep As Double = 0.75, _
                      Optional ByVal rayon As Double = 0) As Shape
    Dim s As Shape
    Set s = ws.Shapes.AddShape(typ, L, T, W, H)
    s.Name = nom
    If fond = SANS Then
        s.Fill.Visible = msoFalse
    Else
        s.Fill.Visible = msoTrue: s.Fill.Solid: s.Fill.ForeColor.RGB = fond
    End If
    If bord = SANS Then
        s.Line.Visible = msoFalse
    Else
        s.Line.Visible = msoTrue: s.Line.ForeColor.RGB = bord: s.Line.Weight = ep
    End If
    s.Shadow.Visible = msoFalse
    If rayon > 0 And (typ = msoShapeRoundedRectangle Or typ = msoShapeRound2SameRectangle) Then
        s.Adjustments.Item(1) = Application.Min(0.5, rayon / Application.Min(W, H))
    End If
    s.Placement = xlFreeFloating
    s.TextFrame2.MarginLeft = 0: s.TextFrame2.MarginRight = 0
    s.TextFrame2.MarginTop = 0: s.TextFrame2.MarginBottom = 0
    Set Forme = s
End Function

Public Function Carte(ByVal ws As Worksheet, ByVal nom As String, ByVal L As Double, ByVal T As Double, _
                      ByVal W As Double, ByVal H As Double, ByVal rayon As Double, _
                      Optional ByVal fond As Long = C_BLANC, Optional ByVal bord As Long = C_BORD) As Shape
    Set Carte = Forme(ws, nom, msoShapeRoundedRectangle, L, T, W, H, fond, bord, 0.75, rayon)
End Function

Public Function Pilule(ByVal ws As Worksheet, ByVal nom As String, ByVal L As Double, ByVal T As Double, _
                       ByVal W As Double, ByVal H As Double, ByVal fond As Long, Optional ByVal bord As Long = SANS, _
                       Optional ByVal rayon As Double = -1) As Shape
    If rayon < 0 Then rayon = H / 2
    Set Pilule = Forme(ws, nom, msoShapeRoundedRectangle, L, T, W, H, fond, bord, 0.75, rayon)
End Function

Public Function Cercle(ByVal ws As Worksheet, ByVal nom As String, ByVal L As Double, ByVal T As Double, _
                       ByVal D As Double, ByVal fond As Long, Optional ByVal bord As Long = SANS, _
                       Optional ByVal ep As Double = 0.75) As Shape
    Set Cercle = Forme(ws, nom, msoShapeOval, L, T, D, D, fond, bord, ep)
End Function

Public Function Filet(ByVal ws As Worksheet, ByVal nom As String, ByVal x1 As Double, ByVal y1 As Double, _
                      ByVal x2 As Double, ByVal y2 As Double, ByVal coul As Long, Optional ByVal ep As Double = 0.75, _
                      Optional ByVal pointille As Boolean = False) As Shape
    Dim s As Shape
    Set s = ws.Shapes.AddLine(x1, y1, x2, y2)
    s.Name = nom
    s.Line.ForeColor.RGB = coul: s.Line.Weight = ep
    If pointille Then s.Line.DashStyle = msoLineDash
    s.Placement = xlFreeFloating
    Set Filet = s
End Function

' Texte dans une zone (L, T, W, H) ; W = 0 : largeur mesur�e
Public Function Texte(ByVal ws As Worksheet, ByVal nom As String, ByVal L As Double, ByVal T As Double, _
                      ByVal W As Double, ByVal H As Double, ByVal txt As String, ByVal role As Long, _
                      ByVal taille As Double, ByVal coul As Long, Optional ByVal align As Long = AL_G, _
                      Optional ByVal espacement As Double = 0, Optional ByVal retour As Boolean = False) As Shape
    Dim s As Shape
    If W <= 0 Then W = MesurerTexte(ws, txt, role, taille, espacement) + 2
    If H <= 0 Then H = taille * 1.4
    Set s = ws.Shapes.AddTextbox(msoTextOrientationHorizontal, L, T, W, H)
    s.Name = nom
    s.Fill.Visible = msoFalse: s.Line.Visible = msoFalse
    s.Placement = xlFreeFloating
    FormaterTexte s, txt, role, taille, coul, align, espacement, retour
    Set Texte = s
End Function

' Texte align� � droite sur l'abscisse x (� fin x �)
Public Function TexteFin(ByVal ws As Worksheet, ByVal nom As String, ByVal x As Double, ByVal T As Double, _
                         ByVal txt As String, ByVal role As Long, ByVal taille As Double, ByVal coul As Long, _
                         Optional ByVal espacement As Double = 0, Optional ByVal W As Double = 300) As Shape
    Set TexteFin = Texte(ws, nom, x - W, T, W, 0, txt, role, taille, coul, AL_D, espacement)
End Function

Public Sub FormaterTexte(ByVal s As Shape, ByVal txt As String, ByVal role As Long, ByVal taille As Double, _
                         ByVal coul As Long, Optional ByVal align As Long = AL_G, _
                         Optional ByVal espacement As Double = 0, Optional ByVal retour As Boolean = False)
    With s.TextFrame2
        .MarginLeft = 0: .MarginRight = 0: .MarginTop = 0: .MarginBottom = 0
        .WordWrap = IIf(retour, msoTrue, msoFalse)
        .AutoSize = msoAutoSizeNone
        .VerticalAnchor = msoAnchorTop
        .TextRange.Text = txt
        AppliquerPolice .TextRange.Font, role
        With .TextRange.Font
            .Size = taille
            .Fill.Visible = msoTrue
            .Fill.ForeColor.RGB = coul
            .Spacing = espacement
        End With
        Select Case align
            Case AL_C: .TextRange.ParagraphFormat.Alignment = msoAlignCenter
            Case AL_D: .TextRange.ParagraphFormat.Alignment = msoAlignRight
            Case Else: .TextRange.ParagraphFormat.Alignment = msoAlignLeft
        End Select
    End With
End Sub

' Texte centr� dans une forme (boutons, puces, pastilles)
Public Sub TexteDansForme(ByVal s As Shape, ByVal txt As String, ByVal role As Long, ByVal taille As Double, _
                          ByVal coul As Long, Optional ByVal espacement As Double = 0)
    FormaterTexte s, txt, role, taille, coul, AL_C, espacement
    s.TextFrame2.VerticalAnchor = msoAnchorMiddle
End Sub

' Largeur d'un texte : forme provisoire en AutoSize (repli 0,58 x taille x nb caract�res)
Public Function MesurerTexte(ByVal ws As Worksheet, ByVal txt As String, ByVal role As Long, _
                             ByVal taille As Double, Optional ByVal espacement As Double = 0) As Double
    Dim s As Shape
    On Error GoTo Repli
    Set s = ws.Shapes.AddTextbox(msoTextOrientationHorizontal, 0, 0, LARGEUR_TEXTE_MAX, taille * 2)
    FormaterTexte s, txt, role, taille, C_ENCRE, AL_G, espacement
    s.TextFrame2.AutoSize = msoAutoSizeShapeToFitText
    MesurerTexte = s.Width
    s.Delete
    Exit Function
Repli:
    On Error Resume Next ' tol�r� (R4) : nettoyage de la forme provisoire
    If Not s Is Nothing Then s.Delete
    MesurerTexte = FACTEUR_MESURE * taille * Len(txt) + espacement * Len(txt)
End Function

Public Sub ChangerTexte(ByVal ws As Worksheet, ByVal nom As String, ByVal txt As String, _
                        Optional ByVal coul As Long = SANS)
    With ws.Shapes(nom).TextFrame2.TextRange
        .Text = txt
        If coul <> SANS Then .Font.Fill.ForeColor.RGB = coul
    End With
End Sub

Public Sub ChangerFond(ByVal ws As Worksheet, ByVal nom As String, ByVal coul As Long)
    ws.Shapes(nom).Fill.ForeColor.RGB = coul
End Sub

Public Function FormeExiste(ByVal ws As Worksheet, ByVal nom As String) As Boolean
    Dim s As Shape
    On Error Resume Next ' tol�r� (R4) : test d'existence
    Set s = ws.Shapes(nom)
    FormeExiste = (Err.Number = 0)
    On Error GoTo 0
End Function

' Supprime les formes dont le nom commence par un pr�fixe (formes dynamiques)
Public Sub SupprimerFormes(ByVal ws As Worksheet, ByVal prefixe As String)
    Dim i As Long
    For i = ws.Shapes.Count To 1 Step -1
        If Left$(ws.Shapes(i).Name, Len(prefixe)) = prefixe Then ws.Shapes(i).Delete
    Next i
End Sub

Public Sub Action(ByVal s As Shape, ByVal macro As String)
    s.OnAction = "'" & ThisWorkbook.Name & "'!" & macro
End Sub

' ---------------------------------------------------------------------
' Canevas : grille 20 x 15 pt, fond, quadrillage masqu� (section 9)
' ---------------------------------------------------------------------
Public Sub PreparerCanevas(ByVal ws As Worksheet)
    Dim c As Long, cw As Double
    ws.Cells.Interior.Color = C_FOND
    ws.Rows("1:" & GRILLE_LIGNES).RowHeight = CELLULE_H
    cw = 2.86
    ws.Columns(1).ColumnWidth = cw
    For c = 1 To 6
        If ws.Columns(1).Width = 0 Then Exit For
        cw = cw * CELLULE_L / ws.Columns(1).Width
        ws.Columns(1).ColumnWidth = cw
    Next c
    ws.Range(ws.Columns(1), ws.Columns(GRILLE_COLS)).ColumnWidth = ws.Columns(1).ColumnWidth
    ws.ScrollArea = "A1:" & LettreCol(GRILLE_COLS) & GRILLE_LIGNES
End Sub

' ---------------------------------------------------------------------
' Barre lat�rale (10.1)
' ---------------------------------------------------------------------
Public Sub BarreLaterale(ByVal ws As Worksheet, ByVal page As Long)
    Dim p As String, s As Shape, k As Long, T As Double
    p = PrefixePage(page)
    Forme ws, p & "sb_fond", msoShapeRectangle, 0, 0, SB_L, CANEVAS_H, C_BLANC
    Filet ws, p & "sb_filet", SB_L, 0, SB_L, CANEVAS_H, C_BORD
    Set s = Forme(ws, p & "sb_logo", msoShapeRoundedRectangle, 14, 16, 26, 26, C_VIOLET, SANS, 0, 8)
    Action s, "ClicMarque"
    Set s = Forme(ws, p & "sb_etoile", msoShape4pointStar, 20.5, 22.5, 13, 13, C_BLANC)
    Action s, "ClicMarque"
    Texte ws, p & "sb_marque", 48, 15, 0, 0, TexteMarque(), F_XBOLD, 12.5, C_ENCRE, AL_G, -0.4
    Texte ws, p & "sb_soustitre", 48, 31, 0, 0, TexteSousMarque(), F_MED, 7, C_GRIS_1
    EntreeTableau ws, p, (page = 0)
    Texte ws, p & "sb_groupe1", 18, SB_T_GROUPE1, 0, 0, TitreGroupe(1), F_SEMI, 6.5, C_GRIS_2, AL_G, 0.6
    For k = 0 To 4
        EntreeEtape ws, p, k + 1, SB_T_ETAPES1 + SB_PAS * k, page
    Next k
    Texte ws, p & "sb_groupe2", 18, SB_T_GROUPE2, 0, 0, TitreGroupe(2), F_SEMI, 6.5, C_GRIS_2, AL_G, 0.6
    For k = 0 To 5
        EntreeEtape ws, p, k + 6, SB_T_ETAPES2 + SB_PAS * k, page
    Next k
    T = SB_T_CALC
    Set s = Forme(ws, p & "sb_calc", msoShapeRoundedRectangle, SB_ENTREE_L, T, SB_ENTREE_W, 30, _
        IIf(page = 12, C_ENCRE, C_VIOLET), SANS, 0, 9)
    Action s, "ClicNavigation"
    Set s = Forme(ws, p & "sb_calc_ic1", msoShapeRectangle, 22, 502, 10, 13, SANS, C_BLANC, 1)
    Action s, "ClicNavigation"
    Set s = Forme(ws, p & "sb_calc_ic2", msoShapeRectangle, 24.5, 505, 5, 3, C_BLANC)
    Action s, "ClicNavigation"
    Set s = Texte(ws, p & "sb_calc_txt", 40, 503.5, 120, 14, TexteBoutonCalculateur(), F_BOLD, 9, C_BLANC)
    Action s, "ClicNavigation"
End Sub

Private Sub EntreeTableau(ByVal ws As Worksheet, ByVal p As String, ByVal actif As Boolean)
    Dim s As Shape, x As Variant, y As Variant, i As Long
    Set s = Pilule(ws, p & "nav_00", SB_ENTREE_L, 56, SB_ENTREE_W, 22, IIf(actif, C_VIOLET_CLAIR, C_BLANC), SANS, 7)
    Action s, "ClicNavigation"
    x = Array(20, 26, 20, 26): y = Array(62, 62, 68, 68)
    For i = 0 To 3
        Set s = Forme(ws, p & "nav_00_ic" & i, msoShapeRoundedRectangle, x(i), y(i), 4.5, 4.5, SANS, _
            IIf(actif, C_VIOLET_FONCE, C_ENCRE_2), 1, 1)
        Action s, "ClicNavigation"
    Next i
    Set s = Texte(ws, p & "nav_00_txt", 36, 60.5, 120, 13, TitrePage(0), IIf(actif, F_BOLD, F_MED), 9, _
        IIf(actif, C_VIOLET_FONCE, C_ENCRE_2))
    Action s, "ClicNavigation"
End Sub

Private Sub EntreeEtape(ByVal ws As Worksheet, ByVal p As String, ByVal n As Long, ByVal T As Double, ByVal page As Long)
    Dim s As Shape, nm As String, actif As Boolean
    nm = p & "nav_" & Format$(n, "00")
    actif = (n = page)
    Set s = Pilule(ws, nm, SB_ENTREE_L, T, SB_ENTREE_W, 19, IIf(actif, C_VIOLET_CLAIR, C_BLANC), SANS, 6)
    Action s, "ClicNavigation"
    If actif Then
        Set s = Cercle(ws, nm & "_halo", 18.5, T + 3.5, 12, C_LAVANDE)
        Action s, "ClicNavigation"
        Set s = Cercle(ws, nm & "_point", 20.5, T + 5.5, 8, C_VIOLET)
        Action s, "ClicNavigation"
    Else
        Set s = Cercle(ws, nm & "_coche", 19.5, T + 4.5, 10, C_VIOLET)
        TexteDansForme s, Coche(), F_SYM, 5.5, C_BLANC
        Action s, "ClicNavigation"
    End If
    Set s = Texte(ws, nm & "_txt", 36, T + 4, 128, 12, TitrePage(n), IIf(actif, F_BOLD, F_MED), 8.5, _
        IIf(actif, C_VIOLET_FONCE, C_ENCRE))
    Action s, "ClicNavigation"
End Sub

Public Function PrefixePage(ByVal page As Long) As String
    PrefixePage = "p" & Format$(page, "00") & "_"
End Function

' ---------------------------------------------------------------------
' En-t�te des pages (10.2)
' ---------------------------------------------------------------------
Public Sub EnTete(ByVal ws As Worksheet, ByVal page As Long, ByVal largeurIntro As Double)
    Dim p As String, s As Shape, x As Double
    p = PrefixePage(page)
    Set s = Texte(ws, p & "eyebrow", 196, 18, 0, 0, EyebrowPage(page), F_BOLD, 7.5, C_VIOLET, AL_G, 1.1)
    If page >= 1 And page <= 11 Then
        x = s.Left + s.Width + 6
        Cercle ws, p & "eyebrow_point", x, 20.5, 3.5, C_LAVANDE_MOYEN
        Texte ws, p & "eyebrow_etape", x + 3.5 + 9.5 - 3.5, 18, 0, 0, TexteEtapeSur(page), F_BOLD, 7.5, C_GRIS_2, AL_G, 1.1
    End If
    Texte ws, p & "titre", 196, 30, 0, 28, TitrePage(page), F_XBOLD, 22, C_ENCRE, AL_G, -0.8
    Set s = Texte(ws, p & "intro", 196, 61, largeurIntro, 28, IntroPage(page), F_REG, 9.5, C_ENCRE_2, AL_G, 0, True)
    s.TextFrame2.TextRange.ParagraphFormat.SpaceWithin = 1.1
End Sub

' Puces : conteneur align� � droite sur xFin ; renvoie la largeur totale
Public Sub Puces(ByVal ws As Worksheet, ByVal page As Long, ByVal groupe As String, valeurs As Variant, _
                 libelles As Variant, ByVal actif As String, ByVal xFin As Double, ByVal T As Double, _
                 ByVal H As Double, Optional ByVal largeurFixe As Double = 0, Optional ByVal taille As Double = 8)
    Dim p As String, i As Long, W() As Double, tot As Double, x As Double, s As Shape, hp As Double
    p = PrefixePage(page)
    ReDim W(LBound(valeurs) To UBound(valeurs))
    For i = LBound(valeurs) To UBound(valeurs)
        If largeurFixe > 0 Then W(i) = largeurFixe Else W(i) = MesurerTexte(ws, CStr(libelles(i)), F_BOLD, taille) + 18
        tot = tot + W(i)
    Next i
    hp = H - 6
    Pilule ws, p & "puces_" & groupe & "_fond", xFin - tot - 6, T, tot + 6, H, C_BLANC, C_BORD_2, H / 2
    x = xFin - tot - 3
    For i = LBound(valeurs) To UBound(valeurs)
        Set s = Pilule(ws, p & "puce_" & groupe & "_" & CStr(valeurs(i)), x, T + 3, W(i), hp, C_VIOLET, SANS, hp / 2)
        s.Fill.Visible = IIf(CStr(valeurs(i)) = actif, msoTrue, msoFalse)
        TexteDansForme s, CStr(libelles(i)), IIf(CStr(valeurs(i)) = actif, F_BOLD, F_SEMI), taille, _
            IIf(CStr(valeurs(i)) = actif, C_BLANC, C_ENCRE_2)
        Action s, "ClicPuce"
        x = x + W(i)
    Next i
End Sub

' Mise � jour de l'�tat actif d'un groupe de puces
Public Sub ActiverPuce(ByVal ws As Worksheet, ByVal page As Long, ByVal groupe As String, ByVal actif As String)
    Dim s As Shape, pre As String, v As String
    pre = PrefixePage(page) & "puce_" & groupe & "_"
    For Each s In ws.Shapes
        If Left$(s.Name, Len(pre)) = pre Then
            v = Mid$(s.Name, Len(pre) + 1)
            s.Fill.Visible = IIf(v = actif, msoTrue, msoFalse)
            AppliquerPolice s.TextFrame2.TextRange.Font, IIf(v = actif, F_BOLD, F_SEMI)
            s.TextFrame2.TextRange.Font.Fill.ForeColor.RGB = IIf(v = actif, C_BLANC, C_ENCRE_2)
        End If
    Next s
End Sub

' ---------------------------------------------------------------------
' KPI d'�tape (10.2) et boutons de navigation du pied
' ---------------------------------------------------------------------
Public Sub CarteKPI(ByVal ws As Worksheet, ByVal page As Long, ByVal k As Long, ByVal libelle As String)
    Dim p As String, L As Double
    p = PrefixePage(page) & "kpi" & k
    L = 196 + 188 * k
    Carte ws, p & "_carte", L, 96, 180, 54, 12
    Texte ws, p & "_lib", L + 12, 105, 160, 12, libelle, F_SEMI, 8, C_GRIS_1
    Texte ws, p & "_val", L + 12, 116, 160, 20, "", F_XBOLD, 16, C_ENCRE, AL_G, -0.5
    Texte ws, p & "_sub", L + 12, 135, 160, 12, "", F_REG, 7.5, C_GRIS_2
End Sub

Public Sub MajKPI(ByVal ws As Worksheet, ByVal page As Long, ByVal k As Long, ByVal valeur As String, ByVal sousTexte As String)
    Dim p As String
    p = PrefixePage(page) & "kpi" & k
    ChangerTexte ws, p & "_val", valeur
    ChangerTexte ws, p & "_sub", sousTexte
End Sub

Public Sub BoutonsPied(ByVal ws As Worksheet, ByVal page As Long)
    Dim p As String, s As Shape, W As Double, txt As String
    p = PrefixePage(page)
    Filet ws, p & "pied_filet", 196, 502, 940, 502, C_BORD
    txt = TitrePage(page - 1)
    W = MesurerTexte(ws, txt, F_BOLD, 8.5) + 38
    Set s = Pilule(ws, p & "nav_prec", 196, 510, W, 24, C_BLANC, C_BORD_2, 12)
    Action s, "ClicNavigation"
    Set s = Cercle(ws, p & "nav_prec_c", 199, 513, 18, C_VIOLET_PALE)
    TexteDansForme s, ChevronG(), F_BOLD, 8.5, C_VIOLET
    Action s, "ClicNavigation"
    Set s = Texte(ws, p & "nav_prec_txt", 223, 515.5, W - 30, 13, txt, F_BOLD, 8.5, C_ENCRE)
    Action s, "ClicNavigation"
    txt = TitrePage(page + 1)
    W = MesurerTexte(ws, txt, F_BOLD, 8.5) + 44
    Set s = Pilule(ws, p & "nav_suiv", 940 - W, 510, W, 24, C_ENCRE, SANS, 12)
    Action s, "ClicNavigation"
    Set s = Texte(ws, p & "nav_suiv_txt", 940 - W + 14, 515.5, W - 30, 13, txt, F_BOLD, 8.5, C_BLANC)
    Action s, "ClicNavigation"
    Set s = Cercle(ws, p & "nav_suiv_c", 919, 513, 18, C_BLANC)
    TexteDansForme s, Fleche(), F_BOLD, 8.5, C_ENCRE
    Action s, "ClicNavigation"
End Sub

' ---------------------------------------------------------------------
' Carte Formulation (10.2) : images des formules (PNG ; SVG � partir d'Excel 2016)
' ---------------------------------------------------------------------
Public Sub CarteFormulation(ByVal ws As Worksheet, ByVal page As Long)
    Dim p As String, k As Long, cle As String, T As Double, s As Shape, dims As Variant
    p = PrefixePage(page)
    Carte ws, p & "form_carte", 196, 160, 270, 214, 14
    Set s = Forme(ws, p & "form_icone", msoShapeRoundedRectangle, 210, 172, 22, 22, C_VIOLET_CLAIR, SANS, 0, 7)
    TexteDansForme s, ChrW(402), F_ICONE, 12, C_VIOLET
    Texte ws, p & "form_titre", 240, 176, 0, 0, TitreFormulation(), F_BOLD, 11, C_ENCRE, AL_G, -0.2
    For k = 0 To 2
        cle = "F" & Format$(page, "00") & Chr$(97 + k)
        T = 204 + 56 * k
        Texte ws, p & "form_lib" & k, 210, T, 250, 10, LibelleFormule(cle), F_BOLD, 6.5, C_GRIS_1, AL_G, 0.4
        Forme ws, p & "form_cadre" & k, msoShapeRoundedRectangle, 210, 215 + 56 * k, 242, 40, C_FORMULE_FOND, _
            C_FORMULE_BORD, 0.75, 9
        InsererFormule ws, p & "form_img" & k, cle, 210, 215 + 56 * k, 242, 40
    Next k
End Sub

Private Sub InsererFormule(ByVal ws As Worksheet, ByVal nom As String, ByVal cle As String, ByVal L As Double, _
                           ByVal T As Double, ByVal W As Double, ByVal H As Double)
    Dim d As Variant, ech As Double, iw As Double, ih As Double, s As Shape, dossier As String
    d = DimensionsFormule(cle)
    If IsEmpty(d) Then Exit Sub
    ech = Application.Min(1, 230 / d(0), 34 / d(1))
    iw = d(0) * ech: ih = d(1) * ech
    dossier = ThisWorkbook.Path & "\formules\"
    On Error Resume Next ' tol�r� (R4) : repli SVG -> PNG (Excel 2013 n'ins�re pas le SVG)
    If Val(Application.Version) >= 16 Then
        Set s = ws.Shapes.AddPicture(dossier & cle & ".svg", msoFalse, msoTrue, L + (W - iw) / 2, T + (H - ih) / 2, iw, ih)
    End If
    If s Is Nothing Then
        Err.Clear
        Set s = ws.Shapes.AddPicture(dossier & cle & ".png", msoFalse, msoTrue, L + (W - iw) / 2, T + (H - ih) / 2, iw, ih)
    End If
    If Not s Is Nothing Then s.Name = nom: s.Placement = xlFreeFloating
    On Error GoTo 0
End Sub

' Taille naturelle (points) lue dans formules/manifeste.csv
Public Function DimensionsFormule(ByVal cle As String) As Variant
    Dim f As Integer, ligne As String, c() As String, chemin As String
    chemin = ThisWorkbook.Path & "\formules\manifeste.csv"
    If Len(Dir$(chemin)) = 0 Then Exit Function
    f = FreeFile
    Open chemin For Input As #f
    Do While Not EOF(f)
        Line Input #f, ligne
        c = Split(ligne, ";")
        If UBound(c) >= 5 Then
            If c(0) = cle Then DimensionsFormule = Array(Val(c(4)), Val(c(5))): Exit Do
        End If
    Loop
    Close #f
End Function

' ---------------------------------------------------------------------
' Carte Contr�les (10.2)
' ---------------------------------------------------------------------
Public Sub CarteControles(ByVal ws As Worksheet, ByVal page As Long)
    Dim p As String, k As Long, T As Double
    p = PrefixePage(page)
    Carte ws, p & "ctl_carte", 196, 382, 270, 114, 14
    Texte ws, p & "ctl_titre", 210, 393, 0, 0, TitreControles(), F_BOLD, 10.5, C_ENCRE, AL_G, -0.2
    For k = 0 To 2
        T = 416 + 26 * k
        Cercle ws, p & "ctl_pastille" & k, 210, T + 1, 11, C_VERT_CLAIR
        Texte ws, p & "ctl_txt" & k, 227, T - 0.5, 225, 22, "", F_REG, 8, C_ENCRE_2, AL_G, 0, True
    Next k
End Sub

Public Sub MajControle(ByVal ws As Worksheet, ByVal page As Long, ByVal k As Long, ByVal ok As Boolean, ByVal txt As String)
    Dim p As String, s As Shape
    p = PrefixePage(page)
    Set s = ws.Shapes(p & "ctl_pastille" & k)
    s.Fill.ForeColor.RGB = IIf(ok, C_VERT_CLAIR, C_ROSE_CLAIR)
    TexteDansForme s, IIf(ok, Coche(), Croix()), F_SYM, 6, IIf(ok, C_VERT, C_ROSE_FONCE)
    ChangerTexte ws, p & "ctl_txt" & k, txt
End Sub

' ---------------------------------------------------------------------
' Graphique en barres (10.4) : n lignes, une ou deux s�ries
' ---------------------------------------------------------------------
Public Sub CadreGraphique(ByVal ws As Worksheet, ByVal page As Long)
    Dim p As String
    p = PrefixePage(page)
    Carte ws, p & "gr_carte", 476, 362, 464, 134, 14
End Sub

' libs(1..n), v1(1..n), v2 (1..n) ou vide, vals(1..n) textes, avant(1..n) mise en avant
Public Sub BarresGraphique(ByVal ws As Worksheet, ByVal page As Long, ByVal titre As String, ByVal note As String, _
                           leg As Variant, libs As Variant, v1 As Variant, v2 As Variant, vals As Variant, _
                           avant As Variant, ByVal vmin As Double, ByVal vmax As Double)
    Dim p As String, n As Long, i As Long, pas As Double, bh As Double, T As Double, deux As Boolean
    Dim larg As Double, y As Double
    p = PrefixePage(page) & "grd_"
    SupprimerFormes ws, p
    n = UBound(libs) - LBound(libs) + 1
    deux = IsArray(v2)
    Texte ws, p & "titre", 490, 373, 0, 0, titre, F_BOLD, 10, C_ENCRE, AL_G, -0.2
    If IsArray(leg) Then
        Legende ws, p & "leg", 926, 375, leg
    ElseIf Len(note) > 0 Then
        TexteFin ws, p & "note", 926, 375, note, F_REG, 7.5, C_GRIS_2
    End If
    pas = Application.Min(17, 94 / n)
    If deux Then bh = Application.Min(10, pas - 3) Else bh = Application.Min(9, pas - 5)
    For i = 1 To n
        T = 394 + (i - 1) * pas
        Texte ws, p & "lib" & i, 490, T + (pas - 10) / 2, 92, 12, CStr(libs(i - 1 + LBound(libs))), F_SEMI, 8, C_ENCRE_2
        y = T + (pas - bh) / 2
        Pilule ws, p & "piste" & i, 588, y, 272, bh, C_FOND
        If deux Then
            larg = LargeurBarre(v1(i - 1 + LBound(v1)), vmin, vmax)
            Pilule ws, p & "b1_" & i, 588, y, larg, (bh - 1) / 2, C_LAVANDE
            larg = LargeurBarre(v2(i - 1 + LBound(v2)), vmin, vmax)
            Pilule ws, p & "b2_" & i, 588, y + (bh - 1) / 2 + 1, larg, (bh - 1) / 2, C_VIOLET
        Else
            larg = LargeurBarre(v1(i - 1 + LBound(v1)), vmin, vmax)
            Pilule ws, p & "b1_" & i, 588, y, larg, bh, IIf(avant(i - 1 + LBound(avant)), C_VIOLET, C_LAVANDE)
        End If
        TexteFin ws, p & "val" & i, 926, T + (pas - 10) / 2, CStr(vals(i - 1 + LBound(vals))), F_XBOLD, _
            IIf(deux, 7.5, 8), C_ENCRE
    Next i
End Sub

Private Function LargeurBarre(ByVal v As Variant, ByVal vmin As Double, ByVal vmax As Double) As Double
    Dim r As Double
    If Not EstNombre(v) Or vmax <= vmin Then
        r = 0.02
    Else
        r = (CDbl(v) - vmin) / (vmax - vmin)
        If r < 0.02 Then r = 0.02
        If r > 1 Then r = 1
    End If
    LargeurBarre = 272 * r
End Function

' L�gende align�e � droite sur xFin : (libell�1, couleur1, libell�2, couleur2...)
Public Sub Legende(ByVal ws As Worksheet, ByVal nom As String, ByVal xFin As Double, ByVal T As Double, elements As Variant)
    Dim i As Long, x As Double, W As Double
    x = xFin
    For i = UBound(elements) - 1 To LBound(elements) Step -2
        W = MesurerTexte(ws, CStr(elements(i)), F_REG, 7.5)
        Texte ws, nom & "_t" & i, x - W, T, W + 2, 11, CStr(elements(i)), F_REG, 7.5, C_GRIS_1
        x = x - W - 4 - 7
        Forme ws, nom & "_c" & i, msoShapeRoundedRectangle, x, T + 2, 7, 7, CLng(elements(i + 1)), SANS, 0, 2
        x = x - 10
    Next i
End Sub

' ---------------------------------------------------------------------
' Bulles d'aide (12.3)
' ---------------------------------------------------------------------
Public Sub IconeInfo(ByVal ws As Worksheet, ByVal nom As String, ByVal L As Double, ByVal T As Double)
    Dim s As Shape
    Set s = Cercle(ws, nom, L, T, 9, C_BLANC, C_GRIS_2, 0.75)
    TexteDansForme s, "i", F_BOLD, 6, C_GRIS_2
    Action s, "ClicInfo"
End Sub

Public Sub CreerBulle(ByVal ws As Worksheet, ByVal page As Long)
    Dim p As String, s As Shape
    p = PrefixePage(page) & "bulle_"
    Set s = Forme(ws, p & "fleche", msoShapeIsoscelesTriangle, 0, 0, 12, 7, C_BLANC, C_BORD, 0.75)
    s.Visible = msoFalse
    Set s = Carte(ws, p & "fond", 0, 0, BULLE_W, 80, 10, C_BLANC, C_BORD)
    s.Visible = msoFalse
    Set s = Texte(ws, p & "titre", 0, 0, BULLE_W - 2 * BULLE_MARGE, 13, "", F_BOLD, 9, C_ENCRE)
    s.Visible = msoFalse
    Set s = Texte(ws, p & "texte", 0, 0, BULLE_W - 2 * BULLE_MARGE, 60, "", F_REG, 7.8, C_ENCRE_2, AL_G, 0, True)
    s.Visible = msoFalse
    Set s = Texte(ws, p & "fermer", 0, 0, 40, 11, TexteFermer(), F_BOLD, 7.5, C_VIOLET, AL_D)
    s.Visible = msoFalse
    Action s, "FermerBulle"
End Sub

' Affiche la bulle sous (ou au-dessus de) l'ic�ne cliqu�e
Public Sub AfficherBulle(ByVal ws As Worksheet, ByVal page As Long, ByVal icone As Shape, ByVal titre As String, _
                         ByVal txt As String)
    Dim p As String, L As Double, T As Double, H As Double, sT As Shape, enHaut As Boolean
    FermerBulleSurFeuille ws, page
    p = PrefixePage(page) & "bulle_"
    Set sT = ws.Shapes(p & "texte")
    sT.TextFrame2.TextRange.Text = txt
    sT.TextFrame2.AutoSize = msoAutoSizeShapeToFitText
    H = BULLE_MARGE + 14 + sT.Height + 6 + 11 + BULLE_MARGE
    sT.TextFrame2.AutoSize = msoAutoSizeNone
    L = icone.Left + icone.Width / 2 - BULLE_W / 2
    If L < 180 Then L = 180
    If L + BULLE_W > 950 Then L = 950 - BULLE_W
    T = icone.Top + icone.Height + 8
    enHaut = (T + H > CANEVAS_H - 6)
    If enHaut Then T = icone.Top - 8 - H
    With ws.Shapes(p & "fond"): .Left = L: .Top = T: .Height = H: .Visible = msoTrue: End With
    With ws.Shapes(p & "fleche")
        .Left = icone.Left + icone.Width / 2 - 6
        .Rotation = IIf(enHaut, 180, 0)
        .Top = IIf(enHaut, T + H - 1, T - 6)
        .Visible = msoTrue
    End With
    With ws.Shapes(p & "titre"): .Left = L + BULLE_MARGE: .Top = T + BULLE_MARGE: .Visible = msoTrue: End With
    ws.Shapes(p & "titre").TextFrame2.TextRange.Text = titre
    With sT: .Left = L + BULLE_MARGE: .Top = T + BULLE_MARGE + 14: .Visible = msoTrue: End With
    With ws.Shapes(p & "fermer"): .Left = L + BULLE_W - BULLE_MARGE - 40: .Top = T + H - BULLE_MARGE - 11: .Visible = msoTrue: End With
    ws.Shapes(p & "fleche").ZOrder msoBringToFront
    ProgrammerFermeture ws.Name
End Sub

Public Sub FermerBulleSurFeuille(ByVal ws As Worksheet, ByVal page As Long)
    Dim p As String, k As Variant
    p = PrefixePage(page) & "bulle_"
    For Each k In Array("fleche", "fond", "titre", "texte", "fermer")
        If FormeExiste(ws, p & k) Then ws.Shapes(p & k).Visible = msoFalse
    Next k
End Sub

Private Sub ProgrammerFermeture(ByVal feuille As String)
    AnnulerMinuterieBulle
    mBulleProchaine = Now + TimeValue(BULLE_DELAI)
    mBulleFeuille = feuille
    Application.OnTime mBulleProchaine, "'" & ThisWorkbook.Name & "'!FermerBulle"
End Sub

Public Sub AnnulerMinuterieBulle()
    If mBulleProchaine = 0 Then Exit Sub
    On Error Resume Next ' tol�r� (R4) : la minuterie peut �tre d�j� �chue
    Application.OnTime mBulleProchaine, "'" & ThisWorkbook.Name & "'!FermerBulle", , False
    On Error GoTo 0
    mBulleProchaine = 0
End Sub
