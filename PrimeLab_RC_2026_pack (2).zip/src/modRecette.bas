Attribute VB_Name = "modRecette"
Option Explicit
' =====================================================================
' modRecette : valeurs attendues de la section 15 (recette/*.json),
' comparaison avec le classeur, feuille Recette et fen�tre Ex�cution.
' Module g�n�r� par outils/generer_recette.py (valeurs recopi�es sans arrondi).
' =====================================================================

Private Const COUL_OK As Long = 15660773       ' vert_clair
Private Const COUL_KO As Long = 16116989       ' rose_clair
Private Const COUL_TEXTE_OK As Long = 6657562  ' vert
Private Const COUL_TEXTE_KO As Long = 7286978  ' rose_fonce
Private Const EPS As Double = 0.000000000001
Private Const NB_COL As Long = 7
Private Const STATUT_OK As String = "conforme"
Private Const STATUT_KO As String = "non conforme"
Private Const ABSENT As String = "absent"

Private mRes() As Variant
Private mN As Long
Private mOk As Long
Private mProfil As String

' ---------------------------------------------------------------------
' Points d'entr�e
' ---------------------------------------------------------------------
Public Sub Recette()
    On Error GoTo Erreur
    DebutTraitement
    DeprotegerTout
    gEtape = "Recette"
    PreparerRecette
    ExecuterBase
    gEtape = "Recette des seuils"
    ExecuterScenarios
    EcrireRecette
    If FeuilleExiste(NomPage(0)) Then ProtegerTout
    FinTraitement
    If Not gSilencieux Then MsgBox ResultatRecette(), vbInformation, "PrimeLab"
    Exit Sub
Erreur:
    GererErreur
End Sub

Public Sub RecetteSeuils()
    On Error GoTo Erreur
    DebutTraitement
    DeprotegerTout
    gEtape = "Recette des seuils"
    PreparerRecette
    ExecuterScenarios
    EcrireRecette
    If FeuilleExiste(NomPage(0)) Then ProtegerTout
    FinTraitement
    If Not gSilencieux Then MsgBox ResultatRecette(), vbInformation, "PrimeLab"
    Exit Sub
Erreur:
    GererErreur
End Sub

' Recette sans les sc�narios (appel�e en fin de construction)
Public Sub RecetteRapide()
    DeprotegerTout
    PreparerRecette
    ExecuterBase
    EcrireRecette
    If FeuilleExiste(NomPage(0)) Then ProtegerTout
End Sub

Public Function ResultatRecette() As String
    ResultatRecette = "Recette : " & mOk & " contr�les sur " & mN & " conformes."
End Function

Public Function RecetteConforme() As Boolean
    RecetteConforme = (mN > 0 And mOk = mN)
End Function

Private Sub PreparerRecette()
    mN = 0: mOk = 0: mProfil = ""
    ReDim mRes(1 To NB_COL, 1 To 600)
End Sub

Private Sub ExecuterBase()
    Attendus1
    Attendus2
    Attendus3
    Attendus4
    Attendus5
    Attendus6
    RestaurerProfil
End Sub

Private Sub ExecuterScenarios()
    Dim u0 As Double
    u0 = CDbl(Param("seuil_ecretement"))
    AppliquerSeuil CDbl(Param("seuil_2"))
    AttendusS10_1
    AppliquerSeuil CDbl(Param("seuil_1"))
    AttendusS05_1
    AppliquerSeuil u0
End Sub

' ---------------------------------------------------------------------
' Comparaison d'un indicateur
' ---------------------------------------------------------------------
Private Sub A(ByVal etape As String, ByVal libelle As String, ByVal source As String, ByVal attendu As Variant, _
              ByVal tol As Double, ByVal mode As String)
    Dim obt As Variant, ok As Boolean, ecart As Variant
    obt = Obtenir(source)
    If VarType(attendu) = vbString Then attendu = Remplacer(CStr(attendu))
    ecart = ""
    ok = False
    Select Case mode
        Case "txt"
            If Not IsError(obt) Then ok = (Normaliser(CStr(obt)) = Normaliser(CStr(attendu)))
        Case "bool"
            If VarType(obt) = vbBoolean Then ok = (obt = attendu)
        Case Else
            If EstNombre(obt) Then
                If mode = "rel" Then ecart = obt / attendu - 1 Else ecart = obt - attendu
                If mode = "exact" Then ok = (obt = attendu) Else ok = (Abs(ecart) <= tol + EPS)
            End If
    End Select
    mN = mN + 1
    If mN > UBound(mRes, 2) Then ReDim Preserve mRes(1 To NB_COL, 1 To mN + 200)
    mRes(1, mN) = etape: mRes(2, mN) = libelle: mRes(3, mN) = attendu
    If IsError(obt) Then mRes(4, mN) = ABSENT Else mRes(4, mN) = obt
    mRes(5, mN) = ecart
    If mode = "exact" Or mode = "txt" Or mode = "bool" Then mRes(6, mN) = mode Else mRes(6, mN) = tol
    If mode = "rel" Then mRes(6, mN) = CStr(tol) & " relatif"
    If ok Then mRes(7, mN) = STATUT_OK: mOk = mOk + 1 Else mRes(7, mN) = STATUT_KO
End Sub

Private Function Remplacer(ByVal s As String) As String
    Remplacer = Replace(Replace(s, "{inf}", CarInf()), "{sup}", CarSup())
End Function

Private Function Normaliser(ByVal s As String) As String
    Normaliser = Trim$(Replace(Replace(s, Insec(), " "), ChrW(8239), " "))
End Function

' Lecture d'une valeur du classeur selon sa source
Private Function Obtenir(ByVal source As String) As Variant
    Dim t As String, p() As String
    On Error GoTo Absente
    source = Remplacer(source)
    t = Left$(source, InStr(source, ":") - 1)
    p = Split(Mid$(source, InStr(source, ":") + 1), ":")
    Select Case t
        Case "N": Obtenir = ValeurNom(p(0))
        Case "C": Obtenir = Feuille(Split(p(0), "!")(0)).Range(Split(p(0), "!")(1)).Value2
        Case "H": Obtenir = Feuille(F_HISTORIQUE).Range(p(1) & (CLng(p(0)) - CLng(Param("annee_debut")) + 2)).Value2
        Case "E": Obtenir = Feuille(F_EXPLORATOIRE).Range(p(1) & LigneCle(F_EXPLORATOIRE, p(0), 1, 2)).Value2
        Case "K": Obtenir = Feuille(F_CLASSES).Range(p(1) & LigneCle(F_CLASSES, p(0), 1, 2)).Value2
        Case "T": Obtenir = Feuille(F_TARIF).Range(p(1) & LigneCle(F_TARIF, p(0), 1, 2)).Value2
        Case "S": Obtenir = Feuille(F_SELECTION).Range(p(1) & LigneCle(F_SELECTION, p(0), 1, 0)).Value2
        Case "GF": Obtenir = Feuille(F_GLMF).Range(p(1) & LigneCle(F_GLMF, p(0), 2, 0)).Value2
        Case "GC": Obtenir = Feuille(F_GLMC).Range(p(1) & LigneCle(F_GLMC, p(0), 2, 0)).Value2
        Case "I": Obtenir = PlageNom(p(0)).Cells(CLng(p(1)), 1).Value2
        Case "X": Obtenir = PlageNom("ctl_statut").Cells(CLng(p(0)), 1).Value2
        Case "G": Obtenir = Feuille(F_SEGMENTS).Range("H" & LigneSegment(p(0))).Value2
        Case "B": Obtenir = Feuille(F_SEGMENTS).Range("L" & (CLng(p(0)) - CLng(Param("annee_debut")) + 2)).Value2
        Case "P"
            AppliquerProfil p(0)
            Obtenir = ValeurNom(p(1))
    End Select
    Exit Function
Absente:
    Obtenir = CVErr(xlErrNA)
End Function

' Ligne dont la cl� (colonne c1, ou c1 & "|" & c2) vaut cle
Private Function LigneCle(ByVal nomF As String, ByVal cle As String, ByVal c1 As Long, ByVal c2 As Long) As Long
    Dim ws As Worksheet, v As Variant, r As Long, k As String
    Set ws = Feuille(nomF)
    v = ws.Range("A1").CurrentRegion.Value2
    For r = 2 To UBound(v, 1)
        k = CStr(v(r, c1))
        If c2 > 0 Then k = k & "|" & CStr(v(r, c2))
        If k = cle Then LigneCle = r: Exit Function
    Next r
    Err.Raise vbObjectError + 902, "LigneCle", "cl� absente : " & cle
End Function

Private Function LigneSegment(ByVal cle As String) As Long
    Dim v As Variant, r As Long
    v = Feuille(F_SEGMENTS).Range("A1:C" & PlageNom("seg_annee").Rows.Count + 1).Value2
    For r = 2 To UBound(v, 1)
        If CStr(v(r, 1)) & "|" & CStr(v(r, 2)) & "|" & CStr(v(r, 3)) = cle Then LigneSegment = r: Exit Function
    Next r
    Err.Raise vbObjectError + 903, "LigneSegment", "segment absent : " & cle
End Function

' Profils du calculateur (section 15, CA)
Private Sub AppliquerProfil(ByVal nom As String)
    Dim ws As Worksheet
    If nom = mProfil Then Exit Sub
    Set ws = Feuille(F_CALCULATEUR)
    ReinitialiserEntrees
    If nom = "reference" Then
        ws.Range("B2").Value2 = 35: ws.Range("B3").Value2 = "B": ws.Range("B4").Value2 = 6
        ws.Range("B5").Value2 = "Priv�": ws.Range("B6").Value2 = 0.5
    End If
    ws.Calculate
    mProfil = nom
End Sub

Private Sub RestaurerProfil()
    ReinitialiserEntrees
    Feuille(F_CALCULATEUR).Calculate
    mProfil = ""
End Sub

' ---------------------------------------------------------------------
' Feuille Recette et fen�tre Ex�cution
' ---------------------------------------------------------------------
Private Sub EcrireRecette()
    Dim ws As Worksheet, s() As Variant, i As Long, c As Long
    Set ws = NouvelleFeuille(F_RECETTE)
    If FeuilleExiste(F_CONTROLES) Then ws.Move After:=Feuille(F_CONTROLES)
    ws.Tab.Color = COUL_TEXTE_OK
    EntetesTable ws, 1, 1, Array("etape", "indicateur", "attendu", "obtenu", "ecart", "tolerance", "statut")
    If mN = 0 Then Exit Sub
    ReDim s(1 To mN, 1 To NB_COL)
    For i = 1 To mN
        For c = 1 To NB_COL: s(i, c) = mRes(c, i): Next c
        If VarType(s(i, 1)) = vbString Then s(i, 1) = "'" & s(i, 1)
    Next i
    ws.Range("A2").Resize(mN, NB_COL).Value2 = s
    ws.Range("A2").Resize(mN, NB_COL).Interior.Color = COUL_OK
    ws.Range("G2").Resize(mN, 1).Font.Color = COUL_TEXTE_OK
    For i = 1 To mN
        If mRes(7, i) <> STATUT_OK Then
            ws.Rows(i + 1).Resize(1, NB_COL).Interior.Color = COUL_KO
            ws.Cells(i + 1, 7).Font.Color = COUL_TEXTE_KO
            Debug.Print "KO " & mRes(1, i) & " | " & mRes(2, i) & " | attendu " & mRes(3, i) & " | obtenu " & mRes(4, i)
        End If
    Next i
    ws.Range("I1").Value2 = "resume"
    ws.Range("I2").Value2 = ResultatRecette()
    ws.Range("I1").Font.Bold = True
    AjusterColonnes ws
    Debug.Print ResultatRecette()
End Sub

Private Sub Attendus1()
    A "01", "Lignes de la feuille Contrats", "N:q_lignes", 25074#, 0.0, "exact"
    A "01", "Polices distinctes", "N:q_polices", 7281#, 0.0, "exact"
    A "01", "Sinistres bruts", "N:q_sinistres_bruts", 920#, 0.0, "exact"
    A "01", "Exposition totale", "N:q_expo_totale", 22326.255625421065, 1E-6, "abs"
    A "01", "Exposition 2021", "H:2021:B", 4336.81095890411, 1E-6, "abs"
    A "01", "Exposition 2022", "H:2022:B", 4409.131506849315, 1E-6, "abs"
    A "01", "Exposition 2023", "H:2023:B", 4469.4301369863015, 1E-6, "abs"
    A "01", "Exposition 2024", "H:2024:B", 4508.696721311476, 1E-6, "abs"
    A "01", "Exposition 2025", "H:2025:B", 4602.186301369863, 1E-6, "abs"
    A "01", "Lignes � exposition nulle", "N:q_expo_nulle", 2#, 0.0, "exact"
    A "02", "Sinistres � Doublon �", "N:q_doublons", 22#, 0.0, "exact"
    A "02", "Sinistres � Hors p�riode �", "N:q_hors_periode", 5#, 0.0, "exact"
    A "02", "Sinistres � Orphelin �", "N:q_orphelins", 3#, 0.0, "exact"
    A "02", "Sinistres � Montant nul �", "N:q_montant_nul", 6#, 0.0, "exact"
    A "02", "Sinistres � OK �", "N:q_ok", 884#, 0.0, "exact"
    A "02", "Lignes � �ge imput�", "N:q_ages_imputes", 56#, 0.0, "exact"
    A "02", "Polices � �ge imput�", "N:q_polices_age", 14#, 0.0, "exact"
    A "02", "M�diane d'�ge zone A", "C:Qualite!B2", 48#, 0.0, "exact"
    A "02", "M�diane d'�ge zone B", "C:Qualite!B3", 48#, 0.0, "exact"
    A "02", "M�diane d'�ge zone C", "C:Qualite!B4", 47#, 0.0, "exact"
    A "02", "M�diane d'�ge zone D", "C:Qualite!B5", 47#, 0.0, "exact"
    A "02", "CRM corrig�s", "N:q_crm_corriges", 7#, 0.0, "exact"
    A "02", "Compl�tude de date_naissance", "C:Qualite!F7", 0.9977666108319375, 1E-6, "abs"
    A "03", "Somme des nb_sin", "N:b_sin_ratt", 884#, 0.0, "exact"
    A "03", "Lignes sinistr�es", "N:b_lignes_sin", 848#, 0.0, "exact"
    A "03", "Lignes � exposition non nulle", "N:b_lignes_base", 25072#, 0.0, "exact"
    A "03", "Charge vue rattach�e", "N:b_charge_ratt", 3067850.61, 0.01, "abs"
    A "03", "Lignes � 1 sinistre(s)", "C:Historique_!B11", 814#, 0.0, "exact"
    A "03", "Lignes � 2 sinistre(s)", "C:Historique_!B12", 32#, 0.0, "exact"
    A "03", "Lignes � 3+ sinistre(s)", "C:Historique_!B13", 2#, 0.0, "exact"
    A "03", "Attendu Poisson � 1", "C:Historique_!C11", 848.6542453699617, 0.01, "abs"
    A "03", "Attendu Poisson � 2", "C:Historique_!C12", 17.263933791405456, 0.01, "abs"
    A "03", "Attendu Poisson � 3+", "C:Historique_!C13", 0.27133496996391104, 0.01, "abs"
    A "04", "Facteur f1", "C:Triangle!B13", 1.1051416466033812, 1E-5, "abs"
    A "04", "Facteur f2", "C:Triangle!C13", 1.0352561448377586, 1E-5, "abs"
    A "04", "Facteur f3", "C:Triangle!D13", 1.0163675510218362, 1E-5, "abs"
    A "04", "Facteur f4", "C:Triangle!E13", 1.0082668841195606, 1E-5, "abs"
    A "04", "Facteur f5", "C:Triangle!F13", 1.0040317443462834, 1E-5, "abs"
    A "04", "Facteur f6", "C:Triangle!G13", 1.002037898526363, 1E-5, "abs"
    A "04", "Facteur f7", "C:Triangle!H13", 1.0010213141714417, 1E-5, "abs"
    A "04", "Facteur f8", "C:Triangle!I13", 1.0007283648944847, 1E-5, "abs"
    A "04", "Facteur f9", "C:Triangle!J13", 1.0002994569156363, 1E-5, "abs"
    A "04", "Exercice 2021 : charge vue", "H:2021:D", 477429.63, 1E-5, "rel"
    A "04", "Exercice 2021 : CDF", "H:2021:E", 1.008140725272736, 1E-5, "rel"
    A "04", "Exercice 2021 : ultime", "H:2021:F", 481316.25345489394, 1E-5, "rel"
    A "04", "Exercice 2021 : rho", "H:2021:G", 1.307799433443949, 1E-5, "rel"
    A "04", "Exercice 2022 : charge vue", "H:2022:D", 634212.28, 1E-5, "rel"
    A "04", "Exercice 2022 : CDF", "H:2022:E", 1.0164749078247752, 1E-5, "rel"
    A "04", "Exercice 2022 : ultime", "H:2022:F", 644660.8688543405, 1E-5, "rel"
    A "04", "Exercice 2022 : rho", "H:2022:G", 1.245523269946618, 1E-5, "rel"
    A "04", "Exercice 2023 : charge vue", "H:2023:D", 666170.01, 1E-5, "rel"
    A "04", "Exercice 2023 : CDF", "H:2023:E", 1.0331121127410137, 1E-5, "rel"
    A "04", "Exercice 2023 : ultime", "H:2023:F", 688228.3064758022, 1E-5, "rel"
    A "04", "Exercice 2023 : rho", "H:2023:G", 1.1862126380443982, 1E-5, "rel"
    A "04", "Exercice 2024 : charge vue", "H:2024:D", 590728.7, 1E-5, "rel"
    A "04", "Exercice 2024 : CDF", "H:2024:E", 1.0695356630214536, 1E-5, "rel"
    A "04", "Exercice 2024 : ultime", "H:2024:F", 631805.4118203013, 1E-5, "rel"
    A "04", "Exercice 2024 : rho", "H:2024:G", 1.129726321947046, 1E-5, "rel"
    A "04", "Exercice 2025 : charge vue", "H:2025:D", 699309.99, 1E-5, "rel"
    A "04", "Exercice 2025 : CDF", "H:2025:E", 1.1819884037325683, 1E-5, "rel"
    A "04", "Exercice 2025 : ultime", "H:2025:F", 826576.2987943382, 1E-5, "rel"
    A "04", "Exercice 2025 : rho", "H:2025:G", 1.0759298304257578, 1E-5, "rel"
    A "04", "IBNR total 2021-2025", "N:hist_ibnr_tot", 204736.52939967625, 1E-5, "rel"
    A "04", "Charge cible C*", "N:charge_cible", 3851895.653036981, 1E-5, "rel"
    A "05", "Sinistres au-dessus de u = 15 000", "N:ecr_n_graves", 45#, 0.0, "exact"
    A "05", "Charge revaloris�e", "N:ecr_charge_rev", 3624297.8778727157, 0.01, "abs"
    A "05", "Charge �cr�t�e", "N:ecr_charge_ecr", 2907613.9599778177, 0.01, "abs"
    A "05", "Exc�dent", "N:ecr_excedent", 716683.917894898, 0.01, "abs"
    A "05", "Part de l'exc�dent pour 5 k�", "C:Graves!J2", 0.4198373142387026, 0.0001, "abs"
    A "05", "Part de l'exc�dent pour 10 k�", "C:Graves!J3", 0.2785830192408074, 0.0001, "abs"
    A "05", "Part de l'exc�dent pour 15 k�", "C:Graves!J4", 0.19774420923579167, 0.0001, "abs"
    A "05", "Part de l'exc�dent pour 25 k�", "C:Graves!J5", 0.12196928828033039, 0.0001, "abs"
    A "05", "Part de l'exc�dent pour 50 k�", "C:Graves!J6", 0.04522868475375512, 0.0001, "abs"
    A "06", "Fr�quence brute", "N:expl_freq", 0.03959463757968722, 1E-6, "abs"
    A "06", "Fr�quence � CRM 1,00", "N:expl_freq_crm", 0.06760974828272191, 1E-6, "abs"
    A "06", "Co�t moyen �cr�t�", "N:expl_cout", 3289.156063323324, 0.0001, "abs"
    A "06", "Prime pure �cr�t�e", "N:expl_pp", 130.23294227031775, 0.0001, "abs"
    A "06", "Tranche d'�ge 18-20 : E", "E:age|18-20:E", 301.84653791451456, 0.001, "abs"
    A "06", "Tranche d'�ge 18-20 : E*", "E:age|18-20:F", 303.55891219402656, 0.001, "abs"
    A "06", "Tranche d'�ge 18-20 : N", "E:age|18-20:G", 42#, 0.0, "exact"
    A "06", "Tranche d'�ge 21-24 : E", "E:age|21-24:E", 997.2024777303691, 0.001, "abs"
    A "06", "Tranche d'�ge 21-24 : E*", "E:age|21-24:F", 922.635690246276, 0.001, "abs"
    A "06", "Tranche d'�ge 21-24 : N", "E:age|21-24:G", 86#, 0.0, "exact"
    A "06", "Tranche d'�ge 25-29 : E", "E:age|25-29:E", 1916.4176959353244, 0.001, "abs"
    A "06", "Tranche d'�ge 25-29 : E*", "E:age|25-29:F", 1557.5413429897446, 0.001, "abs"
    A "06", "Tranche d'�ge 25-29 : N", "E:age|25-29:G", 130#, 0.0, "exact"
    A "06", "Tranche d'�ge 30-39 : E", "E:age|30-39:E", 4337.242869975297, 0.001, "abs"
    A "06", "Tranche d'�ge 30-39 : E*", "E:age|30-39:F", 2646.7525171045736, 0.001, "abs"
    A "06", "Tranche d'�ge 30-39 : N", "E:age|30-39:G", 175#, 0.0, "exact"
    A "06", "Tranche d'�ge 40-49 : E", "E:age|40-49:E", 4410.934224118571, 0.001, "abs"
End Sub
Private Sub Attendus2()
    A "06", "Tranche d'�ge 40-49 : E*", "E:age|40-49:F", 2315.9974088629388, 0.001, "abs"
    A "06", "Tranche d'�ge 40-49 : N", "E:age|40-49:G", 155#, 0.0, "exact"
    A "06", "Tranche d'�ge 50-64 : E", "E:age|50-64:E", 5428.256037128527, 0.001, "abs"
    A "06", "Tranche d'�ge 50-64 : E*", "E:age|50-64:F", 2782.335368815031, 0.001, "abs"
    A "06", "Tranche d'�ge 50-64 : N", "E:age|50-64:G", 139#, 0.0, "exact"
    A "06", "Tranche d'�ge 65-74 : E", "E:age|65-74:E", 2935.6708511116103, 0.001, "abs"
    A "06", "Tranche d'�ge 65-74 : E*", "E:age|65-74:F", 1513.4239206527436, 0.001, "abs"
    A "06", "Tranche d'�ge 65-74 : N", "E:age|65-74:G", 75#, 0.0, "exact"
    A "06", "Tranche d'�ge 75+ : E", "E:age|75+:E", 1998.6849315068494, 0.001, "abs"
    A "06", "Tranche d'�ge 75+ : E*", "E:age|75+:F", 1032.792425480949, 0.001, "abs"
    A "06", "Tranche d'�ge 75+ : N", "E:age|75+:G", 82#, 0.0, "exact"
    A "07", "Classes de age : nombre", "N:cls_n_age", 5#, 0.0, "exact"
    A "07", "age 18-24 : N", "K:age|18-24:H", 128#, 0.0, "exact"
    A "07", "age 18-24 : relativit�", "K:age|18-24:J", 1.5698531228231687, 0.0001, "abs"
    A "07", "age 25-29 : N", "K:age|25-29:H", 130#, 0.0, "exact"
    A "07", "age 25-29 : relativit�", "K:age|25-29:J", 1.2551979482969566, 0.0001, "abs"
    A "07", "age 30-49 : N", "K:age|30-49:H", 330#, 0.0, "exact"
    A "07", "age 30-49 : relativit�", "K:age|30-49:J", 1.0, 0.0001, "abs"
    A "07", "age 50-74 : N", "K:age|50-74:H", 214#, 0.0, "exact"
    A "07", "age 50-74 : relativit�", "K:age|50-74:J", 0.7491732932289052, 0.0001, "abs"
    A "07", "age 75+ : N", "K:age|75+:H", 82#, 0.0, "exact"
    A "07", "age 75+ : relativit�", "K:age|75+:J", 1.1940135626459214, 0.0001, "abs"
    A "07", "Classes de puissance_cv : nombre", "N:cls_n_puissance_cv", 3#, 0.0, "exact"
    A "07", "puissance_cv {inf}4 : N", "K:puissance_cv|{inf}4:H", 122#, 0.0, "exact"
    A "07", "puissance_cv {inf}4 : relativit�", "K:puissance_cv|{inf}4:J", 0.7339446566172286, 0.0001, "abs"
    A "07", "puissance_cv 5-8 : N", "K:puissance_cv|5-8:H", 581#, 0.0, "exact"
    A "07", "puissance_cv 5-8 : relativit�", "K:puissance_cv|5-8:J", 1.0, 0.0001, "abs"
    A "07", "puissance_cv 9+ : N", "K:puissance_cv|9+:H", 181#, 0.0, "exact"
    A "07", "puissance_cv 9+ : relativit�", "K:puissance_cv|9+:J", 1.392484329174355, 0.0001, "abs"
    A "07", "Classes de anc_permis : nombre", "N:cls_n_anc_permis", 3#, 0.0, "exact"
    A "07", "anc_permis 0-2 : N", "K:anc_permis|0-2:H", 86#, 0.0, "exact"
    A "07", "anc_permis 0-2 : relativit�", "K:anc_permis|0-2:J", 2.254091805570741, 0.0001, "abs"
    A "07", "anc_permis 3-20 : N", "K:anc_permis|3-20:H", 374#, 0.0, "exact"
    A "07", "anc_permis 3-20 : relativit�", "K:anc_permis|3-20:J", 1.2485445329729978, 0.0001, "abs"
    A "07", "anc_permis 21+ : N", "K:anc_permis|21+:H", 424#, 0.0, "exact"
    A "07", "anc_permis 21+ : relativit�", "K:anc_permis|21+:J", 1.0, 0.0001, "abs"
    A "07", "Classes de anc_vehicule : nombre", "N:cls_n_anc_vehicule", 3#, 0.0, "exact"
    A "07", "anc_vehicule 0-9 : N", "K:anc_vehicule|0-9:H", 454#, 0.0, "exact"
    A "07", "anc_vehicule 0-9 : relativit�", "K:anc_vehicule|0-9:J", 1.0, 0.0001, "abs"
    A "07", "anc_vehicule 10-14 : N", "K:anc_vehicule|10-14:H", 195#, 0.0, "exact"
    A "07", "anc_vehicule 10-14 : relativit�", "K:anc_vehicule|10-14:J", 0.8603499896301411, 0.0001, "abs"
    A "07", "anc_vehicule 15+ : N", "K:anc_vehicule|15+:H", 235#, 0.0, "exact"
    A "07", "anc_vehicule 15+ : relativit�", "K:anc_vehicule|15+:J", 1.0222562672596693, 0.0001, "abs"
    A "07", "Classes de zone : nombre", "N:cls_n_zone", 4#, 0.0, "exact"
    A "07", "zone A : N", "K:zone|A:H", 127#, 0.0, "exact"
    A "07", "zone A : relativit�", "K:zone|A:J", 0.8216117460356274, 0.0001, "abs"
    A "07", "zone B : N", "K:zone|B:H", 263#, 0.0, "exact"
    A "07", "zone B : relativit�", "K:zone|B:J", 1.0, 0.0001, "abs"
    A "07", "zone C : N", "K:zone|C:H", 310#, 0.0, "exact"
    A "07", "zone C : relativit�", "K:zone|C:J", 1.3304270896184367, 0.0001, "abs"
    A "07", "zone D : N", "K:zone|D:H", 184#, 0.0, "exact"
    A "07", "zone D : relativit�", "K:zone|D:J", 1.371107872155814, 0.0001, "abs"
    A "07", "Classes de usage : nombre", "N:cls_n_usage", 3#, 0.0, "exact"
    A "07", "usage Priv� : N", "K:usage|Priv�:H", 502#, 0.0, "exact"
    A "07", "usage Priv� : relativit�", "K:usage|Priv�:J", 1.0, 0.0001, "abs"
    A "07", "usage Trajet : N", "K:usage|Trajet:H", 294#, 0.0, "exact"
    A "07", "usage Trajet : relativit�", "K:usage|Trajet:J", 1.073325440785117, 0.0001, "abs"
    A "07", "usage Professionnel : N", "K:usage|Professionnel:H", 88#, 0.0, "exact"
    A "07", "usage Professionnel : relativit�", "K:usage|Professionnel:J", 1.6528282375739856, 0.0001, "abs"
    A "07", "Classes de couleur : nombre", "N:cls_n_couleur", 6#, 0.0, "exact"
    A "07", "couleur Blanc : N", "K:couleur|Blanc:H", 216#, 0.0, "exact"
    A "07", "couleur Blanc : relativit�", "K:couleur|Blanc:J", 0.9722467146953292, 0.0001, "abs"
    A "07", "couleur Gris : N", "K:couleur|Gris:H", 230#, 0.0, "exact"
    A "07", "couleur Gris : relativit�", "K:couleur|Gris:J", 1.0, 0.0001, "abs"
    A "07", "couleur Noir : N", "K:couleur|Noir:H", 155#, 0.0, "exact"
    A "07", "couleur Noir : relativit�", "K:couleur|Noir:J", 0.9178438260541824, 0.0001, "abs"
    A "07", "couleur Bleu : N", "K:couleur|Bleu:H", 102#, 0.0, "exact"
    A "07", "couleur Bleu : relativit�", "K:couleur|Bleu:J", 0.9286079271760876, 0.0001, "abs"
    A "07", "couleur Rouge : N", "K:couleur|Rouge:H", 91#, 0.0, "exact"
    A "07", "couleur Rouge : relativit�", "K:couleur|Rouge:J", 1.0354699630334028, 0.0001, "abs"
    A "07", "couleur Vert : N", "K:couleur|Vert:H", 90#, 0.0, "exact"
    A "07", "couleur Vert : relativit�", "K:couleur|Vert:J", 1.1952432333550598, 0.0001, "abs"
    A "08", "age : chi2", "S:age:B", 52.6523318040296, 0.001, "abs"
    A "08", "age : ddl", "S:age:C", 4#, 0.0, "exact"
    A "08", "age : V", "S:age:E", 0.04856248011123699, 0.001, "abs"
    A "08", "age : delta D", "S:age:G", 66.45678590774719, 0.001, "abs"
    A "08", "age : d�cision", "S:age:J", "Retenue", 0.0, "txt"
    A "08", "zone : chi2", "S:zone:B", 32.222789104205226, 0.001, "abs"
    A "08", "zone : ddl", "S:zone:C", 3#, 0.0, "exact"
    A "08", "zone : V", "S:zone:E", 0.03799037828276436, 0.001, "abs"
    A "08", "zone : delta D", "S:zone:G", 33.06425184972093, 0.001, "abs"
    A "08", "zone : d�cision", "S:zone:J", "Retenue", 0.0, "txt"
    A "08", "puissance_cv : chi2", "S:puissance_cv:B", 31.49308662823553, 0.001, "abs"
    A "08", "puissance_cv : ddl", "S:puissance_cv:C", 2#, 0.0, "exact"
    A "08", "puissance_cv : V", "S:puissance_cv:E", 0.03755775870628105, 0.001, "abs"
    A "08", "puissance_cv : delta D", "S:puissance_cv:G", 40.43070600225258, 0.001, "abs"
    A "08", "puissance_cv : d�cision", "S:puissance_cv:J", "Retenue", 0.0, "txt"
    A "08", "usage : chi2", "S:usage:B", 19.262170639340148, 0.001, "abs"
    A "08", "usage : ddl", "S:usage:C", 2#, 0.0, "exact"
    A "08", "usage : V", "S:usage:E", 0.02937275389434858, 0.001, "abs"
End Sub
Private Sub Attendus3()
    A "08", "usage : delta D", "S:usage:G", 22.533082419728885, 0.001, "abs"
    A "08", "usage : d�cision", "S:usage:J", "Retenue", 0.0, "txt"
    A "08", "anc_permis : chi2", "S:anc_permis:B", 50.72813805013429, 0.001, "abs"
    A "08", "anc_permis : ddl", "S:anc_permis:C", 2#, 0.0, "exact"
    A "08", "anc_permis : V", "S:anc_permis:E", 0.04766685674672133, 0.001, "abs"
    A "08", "anc_permis : d�cision", "S:anc_permis:J", "�cart�e (redondante avec age)", 0.0, "txt"
    A "08", "anc_vehicule : chi2", "S:anc_vehicule:B", 3.873631572249208, 0.001, "abs"
    A "08", "anc_vehicule : ddl", "S:anc_vehicule:C", 2#, 0.0, "exact"
    A "08", "anc_vehicule : V", "S:anc_vehicule:E", 0.013171984454041573, 0.001, "abs"
    A "08", "anc_vehicule : d�cision", "S:anc_vehicule:J", "�cart�e (non significative)", 0.0, "txt"
    A "08", "couleur : chi2", "S:couleur:B", 4.792422421267194, 0.001, "abs"
    A "08", "couleur : ddl", "S:couleur:C", 5#, 0.0, "exact"
    A "08", "couleur : V", "S:couleur:E", 0.014651078632277808, 0.001, "abs"
    A "08", "couleur : d�cision", "S:couleur:J", "�cart�e (non significative)", 0.0, "txt"
    A "08", "V maximal entre retenues", "N:assoc_vmax", 0.07309187546189333, 0.0001, "abs"
    A "08", "Paire de V maximal", "N:assoc_paire", "age|puissance_cv", 0.0, "txt"
    A "09", "Fr�quence : Intercept coefficient", "GF:Intercept:C", -2.943525417160082, 1E-5, "abs"
    A "09", "Fr�quence : Intercept erreur std", "GF:Intercept:E", 0.0857382415487572, 1E-5, "abs"
    A "09", "Fr�quence : age 18-24 coefficient", "GF:age|18-24:C", 0.550067678724083, 1E-5, "abs"
    A "09", "Fr�quence : age 18-24 erreur std", "GF:age|18-24:E", 0.10515671834468542, 1E-5, "abs"
    A "09", "Fr�quence : age 25-29 coefficient", "GF:age|25-29:C", 0.3088821986958816, 1E-5, "abs"
    A "09", "Fr�quence : age 25-29 erreur std", "GF:age|25-29:E", 0.1040544612851713, 1E-5, "abs"
    A "09", "Fr�quence : age 50-74 coefficient", "GF:age|50-74:C", -0.29908409381936896, 1E-5, "abs"
    A "09", "Fr�quence : age 50-74 erreur std", "GF:age|50-74:E", 0.0877843353742387, 1E-5, "abs"
    A "09", "Fr�quence : age 75+ coefficient", "GF:age|75+:C", 0.2339706235939152, 1E-5, "abs"
    A "09", "Fr�quence : age 75+ erreur std", "GF:age|75+:E", 0.12380485462311223, 1E-5, "abs"
    A "09", "Fr�quence : zone A coefficient", "GF:zone|A:C", -0.1895071449832062, 1E-5, "abs"
    A "09", "Fr�quence : zone A erreur std", "GF:zone|A:E", 0.10811379310681724, 1E-5, "abs"
    A "09", "Fr�quence : zone C coefficient", "GF:zone|C:C", 0.29149264030655614, 1E-5, "abs"
    A "09", "Fr�quence : zone C erreur std", "GF:zone|C:E", 0.08388307376621376, 1E-5, "abs"
    A "09", "Fr�quence : zone D coefficient", "GF:zone|D:C", 0.321889736245077, 1E-5, "abs"
    A "09", "Fr�quence : zone D erreur std", "GF:zone|D:E", 0.09614298685434684, 1E-5, "abs"
    A "09", "Fr�quence : puissance_cv {inf}4 coefficient", "GF:puissance_cv|{inf}4:C", -0.35951563711862033, 1E-5, "abs"
    A "09", "Fr�quence : puissance_cv {inf}4 erreur std", "GF:puissance_cv|{inf}4:E", 0.09985786848100929, 1E-5, "abs"
    A "09", "Fr�quence : puissance_cv 9+ coefficient", "GF:puissance_cv|9+:C", 0.3825283497809264, 1E-5, "abs"
    A "09", "Fr�quence : puissance_cv 9+ erreur std", "GF:puissance_cv|9+:E", 0.08570350929043108, 1E-5, "abs"
    A "09", "Fr�quence : usage Trajet coefficient", "GF:usage|Trajet:C", 0.08585313413334694, 1E-5, "abs"
    A "09", "Fr�quence : usage Trajet erreur std", "GF:usage|Trajet:E", 0.07347996975821233, 1E-5, "abs"
    A "09", "Fr�quence : usage Professionnel coefficient", "GF:usage|Professionnel:C", 0.590787749942751, 1E-5, "abs"
    A "09", "Fr�quence : usage Professionnel erreur std", "GF:usage|Professionnel:E", 0.11642447848220179, 1E-5, "abs"
    A "09", "Co�t : Intercept coefficient", "GC:Intercept:C", 8.14392996723956, 1E-5, "abs"
    A "09", "Co�t : Intercept erreur std", "GC:Intercept:E", 0.09596118410508357, 1E-5, "abs"
    A "09", "Co�t : age 18-24 coefficient", "GC:age|18-24:C", 0.07718158585351355, 1E-5, "abs"
    A "09", "Co�t : age 18-24 erreur std", "GC:age|18-24:E", 0.11870610854635104, 1E-5, "abs"
    A "09", "Co�t : age 25-29 coefficient", "GC:age|25-29:C", 0.08435614320241493, 1E-5, "abs"
    A "09", "Co�t : age 25-29 erreur std", "GC:age|25-29:E", 0.11696599213968917, 1E-5, "abs"
    A "09", "Co�t : age 50-74 coefficient", "GC:age|50-74:C", -0.035929008952387265, 1E-5, "abs"
    A "09", "Co�t : age 50-74 erreur std", "GC:age|50-74:E", 0.09890178606701885, 1E-5, "abs"
    A "09", "Co�t : age 75+ coefficient", "GC:age|75+:C", -0.4432062756072346, 1E-5, "abs"
    A "09", "Co�t : age 75+ erreur std", "GC:age|75+:E", 0.14004770407626693, 1E-5, "abs"
    A "09", "Co�t : zone A coefficient", "GC:zone|A:C", -0.1285297640382321, 1E-5, "abs"
    A "09", "Co�t : zone A erreur std", "GC:zone|A:E", 0.12177531582329244, 1E-5, "abs"
    A "09", "Co�t : zone C coefficient", "GC:zone|C:C", -0.1411674076091369, 1E-5, "abs"
    A "09", "Co�t : zone C erreur std", "GC:zone|C:E", 0.09471432538169758, 1E-5, "abs"
    A "09", "Co�t : zone D coefficient", "GC:zone|D:C", 0.11305244311584516, 1E-5, "abs"
    A "09", "Co�t : zone D erreur std", "GC:zone|D:E", 0.10807925829457685, 1E-5, "abs"
    A "09", "Co�t : puissance_cv {inf}4 coefficient", "GC:puissance_cv|{inf}4:C", -0.12505094794441488, 1E-5, "abs"
    A "09", "Co�t : puissance_cv {inf}4 erreur std", "GC:puissance_cv|{inf}4:E", 0.11275838435439624, 1E-5, "abs"
    A "09", "Co�t : puissance_cv 9+ coefficient", "GC:puissance_cv|9+:C", 0.06987164420708225, 1E-5, "abs"
    A "09", "Co�t : puissance_cv 9+ erreur std", "GC:puissance_cv|9+:E", 0.09617424757600607, 1E-5, "abs"
    A "09", "Co�t : usage Trajet coefficient", "GC:usage|Trajet:C", 0.03214507485958721, 1E-5, "abs"
    A "09", "Co�t : usage Trajet erreur std", "GC:usage|Trajet:E", 0.08313196106452432, 1E-5, "abs"
    A "09", "Co�t : usage Professionnel coefficient", "GC:usage|Professionnel:C", 0.032572878098076616, 1E-5, "abs"
    A "09", "Co�t : usage Professionnel erreur std", "GC:usage|Professionnel:E", 0.13163630049609623, 1E-5, "abs"
    A "09", "D�viance fr�quence (cellules)", "N:glmf_dev_cel", 164.6025506415574, 0.001, "abs"
    A "09", "D�viance fr�quence (lignes)", "N:glmf_dev_lig", 5621.922515780955, 0.001, "abs"
    A "09", "D�viance nulle fr�quence (lignes)", "N:glmf_dev0_lig", 5768.516727402073, 0.001, "abs"
    A "09", "D�viance co�t (cellules)", "N:glmc_dev_cel", 154.30621410313336, 0.001, "abs"
    A "09", "D�viance co�t (sinistres)", "N:glmc_dev_sin", 877.468311245729, 0.001, "abs"
    A "09", "D�viance nulle co�t (sinistres)", "N:glmc_dev0_sin", 902.4712800581475, 0.001, "abs"
    A "09", "Dispersion phi (co�t)", "N:glmc_phi", 1.2623700771030593, 0.0001, "abs"
    A "09", "Cellules fr�quence", "N:glmf_ncel", 172#, 0.0, "exact"
    A "09", "Cellules co�t", "N:glmc_ncel", 139#, 0.0, "exact"
    A "09", "It�rations IRLS fr�quence", "N:glmf_iter", 5#, 1.0, "abs"
    A "09", "It�rations IRLS co�t", "N:glmc_iter", 7#, 1.0, "abs"
    A "09", "Lift fr�quence Q1 observ�", "I:glmf_q_obs:1", 0.01858931350285902, 1E-5, "abs"
    A "09", "Lift fr�quence Q1 pr�dit", "I:glmf_q_pred:1", 0.018045964454624808, 1E-5, "abs"
    A "09", "Lift fr�quence Q2 observ�", "I:glmf_q_obs:2", 0.028213728467648067, 1E-5, "abs"
    A "09", "Lift fr�quence Q2 pr�dit", "I:glmf_q_pred:2", 0.02561752618689718, 1E-5, "abs"
    A "09", "Lift fr�quence Q3 observ�", "I:glmf_q_obs:3", 0.029564203523394013, 1E-5, "abs"
    A "09", "Lift fr�quence Q3 pr�dit", "I:glmf_q_pred:3", 0.03204035315406378, 1E-5, "abs"
    A "09", "Lift fr�quence Q4 observ�", "I:glmf_q_obs:4", 0.04188116256648472, 1E-5, "abs"
    A "09", "Lift fr�quence Q4 pr�dit", "I:glmf_q_pred:4", 0.04275226662603658, 1E-5, "abs"
    A "09", "Lift fr�quence Q5 observ�", "I:glmf_q_obs:5", 0.07972159762356282, 1E-5, "abs"
    A "09", "Lift fr�quence Q5 pr�dit", "I:glmf_q_pred:5", 0.07951451696623778, 1E-5, "abs"
    A "09", "Lift co�t Q1 observ�", "I:glmc_q_obs:1", 2369.5217770318013, 0.1, "abs"
    A "09", "Lift co�t Q1 pr�dit", "I:glmc_q_pred:1", 2504.6545681924886, 0.1, "abs"
    A "09", "Lift co�t Q2 observ�", "I:glmc_q_obs:2", 3131.187025437492, 0.1, "abs"
    A "09", "Lift co�t Q2 pr�dit", "I:glmc_q_pred:2", 3061.513376882167, 0.1, "abs"
    A "09", "Lift co�t Q3 observ�", "I:glmc_q_obs:3", 3326.657687381539, 0.1, "abs"
End Sub
Private Sub Attendus4()
    A "09", "Lift co�t Q3 pr�dit", "I:glmc_q_pred:3", 3306.048269241497, 0.1, "abs"
    A "09", "Lift co�t Q4 observ�", "I:glmc_q_obs:4", 3771.560879068853, 0.1, "abs"
    A "09", "Lift co�t Q4 pr�dit", "I:glmc_q_pred:4", 3569.2984417444923, 0.1, "abs"
    A "09", "Lift co�t Q5 observ�", "I:glmc_q_obs:5", 3847.0648212791816, 0.1, "abs"
    A "09", "Lift co�t Q5 pr�dit", "I:glmc_q_pred:5", 4024.700502232992, 0.1, "abs"
    A "09", "Observ� / pr�dit CRM 0,50", "I:crm_ratio:1", 1.0002682112788712, 0.0001, "abs"
    A "09", "Observ� / pr�dit CRM 0,51-0,79", "I:crm_ratio:2", 0.9503320429244143, 0.0001, "abs"
    A "09", "Observ� / pr�dit CRM 0,80-0,99", "I:crm_ratio:3", 1.0327798672429322, 0.0001, "abs"
    A "09", "Observ� / pr�dit CRM {sup} 1,00", "I:crm_ratio:4", 1.0694105791137616, 0.0001, "abs"
    A "10", "n_u", "N:n_u", 45#, 0.0, "exact"
    A "10", "alpha", "N:alpha", 1.7731660503954045, 1E-5, "abs"
    A "10", "IC 95 % borne basse", "N:ic_bas", 1.2550831933824227, 0.0001, "abs"
    A "10", "IC 95 % borne haute", "N:ic_haut", 2.291248907408386, 0.0001, "abs"
    A "10", "e(u) Pareto", "N:e_u", 19400.748380414345, 0.01, "abs"
    A "10", "e(u) empirique", "N:e_emp", 15926.309286553294, 0.01, "abs"
    A "10", "kappa", "N:kappa", 1.3002577677558358, 1E-6, "abs"
    A "10", "kappa empirique", "N:kappa_emp", 1.2464852376415079, 1E-6, "abs"
    A "10", "�cart kappa", "N:ecart_kappa", 0.04313932366826245, 1E-6, "abs"
    A "10", "Survie observ�e 1.5u", "I:surv_obs:1", 0.4444444444444444, 0.0001, "abs"
    A "10", "Survie Pareto 1.5u", "I:surv_par:1", 0.4872602207982465, 0.0001, "abs"
    A "10", "Survie observ�e 2u", "I:surv_obs:2", 0.3111111111111111, 0.0001, "abs"
    A "10", "Survie Pareto 2u", "I:surv_par:2", 0.2925659848572242, 0.0001, "abs"
    A "10", "Survie observ�e 3u", "I:surv_obs:3", 0.17777777777777778, 0.0001, "abs"
    A "10", "Survie Pareto 3u", "I:surv_par:3", 0.1425557663795875, 0.0001, "abs"
    A "10", "Survie observ�e 5u", "I:surv_obs:4", 0.044444444444444446, 0.0001, "abs"
    A "10", "Survie Pareto 5u", "I:surv_par:4", 0.05762489115327328, 0.0001, "abs"
    A "10", "Survie observ�e 10u", "I:surv_obs:5", 0.0, 0.0001, "abs"
    A "10", "Survie Pareto 10u", "I:surv_par:5", 0.016859083032547743, 0.0001, "abs"
    A "11", "B0", "N:B0", 235.79601257963313, 1E-5, "rel"
    A "11", "theta", "N:theta", 1.0175939001631253, 1E-5, "rel"
    A "11", "B", "N:base_pp", 239.94458408382224, 1E-5, "rel"
    A "11", "Prime pure moyenne", "N:pp_moy", 172.5276158108279, 0.0001, "abs"
    A "11", "Polices renouvel�es", "N:n_renouv", 4630#, 0.0, "exact"
    A "11", "�volution moyenne", "N:evol_moy", 0.08999133492376754, 1E-5, "abs"
    A "11", "�quilibre plafonn�", "N:equilibre", 0.9529838842345534, 1E-5, "abs"
    A "11", "Prime TTC moyenne nouvelle", "N:ttc_moy", 330.5362439984131, 0.01, "abs"
    A "11", "Prime TTC moyenne actuelle", "N:ttc_moy_act", 303.2466712421437, 0.01, "abs"
    A "11", "Dislocation < -10 %", "I:disl_part:1", 0.13952483801295895, 0.0001, "abs"
    A "11", "Dislocation -10 � -5 %", "I:disl_part:2", 0.14190064794816415, 0.0001, "abs"
    A "11", "Dislocation -5 � 0 %", "I:disl_part:3", 0.15788336933045358, 0.0001, "abs"
    A "11", "Dislocation 0 � +5 %", "I:disl_part:4", 0.20518358531317496, 0.0001, "abs"
    A "11", "Dislocation +5 � +10 %", "I:disl_part:5", 0.1079913606911447, 0.0001, "abs"
    A "11", "Dislocation > +10 %", "I:disl_part:6", 0.24751619870410368, 0.0001, "abs"
    A "11", "age 18-24 : rel. F", "T:age|18-24:C", 1.7333703261897515, 0.0001, "abs"
    A "11", "age 18-24 : rel. C", "T:age|18-24:D", 1.0802382145622922, 0.0001, "abs"
    A "11", "age 18-24 : rel. PP", "T:age|18-24:E", 1.8724528663384752, 0.0001, "abs"
    A "11", "age 18-24 : �volution", "T:age|18-24:F", 0.2554701140683884, 0.0001, "abs"
    A "11", "age 25-29 : rel. F", "T:age|25-29:C", 1.361901927230285, 0.0001, "abs"
    A "11", "age 25-29 : rel. C", "T:age|25-29:D", 1.0880163144306216, 0.0001, "abs"
    A "11", "age 25-29 : rel. PP", "T:age|25-29:E", 1.4817715154810553, 0.0001, "abs"
    A "11", "age 25-29 : �volution", "T:age|25-29:F", 0.1705285666064138, 0.0001, "abs"
    A "11", "age 30-49 : rel. F", "T:age|30-49:C", 1.0, 0.0001, "abs"
    A "11", "age 30-49 : rel. C", "T:age|30-49:D", 1.0, 0.0001, "abs"
    A "11", "age 30-49 : rel. PP", "T:age|30-49:E", 1.0, 0.0001, "abs"
    A "11", "age 30-49 : �volution", "T:age|30-49:F", 0.09463243915986075, 0.0001, "abs"
    A "11", "age 50-74 : rel. F", "T:age|50-74:C", 0.7414970514939776, 0.0001, "abs"
    A "11", "age 50-74 : rel. C", "T:age|50-74:D", 0.9647087767389472, 0.0001, "abs"
    A "11", "age 50-74 : rel. PP", "T:age|50-74:E", 0.7153287135022912, 0.0001, "abs"
    A "11", "age 50-74 : �volution", "T:age|50-74:F", 0.0065354991302495336, 0.0001, "abs"
    A "11", "age 75+ : rel. F", "T:age|75+:C", 1.2636073714192682, 0.0001, "abs"
    A "11", "age 75+ : rel. C", "T:age|75+:D", 0.6419747696935151, 0.0001, "abs"
    A "11", "age 75+ : rel. PP", "T:age|75+:E", 0.8112040512499127, 0.0001, "abs"
    A "11", "age 75+ : �volution", "T:age|75+:F", -0.07622978651554935, 0.0001, "abs"
    A "11", "zone A : rel. F", "T:zone|A:C", 0.8273668053544077, 0.0001, "abs"
    A "11", "zone A : rel. C", "T:zone|A:D", 0.8793873879090537, 0.0001, "abs"
    A "11", "zone A : rel. PP", "T:zone|A:E", 0.727575933803271, 0.0001, "abs"
    A "11", "zone A : �volution", "T:zone|A:F", 0.011501960183440962, 0.0001, "abs"
    A "11", "zone B : rel. F", "T:zone|B:C", 1.0, 0.0001, "abs"
    A "11", "zone B : rel. C", "T:zone|B:D", 1.0, 0.0001, "abs"
    A "11", "zone B : rel. PP", "T:zone|B:E", 1.0, 0.0001, "abs"
    A "11", "zone B : �volution", "T:zone|B:F", 0.05905213386650132, 0.0001, "abs"
    A "11", "zone C : rel. F", "T:zone|C:C", 1.3384237830654675, 0.0001, "abs"
    A "11", "zone C : rel. C", "T:zone|C:D", 0.8683439321475966, 0.0001, "abs"
    A "11", "zone C : rel. PP", "T:zone|C:E", 1.16221217066693, 0.0001, "abs"
    A "11", "zone C : �volution", "T:zone|C:F", 0.07774879956784808, 0.0001, "abs"
    A "11", "zone D : rel. F", "T:zone|D:C", 1.3797326330685655, 0.0001, "abs"
    A "11", "zone D : rel. C", "T:zone|D:D", 1.1196906514754272, 0.0001, "abs"
    A "11", "zone D : rel. PP", "T:zone|D:E", 1.5448737307824487, 0.0001, "abs"
    A "11", "zone D : �volution", "T:zone|D:F", 0.20466479875693722, 0.0001, "abs"
    A "11", "puissance_cv {inf}4 : rel. F", "T:puissance_cv|{inf}4:C", 0.698014336439827, 0.0001, "abs"
    A "11", "puissance_cv {inf}4 : rel. C", "T:puissance_cv|{inf}4:D", 0.8824519423267823, 0.0001, "abs"
    A "11", "puissance_cv {inf}4 : rel. PP", "T:puissance_cv|{inf}4:E", 0.6159641069632654, 0.0001, "abs"
    A "11", "puissance_cv {inf}4 : �volution", "T:puissance_cv|{inf}4:F", 0.021349325849934875, 0.0001, "abs"
    A "11", "puissance_cv 5-8 : rel. F", "T:puissance_cv|5-8:C", 1.0, 0.0001, "abs"
    A "11", "puissance_cv 5-8 : rel. C", "T:puissance_cv|5-8:D", 1.0, 0.0001, "abs"
    A "11", "puissance_cv 5-8 : rel. PP", "T:puissance_cv|5-8:E", 1.0, 0.0001, "abs"
    A "11", "puissance_cv 5-8 : �volution", "T:puissance_cv|5-8:F", 0.07554163347445941, 0.0001, "abs"
    A "11", "puissance_cv 9+ : rel. F", "T:puissance_cv|9+:C", 1.4659864341627071, 0.0001, "abs"
    A "11", "puissance_cv 9+ : rel. C", "T:puissance_cv|9+:D", 1.0723705274507214, 0.0001, "abs"
    A "11", "puissance_cv 9+ : rel. PP", "T:puissance_cv|9+:E", 1.5720806456386645, 0.0001, "abs"
End Sub
Private Sub Attendus5()
    A "11", "puissance_cv 9+ : �volution", "T:puissance_cv|9+:F", 0.1857110107936295, 0.0001, "abs"
    A "11", "usage Priv� : rel. F", "T:usage|Priv�:C", 1.0, 0.0001, "abs"
    A "11", "usage Priv� : rel. C", "T:usage|Priv�:D", 1.0, 0.0001, "abs"
    A "11", "usage Priv� : rel. PP", "T:usage|Priv�:E", 1.0, 0.0001, "abs"
    A "11", "usage Priv� : �volution", "T:usage|Priv�:F", 0.06684118801702144, 0.0001, "abs"
    A "11", "usage Trajet : rel. F", "T:usage|Trajet:C", 1.0896462847069968, 0.0001, "abs"
    A "11", "usage Trajet : rel. C", "T:usage|Trajet:D", 1.032667308503298, 0.0001, "abs"
    A "11", "usage Trajet : rel. PP", "T:usage|Trajet:E", 1.1252420960489928, 0.0001, "abs"
    A "11", "usage Trajet : �volution", "T:usage|Trajet:F", 0.09042635501938512, 0.0001, "abs"
    A "11", "usage Professionnel : rel. F", "T:usage|Professionnel:C", 1.805410067048296, 0.0001, "abs"
    A "11", "usage Professionnel : rel. C", "T:usage|Professionnel:D", 1.033109181432754, 0.0001, "abs"
    A "11", "usage Professionnel : rel. PP", "T:usage|Professionnel:E", 1.8651857165187185, 0.0001, "abs"
    A "11", "usage Professionnel : �volution", "T:usage|Professionnel:F", 0.22971276122114803, 0.0001, "abs"
    A "TB", "Exercice 2021 : primes", "H:2021:I", 949080.4199999999, 0.0001, "abs"
    A "TB", "Exercice 2021 : ultime", "H:2021:F", 481316.25345489394, 0.0001, "abs"
    A "TB", "Exercice 2021 : S/P", "H:2021:L", 0.5071395882921007, 0.0001, "abs"
    A "TB", "Exercice 2021 : ratio combin�", "H:2021:M", 0.7571395882921007, 0.0001, "abs"
    A "TB", "Exercice 2022 : primes", "H:2022:I", 962562.48, 0.0001, "abs"
    A "TB", "Exercice 2022 : ultime", "H:2022:F", 644660.8688543405, 0.0001, "abs"
    A "TB", "Exercice 2022 : S/P", "H:2022:L", 0.6697340507749071, 0.0001, "abs"
    A "TB", "Exercice 2022 : ratio combin�", "H:2022:M", 0.9197340507749071, 0.0001, "abs"
    A "TB", "Exercice 2023 : primes", "H:2023:I", 987273.3, 0.0001, "abs"
    A "TB", "Exercice 2023 : ultime", "H:2023:F", 688228.3064758022, 0.0001, "abs"
    A "TB", "Exercice 2023 : S/P", "H:2023:L", 0.6971000901936699, 0.0001, "abs"
    A "TB", "Exercice 2023 : ratio combin�", "H:2023:M", 0.9471000901936699, 0.0001, "abs"
    A "TB", "Exercice 2024 : primes", "H:2024:I", 1002328.03, 0.0001, "abs"
    A "TB", "Exercice 2024 : ultime", "H:2024:F", 631805.4118203013, 0.0001, "abs"
    A "TB", "Exercice 2024 : S/P", "H:2024:L", 0.6303379661250232, 0.0001, "abs"
    A "TB", "Exercice 2024 : ratio combin�", "H:2024:M", 0.8803379661250232, 0.0001, "abs"
    A "TB", "Exercice 2025 : primes", "H:2025:I", 1031663.5399999999, 0.0001, "abs"
    A "TB", "Exercice 2025 : ultime", "H:2025:F", 826576.2987943382, 0.0001, "abs"
    A "TB", "Exercice 2025 : S/P", "H:2025:L", 0.8012072412623386, 0.0001, "abs"
    A "TB", "Exercice 2025 : ratio combin�", "H:2025:M", 1.0512072412623386, 0.0001, "abs"
    A "TB", "Segments 2025 age 18-24 : S/P", "G:2025|age|18-24", 0.8028910479656733, 0.001, "abs"
    A "TB", "Segments 2025 age 25-29 : S/P", "G:2025|age|25-29", 0.9638748396989125, 0.001, "abs"
    A "TB", "Segments 2025 age 30-49 : S/P", "G:2025|age|30-49", 0.8073260732643506, 0.001, "abs"
    A "TB", "Segments 2025 age 50-74 : S/P", "G:2025|age|50-74", 0.8615859847450724, 0.001, "abs"
    A "TB", "Segments 2025 age 75+ : S/P", "G:2025|age|75+", 0.29638697421941035, 0.001, "abs"
    A "TB", "Segments 2025 zone A : S/P", "G:2025|zone|A", 0.8381674459190164, 0.001, "abs"
    A "TB", "Segments 2025 zone B : S/P", "G:2025|zone|B", 0.6375883453545854, 0.001, "abs"
    A "TB", "Segments 2025 zone C : S/P", "G:2025|zone|C", 1.0126134157280833, 0.001, "abs"
    A "TB", "Segments 2025 zone D : S/P", "G:2025|zone|D", 0.6872502865110697, 0.001, "abs"
    A "TB", "Segments 2025 puissance_cv {inf}4 : S/P", "G:2025|puissance_cv|{inf}4", 0.5727374103136489, 0.001, "abs"
    A "TB", "Segments 2025 puissance_cv 5-8 : S/P", "G:2025|puissance_cv|5-8", 0.8636330928097751, 0.001, "abs"
    A "TB", "Segments 2025 puissance_cv 9+ : S/P", "G:2025|puissance_cv|9+", 0.7428972714538893, 0.001, "abs"
    A "TB", "Segments 2025 usage Priv� : S/P", "G:2025|usage|Priv�", 0.7164977739547257, 0.001, "abs"
    A "TB", "Segments 2025 usage Trajet : S/P", "G:2025|usage|Trajet", 0.8941467973380651, 0.001, "abs"
    A "TB", "Segments 2025 usage Professionnel : S/P", "G:2025|usage|Professionnel", 0.975947988441654, 0.001, "abs"
    A "TB", "Bandeau 2025", "B:2025", "La zone C et l�usage professionnel restent sous-tarif�s : S/P 2025 de 101 % et 98 % (cible 68 %). Lancer la r�vision.", 0.0, "txt"
    A "CA", "Profil par d�faut : fr�quence", "P:defaut:calc_freq", 0.1198550144428689, 0.0001, "abs"
    A "CA", "Profil par d�faut : co�t", "P:defaut:calc_cout", 4412.040974083398, 0.01, "abs"
    A "CA", "Profil par d�faut : HT", "P:defaut:calc_ht", 778.0991310163342, 0.01, "abs"
    A "CA", "Profil par d�faut : vs moyenne", "P:defaut:calc_vs_moyenne", 2.159136260497151, 0.0001, "abs"
    A "CA", "Profil par d�faut : prime pure", "P:defaut:calc_pp", 528.8052346712951, 0.01, "abs"
    A "CA", "Profil par d�faut : TTC", "P:defaut:calc_ttc", 1044.2090338239207, 0.01, "abs"
    A "CA", "Profil par d�faut : vs tarif actuel", "P:defaut:calc_vs_actuel", 0.45621631728528755, 0.0001, "abs"
    A "CA", "Profil de r�f�rence : prime pure", "P:reference:calc_pp", 119.97229204191113, 0.01, "abs"
    A "CA", "Profil de r�f�rence : TTC", "P:reference:calc_ttc", 236.90414342550298, 0.01, "abs"
    A "CA", "Profil de r�f�rence : vs tarif actuel", "P:reference:calc_vs_actuel", 0.015565415160308849, 0.0001, "abs"
    A "CT", "Contr�le 01-1 vert � 15 000 �", "X:1", True, 0.0, "bool"
    A "CT", "Contr�le 01-2 vert � 15 000 �", "X:2", True, 0.0, "bool"
    A "CT", "Contr�le 01-3 vert � 15 000 �", "X:3", True, 0.0, "bool"
    A "CT", "Contr�le 02-1 vert � 15 000 �", "X:4", True, 0.0, "bool"
    A "CT", "Contr�le 02-2 vert � 15 000 �", "X:5", True, 0.0, "bool"
    A "CT", "Contr�le 02-3 vert � 15 000 �", "X:6", True, 0.0, "bool"
    A "CT", "Contr�le 03-1 vert � 15 000 �", "X:7", True, 0.0, "bool"
    A "CT", "Contr�le 03-2 vert � 15 000 �", "X:8", True, 0.0, "bool"
    A "CT", "Contr�le 03-3 vert � 15 000 �", "X:9", True, 0.0, "bool"
    A "CT", "Contr�le 04-1 vert � 15 000 �", "X:10", True, 0.0, "bool"
    A "CT", "Contr�le 04-2 vert � 15 000 �", "X:11", True, 0.0, "bool"
    A "CT", "Contr�le 04-3 vert � 15 000 �", "X:12", True, 0.0, "bool"
    A "CT", "Contr�le 05-1 vert � 15 000 �", "X:13", True, 0.0, "bool"
    A "CT", "Contr�le 05-2 vert � 15 000 �", "X:14", True, 0.0, "bool"
    A "CT", "Contr�le 05-3 vert � 15 000 �", "X:15", True, 0.0, "bool"
    A "CT", "Contr�le 06-1 vert � 15 000 �", "X:16", True, 0.0, "bool"
    A "CT", "Contr�le 06-2 vert � 15 000 �", "X:17", True, 0.0, "bool"
    A "CT", "Contr�le 06-3 vert � 15 000 �", "X:18", True, 0.0, "bool"
    A "CT", "Contr�le 07-1 vert � 15 000 �", "X:19", True, 0.0, "bool"
    A "CT", "Contr�le 07-2 vert � 15 000 �", "X:20", True, 0.0, "bool"
    A "CT", "Contr�le 07-3 vert � 15 000 �", "X:21", True, 0.0, "bool"
    A "CT", "Contr�le 08-1 vert � 15 000 �", "X:22", True, 0.0, "bool"
    A "CT", "Contr�le 08-2 vert � 15 000 �", "X:23", True, 0.0, "bool"
    A "CT", "Contr�le 08-3 vert � 15 000 �", "X:24", True, 0.0, "bool"
    A "CT", "Contr�le 09-1 vert � 15 000 �", "X:25", True, 0.0, "bool"
    A "CT", "Contr�le 09-2 vert � 15 000 �", "X:26", True, 0.0, "bool"
    A "CT", "Contr�le 09-3 vert � 15 000 �", "X:27", True, 0.0, "bool"
    A "CT", "Contr�le 10-1 vert � 15 000 �", "X:28", True, 0.0, "bool"
    A "CT", "Contr�le 10-2 vert � 15 000 �", "X:29", True, 0.0, "bool"
    A "CT", "Contr�le 10-3 vert � 15 000 �", "X:30", True, 0.0, "bool"
    A "CT", "Contr�le 11-1 vert � 15 000 �", "X:31", True, 0.0, "bool"
End Sub
Private Sub Attendus6()
    A "CT", "Contr�le 11-2 vert � 15 000 �", "X:32", True, 0.0, "bool"
    A "CT", "Contr�le 11-3 vert � 15 000 �", "X:33", True, 0.0, "bool"
End Sub

Private Sub AttendusS10_1()
    A "S10", "n_u", "N:n_u", 71#, 0.0, "exact"
    A "S10", "Part de l'exc�dent", "N:ecr_part_exc", 0.2785830192408074, 0.0001, "abs"
    A "S10", "alpha", "N:alpha", 1.435693816403879, 0.0001, "abs"
    A "S10", "kappa", "N:kappa", 1.6232563430993738, 0.0001, "abs"
    A "S10", "kappa empirique", "N:kappa_emp", 1.3861608843024973, 0.0001, "abs"
    A "S10", "theta", "N:theta", 0.9069260076573206, 0.0001, "abs"
    A "S10", "B", "N:base_pp", 231.11706354317374, 0.01, "abs"
    A "S10", "�volution moyenne", "N:evol_moy", 0.09114649945723796, 0.0001, "abs"
    A "S10", "�quilibre plafonn�", "N:equilibre", 0.9539816647280486, 0.0001, "abs"
    A "S10", "Contr�le 01-1 vert", "X:1", True, 0.0, "bool"
    A "S10", "Contr�le 01-2 vert", "X:2", True, 0.0, "bool"
    A "S10", "Contr�le 01-3 vert", "X:3", True, 0.0, "bool"
    A "S10", "Contr�le 02-1 vert", "X:4", True, 0.0, "bool"
    A "S10", "Contr�le 02-2 vert", "X:5", True, 0.0, "bool"
    A "S10", "Contr�le 02-3 vert", "X:6", True, 0.0, "bool"
    A "S10", "Contr�le 03-1 vert", "X:7", True, 0.0, "bool"
    A "S10", "Contr�le 03-2 vert", "X:8", True, 0.0, "bool"
    A "S10", "Contr�le 03-3 vert", "X:9", True, 0.0, "bool"
    A "S10", "Contr�le 04-1 vert", "X:10", True, 0.0, "bool"
    A "S10", "Contr�le 04-2 vert", "X:11", True, 0.0, "bool"
    A "S10", "Contr�le 04-3 vert", "X:12", True, 0.0, "bool"
    A "S10", "Contr�le 05-1 vert", "X:13", True, 0.0, "bool"
    A "S10", "Contr�le 05-2 vert", "X:14", True, 0.0, "bool"
    A "S10", "Contr�le 05-3 vert", "X:15", True, 0.0, "bool"
    A "S10", "Contr�le 06-1 vert", "X:16", True, 0.0, "bool"
    A "S10", "Contr�le 06-2 vert", "X:17", True, 0.0, "bool"
    A "S10", "Contr�le 06-3 vert", "X:18", True, 0.0, "bool"
    A "S10", "Contr�le 07-1 vert", "X:19", True, 0.0, "bool"
    A "S10", "Contr�le 07-2 vert", "X:20", True, 0.0, "bool"
    A "S10", "Contr�le 07-3 vert", "X:21", True, 0.0, "bool"
    A "S10", "Contr�le 08-1 vert", "X:22", True, 0.0, "bool"
    A "S10", "Contr�le 08-2 vert", "X:23", True, 0.0, "bool"
    A "S10", "Contr�le 08-3 vert", "X:24", True, 0.0, "bool"
    A "S10", "Contr�le 09-1 vert", "X:25", True, 0.0, "bool"
    A "S10", "Contr�le 09-2 vert", "X:26", True, 0.0, "bool"
    A "S10", "Contr�le 09-3 vert", "X:27", True, 0.0, "bool"
    A "S10", "Contr�le 10-1 vert", "X:28", True, 0.0, "bool"
    A "S10", "Contr�le 10-2 rose", "X:29", False, 0.0, "bool"
    A "S10", "Contr�le 10-3 vert", "X:30", True, 0.0, "bool"
    A "S10", "Contr�le 11-1 vert", "X:31", True, 0.0, "bool"
    A "S10", "Contr�le 11-2 vert", "X:32", True, 0.0, "bool"
    A "S10", "Contr�le 11-3 vert", "X:33", True, 0.0, "bool"
End Sub

Private Sub AttendusS05_1()
    A "S05", "n_u", "N:n_u", 166#, 0.0, "exact"
    A "S05", "Part de l'exc�dent", "N:ecr_part_exc", 0.4198373142387026, 0.0001, "abs"
    A "S05", "alpha", "N:alpha", 1.3369846181126377, 0.0001, "abs"
    A "S05", "kappa", "N:kappa", 2.171370647175636, 0.0001, "abs"
    A "S05", "kappa empirique", "N:kappa_emp", 1.7236544585555107, 0.0001, "abs"
    A "S05", "theta", "N:theta", 0.8437074878199218, 0.0001, "abs"
    A "S05", "B", "N:base_pp", 226.78046215129487, 0.01, "abs"
    A "S05", "�volution moyenne", "N:evol_moy", 0.09408520655259323, 0.0001, "abs"
    A "S05", "�quilibre plafonn�", "N:equilibre", 0.9578163586680752, 0.0001, "abs"
    A "S05", "Contr�le 01-1 vert", "X:1", True, 0.0, "bool"
    A "S05", "Contr�le 01-2 vert", "X:2", True, 0.0, "bool"
    A "S05", "Contr�le 01-3 vert", "X:3", True, 0.0, "bool"
    A "S05", "Contr�le 02-1 vert", "X:4", True, 0.0, "bool"
    A "S05", "Contr�le 02-2 vert", "X:5", True, 0.0, "bool"
    A "S05", "Contr�le 02-3 vert", "X:6", True, 0.0, "bool"
    A "S05", "Contr�le 03-1 vert", "X:7", True, 0.0, "bool"
    A "S05", "Contr�le 03-2 vert", "X:8", True, 0.0, "bool"
    A "S05", "Contr�le 03-3 vert", "X:9", True, 0.0, "bool"
    A "S05", "Contr�le 04-1 vert", "X:10", True, 0.0, "bool"
    A "S05", "Contr�le 04-2 vert", "X:11", True, 0.0, "bool"
    A "S05", "Contr�le 04-3 vert", "X:12", True, 0.0, "bool"
    A "S05", "Contr�le 05-1 vert", "X:13", True, 0.0, "bool"
    A "S05", "Contr�le 05-2 vert", "X:14", True, 0.0, "bool"
    A "S05", "Contr�le 05-3 rose", "X:15", False, 0.0, "bool"
    A "S05", "Contr�le 06-1 vert", "X:16", True, 0.0, "bool"
    A "S05", "Contr�le 06-2 vert", "X:17", True, 0.0, "bool"
    A "S05", "Contr�le 06-3 vert", "X:18", True, 0.0, "bool"
    A "S05", "Contr�le 07-1 vert", "X:19", True, 0.0, "bool"
    A "S05", "Contr�le 07-2 vert", "X:20", True, 0.0, "bool"
    A "S05", "Contr�le 07-3 vert", "X:21", True, 0.0, "bool"
    A "S05", "Contr�le 08-1 vert", "X:22", True, 0.0, "bool"
    A "S05", "Contr�le 08-2 vert", "X:23", True, 0.0, "bool"
    A "S05", "Contr�le 08-3 vert", "X:24", True, 0.0, "bool"
    A "S05", "Contr�le 09-1 vert", "X:25", True, 0.0, "bool"
    A "S05", "Contr�le 09-2 vert", "X:26", True, 0.0, "bool"
    A "S05", "Contr�le 09-3 vert", "X:27", True, 0.0, "bool"
    A "S05", "Contr�le 10-1 vert", "X:28", True, 0.0, "bool"
    A "S05", "Contr�le 10-2 rose", "X:29", False, 0.0, "bool"
    A "S05", "Contr�le 10-3 vert", "X:30", True, 0.0, "bool"
    A "S05", "Contr�le 11-1 vert", "X:31", True, 0.0, "bool"
    A "S05", "Contr�le 11-2 vert", "X:32", True, 0.0, "bool"
    A "S05", "Contr�le 11-3 vert", "X:33", True, 0.0, "bool"
End Sub
