Attribute VB_Name = "modPages"
Option Explicit
' =====================================================================
' modPages : construction (ConstruirePages) et mise à jour (MajPage)
' des 13 pages. Toute valeur affichée est lue dans une cellule (R14).
' =====================================================================

Public Const NB_PAGES As Long = 13
Private Const LISTE_PAGES As String = "P00_Tableau,P01_Import,P02_Qualite,P03_Base,P04_Ultime,P05_Ecretement," & _
    "P06_Exploratoire,P07_Classes,P08_Selection,P09_Modeles,P10_Graves,P11_Resultats,P12_Calculateur"
Private Const CF_L As Double = 476
Private Const CF_T As Double = 178
Private Const CF_W As Double = 464
Private Const CF_COL0 As Double = 496
Private Const CF_LARGEUR As Double = 444
Private Const CF_LIGNE_H As Double = 17
Private Const CF_FORMULE_MAX As Long = 84
Private Const LARGEUR_INTRO As Double = 520
Private Const LARGEUR_INTRO_PUCES As Double = 400
Private Const FACTEUR_VMAX As Double = 1.05
Private Const SEUIL_REL_AVANT As Double = 1.2
Private Const PV_MIN As Double = 0.001

' ---------------------------------------------------------------------
' Noms et accès
' ---------------------------------------------------------------------
Public Function NomPage(ByVal n As Long) As String
    NomPage = Split(LISTE_PAGES, ",")(n)
End Function

Public Function NumeroPage(ByVal nomFeuille As String) As Long
    Dim n As Long
    NumeroPage = -1
    For n = 0 To NB_PAGES - 1
        If NomPage(n) = nomFeuille Then NumeroPage = n: Exit Function
    Next n
End Function

Public Function FeuillePage(ByVal n As Long) As Worksheet
    Set FeuillePage = ThisWorkbook.Worksheets(NomPage(n))
End Function

Private Function VN(ByVal nom As String) As Variant
    VN = ValeurNom(nom)
End Function

Private Function Ctl(ByVal etape As Long, ByVal k As Long, ByVal col As Long) As Variant
    Ctl = Feuille(F_CONTROLES).Cells((etape - 1) * 3 + k + 1, col).Value2
End Function

Private Function CtlOk(ByVal etape As Long, ByVal k As Long) As Boolean
    Dim v As Variant
    v = Ctl(etape, k, 4)
    CtlOk = False
    If VarType(v) = vbBoolean Then CtlOk = v
End Function

Private Function Nb(ByVal v As Variant, ByVal nd As Long) As String
    If EstNombre(v) Then Nb = FormatNombre(CDbl(v), nd) Else Nb = Tiret()
End Function

Private Function Pc(ByVal v As Variant, ByVal nd As Long, Optional ByVal signe As Boolean = False) As String
    If EstNombre(v) Then Pc = FormatPct(CDbl(v), nd, signe) Else Pc = Tiret()
End Function

Private Function Eu(ByVal v As Variant, ByVal nd As Long) As String
    If EstNombre(v) Then Eu = FormatEuro(CDbl(v), nd) Else Eu = Tiret()
End Function

Private Function KE(ByVal v As Variant) As String
    If EstNombre(v) Then KE = FormatKEuro(CDbl(v)) Else KE = Tiret()
End Function

Public Function NomTableau(ByVal v As String) As String
    Select Case v
        Case "age": NomTableau = "âge"
        Case "puissance_cv": NomTableau = "puissance"
        Case Else: NomTableau = v
    End Select
End Function

' ---------------------------------------------------------------------
' Construction
' ---------------------------------------------------------------------
Public Sub ConstruirePages()
    Dim n As Long
    For n = 0 To NB_PAGES - 1
        Marquer "Page " & n
        ConstruirePage n
    Next n
End Sub

Public Sub SupprimerPages()
    Dim n As Long
    For n = 0 To NB_PAGES - 1
        SupprimerFeuille NomPage(n)
    Next n
End Sub

Public Sub ConstruirePage(ByVal n As Long)
    Dim ws As Worksheet
    SupprimerFeuille NomPage(n)
    If n = 0 Then
        Set ws = ThisWorkbook.Worksheets.Add(Before:=ThisWorkbook.Sheets(1))
    Else
        Set ws = ThisWorkbook.Worksheets.Add(After:=FeuillePage(n - 1))
    End If
    ws.Name = NomPage(n)
    ws.Tab.Color = C_VIOLET
    PreparerCanevas ws
    BarreLaterale ws, n
    Select Case n
        Case 0: ConstruireTableau ws
        Case 12: ConstruireCalculateurPage ws
        Case Else: ConstruireEtape ws, n
    End Select
    CreerBulle ws, n
    MajPage n
End Sub

Private Sub ConstruireEtape(ByVal ws As Worksheet, ByVal n As Long)
    Dim k As Long, avecPuces As Boolean
    avecPuces = (n = 5 Or n = 6 Or n = 7 Or n = 9)
    EnTete ws, n, IIf(avecPuces, LARGEUR_INTRO_PUCES, LARGEUR_INTRO)
    If avecPuces Then PucesEtape ws, n
    For k = 0 To 3
        CarteKPI ws, n, k, LibelleKPI(n, k)
    Next k
    CarteFormulation ws, n
    CarteControles ws, n
    Texte ws, PrefixePage(n) & "cf_titre", CF_L, 159, 0, 0, TitreDansClasseur(), F_BOLD, 11, C_ENCRE, AL_G, -0.2
    TexteFin ws, PrefixePage(n) & "cf_note", 940, 162, "", F_REG, 7.5, C_GRIS_1
    CadreGraphique ws, n
    BoutonsPied ws, n
End Sub

Private Sub PucesEtape(ByVal ws As Worksheet, ByVal n As Long)
    Dim v As Variant, l As Variant, i As Long, act As String
    Select Case n
        Case 5
            v = Array(Param("seuil_1"), Param("seuil_2"), Param("seuil_3"), Param("seuil_4"), Param("seuil_5"))
            ReDim l(0 To 4)
            For i = 0 To 4: l(i) = FormatNombre(v(i) / 1000, 0) & Insec() & "k" & ChrW(8364): Next i
            Puces ws, n, "seuil", v, l, CStr(Param("seuil_ecretement")), 940, 38, 24
        Case 6
            v = Array("age", "zone", "puissance_cv", "usage", "anc_permis", "anc_vehicule", "couleur")
            l = Array("Âge", "Zone", "Puissance", "Usage", "Permis", "Véhicule", "Couleur")
            Puces ws, n, "var", v, l, CStr(LireEtat("B6")), 940, 38, 24
        Case 7
            v = Array("age", "puissance_cv", "anc_permis", "anc_vehicule")
            l = Array("Âge", "Puissance", "Permis", "Véhicule")
            Puces ws, n, "var", v, l, CStr(LireEtat("B7")), 940, 38, 24
        Case 9
            v = Array("F", "C")
            l = Array("Fréquence", "Coût moyen")
            Puces ws, n, "modele", v, l, CStr(LireEtat("B8")), 940, 38, 24
    End Select
End Sub

' ---------------------------------------------------------------------
' Mise à jour
' ---------------------------------------------------------------------
Public Sub MajPage(ByVal n As Long)
    Dim ws As Worksheet
    If Not FeuilleExiste(NomPage(n)) Then Exit Sub
    Set ws = FeuillePage(n)
    Select Case n
        Case 0: MajTableau ws
        Case 12: MajCalculateurPage ws
        Case Else
            MajKPIEtape ws, n
            MajControlesEtape ws, n
            MajCarteFeuille ws, n
            MajGraphiqueEtape ws, n
    End Select
End Sub

Public Sub MajToutesPages()
    Dim n As Long
    For n = 0 To NB_PAGES - 1
        MajPage n
    Next n
End Sub

' KPI des étapes (section 11)
Private Sub MajKPIEtape(ByVal ws As Worksheet, ByVal n As Long)
    Dim a0 As String, a1 As String, m As String
    a0 = CStr(Param("annee_debut")): a1 = CStr(Param("annee_fin"))
    Select Case n
        Case 1
            MajKPI ws, n, 0, Nb(VN("q_lignes"), 0), SousTexteKPI(1, 0, Nb(VN("q_polices"), 0))
            MajKPI ws, n, 1, Nb(VN("q_sinistres_bruts"), 0), SousTexteKPI(1, 1)
            MajKPI ws, n, 2, Nb(VN("q_expo_totale"), 0), SousTexteKPI(1, 2)
            MajKPI ws, n, 3, a0 & DemiTiret() & a1, SousTexteKPI(1, 3, Nb(VN("q_nb_exercices"), 0))
        Case 2
            MajKPI ws, n, 0, Nb(VN("q_doublons"), 0), SousTexteKPI(2, 0)
            MajKPI ws, n, 1, Nb(VN("q_exclus"), 0), SousTexteKPI(2, 1)
            MajKPI ws, n, 2, Nb(VN("q_ages_imputes"), 0), SousTexteKPI(2, 2)
            MajKPI ws, n, 3, Nb(VN("q_crm_corriges"), 0), SousTexteKPI(2, 3, Nb(Param("crm_min"), 2), Nb(Param("crm_max"), 2))
        Case 3
            MajKPI ws, n, 0, Nb(VN("b_sin_ratt"), 0), SousTexteKPI(3, 0, Pc(VN("b_part_ratt"), 0))
            MajKPI ws, n, 1, Nb(VN("b_lignes_sin"), 0), SousTexteKPI(3, 1, Pc(VN("b_part_lignes"), 1))
            MajKPI ws, n, 2, Nb(VN("b_lignes_base"), 0), SousTexteKPI(3, 2)
            MajKPI ws, n, 3, KE(VN("b_charge_ratt")), SousTexteKPI(3, 3)
        Case 4
            MajKPI ws, n, 0, KE(VN("hist_vue_tot")), SousTexteKPI(4, 0, a0 & DemiTiret() & a1)
            MajKPI ws, n, 1, KE(VN("hist_ibnr_tot")), SousTexteKPI(4, 1, Pc(VN("hist_ibnr_tot") / VN("hist_vue_tot"), 1))
            MajKPI ws, n, 2, Pc(Param("taux_inflation"), 1), SousTexteKPI(4, 2)
            MajKPI ws, n, 3, KE(VN("charge_cible")), SousTexteKPI(4, 3)
        Case 5
            MajKPI ws, n, 0, Eu(VN("ecr_seuil"), 0), SousTexteKPI(5, 0)
            MajKPI ws, n, 1, Nb(VN("ecr_n_graves"), 0), SousTexteKPI(5, 1, Pc(VN("ecr_part_graves"), 1))
            MajKPI ws, n, 2, KE(VN("ecr_charge_ecr")), SousTexteKPI(5, 2)
            MajKPI ws, n, 3, KE(VN("ecr_excedent")), SousTexteKPI(5, 3, Pc(VN("ecr_part_exc"), 1))
        Case 6
            MajKPI ws, n, 0, Pc(VN("expl_freq"), 2), SousTexteKPI(6, 0, Nb(VN("expl_n_tot"), 0), Nb(VN("expl_e_tot"), 0))
            MajKPI ws, n, 1, Pc(VN("expl_freq_crm"), 2), SousTexteKPI(6, 1)
            MajKPI ws, n, 2, Eu(VN("expl_cout"), 0), SousTexteKPI(6, 2)
            MajKPI ws, n, 3, Eu(VN("expl_pp"), 2), SousTexteKPI(6, 3)
        Case 7
            MajKPI ws, n, 0, Nb(Param("exposition_min"), 0), SousTexteKPI(7, 0)
            MajKPI ws, n, 1, Nb(VN("cls_nb_age"), 0), SousTexteKPI(7, 1, Nb(VN("cls_nb_tr_age"), 0))
            MajKPI ws, n, 2, Nb(VN("cls_nb_cv"), 0), SousTexteKPI(7, 2, Nb(VN("cls_nb_tr_cv"), 0))
            MajKPI ws, n, 3, Nb(Param("z_fusion"), 3), SousTexteKPI(7, 3)
        Case 8
            MajKPI ws, n, 0, Nb(PlageNom("sel_var").Rows.Count, 0), SousTexteKPI(8, 0)
            MajKPI ws, n, 1, Nb(Application.CountIf(PlageNom("sel_decision"), "Retenue"), 0), SousTexteKPI(8, 1, ListeRetenues())
            MajKPI ws, n, 2, Pc(Param("seuil_p"), 0), SousTexteKPI(8, 2)
            m = Replace(Replace(CStr(VN("assoc_paire")), "|", " " & Multiplie() & " "), "puissance_cv", "puissance")
            MajKPI ws, n, 3, Nb(VN("assoc_vmax"), 2), SousTexteKPI(8, 3, Replace(m, "age", "âge"))
        Case 9
            MajKPI ws, n, 0, Pc(VN("glmf_base"), 2), SousTexteKPI(9, 0)
            MajKPI ws, n, 1, Eu(VN("glmc_base"), 0), SousTexteKPI(9, 1)
            If CStr(LireEtat("B8")) = "C" Then
                MajKPI ws, n, 2, Pc(VN("glmc_dev_expl"), 1), SousTexteKPI(9, 2, TexteDevianceModele(False))
            Else
                MajKPI ws, n, 2, Pc(VN("glmf_dev_expl"), 1), SousTexteKPI(9, 2, TexteDevianceModele(True))
            End If
            MajKPI ws, n, 3, Nb(VN("glmf_nparam"), 0), SousTexteKPI(9, 3)
        Case 10
            MajKPI ws, n, 0, Nb(VN("n_u"), 0), SousTexteKPI(10, 0, Nb(VN("q_ok"), 0))
            MajKPI ws, n, 1, Nb(VN("alpha"), 3), SousTexteKPI(10, 1, Nb(VN("ic_bas"), 2), Nb(VN("ic_haut"), 2))
            MajKPI ws, n, 2, Eu(VN("e_u"), 0), SousTexteKPI(10, 2)
            MajKPI ws, n, 3, Nb(VN("kappa"), 3), SousTexteKPI(10, 3, Nb(VN("kappa_emp"), 3))
        Case 11
            MajKPI ws, n, 0, Eu(VN("pp_moy"), 2), SousTexteKPI(11, 0)
            MajKPI ws, n, 1, Pc(VN("evol_moy"), 1, True), SousTexteKPI(11, 1)
            MajKPI ws, n, 2, Pc(VN("equilibre"), 1), SousTexteKPI(11, 2)
            MajKPI ws, n, 3, Eu(VN("ttc_moy"), 2), SousTexteKPI(11, 3, Eu(VN("ttc_moy_act"), 2))
    End Select
End Sub

Private Function ListeRetenues() As String
    Dim v As Variant, d As Variant, i As Long, s As String
    v = PlageNom("sel_var").Value2: d = PlageNom("sel_decision").Value2
    For i = 1 To UBound(v, 1)
        If CStr(d(i, 1)) = "Retenue" Then
            If Len(s) > 0 Then s = s & ", "
            s = s & NomTableau(CStr(v(i, 1)))
        End If
    Next i
    ListeRetenues = s
End Function

' Contrôles des étapes (statuts de la feuille Controles)
Private Sub MajControlesEtape(ByVal ws As Worksheet, ByVal n As Long)
    Dim k As Long, a As String, b As String, e As Variant, f As Variant
    For k = 1 To 3
        e = Ctl(n, k, 5): f = Ctl(n, k, 6)
        a = "": b = ""
        Select Case n * 10 + k
            Case 13, 31, 52, 71, 91: a = Nb(e, 0): If n = 5 Then b = Nb(f, 0)
            Case 53: a = Pc(e, 1): b = Pc(f, 0)
            Case 72: a = Nb(e, 3)
            Case 73: a = Intervalle(CStr(e))
            Case 82: a = Nb(e, 1)
            Case 92: a = Nb(e, 0): b = Nb(f, 0)
            Case 93: a = Nb(e, 2): b = Nb(f, 2)
            Case 102: a = Pc(e, 1, True): b = Pc(f, 0)
            Case 103: a = Nb(e, 2)
            Case 112: a = Pc(e, 0)
            Case 113: a = Pc(e, 1): b = Pc(f, 0)
        End Select
        MajControle ws, n, k - 1, CtlOk(n, k), TexteControle(n, k, a, b)
    Next k
End Sub

' ---------------------------------------------------------------------
' Carte « Dans le classeur » (10.3)
' ---------------------------------------------------------------------
Private Sub MajCarteFeuille(ByVal ws As Worksheet, ByVal n As Long)
    Dim f As String, meta As String, ent As Variant, cols As Variant, fm As Variant, lg As Variant
    Dim surl As Long, cel As String, ong As Variant, act As Long, err As Long, v As String, r1 As Long
    surl = -1: err = -1: act = 0
    Select Case n
        Case 1
            f = F_CONTRATS: meta = MetaFeuille(1, Nb(VN("q_lignes"), 0))
            ent = Array("id_police", "exercice", "date_debut", "date_fin", "zone", "puissance_cv", "crm", "exposition")
            cols = Array("A", "B", "C", "D", "H", "I", "M", "P"): fm = Array("t", "y", "d", "d", "t", "i", "n2", "n3")
            lg = Array(2, 3, 4, 5, 6): surl = 7: cel = "P2"
            ong = Array(F_CONTRATS, F_SINISTRES, F_TRIANGLE, F_PARAMETRES)
        Case 2
            f = F_SINISTRES: meta = MetaFeuille(2, Nb(VN("q_sinistres_bruts"), 0))
            ent = Array("id_sinistre", "id_police", "date_survenance", "garantie", "charge_vue", "controle")
            cols = Array("A", "B", "C", "E", "F", "J"): fm = Array("t", "t", "d", "t", "n2", "t")
            lg = LignesStatuts(): err = 5: cel = "J2"
            ong = Array(F_SINISTRES, F_QUALITE, F_JOURNAL)
        Case 3
            f = F_CONTRATS: meta = MetaFeuille(3, Nb(VN("b_lignes_sin"), 0))
            ent = Array("id_police", "exercice", "exposition", "age", "zone", "puissance_cv", "nb_sin", "charge_vue")
            cols = Array("A", "B", "P", "R", "H", "I", "W", "X"): fm = Array("t", "y", "n3", "i", "t", "i", "i", "n2")
            lg = PremieresLignes(PlageNom("c_nb_sin"), 5, 0): surl = 6: cel = "W" & lg(0)
            ong = Array(F_CONTRATS, F_SINISTRES)
        Case 4
            f = F_HISTORIQUE: meta = MetaFeuille(4, Nb(VN("q_nb_exercices"), 0))
            ent = Array("exercice", "exposition", "nb_sin", "charge_vue", "cdf", "charge_ult", "rho", "charge_2027")
            cols = Array("A", "B", "C", "D", "E", "F", "G", "H"): fm = Array("y", "i", "i", "i", "n4", "i", "n4", "i")
            lg = Array(2, 3, 4, 5, 6): surl = 5: cel = "F2"
            ong = Array(F_HISTORIQUE, F_TRIANGLE)
        Case 5
            f = F_SINISTRES: meta = MetaFeuille(5, Nb(VN("q_ok"), 0))
            ent = Array("id_sinistre", "garantie", "exercice", "charge_vue", "charge_reval", "grave", "charge_ecr", "excedent")
            cols = Array("A", "E", "H", "F", "L", "M", "N", "O"): fm = Array("t", "t", "y", "n2", "n2", "i", "n2", "n2")
            lg = LignesEcretement(): surl = 6: cel = "N" & lg(0)
            ong = Array(F_SINISTRES, F_PARAMETRES)
        Case 6, 7
            v = CStr(LireEtat(IIf(n = 6, "B6", "B7")))
            meta = MetaFeuille(n, NomAffiche(v))
            If n = 6 Then
                f = F_EXPLORATOIRE: r1 = PremiereLigneVariable(PlageNom("expl_var"), v)
                ent = Array("tranche", "exposition", "e_crm", "nb_sin", "frequence", "freq_crm", "cout_moyen")
                cols = Array("B", "E", "F", "G", "I", "J", "M"): fm = Array("t", "i", "i", "i", "p2", "p2", "e0")
                surl = 5: cel = "J" & r1: ong = Array(F_EXPLORATOIRE, F_CONTRATS)
            Else
                f = F_CLASSES: r1 = PremiereLigneVariable(PlageNom("cls_var"), v)
                ent = Array("classe", "tranches", "exposition", "nb_sin", "freq_crm", "relativite", "z_suivante")
                cols = Array("B", "C", "F", "H", "I", "J", "K"): fm = Array("t", "t", "i", "i", "p2", "n2", "n2")
                surl = 5: cel = "J" & r1: ong = Array(F_CLASSES, F_BORNES)
            End If
            lg = LignesVariable(Feuille(f), v, r1, 5)
        Case 8
            f = F_SELECTION: meta = MetaFeuille(8, Nb(PlageNom("sel_var").Rows.Count, 0))
            ent = Array("variable", "chi2", "ddl", "p_value", "v_cramer", "delta_d", "decision")
            cols = Array("A", "B", "C", "D", "E", "G", "J"): fm = Array("var", "n1", "i", "pv", "n3", "n1", "dec")
            lg = Array(2, 3, 4, 5, 6): surl = 3: cel = "D2": ong = Array(F_SELECTION, F_ASSOCIATIONS)
        Case 9
            If CStr(LireEtat("B8")) = "C" Then f = F_GLMC: act = 1 Else f = F_GLMF
            meta = MetaFeuille(9, Nb(VN(IIf(act = 1, "glmc_ncel", "glmf_ncel")), 0))
            ent = Array("parametre", "coefficient", "relativite", "erreur_std", "z", "p_value")
            cols = Array("A", "C", "D", "E", "F", "G"): fm = Array("t", "n4", "n3", "n4", "n2", "pv")
            lg = Array(2, 3, 4, 5, 6): surl = 2: cel = "D3": ong = Array(F_GLMF, F_GLMC, F_CELLULES)
        Case 10
            f = F_GRAVES: meta = MetaFeuille(10, Nb(VN("n_u"), 0))
            ent = Array("id_sinistre", "garantie", "exercice", "charge_reval", "ln_x_u", "excedent")
            cols = Array("A", "B", "C", "D", "E", "F"): fm = Array("t", "t", "y", "n2", "n3", "n2")
            lg = PremieresLignes(PlageNom("gr_id"), 5, -1): surl = 4: cel = "E2": ong = Array(F_GRAVES, "Pareto")
        Case 11
            f = F_TARIF: meta = MetaFeuille(11, Nb(VN("theta"), 4), Nb(VN("kappa"), 3))
            ent = Array("variable", "classe", "rel_frequence", "rel_cout", "rel_prime_pure", "evolution")
            cols = Array("A", "B", "C", "D", "E", "F"): fm = Array("var", "t", "n3", "n3", "n3", "p1s")
            lg = Array(2, 3, 4, 5, 6): surl = 4: cel = "E2": ong = Array(F_TARIF, F_IMPACT, F_CALCULATEUR)
    End Select
    DessinerCarteFeuille ws, n, f, meta, ent, cols, fm, lg, surl, cel, ong, act, err
End Sub

' Première ligne de chaque statut de contrôle, dans l'ordre de la feuille
Private Function LignesStatuts() As Variant
    Dim v As Variant, r As Long, vus As Object, res() As Long, n As Long
    v = PlageNom("s_controle").Value2
    Set vus = Dico()
    ReDim res(0 To 4)
    For r = 1 To UBound(v, 1)
        If Not vus.Exists(CStr(v(r, 1))) And n <= 4 Then
            vus.Add CStr(v(r, 1)), r
            res(n) = r + 1: n = n + 1
        End If
    Next r
    If n < 5 Then ReDim Preserve res(0 To Application.Max(n - 1, 0))
    LignesStatuts = res
End Function

' Premières lignes (n) où la plage est > seuil (seuil < 0 : toutes les lignes non vides)
Private Function PremieresLignes(ByVal plage As Range, ByVal n As Long, ByVal seuil As Double) As Variant
    Dim v As Variant, r As Long, res() As Long, m As Long
    v = plage.Value2
    ReDim res(0 To n - 1)
    For r = 1 To UBound(v, 1)
        If seuil >= 0 Then
            If EstNombre(v(r, 1)) Then If v(r, 1) > seuil Then res(m) = plage.Row + r - 1: m = m + 1
        ElseIf Len(CStr(v(r, 1))) > 0 Then
            res(m) = plage.Row + r - 1: m = m + 1
        End If
        If m = n Then Exit For
    Next r
    If m = 0 Then res(0) = plage.Row: m = 1
    If m < n Then ReDim Preserve res(0 To m - 1)
    PremieresLignes = res
End Function

' Étape 05 : les 4 premiers sinistres retenus, puis le premier grave s'il n'y figure pas
Private Function LignesEcretement() As Variant
    Dim ret As Variant, gr As Variant, r As Long, res(0 To 4) As Long, m As Long, grave As Boolean, pg As Long
    ret = PlageNom("s_retenu").Value2: gr = PlageNom("s_grave").Value2
    For r = 1 To UBound(ret, 1)
        If ret(r, 1) = 1 Then
            If m < 4 Then
                res(m) = r + 1: m = m + 1
                If gr(r, 1) = 1 Then grave = True
            ElseIf m = 4 And grave Then
                res(4) = r + 1: m = 5: Exit For
            ElseIf gr(r, 1) = 1 Then
                res(4) = r + 1: m = 5: Exit For
            End If
        End If
    Next r
    LignesEcretement = res
End Function

Private Function PremiereLigneVariable(ByVal plage As Range, ByVal v As String) As Long
    Dim x As Variant, r As Long
    x = plage.Value2
    For r = 1 To UBound(x, 1)
        If CStr(x(r, 1)) = v Then PremiereLigneVariable = plage.Row + r - 1: Exit Function
    Next r
    PremiereLigneVariable = plage.Row
End Function

Private Function LignesVariable(ByVal ws As Worksheet, ByVal v As String, ByVal r1 As Long, ByVal n As Long) As Variant
    Dim res() As Long, m As Long
    ReDim res(0 To n - 1)
    Do While CStr(ws.Cells(r1 + m, 1).Value2) = v And m < n
        res(m) = r1 + m: m = m + 1
    Loop
    If m = 0 Then m = 1: res(0) = r1
    ReDim Preserve res(0 To m - 1)
    LignesVariable = res
End Function

Private Function FormatCellule(ByVal v As Variant, ByVal fm As String) As String
    If IsError(v) Then FormatCellule = Tiret(): Exit Function
    If Len(CStr(v)) = 0 Then FormatCellule = Tiret(): Exit Function
    Select Case fm
        Case "d": FormatCellule = TexteDate(v)
        Case "y": FormatCellule = CStr(v)
        Case "i": FormatCellule = Nb(v, 0)
        Case "n1": FormatCellule = Nb(v, 1)
        Case "n2": FormatCellule = Nb(v, 2)
        Case "n3": FormatCellule = Nb(v, 3)
        Case "n4": FormatCellule = Nb(v, 4)
        Case "p2": FormatCellule = Pc(v, 2)
        Case "p1s": FormatCellule = Pc(v, 1, True)
        Case "e0": FormatCellule = Eu(v, 0)
        Case "pv"
            If EstNombre(v) Then
                If v < PV_MIN Then FormatCellule = "<" & Insec() & FormatNombre(PV_MIN, 3) Else FormatCellule = Nb(v, 3)
            Else
                FormatCellule = Tiret()
            End If
        Case "var": FormatCellule = NomTableau(CStr(v))
        Case "dec": FormatCellule = LibelleDecision(CStr(v))
        Case Else: FormatCellule = Intervalle(CStr(v))
    End Select
End Function

Private Sub DessinerCarteFeuille(ByVal ws As Worksheet, ByVal n As Long, ByVal nomF As String, ByVal meta As String, _
                                 ent As Variant, cols As Variant, fm As Variant, lg As Variant, ByVal surl As Long, _
                                 ByVal cel As String, ong As Variant, ByVal act As Long, ByVal err As Long)
    Dim p As String, src As Worksheet, nc As Long, nr As Long, c As Long, r As Long, txt() As String
    Dim W() As Double, tot As Double, x As Double, s As Shape, frm As String, mx As Long
    p = PrefixePage(n) & "cf_"
    SupprimerFormes ws, p & "d_"
    Set src = Feuille(nomF)
    nc = UBound(ent) + 1: nr = UBound(lg) + 1
    ReDim txt(0 To nr, 0 To nc - 1): ReDim W(0 To nc - 1)
    For c = 0 To nc - 1
        txt(0, c) = ent(c): mx = Len(txt(0, c))
        For r = 1 To nr
            txt(r, c) = FormatCellule(src.Range(cols(c) & lg(r - 1)).Value2, fm(c))
            If Len(txt(r, c)) > mx Then mx = Len(txt(r, c))
        Next r
        W(c) = mx * 4.4 + 12: tot = tot + W(c)
    Next c
    For c = 0 To nc - 1: W(c) = W(c) * CF_LARGEUR / tot: Next c
    ChangerTexte ws, PrefixePage(n) & "cf_note", TexteCelluleSelectionnee(cel)
    Carte ws, p & "d_carte", CF_L, CF_T, CF_W, 176, 11, C_BLANC, C_BORD_2
    Forme ws, p & "d_barre", msoShapeRound2SameRectangle, CF_L, CF_T, CF_W, 22, C_FEUILLE_TITRE, SANS, 0, 11
    Filet ws, p & "d_barre_filet", CF_L, 200, CF_L + CF_W, 200, C_FEUILLE_LIGNE
    Set s = Forme(ws, p & "d_icone", msoShapeRoundedRectangle, 486, 182, 14, 14, C_EXCEL, SANS, 0, 4)
    TexteDansForme s, "X", F_XBOLD, 7.5, C_BLANC
    Texte ws, p & "d_nom", 506, 183.5, 0, 0, nomF, F_BOLD, 8.5, C_ENCRE
    TexteFin ws, p & "d_meta", 862, 184, meta, F_REG, 7.5, C_GRIS_1
    Set s = Pilule(ws, p & "d_ouvrir", 870, 181, 62, 16, C_BLANC, C_BORD_2, 8)
    TexteDansForme s, TexteOuvrirOnglet(), F_BOLD, 6.8, C_VIOLET
    s.AlternativeText = nomF & "!" & cel
    Action s, "ClicOuvrirOnglet"
    frm = src.Range(cel).FormulaLocal
    If Len(frm) > CF_FORMULE_MAX Then frm = Left$(frm, CF_FORMULE_MAX) & ChrW(8230)
    Texte ws, p & "d_ref", 484, 204, 34, 10, cel, F_MONO, 7, C_GRIS_1
    Filet ws, p & "d_sep1", 520, 200, 520, 218, C_FEUILLE_LIGNE
    Filet ws, p & "d_sep2", 544, 200, 544, 218, C_FEUILLE_LIGNE
    Set s = Texte(ws, p & "d_fx", 526, 203, 16, 11, "fx", F_REG, 7.5, C_VIOLET)
    s.TextFrame2.TextRange.Font.Italic = msoTrue
    Texte ws, p & "d_formule", 550, 204, 386, 10, frm, F_MONO, 7, C_ENCRE
    Forme ws, p & "d_lettres", msoShapeRectangle, CF_L, 218, CF_W, 12, C_FEUILLE_ENTETE
    Forme ws, p & "d_numeros", msoShapeRectangle, CF_L, 230, 20, 102, C_FEUILLE_ENTETE
    DessinerCellules ws, p, txt, W, nr, nc, lg, surl, err
    DessinerOnglets ws, p, ong, act
End Sub

Private Sub DessinerCellules(ByVal ws As Worksheet, ByVal p As String, txt() As String, W() As Double, _
                             ByVal nr As Long, ByVal nc As Long, lg As Variant, ByVal surl As Long, ByVal err As Long)
    Dim x As Double, c As Long, r As Long, T As Double, role As Long, coul As Long, enErreur As Boolean
    x = CF_COL0
    For c = 0 To nc - 1
        Texte ws, p & "d_l" & c, x, 220, W(c), 9, Chr$(65 + c), F_SEMI, 6.5, C_GRIS_2, AL_C
        If c = surl Then Forme ws, p & "d_surl", msoShapeRectangle, x, 247, W(c), CF_LIGNE_H * nr, C_VIOLET_PALE
        For r = 0 To nr
            T = 230 + CF_LIGNE_H * r
            role = IIf(r = 0, F_BOLD, F_REG): coul = C_ENCRE
            enErreur = (r > 0 And c = err And txt(r, c) <> "OK")
            If r > 0 And c = surl Then role = F_SEMI: coul = C_VIOLET_FONCE
            If enErreur Then
                Forme ws, p & "d_err" & r, msoShapeRectangle, x, T, W(c), CF_LIGNE_H, C_ROSE_CLAIR
                role = F_SEMI: coul = C_ROSE_FONCE
            End If
            Texte ws, p & "d_c" & r & "_" & c, x + 5, T + 4.2, W(c) - 6, 10, txt(r, c), role, 7.5, coul
        Next r
        x = x + W(c)
        If c < nc - 1 Then Filet ws, p & "d_v" & c, x, 218, x, 332, C_FEUILLE_LIGNE, 0.5
    Next c
    Filet ws, p & "d_v0g", CF_COL0, 218, CF_COL0, 332, C_FEUILLE_LIGNE, 0.5
    For r = 0 To nr
        T = 230 + CF_LIGNE_H * (r + 1)
        Filet ws, p & "d_h" & r, CF_L, T, CF_L + CF_W, T, C_FEUILLE_LIGNE, 0.5
        If r > 0 Then Texte ws, p & "d_n" & r, CF_L, 230 + CF_LIGNE_H * r + 4.5, 20, 9, CStr(lg(r - 1)), F_REG, 6.5, C_GRIS_2, AL_C
    Next r
    Texte ws, p & "d_n0", CF_L, 234.5, 20, 9, "1", F_REG, 6.5, C_GRIS_2, AL_C
End Sub

Private Sub DessinerOnglets(ByVal ws As Worksheet, ByVal p As String, ong As Variant, ByVal act As Long)
    Dim i As Long, x As Double, W As Double, s As Shape
    x = 486
    For i = 0 To UBound(ong)
        W = MesurerTexte(ws, CStr(ong(i)), F_BOLD, 7) + 16
        Set s = Pilule(ws, p & "d_onglet" & i, x, 336, W, 14, IIf(i = act, C_EXCEL_CLAIR, C_BLANC), SANS, 4)
        If i <> act Then s.Fill.Visible = msoFalse
        TexteDansForme s, CStr(ong(i)), IIf(i = act, F_BOLD, F_MED), 7, IIf(i = act, C_EXCEL, C_GRIS_1)
        x = x + W + 4
    Next i
End Sub

' ---------------------------------------------------------------------
' Graphiques en barres des étapes (10.4, section 11)
' ---------------------------------------------------------------------
Private Sub MajGraphiqueEtape(ByVal ws As Worksheet, ByVal n As Long)
    Select Case n
        Case 1: GraphiqueAnnuel ws, n, PlageNom("hist_expo").Value2, Nothing, 0
        Case 2: GraphiqueCompletude ws
        Case 3: GraphiquePoisson ws
        Case 4: GraphiqueAnnuel ws, n, PlageNom("hist_vue").Value2, PlageNom("hist_ult"), 1
        Case 5: GraphiqueSeuils ws
        Case 6: GraphiqueExploratoire ws
        Case 7: GraphiqueClasses ws
        Case 8: GraphiqueCramer ws
        Case 9: GraphiqueQuintiles ws
        Case 10: GraphiqueSurvie ws
        Case 11: GraphiqueDislocation ws
    End Select
End Sub

Private Function MaxTableau(v As Variant) As Double
    Dim x As Variant, m As Double
    For Each x In v
        If EstNombre(x) Then If x > m Then m = x
    Next x
    MaxTableau = m
End Function

Private Sub GraphiqueAnnuel(ByVal ws As Worksheet, ByVal n As Long, v1 As Variant, ByVal p2 As Range, ByVal mode As Long)
    Dim a As Variant, i As Long, k As Long, libs() As String, x1() As Variant, x2() As Variant, vals() As String
    Dim av() As Boolean, vmax As Double, v2 As Variant
    a = PlageNom("hist_exercice").Value2
    k = UBound(a, 1)
    ReDim libs(0 To k - 1): ReDim x1(0 To k - 1): ReDim x2(0 To k - 1): ReDim vals(0 To k - 1): ReDim av(0 To k - 1)
    If Not p2 Is Nothing Then v2 = p2.Value2
    For i = 1 To k
        libs(i - 1) = CStr(a(i, 1)): x1(i - 1) = v1(i, 1)
        av(i - 1) = (a(i, 1) = Param("annee_fin"))
        If mode = 0 Then
            vals(i - 1) = Nb(v1(i, 1), 0)
        Else
            x2(i - 1) = v2(i, 1)
            vals(i - 1) = KE(v1(i, 1)) & " / " & Nb(v2(i, 1) / 1000, 0)
        End If
    Next i
    vmax = MaxTableau(v1)
    If mode = 0 Then
        BarresGraphique ws, n, TitreGraphique(n), NoteGraphique(n), Empty, libs, x1, Empty, vals, av, 0, FACTEUR_VMAX * vmax
    Else
        If MaxTableau(v2) > vmax Then vmax = MaxTableau(v2)
        BarresGraphique ws, n, TitreGraphique(n), "", LegendeAvec(4), libs, x1, x2, vals, av, 0, FACTEUR_VMAX * vmax
    End If
End Sub

Private Function LegendeAvec(ByVal n As Long, Optional ByVal frequence As Boolean = True) As Variant
    Dim l As Variant
    l = LegendeGraphique(n, frequence)
    LegendeAvec = Array(l(0), C_LAVANDE, l(1), C_VIOLET)
End Function

Private Sub GraphiqueCompletude(ByVal ws As Worksheet)
    Dim ws2 As Worksheet, i As Long, libs(0 To 5) As String, x1(0 To 5) As Variant, vals(0 To 5) As String, av(0 To 5) As Boolean
    Set ws2 = Feuille(F_QUALITE)
    For i = 0 To 5
        libs(i) = CStr(ws2.Cells(i + 2, 4).Value2): x1(i) = ws2.Cells(i + 2, 6).Value2
        vals(i) = Pc(x1(i), 2): av(i) = (x1(i) < 1)
    Next i
    BarresGraphique ws, 2, TitreGraphique(2), NoteGraphique(2), Empty, libs, x1, Empty, vals, av, 0.99, 1
End Sub

Private Sub GraphiquePoisson(ByVal ws As Worksheet)
    Dim o As Variant, a As Variant, i As Long, libs(0 To 2) As String, x1(0 To 2) As Variant, x2(0 To 2) As Variant
    Dim vals(0 To 2) As String, av(0 To 2) As Boolean, vmax As Double
    o = PlageNom("hist_obs").Value2: a = PlageNom("hist_att").Value2
    For i = 0 To 2
        libs(i) = LibelleNbSinistres(i + 1): x1(i) = o(i + 1, 1): x2(i) = a(i + 1, 1)
        vals(i) = Nb(o(i + 1, 1), 0) & " / " & Nb(a(i + 1, 1), 1)
    Next i
    vmax = Application.Max(MaxTableau(o), MaxTableau(a))
    BarresGraphique ws, 3, TitreGraphique(3), "", LegendeAvec(3), libs, x1, x2, vals, av, 0, FACTEUR_VMAX * vmax
End Sub

Private Sub GraphiqueSeuils(ByVal ws As Worksheet)
    Dim s As Variant, pt As Variant, i As Long, libs(0 To 4) As String, x1(0 To 4) As Variant, vals(0 To 4) As String
    Dim av(0 To 4) As Boolean
    s = PlageNom("seuils_val").Value2: pt = PlageNom("seuils_part").Value2
    For i = 0 To 4
        libs(i) = FormatNombre(s(i + 1, 1) / 1000, 0) & Insec() & "k" & ChrW(8364)
        x1(i) = pt(i + 1, 1): vals(i) = Pc(pt(i + 1, 1), 1)
        av(i) = (s(i + 1, 1) = Param("seuil_ecretement"))
    Next i
    BarresGraphique ws, 5, TitreGraphique(5), NoteGraphique(5), Empty, libs, x1, Empty, vals, av, 0, 0.5
End Sub

Private Sub GraphiqueExploratoire(ByVal ws As Worksheet)
    Dim v As String, r1 As Long, wsx As Worksheet, k As Long, i As Long, libs() As String, x1() As Variant, x2() As Variant
    Dim vals() As String, av() As Boolean, vmax As Double
    v = CStr(LireEtat("B6"))
    Set wsx = Feuille(F_EXPLORATOIRE)
    r1 = PremiereLigneVariable(PlageNom("expl_var"), v)
    Do While CStr(wsx.Cells(r1 + k, 1).Value2) = v: k = k + 1: Loop
    ReDim libs(0 To k - 1): ReDim x1(0 To k - 1): ReDim x2(0 To k - 1): ReDim vals(0 To k - 1): ReDim av(0 To k - 1)
    For i = 0 To k - 1
        libs(i) = LibelleAvecUnite(v, CStr(wsx.Cells(r1 + i, 2).Value2))
        x1(i) = wsx.Cells(r1 + i, 9).Value2: x2(i) = wsx.Cells(r1 + i, 10).Value2
        vals(i) = Nb(x1(i) * 100, 1) & " / " & Nb(x2(i) * 100, 1)
        If EstNombre(x1(i)) Then If x1(i) > vmax Then vmax = x1(i)
        If EstNombre(x2(i)) Then If x2(i) > vmax Then vmax = x2(i)
    Next i
    BarresGraphique ws, 6, TitreGraphique(6, DesignationVariable(v, False)), "", LegendeAvec(6), libs, x1, x2, vals, av, _
        0, FACTEUR_VMAX * vmax
End Sub

Private Sub GraphiqueClasses(ByVal ws As Worksheet)
    Dim v As String, r1 As Long, wsx As Worksheet, k As Long, i As Long, libs() As String, x1() As Variant
    Dim vals() As String, av() As Boolean, vmax As Double, refLib As String
    v = CStr(LireEtat("B7"))
    Set wsx = Feuille(F_CLASSES)
    r1 = PremiereLigneVariable(PlageNom("cls_var"), v)
    Do While CStr(wsx.Cells(r1 + k, 1).Value2) = v: k = k + 1: Loop
    ReDim libs(0 To k - 1): ReDim x1(0 To k - 1): ReDim vals(0 To k - 1): ReDim av(0 To k - 1)
    For i = 0 To k - 1
        libs(i) = LibelleAvecUnite(v, CStr(wsx.Cells(r1 + i, 2).Value2))
        x1(i) = wsx.Cells(r1 + i, 10).Value2
        vals(i) = Multiplie() & Nb(x1(i), 2)
        av(i) = EstNombre(x1(i))
        If av(i) Then av(i) = (x1(i) >= SEUIL_REL_AVANT): If x1(i) > vmax Then vmax = x1(i)
        If wsx.Cells(r1 + i, 12).Value2 = True Then refLib = libs(i)
    Next i
    BarresGraphique ws, 7, TitreGraphique(7, DesignationVariable(v, True)), NoteGraphique(7, refLib), Empty, libs, x1, _
        Empty, vals, av, 0, FACTEUR_VMAX * vmax
End Sub

Private Sub GraphiqueCramer(ByVal ws As Worksheet)
    Dim v As Variant, d As Variant, nm As Variant, n As Long, i As Long, cles() As Double, idx() As Long
    Dim libs() As String, x1() As Variant, vals() As String, av() As Boolean
    nm = PlageNom("sel_var").Value2: v = PlageNom("sel_v").Value2: d = PlageNom("sel_decision").Value2
    n = UBound(nm, 1)
    ReDim cles(1 To n): ReDim idx(1 To n)
    ReDim libs(0 To n - 1): ReDim x1(0 To n - 1): ReDim vals(0 To n - 1): ReDim av(0 To n - 1)
    For i = 1 To n: cles(i) = -v(i, 1): idx(i) = i: Next i
    TriFusion cles, idx, n
    For i = 1 To n
        libs(i - 1) = NomTableau(CStr(nm(idx(i), 1))): x1(i - 1) = v(idx(i), 1)
        vals(i - 1) = Nb(v(idx(i), 1), 3): av(i - 1) = (CStr(d(idx(i), 1)) = "Retenue")
    Next i
    BarresGraphique ws, 8, TitreGraphique(8), NoteGraphique(8), Empty, libs, x1, Empty, vals, av, 0, _
        FACTEUR_VMAX * MaxTableau(v)
End Sub

Private Sub GraphiqueQuintiles(ByVal ws As Worksheet)
    Dim pre As String, o As Variant, p As Variant, i As Long, libs(0 To 4) As String, x1(0 To 4) As Variant
    Dim x2(0 To 4) As Variant, vals(0 To 4) As String, av(0 To 4) As Boolean, freq As Boolean, vmax As Double
    freq = (CStr(LireEtat("B8")) <> "C")
    pre = IIf(freq, "glmf", "glmc")
    o = PlageNom(pre & "_q_obs").Value2: p = PlageNom(pre & "_q_pred").Value2
    For i = 0 To 4
        libs(i) = LibelleQuintile(i + 1): x1(i) = o(i + 1, 1): x2(i) = p(i + 1, 1)
        If freq Then
            vals(i) = Nb(o(i + 1, 1) * 100, 2) & " / " & Nb(p(i + 1, 1) * 100, 2)
        Else
            vals(i) = Nb(o(i + 1, 1), 0) & " / " & Nb(p(i + 1, 1), 0)
        End If
    Next i
    vmax = Application.Max(MaxTableau(o), MaxTableau(p))
    BarresGraphique ws, 9, TitreGraphique(9, IIf(freq, "Fréquence", "Coût moyen")), "", LegendeAvec(9, freq), libs, x1, x2, _
        vals, av, 0, FACTEUR_VMAX * vmax
End Sub

Private Sub GraphiqueSurvie(ByVal ws As Worksheet)
    Dim o As Variant, p As Variant, x As Variant, i As Long, libs(0 To 4) As String, x1(0 To 4) As Variant
    Dim x2(0 To 4) As Variant, vals(0 To 4) As String, av(0 To 4) As Boolean, vmax As Double
    o = PlageNom("surv_obs").Value2: p = PlageNom("surv_par").Value2
    x = Feuille(F_GRAVES).Range("N14:N18").Value2
    For i = 0 To 4
        libs(i) = FormatKEuro(CDbl(x(i + 1, 1))): x1(i) = o(i + 1, 1): x2(i) = p(i + 1, 1)
        vals(i) = Nb(o(i + 1, 1) * 100, 1) & " / " & Pc(p(i + 1, 1), 1)
    Next i
    vmax = Application.Max(MaxTableau(o), MaxTableau(p))
    BarresGraphique ws, 10, TitreGraphique(10), "", LegendeAvec(10), libs, x1, x2, vals, av, 0, FACTEUR_VMAX * vmax
End Sub

Private Sub GraphiqueDislocation(ByVal ws As Worksheet)
    Dim t As Variant, p As Variant, i As Long, libs(0 To 5) As String, x1(0 To 5) As Variant, vals(0 To 5) As String
    Dim av(0 To 5) As Boolean
    t = PlageNom("disl_tranche").Value2: p = PlageNom("disl_part").Value2
    For i = 0 To 5
        libs(i) = Replace(Replace(CStr(t(i + 1, 1)), "-", Moins()), " %", Insec() & "%")
        x1(i) = p(i + 1, 1): vals(i) = Pc(p(i + 1, 1), 1): av(i) = (i = 5)
    Next i
    BarresGraphique ws, 11, TitreGraphique(11), NoteGraphique(11), Empty, libs, x1, Empty, vals, av, 0, _
        FACTEUR_VMAX * MaxTableau(p)
End Sub

' ---------------------------------------------------------------------
' Tableau de bord (10.5, 11.1)
' ---------------------------------------------------------------------
Private Sub ConstruireTableau(ByVal ws As Worksheet)
    Dim p As String, a0 As Long, a1 As Long, v() As Variant, la() As Variant, y As Long, k As Long, s As Shape
    Dim L As Double, dims As Variant, libs As Variant
    p = PrefixePage(0)
    EnTete ws, 0, 480
    a0 = CLng(Param("annee_debut")): a1 = CLng(Param("annee_fin"))
    ReDim v(0 To a1 - a0): ReDim la(0 To a1 - a0)
    For y = a0 To a1: v(y - a0) = y: la(y - a0) = CStr(y): Next y
    Puces ws, 0, "annee", v, la, CStr(LireEtat("B4")), 940, 36, 26, 44, 8.5
    For k = 0 To 3
        L = 196 + 188 * k
        Carte ws, p & "kpi" & k & "_carte", L, 92, 180, 72, 12
        Set s = Texte(ws, p & "kpi" & k & "_lib", L + 14, 104, 0, 0, LibelleKPI(0, k), F_SEMI, 8.5, C_GRIS_1)
        IconeInfo ws, p & "info_kpi" & k, s.Left + s.Width + 4, 105
        Pilule ws, p & "kpi" & k & "_badge", L + 166 - 40, 102, 40, 13, C_PISTE, SANS, 6.5
        Texte ws, p & "kpi" & k & "_val", L + 14, 119, 160, 26, "", F_XBOLD, 19, C_ENCRE, AL_G, -0.6
        Texte ws, p & "kpi" & k & "_sub", L + 14, 147, 160, 12, "", F_REG, 7.5, C_GRIS_2
    Next k
    Carte ws, p & "gr_carte", 196, 174, 436, 268, 16
    Texte ws, p & "gr_titre", 212, 187, 0, 0, TitreGraphique(0), F_BOLD, 11, C_ENCRE, AL_G, -0.2
    LegendeTableau ws, p
    Texte ws, p & "gr_note", 212, 424, 0, 0, NoteGraphique(0), F_REG, 7, C_GRIS_2
    GraphiqueTableau ws
    Carte ws, p & "seg_carte", 642, 174, 298, 268, 16
    Set s = Texte(ws, p & "seg_titre", 658, 187, 0, 0, TitreSegments(), F_BOLD, 11, C_ENCRE, AL_G, -0.2)
    IconeInfo ws, p & "info_seg", s.Left + s.Width + 6, 189
    Texte ws, p & "seg_sous", 658, 203, 260, 11, "", F_REG, 7.5, C_GRIS_2
    dims = Array("age", "zone", "puissance_cv", "usage")
    ReDim libs(0 To 3)
    For k = 0 To 3: libs(k) = OngletSegment(CStr(dims(k))): Next k
    Onglets ws, 0, "seg", dims, libs, CStr(LireEtat("B5")), 658, 220, 266, 22, 65, 18
    For k = 0 To 3
        Set s = Texte(ws, p & "seg_ent" & k, 658, 410, 120, 10, "", F_SEMI, 6.5, C_GRIS_2, AL_G, 0.5)
    Next k
    Set s = Forme(ws, p & "bandeau", msoShapeRoundedRectangle, 196, 452, 744, 62, C_VIOLET, SANS, 0, 16)
    Action s, "ClicBandeau"
    Set s = Texte(ws, p & "bandeau_eyebrow", 216, 464, 0, 0, EyebrowBandeau(), F_BOLD, 7.5, C_BLANC, AL_G, 1.1)
    s.TextFrame2.TextRange.Font.Fill.Transparency = 0.15
    Action s, "ClicBandeau"
    Set s = Texte(ws, p & "bandeau_msg", 216, 478, 660, 30, "", F_BOLD, 11.5, C_BLANC, AL_G, 0, True)
    Action s, "ClicBandeau"
    Set s = Cercle(ws, p & "bandeau_fleche", 898, 469, 28, C_BLANC)
    TexteDansForme s, Fleche(), F_BOLD, 12, C_VIOLET
    Action s, "ClicBandeau"
End Sub

Private Sub LegendeTableau(ByVal ws As Worksheet, ByVal p As String)
    Dim x As Double, s As Shape, i As Long, lg As Variant, coul As Variant
    lg = LegendeGraphique(0): coul = Array(C_LAVANDE, C_VIOLET, C_ROSE)
    x = 212
    For i = 0 To 2
        If i < 2 Then
            Forme ws, p & "gr_leg_c" & i, msoShapeRoundedRectangle, x, 210, 7, 7, CLng(coul(i)), SANS, 0, 2
            x = x + 11
        Else
            Forme ws, p & "gr_leg_c" & i, msoShapeRoundedRectangle, x, 212.5, 11, 2, CLng(coul(i)), SANS, 0, 1
            x = x + 15
        End If
        Set s = Texte(ws, p & "gr_leg_t" & i, x, 207.5, 0, 0, CStr(lg(i)), F_REG, 7.5, C_ENCRE_2)
        x = x + s.Width + 10
    Next i
End Sub

' Onglets segmentés (fond gris, onglet actif blanc) : tableau de bord et calculateur
Public Sub Onglets(ByVal ws As Worksheet, ByVal page As Long, ByVal groupe As String, valeurs As Variant, libelles As Variant, _
                   ByVal actif As String, ByVal L As Double, ByVal T As Double, ByVal W As Double, ByVal H As Double, _
                   ByVal wo As Double, ByVal ho As Double, Optional ByVal rayonFond As Double = -1, _
                   Optional ByVal rayonOnglet As Double = -1)
    Dim p As String, i As Long, s As Shape
    p = PrefixePage(page)
    If rayonFond < 0 Then rayonFond = H / 2
    If rayonOnglet < 0 Then rayonOnglet = ho / 2
    Forme ws, p & "ong_" & groupe & "_fond", msoShapeRoundedRectangle, L, T, W, H, C_FOND, SANS, 0, rayonFond
    For i = LBound(valeurs) To UBound(valeurs)
        Set s = Forme(ws, p & "puce_" & groupe & "_" & CStr(valeurs(i)), msoShapeRoundedRectangle, _
            L + 3 + wo * (i - LBound(valeurs)), T + (H - ho) / 2, wo, ho, C_BLANC, SANS, 0, rayonOnglet)
        TexteDansForme s, CStr(libelles(i)), F_SEMI, 8.5, C_ENCRE_2
        Action s, "ClicPuce"
    Next i
    ActiverOnglet ws, page, groupe, actif
End Sub

Public Sub ActiverOnglet(ByVal ws As Worksheet, ByVal page As Long, ByVal groupe As String, ByVal actif As String)
    Dim s As Shape, pre As String, v As String, est As Boolean
    pre = PrefixePage(page) & "puce_" & groupe & "_"
    For Each s In ws.Shapes
        If Left$(s.Name, Len(pre)) = pre Then
            v = Mid$(s.Name, Len(pre) + 1)
            If InStr(v, "~") = 0 Then
                est = (v = actif)
                s.Fill.Visible = IIf(est, msoTrue, msoFalse)
                If Len(s.TextFrame2.TextRange.Text) > 0 Then
                    AppliquerPolice s.TextFrame2.TextRange.Font, IIf(est, F_BOLD, F_SEMI)
                    s.TextFrame2.TextRange.Font.Fill.ForeColor.RGB = IIf(est, C_VIOLET_FONCE, C_ENCRE_2)
                End If
            End If
        End If
    Next s
End Sub

' Graphique Excel du tableau de bord : colonnes primes / charge ultime, ratio combiné en courbe
Private Sub GraphiqueTableau(ByVal ws As Worksheet)
    Dim co As ChartObject, ch As Chart, wh As Worksheet, n As Long, s As Series, d As String
    Set wh = Feuille(F_HISTORIQUE)
    n = PlageNom("hist_exercice").Rows.Count
    d = CStr(n + 1)
    wh.Range("W1:AA1").Value2 = Array("exercice_lib", "primes_k", "ultime_k", "cor", "reference")
    wh.Range("W2:W" & d).Formula = "=TEXT(A2,""0"")"
    wh.Range("X2:X" & d).Formula = "=I2/1000"
    wh.Range("Y2:Y" & d).Formula = "=F2/1000"
    wh.Range("Z2:Z" & d).Formula = "=M2"
    wh.Range("AA2:AA" & d).Value2 = 1
    Set co = ws.ChartObjects.Add(206, 224, 416, 196)
    co.Name = PrefixePage(0) & "graphique"
    Set ch = co.Chart
    Do While ch.SeriesCollection.Count > 0: ch.SeriesCollection(1).Delete: Loop
    ch.ChartType = xlColumnClustered
    AjouterSerie ch, "Primes acquises", wh.Range("X2:X" & d), wh.Range("W2:W" & d), xlColumnClustered, xlPrimary
    AjouterSerie ch, "Charge ultime", wh.Range("Y2:Y" & d), wh.Range("W2:W" & d), xlColumnClustered, xlPrimary
    AjouterSerie ch, "Ratio combiné", wh.Range("Z2:Z" & d), wh.Range("W2:W" & d), xlLine, xlSecondary
    AjouterSerie ch, "100 %", wh.Range("AA2:AA" & d), wh.Range("W2:W" & d), xlLine, xlSecondary
    MettreEnFormeGraphique ch
End Sub

Private Sub AjouterSerie(ByVal ch As Chart, ByVal nom As String, ByVal valeurs As Range, ByVal cat As Range, _
                         ByVal typ As Long, ByVal axe As Long)
    Dim s As Series
    Set s = ch.SeriesCollection.NewSeries
    s.Name = nom
    s.Values = valeurs
    s.XValues = cat
    s.ChartType = typ
    s.AxisGroup = axe
End Sub

Private Sub MettreEnFormeGraphique(ByVal ch As Chart)
    Dim s As Series, ax As Axis, i As Long
    ch.HasLegend = False
    ch.HasTitle = False
    ch.ChartArea.Format.Fill.Visible = msoFalse
    ch.ChartArea.Format.Line.Visible = msoFalse
    ch.PlotArea.Format.Fill.Visible = msoFalse
    ch.ChartGroups(1).GapWidth = 60
    ch.ChartGroups(1).Overlap = -15
    Set ax = ch.Axes(xlValue, xlPrimary)
    ax.MinimumScale = 0: ax.MaximumScale = 1200: ax.MajorUnit = 300
    ax.HasMajorGridlines = True
    ax.MajorGridlines.Format.Line.ForeColor.RGB = C_LIGNE
    ax.Format.Line.Visible = msoFalse
    ax.TickLabels.Font.Size = 7: ax.TickLabels.Font.Color = C_GRIS_2
    ax.TickLabels.NumberFormat = "0"
    Set ax = ch.Axes(xlValue, xlSecondary)
    ax.MinimumScale = 0.7: ax.MaximumScale = 1.15
    ax.TickLabelPosition = xlTickLabelPositionNone
    ax.Format.Line.Visible = msoFalse
    ax.MajorTickMark = xlNone
    Set ax = ch.Axes(xlCategory, xlPrimary)
    ax.Format.Line.ForeColor.RGB = C_LIGNE
    ax.TickLabels.Font.Size = 8: ax.TickLabels.Font.Color = C_ENCRE_2
    ax.MajorTickMark = xlNone
    ch.SeriesCollection(1).Format.Fill.ForeColor.RGB = C_LAVANDE
    ch.SeriesCollection(2).Format.Fill.ForeColor.RGB = C_VIOLET
    Set s = ch.SeriesCollection(3)
    s.Format.Line.ForeColor.RGB = C_ROSE: s.Format.Line.Weight = 1.6
    s.MarkerStyle = xlMarkerStyleCircle: s.MarkerSize = 6
    s.MarkerBackgroundColor = C_BLANC: s.MarkerForegroundColor = C_ROSE
    s.HasDataLabels = True
    s.DataLabels.Position = xlLabelPositionAbove
    s.DataLabels.NumberFormat = "0.0 %"
    s.DataLabels.Font.Size = 7: s.DataLabels.Font.Bold = True: s.DataLabels.Font.Color = C_ROSE_TEXTE
    Set s = ch.SeriesCollection(4)
    s.Format.Line.ForeColor.RGB = C_ROSE: s.Format.Line.Weight = 1
    s.Format.Line.DashStyle = msoLineDash: s.Format.Line.Transparency = 0.45
    s.MarkerStyle = xlMarkerStyleNone
    For i = 1 To ch.SeriesCollection.Count
        ch.SeriesCollection(i).Format.Line.Visible = IIf(i >= 3, msoTrue, msoFalse)
    Next i
    ch.ChartArea.Font.Name = IIf(PoliceJakarta(), "Plus Jakarta Sans", "Segoe UI")
    ch.PlotArea.Width = ch.ChartArea.Width - 34
End Sub

Public Sub RecreerGraphiqueTableau(ByVal ws As Worksheet)
    Dim co As ChartObject
    For Each co In ws.ChartObjects
        co.Delete
    Next co
    GraphiqueTableau ws
    MajGraphiqueTableau ws, CLng(LireEtat("B4"))
End Sub

' Étiquettes du ratio combiné au format français et mise en avant de l'exercice
Private Sub MajGraphiqueTableau(ByVal ws As Worksheet, ByVal annee As Long)
    Dim ch As Chart, i As Long, n As Long, y As Variant, cor As Variant, pt As Point
    Set ch = ws.ChartObjects(PrefixePage(0) & "graphique").Chart
    y = PlageNom("hist_exercice").Value2: cor = PlageNom("hist_cor").Value2
    n = UBound(y, 1)
    For i = 1 To n
        Set pt = ch.SeriesCollection(2).Points(i)
        pt.Format.Fill.ForeColor.RGB = C_VIOLET
        pt.Format.Fill.Transparency = IIf(y(i, 1) = annee, 0, 0.45)
        Set pt = ch.SeriesCollection(3).Points(i)
        pt.DataLabel.Text = Pc(cor(i, 1), 1)
        pt.DataLabel.Font.Size = 7: pt.DataLabel.Font.Bold = True: pt.DataLabel.Font.Color = C_ROSE_TEXTE
        Set pt = ch.SeriesCollection(4).Points(i)
        pt.HasDataLabel = (i = n)
        If i = n Then
            pt.DataLabel.Text = "100" & Insec() & "%"
            pt.DataLabel.Position = xlLabelPositionRight
            pt.DataLabel.Font.Size = 7: pt.DataLabel.Font.Color = C_ROSE_TEXTE
        End If
    Next i
End Sub

Private Sub MajTableau(ByVal ws As Worksheet)
    Dim p As String, annee As Long, r As Long, rp As Long, h As Worksheet, k As Long
    p = PrefixePage(0)
    annee = CLng(LireEtat("B4"))
    Set h = Feuille(F_HISTORIQUE)
    r = annee - CLng(Param("annee_debut")) + 2: rp = r - 1
    MajKPITableau ws, 0, Pc(0, 0), KE(h.Cells(r, 9).Value2), SousTexteKPI(0, 0, Nb(h.Cells(r, 2).Value2, 0)), _
        h.Cells(r, 9).Value2, h.Cells(rp, 9).Value2, True, False, rp >= 2
    MajKPITableau ws, 1, "", KE(h.Cells(r, 6).Value2), SousTexteKPI(0, 1, KE(h.Cells(r, 10).Value2)), _
        h.Cells(r, 6).Value2, h.Cells(rp, 6).Value2, False, False, rp >= 2
    MajKPITableau ws, 2, "", Pc(h.Cells(r, 12).Value2, 1), SousTexteKPI(0, 2, Pc(h.Cells(r, 11).Value2, 1)), _
        h.Cells(r, 12).Value2, h.Cells(rp, 12).Value2, False, True, rp >= 2
    MajKPITableau ws, 3, "", Pc(h.Cells(r, 13).Value2, 1), _
        SousTexteKPI(0, 3, Pc(CDbl(Param("taux_gestion")) + CDbl(Param("taux_acquisition")), 1)), _
        h.Cells(r, 13).Value2, h.Cells(rp, 13).Value2, False, True, rp >= 2
    MajGraphiqueTableau ws, annee
    MajSegments ws, annee
    ChangerTexte ws, p & "bandeau_msg", CStr(Feuille(F_SEGMENTS).Cells(r, 12).Value2)
End Sub

' KPI du tableau de bord avec badge de variation (vs y-1)
Private Sub MajKPITableau(ByVal ws As Worksheet, ByVal k As Long, ByVal inutilise As String, ByVal valeur As String, _
                          ByVal sousTexte As String, ByVal v As Variant, ByVal vPrec As Variant, ByVal hausseFavorable As Boolean, _
                          ByVal enPoints As Boolean, ByVal avecPrec As Boolean)
    Dim p As String, txt As String, fond As Long, coul As Long, d As Double, s As Shape, W As Double, L As Double
    p = PrefixePage(0) & "kpi" & k
    ChangerTexte ws, p & "_val", valeur
    ChangerTexte ws, p & "_sub", sousTexte
    If avecPrec And EstNombre(v) And EstNombre(vPrec) Then
        If enPoints Then
            d = v - vPrec: txt = FormatPoints(d, 1)
        Else
            d = v / vPrec - 1: txt = FormatPct(d, 1, True)
        End If
        If (d >= 0) = hausseFavorable Then fond = C_VERT_CLAIR: coul = C_VERT Else fond = C_ROSE_CLAIR: coul = C_ROSE_FONCE
    Else
        txt = Tiret(): fond = C_PISTE: coul = C_GRIS_1
    End If
    Set s = ws.Shapes(p & "_badge")
    W = MesurerTexte(ws, txt, F_BOLD, 7) + 12
    L = 196 + 188 * k + 166
    s.Left = L - W: s.Width = W
    s.Fill.ForeColor.RGB = fond
    TexteDansForme s, txt, F_BOLD, 7, coul
End Sub

Private Sub MajSegments(ByVal ws As Worksheet, ByVal annee As Long)
    Dim p As String, dimSel As String, v As Variant, r As Long, i As Long, T As Double, cible As Double
    Dim sp As Double, s As Shape
    p = PrefixePage(0) & "segd_"
    SupprimerFormes ws, p
    dimSel = CStr(LireEtat("B5"))
    cible = CDbl(ValeurNom("sp_cible"))
    ChangerTexte ws, PrefixePage(0) & "seg_sous", SousTitreSegments(annee)
    ChangerTexte ws, PrefixePage(0) & "seg_ent0", EnteteSegments(0)
    PlacerEntete ws, 1, 766, EnteteSegments(1)
    PlacerEntete ws, 2, 814, EnteteSegments(2)
    PlacerEntete ws, 3, 926, EnteteSegments(3, Pc(cible, 0))
    ActiverOnglet ws, 0, "seg", dimSel
    v = Feuille(F_SEGMENTS).Range("A2:I" & PlageNom("seg_annee").Rows.Count + 1).Value2
    For r = 1 To UBound(v, 1)
        If v(r, 1) = annee And CStr(v(r, 2)) = dimSel And i < 5 Then
            T = 252 + 30 * i
            Texte ws, p & "lib" & i, 658, T + 9, 70, 13, LibelleAvecUnite(dimSel, CStr(v(r, 3))), F_BOLD, 8.5, C_ENCRE
            TexteFin ws, p & "expo" & i, 766, T + 9.5, Nb(v(r, 4), 0), F_REG, 8, C_GRIS_1, 0, 60
            TexteFin ws, p & "pm" & i, 814, T + 9.5, Eu(v(r, 9), 0), F_REG, 8, C_ENCRE_2, 0, 48
            Pilule ws, p & "piste" & i, 826, T + 12, 60, 6, C_PISTE
            sp = 0: If EstNombre(v(r, 8)) Then sp = v(r, 8)
            Pilule ws, p & "barre" & i, 826, T + 12, Application.Max(2, 60 * Application.Min(1, sp / 1.2)), 6, _
                IIf(sp > cible, C_ROSE, C_VIOLET)
            TexteFin ws, p & "sp" & i, 926, T + 8.5, Pc(v(r, 8), 1), F_XBOLD, 8.5, IIf(sp > cible, C_ROSE_TEXTE, C_ENCRE), 0, 60
            Filet ws, p & "filet" & i, 658, T + 30, 924, T + 30, C_BORD, 0.5, True
            i = i + 1
        End If
    Next r
End Sub

Private Sub PlacerEntete(ByVal ws As Worksheet, ByVal k As Long, ByVal xFin As Double, ByVal txt As String)
    Dim s As Shape, W As Double
    Set s = ws.Shapes(PrefixePage(0) & "seg_ent" & k)
    s.TextFrame2.TextRange.Text = txt
    W = MesurerTexte(ws, txt, F_SEMI, 6.5, 0.5) + 2
    s.Width = W: s.Left = xFin - W
End Sub

' ---------------------------------------------------------------------
' Calculateur (10.6, 11.13)
' ---------------------------------------------------------------------
Private Sub ConstruireCalculateurPage(ByVal ws As Worksheet)
    Dim p As String, s As Shape, k As Long, zones As Variant, libz As Variant, usages As Variant
    p = PrefixePage(12)
    EnTete ws, 12, 470
    Set s = Pilule(ws, p & "reinit", 850, 40, 90, 24, C_BLANC, C_BORD_2, 12)
    Action s, "ClicCalc"
    Set s = Texte(ws, p & "reinit~ic", 858, 45, 14, 13, Recharger(), F_SYM, 9, C_ENCRE)
    Action s, "ClicCalc"
    Set s = Texte(ws, p & "reinit~tx", 873, 45.5, 64, 13, TexteCalc("reinit"), F_BOLD, 8.5, C_ENCRE)
    Action s, "ClicCalc"
    Carte ws, p & "profil_carte", 196, 96, 252, 268, 16
    Texte ws, p & "profil_titre", 212, 108, 0, 0, TexteCalc("profil"), F_BOLD, 11, C_ENCRE, AL_G, -0.2
    LigneValeur ws, "age", 132, TexteCalc("age"), 16
    Texte ws, p & "zone_lib", 212, 168, 0, 0, TexteCalc("zone"), F_SEMI, 8.5, C_ENCRE_2
    zones = Array("A", "B", "C", "D")
    Forme ws, p & "ong_zone_fond", msoShapeRoundedRectangle, 212, 182, 220, 32, C_FOND, SANS, 0, 10
    For k = 0 To 3
        Set s = Forme(ws, p & "puce_zone_" & zones(k), msoShapeRoundedRectangle, 216 + 53 * k, 184, 51, 28, C_BLANC, SANS, 0, 8)
        Action s, "ClicPuce"
        Set s = Texte(ws, p & "puce_zone_" & zones(k) & "~l", 216 + 53 * k, 186, 51, 13, CStr(zones(k)), F_BOLD, 10, C_ENCRE_2, AL_C)
        Action s, "ClicPuce"
        Set s = Texte(ws, p & "puce_zone_" & zones(k) & "~s", 216 + 53 * k, 199, 51, 10, LibelleZone(CStr(zones(k))), F_MED, 6.5, C_GRIS_2, AL_C)
        Action s, "ClicPuce"
    Next k
    LigneValeur ws, "cv", 224, TexteCalc("cv"), 16
    Texte ws, p & "usage_lib", 212, 258, 0, 0, TexteCalc("usage"), F_SEMI, 8.5, C_ENCRE_2
    usages = Array("Privé", "Trajet", "Professionnel")
    Onglets ws, 12, "usage", usages, usages, CStr(ValeurNom("calc_usage")), 212, 272, 220, 22, 71.3, 18, 11, 9
    LigneValeur ws, "crm", 306, TexteCalc("crm"), 16
    Texte ws, p & "crm_aide", 212, 322, 222, 20, TexteCalc("aide_crm"), F_REG, 7, C_GRIS_2, AL_G, 0, True
    Carte ws, p & "ch_carte", 196, 372, 252, 124, 16
    Texte ws, p & "ch_titre", 212, 383, 0, 0, TexteCalc("chargements"), F_BOLD, 11, C_ENCRE, AL_G, -0.2
    For k = 0 To 4
        LigneChargement ws, k
    Next k
    CarteTTC ws
    For k = 0 To 3
        Carte ws, p & "mini" & k & "_carte", 458 + 122.5 * k, 228, 114.5, 58, 14
        Texte ws, p & "mini" & k & "_lib", 458 + 122.5 * k + 12, 237, 100, 11, TexteCalc("mini" & k), F_SEMI, 8, C_GRIS_1
        Texte ws, p & "mini" & k & "_val", 458 + 122.5 * k + 12, 249, 100, 19, "", F_XBOLD, 14, _
            Choose(k + 1, C_VIOLET_FONCE, C_ROSE_TEXTE, C_ENCRE, C_ENCRE), AL_G, -0.4
        Texte ws, p & "mini" & k & "_ind", 458 + 122.5 * k + 12, 270, 102, 9, "", F_MONO, 6.3, C_GRIS_2
    Next k
    Carte ws, p & "formule_carte", 458, 294, 482, 128, 16
    Texte ws, p & "formule_titre", 474, 306, 0, 0, TexteCalc("formule"), F_BOLD, 11, C_ENCRE, AL_G, -0.2
    For k = 0 To 1
        Texte ws, p & "formule_lib" & k, 474, 328 + 46 * k, 0, 0, TexteCalc(IIf(k = 0, "f_pp", "f_ttc")), F_BOLD, 6.5, C_GRIS_1, AL_G, 0.4
        Set s = Forme(ws, p & "formule_box" & k, msoShapeRoundedRectangle, 474, 338 + 46 * k, 450, 30, C_FORMULE_FOND, C_FORMULE_BORD, 0.75, 9)
        TexteDansForme s, "", F_MATH, 9.5, C_ENCRE
    Next k
    CarteExcel ws
End Sub

Private Sub LigneValeur(ByVal ws As Worksheet, ByVal cle As String, ByVal T As Double, ByVal libelle As String, ByVal d As Double)
    Dim p As String, s As Shape
    p = PrefixePage(12)
    Texte ws, p & cle & "_lib", 212, T, 0, 0, libelle, F_SEMI, 8.5, C_ENCRE_2
    TexteFin ws, p & cle & "_val", 392, T - 1.5, "", F_XBOLD, 10, C_ENCRE, 0, 120
    Set s = Cercle(ws, p & "btn_" & cle & "_moins", 398, T - 2.5, d, C_VIOLET_PALE)
    TexteDansForme s, Moins(), F_BOLD, 9, C_VIOLET
    Action s, "ClicCalc"
    Set s = Cercle(ws, p & "btn_" & cle & "_plus", 418, T - 2.5, d, C_VIOLET_PALE)
    TexteDansForme s, "+", F_BOLD, 9, C_VIOLET
    Action s, "ClicCalc"
    If cle <> "crm" Then Texte ws, p & cle & "_leg", 212, T + 16, 200, 11, "", F_REG, 7.5, C_GRIS_2
End Sub

Private Sub LigneChargement(ByVal ws As Worksheet, ByVal k As Long)
    Dim p As String, s As Shape, T As Double
    p = PrefixePage(12): T = 404 + 18 * k
    Texte ws, p & "ch" & k & "_lib", 212, T, 0, 0, TexteCalc("ch" & k), F_REG, 8, C_ENCRE_2
    TexteFin ws, p & "ch" & k & "_val", 392, T - 1, "", F_XBOLD, 9, C_ENCRE, 0, 80
    Set s = Cercle(ws, p & "btn_ch" & k & "_moins", 398, T - 1.5, 14, C_VIOLET_PALE)
    TexteDansForme s, Moins(), F_BOLD, 8, C_VIOLET
    Action s, "ClicCalc"
    Set s = Cercle(ws, p & "btn_ch" & k & "_plus", 416, T - 1.5, 14, C_VIOLET_PALE)
    TexteDansForme s, "+", F_BOLD, 8, C_VIOLET
    Action s, "ClicCalc"
End Sub

Private Sub CarteTTC(ByVal ws As Worksheet)
    Dim p As String, s As Shape, k As Long
    p = PrefixePage(12)
    Forme ws, p & "ttc_carte", msoShapeRoundedRectangle, 458, 96, 482, 124, C_VIOLET, SANS, 0, 18
    Set s = Forme(ws, p & "ttc_etoile", msoShape4pointStar, 830, 100, 104, 104, C_BLANC)
    s.Fill.Transparency = 0.9
    Set s = Texte(ws, p & "ttc_eyebrow", 478, 110, 0, 0, TexteCalc("eyebrow_ttc"), F_BOLD, 7.5, C_BLANC, AL_G, 1.1)
    s.TextFrame2.TextRange.Font.Fill.Transparency = 0.15
    Texte ws, p & "ttc_val", 476, 120, 300, 40, "", F_XBOLD, 32, C_BLANC, AL_G, -1.2
    Set s = Texte(ws, p & "ttc_mensuel", 478, 160, 300, 14, "", F_REG, 9.5, C_BLANC)
    s.TextFrame2.TextRange.Font.Fill.Transparency = 0.1
    Pilule ws, p & "ttc_pilule", 800, 116, 124, 18, C_BLANC
    Set s = TexteFin(ws, p & "ttc_moy", 924, 140, "", F_REG, 7.5, C_BLANC, 0, 400)
    s.TextFrame2.TextRange.Font.Fill.Transparency = 0.1
    For k = 0 To 4
        Forme ws, p & "pile" & k, msoShapeRectangle, 478, 180, 10, 7, Choose(k + 1, C_BLANC, C_PILE_SECURITE, _
            C_PILE_FRAIS, C_PILE_MARGE, C_PILE_TAXES)
        Forme ws, p & "leg" & k & "_c", msoShapeRoundedRectangle, 478, 196.5, 7, 7, Choose(k + 1, C_BLANC, _
            C_PILE_SECURITE, C_PILE_FRAIS, C_PILE_MARGE, C_PILE_TAXES), SANS, 0, 2
        Set s = Texte(ws, p & "leg" & k & "_t", 478, 194.5, 80, 11, "", F_REG, 7.5, C_BLANC)
    Next k
End Sub

Private Sub CarteExcel(ByVal ws As Worksheet)
    Dim p As String, s As Shape
    p = PrefixePage(12)
    Carte ws, p & "excel_carte", 458, 430, 482, 66, 16
    Set s = Forme(ws, p & "excel_icone", msoShapeRoundedRectangle, 474, 446, 18, 18, C_EXCEL, SANS, 0, 4)
    TexteDansForme s, "X", F_XBOLD, 9, C_BLANC
    Texte ws, p & "excel_titre", 500, 443, 0, 0, TexteCalc("excel_titre"), F_BOLD, 11, C_ENCRE, AL_G, -0.2
    Texte ws, p & "excel_texte", 500, 459, 320, 24, TexteCalc("excel_texte"), F_REG, 7.5, C_GRIS_1, AL_G, 0, True
    Set s = Pilule(ws, p & "excel_bouton", 836, 449, 90, 24, C_ENCRE, SANS, 12)
    TexteDansForme s, TexteOuvrirOnglet(), F_BOLD, 8.5, C_BLANC
    Action s, "ClicOuvrirOnglet"
End Sub

Public Sub MajCalculateurPage(ByVal ws As Worksheet)
    Dim p As String, k As Long, z As String, ttc As Double, x As Double, W As Double, s As Shape, mt(0 To 4) As Double
    Dim taux As Variant, txt As String
    p = PrefixePage(12)
    ChangerTexte ws, p & "age_val", TexteCalc("age_val", Nb(VN("calc_age"), 0))
    ChangerTexte ws, p & "age_leg", TexteCalc("classe_age", Intervalle(CStr(VN("calc_cl_age"))))
    ChangerTexte ws, p & "cv_val", TexteCalc("cv_val", Nb(VN("calc_cv"), 0))
    ChangerTexte ws, p & "cv_leg", TexteCalc("classe_cv", Intervalle(CStr(VN("calc_cl_puissance_cv"))))
    ChangerTexte ws, p & "crm_val", Nb(VN("calc_crm"), 2)
    z = CStr(VN("calc_zone"))
    For k = 0 To 3
        ws.Shapes(p & "puce_zone_" & Chr$(65 + k)).Fill.Visible = IIf(Chr$(65 + k) = z, msoTrue, msoFalse)
        With ws.Shapes(p & "puce_zone_" & Chr$(65 + k) & "~l").TextFrame2.TextRange.Font
            .Fill.ForeColor.RGB = IIf(Chr$(65 + k) = z, C_VIOLET_FONCE, C_ENCRE_2)
        End With
    Next k
    ActiverOnglet ws, 12, "usage", CStr(VN("calc_usage"))
    taux = Array("calc_securite", "calc_gestion", "calc_acquisition", "calc_marge", "calc_taxes")
    For k = 0 To 4
        ChangerTexte ws, p & "ch" & k & "_val", Pc(VN(taux(k)), 1)
    Next k
    MajCarteTTC ws
    MajMiniCartes ws
End Sub

Private Sub MajCarteTTC(ByVal ws As Worksheet)
    Dim p As String, k As Long, ttc As Double, x As Double, W As Double, mt(0 To 4) As Double, s As Shape, nm As Variant
    p = PrefixePage(12)
    ttc = VN("calc_ttc")
    ChangerTexte ws, p & "ttc_val", Eu(ttc, 2)
    ChangerTexte ws, p & "ttc_mensuel", TexteCalc("mensuel", Eu(VN("calc_mensuel"), 2))
    Set s = ws.Shapes(p & "ttc_pilule")
    TexteDansForme s, TexteCalc("vs_actuel", Pc(VN("calc_vs_actuel"), 1, True)), F_BOLD, 8.5, C_VIOLET_FONCE
    W = MesurerTexte(ws, s.TextFrame2.TextRange.Text, F_BOLD, 8.5) + 24
    s.Width = W: s.Left = 924 - W
    ChangerTexte ws, p & "ttc_moy", TexteCalc("vs_moyenne", Eu(VN("ttc_moy"), 2), Pc(VN("calc_vs_moyenne"), 1, True))
    nm = Array("calc_pp", "calc_mt_securite", "calc_mt_frais", "calc_mt_marge", "calc_mt_taxes")
    x = 478
    For k = 0 To 4
        mt(k) = VN(nm(k))
        W = 446 * mt(k) / ttc
        With ws.Shapes(p & "pile" & k): .Left = x: .Width = Application.Max(W, 0.5): End With
        x = x + W
    Next k
    x = 478
    For k = 0 To 4
        ws.Shapes(p & "leg" & k & "_c").Left = x
        Set s = ws.Shapes(p & "leg" & k & "_t")
        s.Left = x + 10
        s.TextFrame2.TextRange.Text = TexteCalc("leg" & k) & "  " & Eu(mt(k), 2)
        s.TextFrame2.TextRange.Characters(Len(TexteCalc("leg" & k)) + 3).Font.Bold = msoTrue
        W = MesurerTexte(ws, s.TextFrame2.TextRange.Text, F_BOLD, 7.5)
        s.Width = W + 4
        x = x + 10 + W + 12
    Next k
End Sub

Private Sub MajMiniCartes(ByVal ws As Worksheet)
    Dim p As String, fb As String, rf As String, crm As String, cb As String, rc As String, kp As String, th As String
    Dim s As String, ht As String, pp As String, ttc As String, ch As String
    p = PrefixePage(12)
    fb = Pc(VN("calc_freq_base"), 2): rf = Nb(VN("calc_rf"), 2): crm = Nb(VN("calc_crm"), 2)
    cb = Eu(VN("calc_cout_base"), 0): rc = Nb(VN("calc_rc"), 2): kp = Nb(VN("kappa"), 3): th = Nb(VN("theta"), 3)
    pp = Nb(VN("calc_pp"), 2): ttc = Eu(VN("calc_ttc"), 2)
    ChangerTexte ws, p & "mini0_val", Pc(VN("calc_freq"), 2)
    ChangerTexte ws, p & "mini0_ind", fb & " " & Multiplie() & " " & rf & " " & Multiplie() & " " & crm
    ChangerTexte ws, p & "mini1_val", Eu(VN("calc_cout"), 2)
    ChangerTexte ws, p & "mini1_ind", cb & " " & Multiplie() & " " & rc & " " & Multiplie() & " " & Kappa() & Theta()
    ChangerTexte ws, p & "mini2_val", Eu(VN("calc_pp"), 2)
    ChangerTexte ws, p & "mini2_ind", TexteCalc("ind2")
    ChangerTexte ws, p & "mini3_val", Eu(VN("calc_ht"), 2)
    ch = Nb(1 + VN("calc_securite"), 2)
    s = Nb(VN("calc_gestion") + VN("calc_acquisition") + VN("calc_marge"), 2)
    ChangerTexte ws, p & "mini3_ind", Multiplie() & " " & ch & " / (1 " & Moins() & " " & s & ")"
    ChangerTexte ws, p & "formule_box0", "PP = " & fb & " " & Multiplie() & " " & rf & " " & Multiplie() & " " & crm & " " & _
        Multiplie() & " " & cb & " " & Multiplie() & " " & rc & " " & Multiplie() & " " & kp & " " & Multiplie() & " " & _
        th & " = " & Eu(VN("calc_pp"), 2)
    ChangerTexte ws, p & "formule_box1", Pi_() & " = " & pp & " " & Multiplie() & " (1 + " & Nb(VN("calc_securite"), 3) & _
        ") / (1 " & Moins() & " " & Nb(VN("calc_gestion") + VN("calc_acquisition") + VN("calc_marge"), 3) & ") " & _
        Multiplie() & " (1 + " & Nb(VN("calc_taxes"), 3) & ") = " & ttc
End Sub
