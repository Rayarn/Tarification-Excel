Attribute VB_Name = "modContenu"
Option Explicit
' =====================================================================
' modContenu : tous les textes affichés (R12), section 11 du cahier.
' Les valeurs dynamiques sont passées en argument, déjà formatées (R8).
' =====================================================================

Private Const NB_ETAPES As Long = 11

' ---------------------------------------------------------------------
' Marque, groupes, titres, eyebrows
' ---------------------------------------------------------------------
Public Function TexteMarque() As String: TexteMarque = "PrimeLab": End Function
Public Function TexteSousMarque() As String: TexteSousMarque = "Étude tarifaire RC auto 2026": End Function
Public Function TexteBoutonCalculateur() As String: TexteBoutonCalculateur = "Calculateur de prime": End Function
Public Function TitreFormulation() As String: TitreFormulation = "Formulation": End Function
Public Function TitreControles() As String: TitreControles = "Contrôles": End Function
Public Function TexteFermer() As String: TexteFermer = "Fermer": End Function
Public Function TitreDansClasseur() As String: TitreDansClasseur = "Dans le classeur": End Function
Public Function TexteOuvrirOnglet() As String: TexteOuvrirOnglet = "Ouvrir l" & Apos() & "onglet " & Fleche(): End Function
Public Function TexteRetourPage() As String: TexteRetourPage = ChevronG() & " Retour à la page": End Function

Public Function TexteCelluleSelectionnee(ByVal adresse As String) As String
    TexteCelluleSelectionnee = "Cellule " & adresse & " sélectionnée"
End Function

Public Function TitreGroupe(ByVal g As Long) As String
    If g = 1 Then TitreGroupe = "PRÉPARER LES DONNÉES" Else TitreGroupe = "CONSTRUIRE LE TARIF"
End Function

Public Function TitrePage(ByVal n As Long) As String
    Select Case n
        Case 0: TitrePage = "Tableau de bord"
        Case 1: TitrePage = "Import et exposition"
        Case 2: TitrePage = "Qualité des données"
        Case 3: TitrePage = "Base de modélisation"
        Case 4: TitrePage = "Charge ultime et inflation"
        Case 5: TitrePage = "Écrêtement"
        Case 6: TitrePage = "Analyse exploratoire"
        Case 7: TitrePage = "Classes"
        Case 8: TitrePage = "Sélection des variables"
        Case 9: TitrePage = "Modèles GLM"
        Case 10: TitrePage = "Sinistres graves"
        Case 11: TitrePage = "Résultats et impact"
        Case 12: TitrePage = "Calculateur de prime"
    End Select
End Function

Public Function EyebrowPage(ByVal n As Long) As String
    Select Case n
        Case 0
            EyebrowPage = "PORTEFEUILLE AUTOMOBILE " & PointMedian() & " RC " & PointMedian() & " " & _
                Param("annee_debut") & DemiTiret() & Param("annee_fin")
        Case 1 To 5: EyebrowPage = TitreGroupe(1)
        Case 6 To 11: EyebrowPage = TitreGroupe(2)
        Case Else: EyebrowPage = "TARIF RC AUTO 2026"
    End Select
End Function

Public Function TexteEtapeSur(ByVal n As Long) As String
    TexteEtapeSur = "ÉTAPE " & Format$(n, "00") & " / " & NB_ETAPES
End Function

Public Function IntroPage(ByVal n As Long) As String
    Select Case n
        Case 0: IntroPage = "Performance technique du portefeuille RC, charges à l" & Apos() & "ultime. Base de l" & Apos() & "étude tarifaire 2026."
        Case 1: IntroPage = "Chargement des tables contrats et sinistres " & Param("annee_debut") & DemiTiret() & Param("annee_fin") & _
            ", typage des colonnes et calcul de l" & Apos() & "exposition de chaque ligne police " & Multiplie() & _
            " exercice sur la période d" & Apos() & "observation."
        Case 2: IntroPage = "Contrôles de complétude, de cohérence et d" & Apos() & "unicité avant toute agrégation. " & _
            "Chaque anomalie est corrigée ou exclue, et tracée dans l" & Apos() & "onglet Journal."
        Case 3: IntroPage = "Agrégation des sinistres retenus au niveau ligne police " & Multiplie() & " exercice, puis " & _
            "jointure gauche sur les contrats. Chaque ligne porte exposition, nombre de sinistres et charge."
        Case 4: IntroPage = "Développement des charges vues par Chain Ladder pour estimer la charge ultime de chaque " & _
            "exercice, puis revalorisation au point milieu de la période d" & Apos() & "application du tarif."
        Case 5: IntroPage = "Les sinistres revalorisés au-delà du seuil u sont plafonnés pour stabiliser le coût moyen " & _
            "par segment. L" & Apos() & "excédent est isolé puis mutualisé à l" & Apos() & "étape Sinistres graves."
        Case 6: IntroPage = "Fréquence et coût moyen écrêté par tranche de chaque variable candidate. La fréquence " & _
            "à CRM 1,00 retire l" & Apos() & "effet du bonus-malus, appliqué ensuite en multiplicateur."
        Case 7: IntroPage = "Regroupement des tranches voisines en classes homogènes et assez exposées. Deux classes " & _
            "voisines fusionnent tant que leurs fréquences à CRM 1,00 ne diffèrent pas significativement."
        Case 8: IntroPage = "Chaque variable est d" & Apos() & "abord testée seule (" & Chi() & "², V de Cramér), puis " & _
            "confirmée dans le GLM par le test du rapport de vraisemblance. Une variable trop liée à une variable " & _
            "déjà retenue est écartée."
        Case 9: IntroPage = "Deux GLM multiplicatifs ajustés par IRLS sur les cellules tarifaires : Poisson pour la " & _
            "fréquence, avec exposition et CRM en offset, Gamma pour le coût moyen écrêté."
        Case 10: IntroPage = "L" & Apos() & "excédent au-delà du seuil suit une loi de Pareto estimée sur les cinq " & _
            "exercices. Il est mutualisé sur tout le portefeuille par un coefficient appliqué au coût écrêté."
        Case 11: IntroPage = "Assemblage du tarif : base, relativités, coefficient graves, calage sur la charge cible, " & _
            "puis chargements. Impact mesuré sur les " & FormatEntier(ValeurNom("n_renouv")) & _
            " polices renouvelées au 01/01/" & (CLng(Param("annee_fin")) + 1) & "."
        Case 12: IntroPage = "Le tarif issu de l" & Apos() & "étude, assemblé : relativités GLM, coefficient graves, " & _
            "calage et chargements. Modifiez le profil et les hypothèses, chaque étape du calcul se met à jour."
    End Select
End Function

' ---------------------------------------------------------------------
' Libellés de KPI et sous-textes
' ---------------------------------------------------------------------
Public Function LibelleKPI(ByVal n As Long, ByVal k As Long) As String
    Dim t As Variant
    Select Case n
        Case 0: t = Array("Primes acquises", "Charge ultime", "S/P ultime", "Ratio combiné")
        Case 1: t = Array("Contrats", "Sinistres bruts", "Exposition", "Période")
        Case 2: t = Array("Doublons", "Sinistres exclus", "Âges imputés", "CRM corrigés")
        Case 3: t = Array("Sinistres rattachés", "Lignes sinistrées", "Base de modélisation", "Charge rattachée")
        Case 4: t = Array("Charge vue", "IBNR", "Inflation", "Charge cible")
        Case 5: t = Array("Seuil u", "Sinistres graves", "Charge écrêtée", "Excédent")
        Case 6: t = Array("Fréquence brute", "Fréquence à CRM 1,00", "Coût moyen écrêté", "Prime pure écrêtée")
        Case 7: t = Array("Exposition min.", "Classes d" & Apos() & "âge", "Classes de puissance", "Seuil de fusion")
        Case 8: t = Array("Candidates", "Retenues", "Seuil", "Liaison max.")
        Case 9: t = Array("Fréquence de base", "Coût de base écrêté", "Déviance expliquée", "Paramètres")
        Case 10: t = Array("Sinistres > u", Alpha() & ChrW(770) & " Pareto", "Excédent moyen", "Coefficient " & Kappa())
        Case 11: t = Array("Prime pure moyenne", "Évolution moyenne", "Équilibre plafonné", "Prime TTC moyenne")
    End Select
    LibelleKPI = t(k)
End Function

' Sous-textes : a, b = valeurs déjà formatées
Public Function SousTexteKPI(ByVal n As Long, ByVal k As Long, Optional ByVal a As String = "", _
                             Optional ByVal b As String = "") As String
    Dim s As String
    Select Case n * 10 + k
        Case 0: s = a & " années-police"
        Case 1: s = "dont IBNR " & a
        Case 2: s = "vu à fin " & Param("annee_fin") & " : " & a
        Case 3: s = "dont frais " & a
        Case 10: s = "lignes " & PointMedian() & " " & a & " polices"
        Case 11: s = "avant contrôles"
        Case 12: s = "années-police"
        Case 13: s = a & " exercices"
        Case 20: s = "sinistres supprimés"
        Case 21: s = "hors période, orphelins, sans suite"
        Case 22: s = "lignes " & PointMedian() & " médiane de la zone"
        Case 23: s = "ramenés dans [" & a & " ; " & b & "]"
        Case 30: s = a & " des sinistres retenus"
        Case 31: s = a & " des lignes"
        Case 32: s = "lignes à exposition non nulle"
        Case 33: s = "identique avant et après jointure"
        Case 40: s = a & ", au 31/12/" & Param("annee_fin")
        Case 41: s = a & " de la charge vue"
        Case 42: s = "par an " & PointMedian() & " coût des sinistres"
        Case 43: s = "ultime revalorisée " & Int(CDbl(Param("annee_milieu_application")))
        Case 50: s = "modifiable par les puces"
        Case 51: s = a & " des sinistres"
        Case 52: s = "base du modèle de coût"
        Case 53: s = a & " de la charge revalorisée"
        Case 60: s = a & " / " & b
        Case 61: s = "N / " & Sigma() & " E " & Multiplie() & " CRM"
        Case 62: s = "charge écrêtée / N"
        Case 63: s = "par année-police"
        Case 70: s = "années-police par classe"
        Case 71, 72: s = "depuis " & a & " tranches"
        Case 73: s = "|z|, niveau 10 % bilatéral"
        Case 80: s = "le sexe est exclu d" & Apos() & "office"
        Case 81: s = a
        Case 82: s = "sur toutes les p-values"
        Case 83: s = "V entre retenues " & PointMedian() & " " & a
        Case 90: s = "CRM 1,00 " & PointMedian() & " classes de référence"
        Case 91: s = "classes de référence"
        Case 92: s = a
        Case 93: s = "par modèle"
        Case 100: s = "sur " & a & " retenus"
        Case 101: s = "IC 95 % : " & a & " à " & b
        Case 102: s = "u / (" & Alpha() & ChrW(770) & " " & Moins() & " 1)"
        Case 103: s = "empirique : " & a
        Case 110: s = "par année-police " & PointMedian() & " niveau " & Int(CDbl(Param("annee_milieu_application")))
        Case 111: s = "vs tarif en vigueur, avant plafond"
        Case 112: s = "de la prime technique"
        Case 113: s = "actuelle : " & a
    End Select
    SousTexteKPI = Replace(s, " %", Insec() & "%")
End Function

Public Function TexteDevianceModele(ByVal frequence As Boolean) As String
    If frequence Then TexteDevianceModele = "fréquence, au niveau des lignes" Else _
        TexteDevianceModele = "coût moyen, au niveau des sinistres"
End Function

' ---------------------------------------------------------------------
' Formules (annexe B) : libellés affichés au-dessus des encadrés
' ---------------------------------------------------------------------
Public Function LibelleFormule(ByVal cle As String) As String
    Select Case cle
        Case "F01a": LibelleFormule = "EXPOSITION D'UNE LIGNE"
        Case "F01b": LibelleFormule = "BORNES DE L'EXERCICE y"
        Case "F01c": LibelleFormule = "EXPOSITION TOTALE"
        Case "F02a": LibelleFormule = "TAUX DE COMPLÉTUDE D'UNE COLONNE"
        Case "F02b": LibelleFormule = "RÈGLES DE COHÉRENCE"
        Case "F02c": LibelleFormule = "BILAN"
        Case "F03a": LibelleFormule = "NOMBRE DE SINISTRES DE LA LIGNE i"
        Case "F03b": LibelleFormule = "CHARGE DE LA LIGNE i"
        Case "F03c": LibelleFormule = "CONTRÔLE DE CONSERVATION"
        Case "F04a": LibelleFormule = "FACTEUR DE DÉVELOPPEMENT"
        Case "F04b": LibelleFormule = "CHARGE ULTIME DE L'EXERCICE y"
        Case "F04c": LibelleFormule = "REVALORISATION ET CHARGE CIBLE"
        Case "F05a": LibelleFormule = "CHARGE ÉCRÊTÉE"
        Case "F05b": LibelleFormule = "EXCÉDENT"
        Case "F05c": LibelleFormule = "EXCÈS MOYEN EMPIRIQUE"
        Case "F06a": LibelleFormule = "FRÉQUENCE DE LA TRANCHE j"
        Case "F06b": LibelleFormule = "FRÉQUENCE À CRM 1,00"
        Case "F06c": LibelleFormule = "COÛT MOYEN ÉCRÊTÉ"
        Case "F07a": LibelleFormule = "CONTRAINTE D'EXPOSITION"
        Case "F07b": LibelleFormule = "TEST DE FUSION DE DEUX CLASSES VOISINES"
        Case "F07c": LibelleFormule = "RÈGLE"
        Case "F08a": LibelleFormule = "STATISTIQUE DU " & Chi() & "² (FRÉQUENCE À CRM 1,00)"
        Case "F08b": LibelleFormule = "V DE CRAMÉR"
        Case "F08c": LibelleFormule = "TEST DU RAPPORT DE VRAISEMBLANCE"
        Case "F09a": LibelleFormule = "FRÉQUENCE " & PointMedian() & " POISSON, LIEN LOG"
        Case "F09b": LibelleFormule = "COÛT MOYEN " & PointMedian() & " GAMMA, LIEN LOG"
        Case "F09c": LibelleFormule = "ITÉRATION IRLS"
        Case "F10a": LibelleFormule = "QUEUE DE PARETO AU-DELÀ DE u"
        Case "F10b": LibelleFormule = "ESTIMATEUR DU MAXIMUM DE VRAISEMBLANCE"
        Case "F10c": LibelleFormule = "COEFFICIENT DE MUTUALISATION"
        Case "F11a": LibelleFormule = "PRIME PURE"
        Case "F11b": LibelleFormule = "PRIME COMMERCIALE"
        Case "F11c": LibelleFormule = "PLAFONNEMENT"
    End Select
End Function

' ---------------------------------------------------------------------
' Contrôles des étapes : a, b = valeurs dynamiques formatées
' ---------------------------------------------------------------------
Public Function TexteControle(ByVal n As Long, ByVal k As Long, Optional ByVal a As String = "", _
                             Optional ByVal b As String = "") As String
    Dim s As String
    Select Case n * 10 + k
        Case 11: s = "Dates au format date Excel, aucune stockée en texte"
        Case 12: s = "Une seule ligne par police et par exercice"
        Case 13: s = "Exposition comprise entre 0 et 1 (" & a & " lignes nulles : dates incohérentes)"
        Case 21: s = "Clé (police, date, montant) unique parmi les sinistres retenus"
        Case 22: s = "Chaque sinistre retenu est couvert par une ligne de contrat"
        Case 23: s = "Aucune colonne tarifaire sous 99,5 % de complétude"
        Case 31: s = "Jointure gauche : les " & a & " lignes de contrats sont conservées"
        Case 32: s = "Somme des N" & ChrW(7522) & " égale au nombre de sinistres retenus"
        Case 33: s = "Charge totale identique avant et après jointure"
        Case 41: s = "Dernière diagonale du triangle = charge des sinistres retenus (écart < 0,5 %)"
        Case 42: s = "Facteurs de développement décroissants vers 1"
        Case 43: s = "IBNR positif sur chaque exercice"
        Case 51: s = "Charge écrêtée + excédent = charge revalorisée"
        Case 52: s = "Au moins " & b & " sinistres au-dessus de u (" & a & ")"
        Case 53: s = "Excédent sous " & b & " de la charge (" & a & ")"
        Case 61: s = "Somme des expositions par tranche = exposition totale"
        Case 62: s = "Somme des sinistres par tranche = sinistres retenus"
        Case 63: s = "Charge écrêtée totale = valeur de l" & Apos() & "étape 05"
        Case 71: s = "Chaque classe dépasse " & a & " années-police"
        Case 72: s = "Classes voisines significativement différentes (|z| " & CarSup() & " " & a & ")"
        Case 73: s = "Classe de référence = la plus exposée (" & a & " ans)"
        Case 81: s = "Effectif attendu " & CarSup() & " 5 dans chaque classe"
        Case 82: s = "Aucune paire de variables retenues avec V " & CarSup() & " " & a
        Case 83: s = "Sexe exclu d" & Apos() & "office (arrêt Test-Achats, 2011)"
        Case 91: s = "Sinistres prédits = sinistres observés (" & a & ")"
        Case 92: s = "Convergence IRLS atteinte (" & a & " et " & b & " itérations)"
        Case 93: s = "Observé / prédit entre " & a & " et " & b & " par classe de CRM"
        Case 101: s = "Borne basse de l" & Apos() & "IC de " & Alpha() & ChrW(770) & " au-dessus de 1 (espérance finie)"
        Case 102: s = Kappa() & " Pareto à moins de " & b & " du " & Kappa() & " empirique (" & a & ")"
        Case 103: s = "Survie observée proche de la Pareto (écart < " & a & ")"
        Case 111: s = Sigma() & " exposition " & Multiplie() & " prime pure = charge cible (calage " & Theta() & ")"
        Case 112: s = "Aucune évolution au-delà de " & ChrW(177) & a & " après plafonnement"
        Case 113: s = "Équilibre après plafonnement " & CarSup() & " " & b & " (" & a & ")"
    End Select
    TexteControle = Replace(s, " %", Insec() & "%")
End Function

' ---------------------------------------------------------------------
' Cartes « Dans le classeur » et graphiques
' ---------------------------------------------------------------------
Public Function MetaFeuille(ByVal n As Long, Optional ByVal a As String = "", Optional ByVal b As String = "") As String
    Select Case n
        Case 1: MetaFeuille = a & " lignes"
        Case 2: MetaFeuille = a & " lignes brutes"
        Case 3: MetaFeuille = a & " lignes sinistrées"
        Case 4: MetaFeuille = a & " exercices"
        Case 5: MetaFeuille = a & " sinistres retenus"
        Case 6, 7: MetaFeuille = "variable : " & a
        Case 8: MetaFeuille = a & " variables candidates"
        Case 9: MetaFeuille = "IRLS " & PointMedian() & " " & a & " cellules"
        Case 10: MetaFeuille = a & " sinistres > u"
        Case 11: MetaFeuille = Theta() & " = " & a & " " & PointMedian() & " " & Kappa() & " = " & b
    End Select
End Function

Public Function TitreGraphique(ByVal n As Long, Optional ByVal a As String = "") As String
    Select Case n
        Case 0: TitreGraphique = "Primes, sinistres et rentabilité"
        Case 1: TitreGraphique = "Exposition par exercice"
        Case 2: TitreGraphique = "Complétude par colonne"
        Case 3: TitreGraphique = "Lignes par nombre de sinistres"
        Case 4: TitreGraphique = "Charge vue et ultime par exercice"
        Case 5: TitreGraphique = "Part de la charge au-dessus du seuil"
        Case 6: TitreGraphique = "Fréquence par " & a
        Case 7: TitreGraphique = "Relativité par " & a
        Case 8: TitreGraphique = "V de Cramér"
        Case 9: TitreGraphique = a & " observée et prédite par quintile"
        Case 10: TitreGraphique = "Survie au-delà de x"
        Case 11: TitreGraphique = "Évolution de prime des polices renouvelées"
    End Select
End Function

Public Function NoteGraphique(ByVal n As Long, Optional ByVal a As String = "") As String
    Select Case n
        Case 0: NoteGraphique = "Échelle de gauche en k" & ChrW(8364) & ". Ratio combiné sur l" & Apos() & _
            "échelle de droite (70" & Insec() & "% à 115" & Insec() & "%)."
        Case 1: NoteGraphique = "années-police"
        Case 2: NoteGraphique = "seuil 99,5" & Insec() & "%"
        Case 5: NoteGraphique = "selon le seuil testé"
        Case 7: NoteGraphique = "base " & a & " = 1,00"
        Case 8: NoteGraphique = "liaison avec la fréquence à CRM 1,00"
        Case 11: NoteGraphique = "avant plafonnement " & PointMedian() & " % des polices"
    End Select
    NoteGraphique = Replace(NoteGraphique, " %", Insec() & "%")
End Function

Public Function LegendeGraphique(ByVal n As Long, Optional ByVal frequence As Boolean = True) As Variant
    Select Case n
        Case 0: LegendeGraphique = Array("Primes acquises", "Charge ultime", "Ratio combiné")
        Case 3: LegendeGraphique = Array("Observé", "Poisson")
        Case 4: LegendeGraphique = Array("Vue", "Ultime")
        Case 6: LegendeGraphique = Array("Brute", "À CRM 1,00")
        Case 9: LegendeGraphique = Array(IIf(frequence, "Observée", "Observé"), IIf(frequence, "Prédite", "Prédit"))
        Case 10: LegendeGraphique = Array("Observée", "Pareto")
    End Select
End Function

' Nom affiché d'une variable (puces, cartes, graphiques)
Public Function NomAffiche(ByVal v As String) As String
    Select Case v
        Case "age": NomAffiche = "âge"
        Case "puissance_cv": NomAffiche = "puissance"
        Case "anc_permis": NomAffiche = "permis"
        Case "anc_vehicule": NomAffiche = "véhicule"
        Case Else: NomAffiche = v
    End Select
End Function

Public Function NomPuce(ByVal v As String) As String
    NomPuce = Majuscule1(NomAffiche(v))
End Function

' « tranche d'âge », « classe de puissance »...
Public Function DesignationVariable(ByVal v As String, ByVal classe As Boolean) As String
    Dim m As String
    If classe Then m = "classe" Else m = "tranche"
    Select Case v
        Case "age": DesignationVariable = m & " d" & Apos() & "âge"
        Case "zone": DesignationVariable = "zone"
        Case "usage": DesignationVariable = "usage"
        Case "couleur": DesignationVariable = "couleur"
        Case "puissance_cv": DesignationVariable = m & " de puissance"
        Case "anc_permis": DesignationVariable = m & " d" & Apos() & "ancienneté de permis"
        Case Else: DesignationVariable = m & " d" & Apos() & "âge du véhicule"
    End Select
End Function

' Libellé d'une tranche ou d'une classe avec son unité (« 18–24 ans », « Zone A », « 5–8 CV »)
Public Function LibelleAvecUnite(ByVal v As String, ByVal lib As String) As String
    Select Case v
        Case "age", "anc_permis", "anc_vehicule": LibelleAvecUnite = Intervalle(lib) & " ans"
        Case "puissance_cv": LibelleAvecUnite = Intervalle(lib) & " CV"
        Case "zone": LibelleAvecUnite = "Zone " & lib
        Case Else: LibelleAvecUnite = lib
    End Select
End Function

Public Function LibelleNbSinistres(ByVal k As Long) As String
    Select Case k
        Case 1: LibelleNbSinistres = "1 sinistre"
        Case 2: LibelleNbSinistres = "2 sinistres"
        Case Else: LibelleNbSinistres = "3 et plus"
    End Select
End Function

Public Function LibelleQuintile(ByVal q As Long) As String
    LibelleQuintile = "Quintile " & q
End Function

Public Function LibelleDecision(ByVal d As String) As String
    If d = "Retenue" Then
        LibelleDecision = "Retenue"
    ElseIf InStr(d, "redondante") > 0 Then
        LibelleDecision = "Redondante"
    ElseIf InStr(d, "non significative") > 0 Then
        LibelleDecision = "Non signif."
    ElseIf InStr(d, "vraisemblance") > 0 Then
        LibelleDecision = "Écartée (LRT)"
    Else
        LibelleDecision = d
    End If
End Function

' ---------------------------------------------------------------------
' Tableau de bord
' ---------------------------------------------------------------------
Public Function TitreSegments() As String: TitreSegments = "Rentabilité par segment": End Function

Public Function SousTitreSegments(ByVal annee As Long) As String
    SousTitreSegments = "Exercice " & annee & " " & PointMedian() & " S/P ultime, graves mutualisés"
End Function

Public Function OngletSegment(ByVal v As String) As String
    Select Case v
        Case "age": OngletSegment = "Âge"
        Case "zone": OngletSegment = "Zone"
        Case "puissance_cv": OngletSegment = "Puissance"
        Case Else: OngletSegment = "Usage"
    End Select
End Function

Public Function EnteteSegments(ByVal k As Long, Optional ByVal cible As String = "") As String
    Select Case k
        Case 0: EnteteSegments = "SEGMENT"
        Case 1: EnteteSegments = "EXPO."
        Case 2: EnteteSegments = "PRIME MOY."
        Case Else: EnteteSegments = "S/P (CIBLE " & cible & ")"
    End Select
End Function

Public Function EyebrowBandeau() As String: EyebrowBandeau = "ÉTUDE TARIFAIRE 2026": End Function

Public Function TitreAide(ByVal cle As String) As String
    Select Case cle
        Case "kpi0": TitreAide = "Primes acquises"
        Case "kpi1": TitreAide = "Charge ultime"
        Case "kpi2": TitreAide = "S/P ultime"
        Case "kpi3": TitreAide = "Ratio combiné"
        Case "seg": TitreAide = "Rentabilité par segment"
        Case Else: TitreAide = "PrimeLab"
    End Select
End Function

Public Function TexteAide(ByVal cle As String) As String
    Select Case cle
        Case "kpi0": TexteAide = "Primes hors taxes acquises sur l" & Apos() & "exercice au tarif alors en vigueur : " & _
            "prime annuelle " & Multiplie() & " exposition de chaque ligne."
        Case "kpi1": TexteAide = "Charge vue au 31/12/" & Param("annee_fin") & " multipliée par le facteur de " & _
            "développement Chain Ladder de l" & Apos() & "exercice. L" & Apos() & "IBNR est l" & Apos() & _
            "écart entre charge ultime et charge vue."
        Case "kpi2": TexteAide = "Charge ultime / primes acquises. Le S/P vu sous-estime les exercices récents, " & _
            "encore immatures : le tableau de bord raisonne donc à l" & Apos() & "ultime."
        Case "kpi3": TexteAide = "S/P ultime + frais de gestion et d" & Apos() & "acquisition (25 % des primes). " & _
            "Au-delà de 100 %, l" & Apos() & "exercice est techniquement déficitaire."
        Case "seg": TexteAide = "La charge ultime de l" & Apos() & "exercice est répartie entre segments au prorata " & _
            "de leur charge écrêtée : les graves sont mutualisés. S/P cible = (1 " & Moins() & " frais " & _
            Moins() & " marge) / (1 + sécurité)."
        Case "police_ok": TexteAide = "Police Plus Jakarta Sans détectée : rendu conforme à la charte."
        Case "police_repli": TexteAide = "Plus Jakarta Sans n" & Apos() & "est pas installée : repli sur Segoe UI. " & _
            "Installer les polices du dossier polices puis reconstruire l" & Apos() & "application."
    End Select
    TexteAide = Replace(TexteAide, " %", Insec() & "%")
End Function

' ---------------------------------------------------------------------
' Bandeau du tableau de bord (6.12)
' ---------------------------------------------------------------------
Public Function DesignationSegment(ByVal dimension As String, ByVal classe As String) As String
    Select Case dimension
        Case "age": DesignationSegment = "les " & Intervalle(classe) & " ans"
        Case "zone": DesignationSegment = "la zone " & classe
        Case "puissance_cv": DesignationSegment = "les " & Intervalle(classe) & " CV"
        Case Else: DesignationSegment = "l" & Apos() & "usage " & LCase$(classe)
    End Select
End Function

Public Function TexteBandeau(ByVal k As Long, noms() As String, valeurs() As Double, ByVal annee As Long, _
                             ByVal cible As Double) As String
    Dim s As String
    Select Case k
        Case 0
            s = "Aucun segment significatif au-dessus du S/P cible en " & annee & ". Consulter l" & Apos() & "étude."
        Case 1
            s = Majuscule1(noms(1)) & " reste sous-tarifé" & Insec() & ": S/P " & annee & " de " & _
                FormatPct(valeurs(1), 0) & " (cible " & FormatPct(cible, 0) & "). Lancer la révision."
        Case Else
            s = Majuscule1(noms(1)) & " et " & noms(2) & " restent sous-tarifés" & Insec() & ": S/P " & annee & " de " & _
                FormatPct(valeurs(1), 0) & " et " & FormatPct(valeurs(2), 0) & " (cible " & FormatPct(cible, 0) & _
                "). Lancer la révision."
    End Select
    TexteBandeau = s
End Function

' ---------------------------------------------------------------------
' Calculateur (11.13)
' ---------------------------------------------------------------------
Public Function TexteCalc(ByVal cle As String, Optional ByVal a As String = "", Optional ByVal b As String = "") As String
    Dim s As String
    Select Case cle
        Case "reinit": s = "Réinitialiser"
        Case "profil": s = "Profil de l" & Apos() & "assuré"
        Case "age": s = "Âge du conducteur"
        Case "age_val": s = a & " ans"
        Case "classe_age": s = "Classe " & a & " ans"
        Case "zone": s = "Zone géographique"
        Case "cv": s = "Puissance fiscale"
        Case "cv_val": s = a & " CV"
        Case "classe_cv": s = "Classe " & a & " CV"
        Case "usage": s = "Usage"
        Case "crm": s = "Coefficient bonus-malus"
        Case "aide_crm": s = Moins() & " : un an sans sinistre (" & Multiplie() & " 0,95) " & PointMedian() & _
            " + : un sinistre responsable (" & Multiplie() & " 1,25)"
        Case "chargements": s = "Hypothèses de chargement"
        Case "ch0": s = "Sécurité (sur prime pure)"
        Case "ch1": s = "Frais de gestion"
        Case "ch2": s = "Frais d" & Apos() & "acquisition"
        Case "ch3": s = "Marge"
        Case "ch4": s = "Taxes"
        Case "eyebrow_ttc": s = "PRIME COMMERCIALE TTC"
        Case "mensuel": s = "soit " & a & " par mois"
        Case "vs_actuel": s = a & " vs tarif actuel"
        Case "vs_moyenne": s = "vs prime moyenne du portefeuille (" & a & ") : " & b
        Case "leg0": s = "Prime pure"
        Case "leg1": s = "Sécurité"
        Case "leg2": s = "Frais"
        Case "leg3": s = "Marge"
        Case "leg4": s = "Taxes"
        Case "mini0": s = "Fréquence"
        Case "mini1": s = "Coût moyen"
        Case "mini2": s = "Prime pure"
        Case "mini3": s = "Prime HT"
        Case "ind2": s = "fréq. " & Multiplie() & " coût"
        Case "formule": s = "Formule appliquée"
        Case "f_pp": s = "PRIME PURE"
        Case "f_ttc": s = "PRIME COMMERCIALE TTC"
        Case "excel_titre": s = "Le même calcul dans Excel"
        Case "excel_texte": s = "Onglet Calculateur : chaque montant ci-dessus est une formule de la feuille, " & _
            "lisible en mode administration."
    End Select
    TexteCalc = s
End Function

Public Function LibelleZone(ByVal z As String) As String
    Select Case z
        Case "A": LibelleZone = "Rural"
        Case "B": LibelleZone = "Périurb."
        Case "C": LibelleZone = "Urbain"
        Case Else: LibelleZone = "Dense"
    End Select
End Function

' ---------------------------------------------------------------------
' Messages
' ---------------------------------------------------------------------
Public Function MessageConstruction(ByVal secondes As Double, ByVal resultat As String) As String
    MessageConstruction = "Application construite en " & FormatNombre(secondes, 0) & " s. " & resultat
End Function

Public Function MessageChargementRefuse() As String
    MessageChargementRefuse = "Chargements refusés : la somme frais + marge laisserait moins de 5 % de la prime."
End Function
