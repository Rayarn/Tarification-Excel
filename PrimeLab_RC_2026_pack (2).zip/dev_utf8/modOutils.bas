Attribute VB_Name = "modOutils"
Option Explicit
' =====================================================================
' modOutils : caractères spéciaux (R6), formats français (R8), tri,
' algèbre matricielle, noms définis, feuilles de travail.
' =====================================================================

' --- Formats des feuilles de travail (section 7) ---
Private Const COUL_ENTETE_BRUTE As Long = 16772079   ' violet_clair
Private Const COUL_ENTETE_DERIVEE As Long = 16773363 ' violet_pale
Private Const COUL_TEXTE_DERIVEE As Long = 15218262  ' violet_fonce
Private Const COUL_FORMULE_FOND As Long = 16775674   ' formule_fond
Private Const COUL_BORD As Long = 16051180           ' bord
Private Const LARGEUR_MIN_COL As Double = 9
Private Const LARGEUR_MAX_COL As Double = 60
Private Const LIGNES_AJUSTEMENT As Long = 300
Private Const PIVOT_MIN As Double = 0.000000000001
Private Const ERR_SINGULIERE As Long = vbObjectError + 901

' ---------------------------------------------------------------------
' Caractères hors Windows-1252 (R6)
' ---------------------------------------------------------------------
Public Function CarInf() As String: CarInf = ChrW(8804): End Function
Public Function CarSup() As String: CarSup = ChrW(8805): End Function
Public Function Moins() As String: Moins = ChrW(8722): End Function
Public Function DemiTiret() As String: DemiTiret = ChrW(8211): End Function
Public Function Alpha() As String: Alpha = ChrW(945): End Function
Public Function Kappa() As String: Kappa = ChrW(954): End Function
Public Function Theta() As String: Theta = ChrW(952): End Function
Public Function Lambda() As String: Lambda = ChrW(955): End Function
Public Function Mu() As String: Mu = ChrW(956): End Function
Public Function Sigma() As String: Sigma = ChrW(931): End Function
Public Function Chi() As String: Chi = ChrW(967): End Function
Public Function Pi_() As String: Pi_ = ChrW(928): End Function
Public Function Coche() As String: Coche = ChrW(10003): End Function
Public Function Croix() As String: Croix = ChrW(10007): End Function
Public Function Recharger() As String: Recharger = ChrW(8634): End Function
Public Function Fleche() As String: Fleche = ChrW(8250): End Function
Public Function ChevronG() As String: ChevronG = ChrW(8249): End Function
Public Function Insec() As String: Insec = ChrW(160): End Function
Public Function Indice0() As String: Indice0 = ChrW(8320): End Function
Public Function Tiret() As String: Tiret = ChrW(8212): End Function
Public Function PointMedian() As String: PointMedian = ChrW(183): End Function
Public Function Apos() As String: Apos = ChrW(8217): End Function
Public Function Multiplie() As String: Multiplie = ChrW(215): End Function

' Libellé d'intervalle : trait d'union remplacé par le demi-tiret (section 0.3)
Public Function Intervalle(ByVal s As String) As String
    Intervalle = Replace(s, "-", DemiTiret())
End Function

' ---------------------------------------------------------------------
' Formats français indépendants des paramètres régionaux (R8)
' ---------------------------------------------------------------------
Public Function ArrondiArith(ByVal x As Double, ByVal nd As Long) As Double
    Dim f As Variant, v As Variant
    f = CDec(10 ^ nd)
    v = CDec(Abs(x)) * f
    v = Int(v + CDec(0.5)) / f
    If x < 0 Then ArrondiArith = -CDbl(v) Else ArrondiArith = CDbl(v)
End Function

' Nombre formaté : séparateur de milliers insécable, virgule décimale.
' signeTypo = vrai : signe moins typographique et « + » explicite.
Public Function FormatNombre(ByVal x As Double, ByVal nd As Long, _
                             Optional ByVal signeTypo As Boolean = False, _
                             Optional ByVal plusExplicite As Boolean = False) As String
    Dim f As Variant, n As Variant, ent As Variant, fr As Variant
    Dim sEnt As String, sDec As String, res As String, i As Long, neg As Boolean
    f = CDec(10 ^ nd)
    n = Int(CDec(Abs(x)) * f + CDec(0.5))
    neg = (x < 0 And n > 0)
    ent = Int(n / f)
    fr = n - ent * f
    sEnt = CStr(ent)
    res = ""
    For i = Len(sEnt) To 1 Step -1
        res = Mid$(sEnt, i, 1) & res
        If (Len(sEnt) - i + 1) Mod 3 = 0 And i > 1 Then res = Insec() & res
    Next i
    If nd > 0 Then
        sDec = CStr(fr)
        sDec = String(nd - Len(sDec), "0") & sDec
        res = res & "," & sDec
    End If
    If neg Then
        If signeTypo Then res = Moins() & res Else res = "-" & res
    ElseIf plusExplicite And n > 0 Then
        res = "+" & res
    End If
    FormatNombre = res
End Function

Public Function FormatEntier(ByVal x As Double) As String
    FormatEntier = FormatNombre(x, 0)
End Function

Public Function FormatPct(ByVal x As Double, ByVal nd As Long, _
                          Optional ByVal signe As Boolean = False) As String
    FormatPct = FormatNombre(x * 100, nd, signe, signe) & Insec() & "%"
End Function

Public Function FormatEuro(ByVal x As Double, ByVal nd As Long) As String
    FormatEuro = FormatNombre(x, nd) & Insec() & ChrW(8364)
End Function

Public Function FormatKEuro(ByVal x As Double) As String
    FormatKEuro = FormatNombre(x / 1000, 0) & Insec() & "k" & ChrW(8364)
End Function

Public Function FormatPoints(ByVal x As Double, ByVal nd As Long) As String
    FormatPoints = FormatNombre(x * 100, nd, True, True) & Insec() & "pt"
End Function

' Valeur de cellule éventuellement en erreur ou vide : tiret long
Public Function EstNombre(ByVal v As Variant) As Boolean
    EstNombre = False
    If IsError(v) Then Exit Function
    If IsEmpty(v) Then Exit Function
    EstNombre = IsNumeric(v) And VarType(v) <> vbString
End Function

Public Function Majuscule1(ByVal s As String) As String
    If Len(s) = 0 Then Majuscule1 = s Else Majuscule1 = UCase$(Left$(s, 1)) & Mid$(s, 2)
End Function

' ---------------------------------------------------------------------
' Tri fusion ascendant non récursif, stable (départage par l'ordre initial)
' cles(1..n), idx(1..n) : idx est réordonné selon cles(idx(i)).
' ---------------------------------------------------------------------
Public Sub TriFusion(cles() As Double, idx() As Long, ByVal n As Long)
    Dim tmp() As Long, largeur As Long, g As Long, m As Long, d As Long
    Dim i As Long, j As Long, k As Long
    If n < 2 Then Exit Sub
    ReDim tmp(1 To n)
    largeur = 1
    Do While largeur < n
        g = 1
        Do While g <= n
            m = g + largeur - 1
            If m > n Then m = n
            d = g + 2 * largeur - 1
            If d > n Then d = n
            i = g: j = m + 1: k = g
            Do While i <= m And j <= d
                If cles(idx(j)) < cles(idx(i)) Then
                    tmp(k) = idx(j): j = j + 1
                Else
                    tmp(k) = idx(i): i = i + 1
                End If
                k = k + 1
            Loop
            Do While i <= m: tmp(k) = idx(i): i = i + 1: k = k + 1: Loop
            Do While j <= d: tmp(k) = idx(j): j = j + 1: k = k + 1: Loop
            g = g + 2 * largeur
        Loop
        For i = 1 To n: idx(i) = tmp(i): Next i
        largeur = largeur * 2
    Loop
End Sub

' Tri fusion de chaînes (ordre binaire), stable
Public Sub TriFusionTexte(cles() As String, idx() As Long, ByVal n As Long)
    Dim tmp() As Long, largeur As Long, g As Long, m As Long, d As Long
    Dim i As Long, j As Long, k As Long
    If n < 2 Then Exit Sub
    ReDim tmp(1 To n)
    largeur = 1
    Do While largeur < n
        g = 1
        Do While g <= n
            m = g + largeur - 1
            If m > n Then m = n
            d = g + 2 * largeur - 1
            If d > n Then d = n
            i = g: j = m + 1: k = g
            Do While i <= m And j <= d
                If StrComp(cles(idx(j)), cles(idx(i)), vbBinaryCompare) < 0 Then
                    tmp(k) = idx(j): j = j + 1
                Else
                    tmp(k) = idx(i): i = i + 1
                End If
                k = k + 1
            Loop
            Do While i <= m: tmp(k) = idx(i): i = i + 1: k = k + 1: Loop
            Do While j <= d: tmp(k) = idx(j): j = j + 1: k = k + 1: Loop
            g = g + 2 * largeur
        Loop
        For i = 1 To n: idx(i) = tmp(i): Next i
        largeur = largeur * 2
    Loop
End Sub

' ---------------------------------------------------------------------
' Algèbre : inversion de Gauss-Jordan à pivot partiel (matrices 1..n)
' ---------------------------------------------------------------------
Public Sub InverserMatrice(a() As Double, ByVal n As Long, inv() As Double)
    Dim m() As Double, i As Long, j As Long, k As Long, p As Long
    Dim maxv As Double, t As Double, piv As Double
    ReDim m(1 To n, 1 To 2 * n)
    ReDim inv(1 To n, 1 To n)
    For i = 1 To n
        For j = 1 To n: m(i, j) = a(i, j): Next j
        m(i, n + i) = 1
    Next i
    For k = 1 To n
        p = k: maxv = Abs(m(k, k))
        For i = k + 1 To n
            If Abs(m(i, k)) > maxv Then maxv = Abs(m(i, k)): p = i
        Next i
        If maxv < PIVOT_MIN Then Err.Raise ERR_SINGULIERE, "InverserMatrice", "matrice singulière"
        If p <> k Then
            For j = 1 To 2 * n
                t = m(k, j): m(k, j) = m(p, j): m(p, j) = t
            Next j
        End If
        piv = m(k, k)
        For j = 1 To 2 * n: m(k, j) = m(k, j) / piv: Next j
        For i = 1 To n
            If i <> k Then
                t = m(i, k)
                If t <> 0 Then
                    For j = 1 To 2 * n: m(i, j) = m(i, j) - t * m(k, j): Next j
                End If
            End If
        Next i
    Next k
    For i = 1 To n
        For j = 1 To n: inv(i, j) = m(i, n + j): Next j
    Next i
End Sub

' ---------------------------------------------------------------------
' Noms définis et paramètres
' ---------------------------------------------------------------------
Public Sub DefinirNom(ByVal nom As String, ByVal plage As Range)
    Dim ref As String
    ref = "='" & plage.Worksheet.Name & "'!" & plage.Address
    If NomExiste(nom) Then
        ThisWorkbook.Names(nom).RefersTo = ref
    Else
        ThisWorkbook.Names.Add Name:=nom, RefersTo:=ref
    End If
End Sub

Public Function NomExiste(ByVal nom As String) As Boolean
    Dim n As Name
    On Error Resume Next ' toléré (R4) : test d'existence
    Set n = ThisWorkbook.Names(nom)
    NomExiste = (Err.Number = 0)
    On Error GoTo 0
End Function

Public Function PlageNom(ByVal nom As String) As Range
    Set PlageNom = ThisWorkbook.Names(nom).RefersToRange
End Function

Public Function ValeurNom(ByVal nom As String) As Variant
    ValeurNom = ThisWorkbook.Names(nom).RefersToRange.Cells(1, 1).Value2
End Function

Public Function Param(ByVal nom As String) As Variant
    Param = ValeurNom(nom)
End Function

Public Sub SupprimerNoms()
    Dim i As Long, nm As String
    For i = ThisWorkbook.Names.Count To 1 Step -1
        nm = ThisWorkbook.Names(i).Name
        If Left$(nm, 1) <> "_" And InStr(nm, "!") = 0 Then ThisWorkbook.Names(i).Delete
    Next i
End Sub

' ---------------------------------------------------------------------
' Feuilles
' ---------------------------------------------------------------------
Public Function FeuilleExiste(ByVal nom As String) As Boolean
    Dim ws As Object
    On Error Resume Next ' toléré (R4) : test d'existence
    Set ws = ThisWorkbook.Sheets(nom)
    FeuilleExiste = (Err.Number = 0)
    On Error GoTo 0
End Function

Public Sub SupprimerFeuille(ByVal nom As String)
    If Not FeuilleExiste(nom) Then Exit Sub
    Application.DisplayAlerts = False
    ThisWorkbook.Sheets(nom).Visible = xlSheetVisible
    ThisWorkbook.Sheets(nom).Delete
    Application.DisplayAlerts = True
End Sub

Public Function NouvelleFeuille(ByVal nom As String) As Worksheet
    Dim ws As Worksheet
    SupprimerFeuille nom
    Set ws = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Sheets(ThisWorkbook.Sheets.Count))
    ws.Name = nom
    Set NouvelleFeuille = ws
End Function

Public Function Feuille(ByVal nom As String) As Worksheet
    Set Feuille = ThisWorkbook.Worksheets(nom)
End Function

Public Sub EntetesTable(ByVal ws As Worksheet, ByVal ligne As Long, ByVal col As Long, _
                        ByVal titres As Variant, Optional ByVal derivee As Boolean = True)
    Dim i As Long
    For i = LBound(titres) To UBound(titres)
        ws.Cells(ligne, col + i - LBound(titres)).Value2 = titres(i)
    Next i
    FormaterEntetes ws.Range(ws.Cells(ligne, col), ws.Cells(ligne, col + UBound(titres) - LBound(titres))), derivee
End Sub

Public Sub FormaterEntetes(ByVal plage As Range, ByVal derivee As Boolean)
    plage.Font.Bold = True
    If derivee Then
        plage.Interior.Color = COUL_ENTETE_DERIVEE
        plage.Font.Color = COUL_TEXTE_DERIVEE
    Else
        plage.Interior.Color = COUL_ENTETE_BRUTE
    End If
End Sub

Public Sub FormaterSynthese(ByVal plage As Range)
    plage.Interior.Color = COUL_FORMULE_FOND
    plage.Borders.Color = COUL_BORD
End Sub

Public Sub AjusterColonnes(ByVal ws As Worksheet)
    Dim c As Range, ur As Range
    Set ur = ws.UsedRange
    ur.Resize(Application.Min(ur.Rows.Count, LIGNES_AJUSTEMENT)).Columns.AutoFit
    For Each c In ur.Columns
        If c.ColumnWidth < LARGEUR_MIN_COL Then c.ColumnWidth = LARGEUR_MIN_COL
        If c.ColumnWidth > LARGEUR_MAX_COL Then c.ColumnWidth = LARGEUR_MAX_COL
    Next c
End Sub

' Volets figés sous la ligne 1 (sans sélection : fenêtre de la feuille active)
Public Sub FigerEntete(ByVal ws As Worksheet)
    Dim visible As Long, active As Object
    On Error Resume Next ' toléré (R4) : opération cosmétique, exige une fenêtre
    Set active = ActiveSheet
    visible = ws.Visible
    ws.Visible = xlSheetVisible
    ws.Activate                         ' exception R3 : réglage de fenêtre
    ActiveWindow.FreezePanes = False
    ActiveWindow.SplitColumn = 0
    ActiveWindow.SplitRow = 1
    ActiveWindow.FreezePanes = True
    ActiveWindow.DisplayGridlines = True
    If Not active Is Nothing Then active.Activate
    ws.Visible = visible
    On Error GoTo 0
End Sub

Public Function LettreCol(ByVal n As Long) As String
    Dim s As String, r As Long
    Do While n > 0
        r = (n - 1) Mod 26
        s = Chr$(65 + r) & s
        n = (n - 1) \ 26
    Loop
    LettreCol = s
End Function

Public Function Dico() As Object
    Set Dico = CreateObject("Scripting.Dictionary")
    Dico.CompareMode = vbBinaryCompare
End Function

' Écrit un tableau 2D (1..n, 1..m) à partir d'une cellule
Public Sub EcrireBloc(ByVal cellule As Range, tableau As Variant)
    Dim n As Long, m As Long
    n = UBound(tableau, 1) - LBound(tableau, 1) + 1
    m = UBound(tableau, 2) - LBound(tableau, 2) + 1
    cellule.Resize(n, m).Value2 = tableau
End Sub

' Formule d'une colonne entière en une instruction (R2) ; matricielle si demandé
Public Sub FormuleColonne(ByVal plage As Range, ByVal formule As String)
    plage.Formula = formule
End Sub

Public Sub FormuleMatricielle(ByVal cellule As Range, ByVal formule As String)
    cellule.FormulaArray = formule
End Sub

' Texte de cellule lisible : valeur numérique ou tiret long
Public Function TexteCellule(ByVal v As Variant) As String
    If IsError(v) Or IsEmpty(v) Then
        TexteCellule = Tiret()
    Else
        TexteCellule = CStr(v)
    End If
End Function
