Attribute VB_Name = "modApp"
Option Explicit
' =====================================================================
' modApp : points d'entrée, état (CALC), gestion d'erreur, moteur.
' =====================================================================

Public Const MDP As String = "primelab2026"
Public Const F_CALC As String = "CALC"
Public Const F_RECETTE As String = "Recette"

Public gEtape As String
Public gSilencieux As Boolean

Private Const LISTE_TRAVAIL As String = "Qualite,Journal,Historique_,Exploratoire,Bornes,Classes,Selection," & _
    "Associations,Cellules,GLM_Frequence,GLM_Cout,Graves,Tarif,Impact,Segments,Calculateur,Controles,Recette"
Private Const LISTE_DONNEES As String = "Contrats,Sinistres,Triangle,TarifActuel,Parametres"
Private Const COUL_ONGLET_TRAVAIL As Long = 16765401  ' lavande
Private Const COUL_ONGLET_DONNEES As Long = 15721958  ' bord_2
Private Const COUL_ONGLET_RECETTE As Long = 6657562   ' vert
Private Const NB_PARTIES_MOTEUR As Long = 5
Private Const FICHIER_TRACE As String = "trace_construction.txt"
Private Const NOM_BOUTON_RETOUR As String = "bouton_retour_page"
Private Const CV_MIN As Long = 3
Private Const CV_MAX As Long = 15
Private Const CRM_BONUS As Double = 0.95
Private Const CRM_SINISTRE As Double = 1.25
Private Const PAS_CHARGEMENT As Double = 0.005
Private Const CHARGEMENT_MAX As Double = 0.5
Private Const RESTE_MIN As Double = 0.05
Private Const DOSSIER_CAPTURES As String = "captures"

' ---------------------------------------------------------------------
' Gestion d'erreur et état de l'application (R4, R9)
' ---------------------------------------------------------------------
Public Sub ModeSilencieux(Optional ByVal actif As Boolean = True)
    gSilencieux = actif
End Sub

Public Sub DebutTraitement()
    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.Calculation = xlCalculationManual
    Application.Cursor = xlWait
End Sub

Public Sub FinTraitement()
    Application.Calculation = xlCalculationAutomatic
    Application.EnableEvents = True
    Application.ScreenUpdating = True
    Application.Cursor = xlDefault
    Application.StatusBar = False
End Sub

Public Sub Calculer()
    Tracer "  calcul"
    Application.Calculate
End Sub

' Étape courante (R4) et trace de progression sur disque en mode silencieux (tests automatisés)
Public Sub Marquer(ByVal etape As String)
    gEtape = etape
    Tracer etape
End Sub

Public Sub Tracer(ByVal texte As String)
    Dim f As Integer
    If Not gSilencieux Then Exit Sub
    On Error Resume Next ' toléré (R4) : trace facultative
    f = FreeFile
    Open ThisWorkbook.Path & Application.PathSeparator & FICHIER_TRACE For Append As #f
    Print #f, Format$(Now, "hh:nn:ss") & " " & texte
    Close #f
    On Error GoTo 0
End Sub

Public Sub GererErreur()
    Dim msg As String
    msg = "Étape : " & gEtape & vbLf & "Erreur " & Err.Number & " : " & Err.Description
    On Error Resume Next ' toléré (R4) : restauration au mieux
    FinTraitement
    Application.DisplayAlerts = True
    EcrireEtat "B12", msg
    On Error GoTo 0
    Debug.Print msg
    If Not gSilencieux Then MsgBox msg, vbCritical, "PrimeLab"
End Sub

Public Sub EcrireEtat(ByVal adresse As String, ByVal valeur As Variant)
    Dim ws As Worksheet, protegee As Boolean
    If Not FeuilleExiste(F_CALC) Then Exit Sub
    Set ws = ThisWorkbook.Worksheets(F_CALC)
    protegee = ws.ProtectContents
    If protegee Then ws.Unprotect MDP
    ws.Range(adresse).Value2 = valeur
    If protegee Then ws.Protect Password:=MDP
End Sub

Public Function LireEtat(ByVal adresse As String) As Variant
    LireEtat = ThisWorkbook.Worksheets(F_CALC).Range(adresse).Value2
End Function

' Feuille CALC (5.2), recréée à la construction
Public Sub CreerFeuilleCalc()
    Dim ws As Worksheet, lib As Variant, i As Long
    Set ws = NouvelleFeuille(F_CALC)
    lib = Array("page_active", "mode_admin", "exercice_tb", "onglet_segment", "variable_06", "variable_07", _
                "modele_09", "feuille_ouverte", "police_jakarta", "derniere_construction", "derniere_erreur")
    ws.Range("A1").Value2 = "etat": ws.Range("B1").Value2 = "valeur"
    For i = 0 To UBound(lib)
        ws.Cells(i + 2, 1).Value2 = lib(i)
    Next i
    ws.Range("B2").Value2 = 0
    ws.Range("B3").Value2 = 0
    ws.Range("B4").Formula = "=annee_fin"
    ws.Range("B4").Value2 = ws.Range("B4").Value2
    ws.Range("B5").Value2 = "age"
    ws.Range("B6").Value2 = "age"
    ws.Range("B7").Value2 = "age"
    ws.Range("B8").Value2 = "F"
End Sub

' ---------------------------------------------------------------------
' Moteur (phase 1)
' ---------------------------------------------------------------------
Public Sub ConstruireMoteur()
    Dim t0 As Double
    On Error GoTo Erreur
    t0 = Timer
    DebutTraitement
    MoteurComplet
    FinTraitement
    EcrireEtat "B11", "Moteur construit le " & TexteDate(Date) & " en " & FormatNombre(Timer - t0, 1) & " s"
    EcrireEtat "B12", ""
    Exit Sub
Erreur:
    GererErreur
End Sub

Public Sub MoteurComplet()
    Dim k As Long
    For k = 1 To NB_PARTIES_MOTEUR
        MoteurPartie k
    Next k
End Sub

' Construction du moteur par parties (chacune reprend l'état depuis les feuilles)
Public Sub ConstruireMoteurPartie(ByVal k As Long)
    On Error GoTo Erreur
    DebutTraitement
    If k > 1 Then RestaurerEtatMoteur
    MoteurPartie k
    FinTraitement
    Exit Sub
Erreur:
    GererErreur
End Sub

Public Sub RestaurerEtatMoteur()
    BornesDonnees
    ChargerTranches
    If FeuilleExiste(F_CLASSES) And FeuilleExiste(F_BORNES) Then ChargerClassesDepuisFeuilles
End Sub

Private Sub MoteurPartie(ByVal k As Long)
    Select Case k
        Case 1
            Marquer "Préparation"
            PreparerDonnees
            SupprimerFeuillesTravail
            SupprimerNoms
            CreerNomsDeBase
            CreerFeuilleCalc
            CreerFeuilleControles
            Marquer "Étape 01": Etape01
            Marquer "Étape 02": Etape02
            Calculer
        Case 2
            Marquer "Étape 03": Etape03
            Marquer "Étape 04": Etape04
            Marquer "Étape 05": Etape05
            Calculer
            Marquer "Journal": EcrireTrisQualite: CreerJournal
        Case 3
            Marquer "Étape 06": Etape06
            Calculer
            Marquer "Étape 07": Etape07
            Calculer
            Marquer "Étape 08": Etape08Formules
            Calculer
            Etape08Decisions
        Case 4
            Marquer "Étape 09 (colonnes)": Etape09Colonnes
            Calculer
            Marquer "Étape 09 (cellules)": Etape09Cellules
            Calculer
            Marquer "Étape 09 (IRLS)": Etape09Modeles
            Calculer
            Marquer "Étape 09 (quintiles)": CalculerQuintiles
        Case 5
            Marquer "Étape 10": Etape10Liste: Etape10Synthese: FormulePrimePure0
            Calculer
            Marquer "Étape 11": Etape11Tarif: Etape11Impact: Etape11Relativites
            Marquer "Tableau de bord": ConstruireSegments
            Marquer "Calculateur": ConstruireCalculateur
            Calculer
            Marquer "Bandeaux": CalculerBandeaux
            Marquer "Mise en forme": MettreEnFormeFeuilles
    End Select
End Sub

Public Sub SupprimerFeuillesTravail()
    Dim noms As Variant, i As Long
    noms = Split(LISTE_TRAVAIL & "," & F_CALC, ",")
    For i = 0 To UBound(noms)
        SupprimerFeuille CStr(noms(i))
    Next i
End Sub

' Ordre des onglets, couleurs, largeurs, volets (section 7)
Public Sub MettreEnFormeFeuilles()
    Dim tr As Variant, dn As Variant, i As Long, ws As Worksheet, apres As Object
    tr = Split(LISTE_TRAVAIL, ","): dn = Split(LISTE_DONNEES, ",")
    FormaterFeuillesDonnees
    Set apres = Nothing
    For i = 0 To UBound(tr)
        If FeuilleExiste(CStr(tr(i))) Then
            Set ws = Feuille(CStr(tr(i)))
            If apres Is Nothing Then ws.Move Before:=ThisWorkbook.Sheets(1) Else ws.Move After:=apres
            Set apres = ws
            ws.Tab.Color = COUL_ONGLET_TRAVAIL
            AjusterColonnes ws
        End If
    Next i
    For i = 0 To UBound(dn)
        Set ws = Feuille(CStr(dn(i)))
        ws.Move After:=apres
        Set apres = ws
        ws.Tab.Color = COUL_ONGLET_DONNEES
    Next i
    If FeuilleExiste(F_RECETTE) Then Feuille(F_RECETTE).Tab.Color = COUL_ONGLET_RECETTE
    Feuille(F_CALC).Move After:=ThisWorkbook.Sheets(ThisWorkbook.Sheets.Count)
End Sub

' Changement du seuil d'écrêtement (puces de l'étape 05) : 6.0
Public Sub AppliquerSeuil(ByVal u As Double)
    PlageNom("seuil_ecretement").Value2 = u
    Calculer
    Marquer "Seuil : IRLS Gamma"
    RelancerCoutEtGraves
    Calculer
    Marquer "Seuil : quintiles"
    CalculerQuintiles
    CalculerBandeaux
End Sub

Public Sub ChangerSeuil(ByVal u As Double)
    On Error GoTo Erreur
    DebutTraitement
    AppliquerSeuil u
    FinTraitement
    Exit Sub
Erreur:
    GererErreur
End Sub

' =====================================================================
' Application complète : construction, recalcul, pages
' =====================================================================
Public Sub ConstruireApplication()
    Dim t0 As Double
    On Error GoTo Erreur
    t0 = Timer
    DebutTraitement
    Marquer "Interface"
    DeprotegerTout
    RestaurerInterfaceExcel
    SupprimerPages
    MoteurComplet
    TerminerConstruction t0
    Exit Sub
Erreur:
    GererErreur
End Sub

' Seconde moitié de la construction, après ConstruireMoteur et un enregistrement :
' utile si Office se ferme avant la fin d'une construction complète
Public Sub ConstruireInterface()
    On Error GoTo Erreur
    DebutTraitement
    DeprotegerTout
    RestaurerEtatMoteur
    SupprimerPages
    TerminerConstruction Timer
    Exit Sub
Erreur:
    GererErreur
End Sub

Private Sub TerminerConstruction(ByVal t0 As Double)
    Dim res As String
    Marquer "Pages"
    ReinitialiserPolice
    EcrireEtat "B10", IIf(PoliceJakarta(), 1, 0)
    ConstruirePages
    Marquer "Recette"
    RecetteRapide
    res = ResultatRecette()
    EcrireEtat "B11", "Construite le " & TexteDate(Date) & " en " & FormatNombre(Timer - t0, 0) & " s"
    EcrireEtat "B12", ""
    Marquer "Protections"
    ProtegerTout
    FinTraitement
    ModeApplication
    If Not gSilencieux Then MsgBox MessageConstruction(Timer - t0, res), vbInformation, "PrimeLab"
End Sub

' Relance du moteur sans reconstruction des pages (mode administration)
Public Sub RecalculerEtude()
    Dim etat As Variant
    On Error GoTo Erreur
    DebutTraitement
    DeprotegerTout
    etat = ThisWorkbook.Worksheets(F_CALC).Range("B2:B10").Value2
    MoteurComplet
    ThisWorkbook.Worksheets(F_CALC).Range("B2:B10").Value2 = etat
    Marquer "Pages"
    ReconstruireGraphiqueTableau
    MajToutesPagesProtegees
    ProtegerTout
    FinTraitement
    Exit Sub
Erreur:
    GererErreur
End Sub

Public Sub ReconstruirePages()
    On Error GoTo Erreur
    DebutTraitement
    DeprotegerTout
    SupprimerPages
    ConstruirePages
    ProtegerTout
    FinTraitement
    AllerPage 0
    Exit Sub
Erreur:
    GererErreur
End Sub

Public Sub MajToutesPagesProtegees()
    Dim n As Long
    For n = 0 To NB_PAGES - 1
        MajPageProtegee n
    Next n
End Sub

Public Sub MajPageProtegee(ByVal n As Long)
    If Not FeuilleExiste(NomPage(n)) Then Exit Sub
    FeuillePage(n).Unprotect MDP
    MajPage n
    ProtegerPage FeuillePage(n)
End Sub

' =====================================================================
' Protections (section 13)
' =====================================================================
Public Sub ProtegerPage(ByVal ws As Worksheet)
    ws.Protect Password:=MDP, DrawingObjects:=True, Contents:=True, Scenarios:=True
    ws.EnableSelection = xlNoSelection
End Sub

Public Sub ProtegerTout()
    Dim n As Long, ws As Worksheet, co As ChartObject
    ThisWorkbook.Unprotect MDP
    For n = 0 To NB_PAGES - 1
        If FeuilleExiste(NomPage(n)) Then
            Set ws = FeuillePage(n)
            For Each co In ws.ChartObjects
                co.Chart.ProtectFormatting = True: co.Chart.ProtectData = True: co.Chart.ProtectSelection = True
            Next co
            ProtegerPage ws
        End If
    Next n
    For Each ws In ThisWorkbook.Worksheets
        If NumeroPage(ws.Name) < 0 Then
            ws.Protect Password:=MDP, DrawingObjects:=True, Contents:=True
            ws.EnableSelection = xlNoRestrictions
            If ws.Name = F_CALC Then
                ws.Visible = xlSheetVeryHidden
            ElseIf Not ModeAdminActif() Then
                ws.Visible = xlSheetHidden
            End If
        End If
    Next ws
    ThisWorkbook.Protect Password:=MDP, Structure:=True
End Sub

Public Sub DeprotegerTout()
    Dim ws As Worksheet
    On Error Resume Next ' toléré (R4) : feuilles déjà déprotégées
    ThisWorkbook.Unprotect MDP
    For Each ws In ThisWorkbook.Worksheets
        ws.Unprotect MDP
    Next ws
    On Error GoTo 0
End Sub

' =====================================================================
' Interface : modes application et administration (section 13)
' =====================================================================
Public Function ModeAdminActif() As Boolean
    ModeAdminActif = False
    If FeuilleExiste(F_CALC) Then ModeAdminActif = (Val(CStr(LireEtat("B3"))) = 1)
End Function

Public Sub ModeApplication()
    On Error GoTo Erreur
    Application.ScreenUpdating = False
    ThisWorkbook.Unprotect MDP
    ThisWorkbook.Worksheets(F_CALC).Unprotect MDP
    EcrireEtat "B3", 0
    ThisWorkbook.Worksheets(F_CALC).Protect Password:=MDP
    MasquerFeuillesTravail
    ThisWorkbook.Protect Password:=MDP, Structure:=True
    AppliquerInterfaceApp
    DefinirRaccourcis
    AllerPage CLng(Val(CStr(LireEtat("B2"))))
    Application.ScreenUpdating = True
    Exit Sub
Erreur:
    GererErreur
End Sub

Public Sub ModeAdmin()
    Dim ws As Worksheet
    On Error GoTo Erreur
    Application.ScreenUpdating = False
    FermerBulle
    ThisWorkbook.Unprotect MDP
    ThisWorkbook.Worksheets(F_CALC).Unprotect MDP
    EcrireEtat "B3", 1
    ThisWorkbook.Worksheets(F_CALC).Protect Password:=MDP
    For Each ws In ThisWorkbook.Worksheets
        If ws.Name <> F_CALC Then ws.Visible = xlSheetVisible
    Next ws
    SupprimerBoutonRetour
    RestaurerInterfaceExcel
    Application.ScreenUpdating = True
    Exit Sub
Erreur:
    GererErreur
End Sub

Public Sub BasculerMode()
    If ModeAdminActif() Then ModeApplication Else ModeAdmin
End Sub

Private Sub MasquerFeuillesTravail()
    Dim ws As Worksheet
    For Each ws In ThisWorkbook.Worksheets
        If NumeroPage(ws.Name) >= 0 Then
            ws.Visible = xlSheetVisible
        ElseIf ws.Name = F_CALC Then
            ws.Visible = xlSheetVeryHidden
        Else
            ws.Visible = xlSheetHidden
        End If
    Next ws
End Sub

Public Sub AppliquerInterfaceApp()
    On Error Resume Next ' toléré (R4) : réglages d'interface sans fenêtre active
    Application.ExecuteExcel4Macro "SHOW.TOOLBAR(""Ribbon"",False)"
    Application.DisplayFormulaBar = False
    Application.DisplayStatusBar = False
    With ActiveWindow
        .DisplayWorkbookTabs = False
        .DisplayHeadings = False
        .DisplayGridlines = False
        .DisplayHorizontalScrollBar = False
        .DisplayVerticalScrollBar = False
    End With
    On Error GoTo 0
End Sub

Public Sub RestaurerInterfaceExcel()
    On Error Resume Next ' toléré (R4) : réglages d'interface sans fenêtre active
    Application.ExecuteExcel4Macro "SHOW.TOOLBAR(""Ribbon"",True)"
    Application.DisplayFormulaBar = True
    Application.DisplayStatusBar = True
    With ActiveWindow
        .DisplayWorkbookTabs = True
        .DisplayHeadings = True
        .DisplayHorizontalScrollBar = True
        .DisplayVerticalScrollBar = True
    End With
    RetirerRaccourcis
    On Error GoTo 0
End Sub

Public Sub DefinirRaccourcis()
    Application.OnKey "^+M", "'" & ThisWorkbook.Name & "'!BasculerMode"
    Application.OnKey "^+m", "'" & ThisWorkbook.Name & "'!BasculerMode"
    Application.OnKey "^{PGDN}", "'" & ThisWorkbook.Name & "'!PageSuivante"
    Application.OnKey "^{PGUP}", "'" & ThisWorkbook.Name & "'!PagePrecedente"
    Application.OnKey "{ESC}", "'" & ThisWorkbook.Name & "'!ToucheEchap"
End Sub

Public Sub RetirerRaccourcis()
    Application.OnKey "^{PGDN}"
    Application.OnKey "^{PGUP}"
    Application.OnKey "{ESC}"
    Application.OnKey "^+M", "'" & ThisWorkbook.Name & "'!BasculerMode"
    Application.OnKey "^+m", "'" & ThisWorkbook.Name & "'!BasculerMode"
End Sub

' Zoom pour que le canevas 960 x 540 tienne dans la fenêtre
Public Sub AjusterZoom()
    Dim z As Double
    On Error Resume Next ' toléré (R4) : fenêtre réduite ou feuille non page
    If NumeroPage(ActiveSheet.Name) < 0 Then Exit Sub
    ActiveWindow.Zoom = 100
    z = Application.Min(ActiveWindow.UsableWidth / CANEVAS_L, ActiveWindow.UsableHeight / CANEVAS_H) * 100
    If z < 10 Then z = 10
    If z > 400 Then z = 400
    ActiveWindow.Zoom = Int(z)              ' exception R3 : réglage de fenêtre
    ActiveWindow.ScrollRow = 1: ActiveWindow.ScrollColumn = 1
    On Error GoTo 0
End Sub

' =====================================================================
' Événements du classeur (appelés par ThisWorkbook)
' =====================================================================
Public Sub InitialiserApplication()
    On Error GoTo Erreur
    If Not FeuilleExiste(F_CALC) Or Not FeuilleExiste(NomPage(0)) Then Exit Sub
    ReinitialiserPolice
    DeprotegerTout
    ProtegerTout
    If ModeAdminActif() Then ModeAdmin Else ModeApplication
    Exit Sub
Erreur:
    GererErreur
End Sub

Public Sub FermetureApplication()
    On Error Resume Next ' toléré (R4) : fermeture
    AnnulerMinuterieBulle
    RestaurerInterfaceExcel
    Application.OnKey "^+M"
    Application.OnKey "^+m"
    On Error GoTo 0
End Sub

Public Sub ActivationClasseur()
    If Not FeuilleExiste(F_CALC) Then Exit Sub
    If Not ModeAdminActif() Then AppliquerInterfaceApp: DefinirRaccourcis: AjusterZoom
End Sub

Public Sub DesactivationClasseur()
    If Not FeuilleExiste(F_CALC) Then Exit Sub
    If Not ModeAdminActif() Then RestaurerInterfaceExcel
End Sub

Public Function BloquerClic() As Boolean
    BloquerClic = False
    If FeuilleExiste(F_CALC) Then BloquerClic = Not ModeAdminActif()
End Function

' =====================================================================
' Navigation (9.1)
' =====================================================================
Public Sub AllerPage(ByVal n As Long)
    Dim ws As Worksheet
    On Error GoTo Erreur
    If n < 0 Or n > NB_PAGES - 1 Then n = 0
    If Not FeuilleExiste(NomPage(n)) Then Exit Sub
    FermerBulle
    Set ws = FeuillePage(n)
    If ws.Visible <> xlSheetVisible Then ThisWorkbook.Unprotect MDP: ws.Visible = xlSheetVisible: _
        ThisWorkbook.Protect Password:=MDP, Structure:=True
    ws.Activate                              ' exception R3 : navigation
    ThisWorkbook.Worksheets(F_CALC).Unprotect MDP
    EcrireEtat "B2", n
    ThisWorkbook.Worksheets(F_CALC).Protect Password:=MDP
    If Not ModeAdminActif() Then AppliquerInterfaceApp
    AjusterZoom
    Exit Sub
Erreur:
    GererErreur
End Sub

Public Sub PageSuivante()
    AllerPage (PageActive() + 1) Mod NB_PAGES
End Sub

Public Sub PagePrecedente()
    AllerPage (PageActive() + NB_PAGES - 1) Mod NB_PAGES
End Sub

Public Function PageActive() As Long
    PageActive = NumeroPage(ActiveSheet.Name)
    If PageActive < 0 Then PageActive = CLng(Val(CStr(LireEtat("B2"))))
End Function

Private Function Appelant() As String
    On Error Resume Next ' toléré (R4) : appel hors forme
    Appelant = CStr(Application.Caller)
    On Error GoTo 0
End Function

Public Sub ClicNavigation()
    Dim c As String, n As Long, page As Long
    c = Appelant()
    page = CLng(Val(Mid$(c, 2, 2)))
    If InStr(c, "_sb_calc") > 0 Then
        n = 12
    ElseIf InStr(c, "_nav_prec") > 0 Then
        n = page - 1
    ElseIf InStr(c, "_nav_suiv") > 0 Then
        n = page + 1
    ElseIf InStr(c, "_nav_") > 0 Then
        n = CLng(Val(Mid$(c, InStr(c, "_nav_") + 5, 2)))
    Else
        Exit Sub
    End If
    AllerPage n
End Sub

Public Sub ClicBandeau()
    AllerPage 1
End Sub

Public Sub ToucheEchap()
    If Len(CStr(LireEtat("B9"))) > 0 And NumeroPage(ActiveSheet.Name) < 0 Then
        RetourPage
    Else
        FermerBulle
    End If
End Sub

' =====================================================================
' Puces et boutons (12.1, 6.13)
' =====================================================================
Public Sub ClicPuce()
    Dim c As String, page As Long, reste As String, groupe As String, valeur As String, ws As Worksheet, p As Long
    On Error GoTo Erreur
    c = Appelant()
    If InStr(c, "~") > 0 Then c = Left$(c, InStr(c, "~") - 1)
    page = CLng(Val(Mid$(c, 2, 2)))
    reste = Mid$(c, InStr(c, "_puce_") + 6)
    p = InStr(reste, "_")
    groupe = Left$(reste, p - 1): valeur = Mid$(reste, p + 1)
    Set ws = FeuillePage(page)
    If PuceActive(page, groupe) = valeur Then Exit Sub
    Application.ScreenUpdating = False
    ws.Unprotect MDP
    AppliquerPuce ws, page, groupe, valeur
    ProtegerPage ws
    Application.ScreenUpdating = True
    Exit Sub
Erreur:
    GererErreur
End Sub

Private Function PuceActive(ByVal page As Long, ByVal groupe As String) As String
    Select Case groupe
        Case "annee": PuceActive = CStr(LireEtat("B4"))
        Case "seg": PuceActive = CStr(LireEtat("B5"))
        Case "var": PuceActive = CStr(LireEtat(IIf(page = 6, "B6", "B7")))
        Case "modele": PuceActive = CStr(LireEtat("B8"))
        Case "seuil": PuceActive = CStr(Param("seuil_ecretement"))
        Case "zone": PuceActive = CStr(ValeurNom("calc_zone"))
        Case "usage": PuceActive = CStr(ValeurNom("calc_usage"))
    End Select
End Function

Private Sub AppliquerPuce(ByVal ws As Worksheet, ByVal page As Long, ByVal groupe As String, ByVal valeur As String)
    Dim adr As String
    Select Case groupe
        Case "annee", "seg", "var", "modele"
            adr = Choose(Application.Match(groupe, Array("annee", "seg", "var", "modele"), 0), "B4", "B5", _
                IIf(page = 6, "B6", "B7"), "B8")
            ThisWorkbook.Worksheets(F_CALC).Unprotect MDP
            If groupe = "annee" Then EcrireEtat adr, CLng(valeur) Else EcrireEtat adr, valeur
            ThisWorkbook.Worksheets(F_CALC).Protect Password:=MDP
            If groupe = "seg" Then ActiverOnglet ws, page, groupe, valeur Else ActiverPuce ws, page, groupe, valeur
            MajPage page
        Case "seuil"
            ChangerSeuilApplication CDbl(valeur)
        Case "zone", "usage"
            Feuille(F_CALCULATEUR).Unprotect MDP
            PlageNom("calc_" & groupe).Value2 = valeur
            Feuille(F_CALCULATEUR).Calculate
            Feuille(F_CALCULATEUR).Protect Password:=MDP, DrawingObjects:=True, Contents:=True
            MajPage 12
    End Select
End Sub

' Puce de seuil : moteur partiel (6.0) puis rafraîchissement de toutes les pages
Public Sub ChangerSeuilApplication(ByVal u As Double)
    Dim n As Long
    On Error GoTo Erreur
    DebutTraitement
    DeprotegerTout
    AppliquerSeuil u
    For n = 0 To NB_PAGES - 1
        If n = 5 Then ActiverPuce FeuillePage(5), 5, "seuil", CStr(u)
        MajPage n
    Next n
    ProtegerTout
    FinTraitement
    Exit Sub
Erreur:
    GererErreur
End Sub

Public Sub ClicCalc()
    Dim c As String, ws As Worksheet, cle As String, plus As Boolean
    On Error GoTo Erreur
    c = Appelant()
    Set ws = Feuille(F_CALCULATEUR)
    Application.ScreenUpdating = False
    ws.Unprotect MDP
    If InStr(c, "_reinit") > 0 Then
        ReinitialiserEntrees
    Else
        cle = Mid$(c, InStr(c, "_btn_") + 5)
        plus = (Right$(cle, 5) = "_plus")
        cle = Left$(cle, InStr(cle, "_") - 1)
        ModifierEntree cle, plus
    End If
    ws.Calculate
    ws.Protect Password:=MDP, DrawingObjects:=True, Contents:=True
    MajPageProtegee 12
    Application.ScreenUpdating = True
    Exit Sub
Erreur:
    GererErreur
End Sub

Private Sub ModifierEntree(ByVal cle As String, ByVal plus As Boolean)
    Dim v As Double, nom As String, k As Long, autres As Double
    Select Case cle
        Case "age"
            v = ValeurNom("calc_age") + IIf(plus, 1, -1)
            If v >= Param("age_min") And v <= Param("age_max") Then PlageNom("calc_age").Value2 = v
        Case "cv"
            v = ValeurNom("calc_cv") + IIf(plus, 1, -1)
            If v >= CV_MIN And v <= CV_MAX Then PlageNom("calc_cv").Value2 = v
        Case "crm"
            v = ValeurNom("calc_crm")
            If plus Then
                v = Application.Min(CDbl(Param("crm_max")), Int(v * CRM_SINISTRE * 100 + 0.000001) / 100)
            Else
                v = Application.Max(CDbl(Param("crm_min")), Int(v * CRM_BONUS * 100 + 0.000001) / 100)
            End If
            PlageNom("calc_crm").Value2 = v
        Case Else
            k = CLng(Val(Mid$(cle, 3)))
            nom = Choose(k + 1, "calc_securite", "calc_gestion", "calc_acquisition", "calc_marge", "calc_taxes")
            v = ArrondiArith(ValeurNom(nom) + IIf(plus, PAS_CHARGEMENT, -PAS_CHARGEMENT), 4)
            If v < 0 Or v > CHARGEMENT_MAX Then Exit Sub
            If k >= 1 And k <= 3 Then
                autres = ValeurNom("calc_gestion") + ValeurNom("calc_acquisition") + ValeurNom("calc_marge") - ValeurNom(nom) + v
                If 1 - autres < RESTE_MIN Then
                    If Not gSilencieux Then MsgBox MessageChargementRefuse(), vbExclamation, "PrimeLab"
                    Exit Sub
                End If
            End If
            PlageNom(nom).Value2 = v
    End Select
End Sub

' =====================================================================
' Bulles d'aide (12.3)
' =====================================================================
Public Sub ClicInfo()
    Dim c As String, page As Long, cle As String, ws As Worksheet
    c = Appelant()
    page = CLng(Val(Mid$(c, 2, 2)))
    cle = Mid$(c, InStr(c, "_info_") + 6)
    Set ws = FeuillePage(page)
    ws.Unprotect MDP
    AfficherBulle ws, page, ws.Shapes(c), TitreAide(cle), TexteAide(cle)
    ProtegerPage ws
End Sub

Public Sub ClicMarque()
    Dim c As String, page As Long, ws As Worksheet
    c = Appelant()
    page = CLng(Val(Mid$(c, 2, 2)))
    Set ws = FeuillePage(page)
    ws.Unprotect MDP
    AfficherBulle ws, page, ws.Shapes(PrefixePage(page) & "sb_logo"), TitreAide("marque"), _
        TexteAide(IIf(PoliceJakarta(), "police_ok", "police_repli"))
    ProtegerPage ws
End Sub

Public Sub FermerBulle()
    Dim n As Long, ws As Worksheet
    On Error Resume Next ' toléré (R4) : bulle absente ou classeur en fermeture
    AnnulerMinuterieBulle
    n = PageActive()
    If n < 0 Or Not FeuilleExiste(NomPage(n)) Then Exit Sub
    Set ws = FeuillePage(n)
    ws.Unprotect MDP
    FermerBulleSurFeuille ws, n
    ProtegerPage ws
    On Error GoTo 0
End Sub

' =====================================================================
' Consultation d'une feuille de travail (12.4)
' =====================================================================
Public Sub ClicOuvrirOnglet()
    Dim c As String, page As Long, cible As String, ws As Worksheet
    c = Appelant()
    page = CLng(Val(Mid$(c, 2, 2)))
    If page = 12 Then
        cible = F_CALCULATEUR & "!" & PlageNom("calc_ttc").Address(False, False)
    Else
        cible = ThisWorkbook.Worksheets(NomPage(page)).Shapes(c).AlternativeText
    End If
    If InStr(cible, "!") = 0 Then Exit Sub
    AfficherFeuille Left$(cible, InStr(cible, "!") - 1), Mid$(cible, InStr(cible, "!") + 1)
End Sub

Public Sub AfficherFeuille(ByVal nom As String, ByVal cellule As String)
    Dim ws As Worksheet, s As Shape, L As Double, T As Double
    On Error GoTo Erreur
    If Not FeuilleExiste(nom) Then Exit Sub
    FermerBulle
    Application.ScreenUpdating = False
    ThisWorkbook.Unprotect MDP
    Set ws = Feuille(nom)
    ws.Visible = xlSheetVisible
    ws.Unprotect MDP
    ws.Activate                                          ' exception R3 : consultation
    ws.Range(cellule).Select                             ' exception R3 : cellule de la carte
    Application.DisplayFormulaBar = True
    ActiveWindow.DisplayHeadings = True
    ActiveWindow.DisplayHorizontalScrollBar = True
    ActiveWindow.DisplayVerticalScrollBar = True
    ActiveWindow.Zoom = 100
    SupprimerBoutonRetour
    With ActiveWindow.VisibleRange
        L = .Left + .Width - 130: T = .Top + 6
    End With
    Set s = ws.Shapes.AddShape(msoShapeRoundedRectangle, L, T, 120, 22)
    s.Name = NOM_BOUTON_RETOUR
    s.Adjustments.Item(1) = 0.5
    s.Fill.ForeColor.RGB = C_ENCRE: s.Line.Visible = msoFalse
    TexteDansForme s, TexteRetourPage(), F_BOLD, 9, C_BLANC
    s.OnAction = "'" & ThisWorkbook.Name & "'!RetourPage"
    s.Placement = xlFreeFloating
    ThisWorkbook.Worksheets(F_CALC).Unprotect MDP
    EcrireEtat "B9", nom
    ThisWorkbook.Worksheets(F_CALC).Protect Password:=MDP
    ws.Protect Password:=MDP, DrawingObjects:=False, Contents:=True
    ws.EnableSelection = xlNoRestrictions
    Application.ScreenUpdating = True
    Exit Sub
Erreur:
    GererErreur
End Sub

Public Sub RetourPage()
    On Error GoTo Erreur
    Application.ScreenUpdating = False
    SupprimerBoutonRetour
    ThisWorkbook.Unprotect MDP
    If Not ModeAdminActif() Then MasquerFeuillesTravail
    ThisWorkbook.Worksheets(F_CALC).Unprotect MDP
    EcrireEtat "B9", ""
    ThisWorkbook.Worksheets(F_CALC).Protect Password:=MDP
    ThisWorkbook.Protect Password:=MDP, Structure:=True
    If Not ModeAdminActif() Then AppliquerInterfaceApp
    AllerPage CLng(Val(CStr(LireEtat("B2"))))
    Application.ScreenUpdating = True
    Exit Sub
Erreur:
    GererErreur
End Sub

Private Sub SupprimerBoutonRetour()
    Dim nom As String, ws As Worksheet
    On Error Resume Next ' toléré (R4) : bouton absent
    nom = CStr(LireEtat("B9"))
    If Len(nom) = 0 Then Exit Sub
    Set ws = Feuille(nom)
    ws.Unprotect MDP
    ws.Shapes(NOM_BOUTON_RETOUR).Delete
    On Error GoTo 0
End Sub

Public Sub ReconstruireGraphiqueTableau()
    ' Le graphique pointe sur Historique_ : recréé si la feuille a été reconstruite
    If FeuilleExiste(NomPage(0)) Then
        FeuillePage(0).Unprotect MDP
        RecreerGraphiqueTableau FeuillePage(0)
    End If
End Sub

' Export des 13 pages en PNG (dossier captures à côté du classeur) : contrôle visuel contre les maquettes
Public Sub ExporterCaptures()
    Dim n As Long, ws As Worksheet, co As ChartObject, dossier As String
    On Error GoTo Erreur
    dossier = ThisWorkbook.Path & Application.PathSeparator & DOSSIER_CAPTURES
    If Len(Dir$(dossier, vbDirectory)) = 0 Then MkDir dossier
    Application.ScreenUpdating = True
    For n = 0 To NB_PAGES - 1
        Marquer "Capture " & n
        Set ws = FeuillePage(n)
        AllerPage n
        ws.Unprotect MDP
        ActiveWindow.Zoom = 100                                      ' exception R3 : capture
        ws.Range("A1:" & LettreCol(48) & "36").CopyPicture Appearance:=xlScreen, Format:=xlBitmap
        Set co = ws.ChartObjects.Add(0, 0, CANEVAS_L, CANEVAS_H)
        co.Chart.Paste
        co.Chart.Export dossier & Application.PathSeparator & NomPage(n) & ".png"
        co.Delete
        ProtegerPage ws
    Next n
    Exit Sub
Erreur:
    GererErreur
End Sub

' Auto-test des interactions (phase 3) : chaque action est jouée sans clic, puis l'état initial est rétabli
Public Sub TesterInteractions()
    Dim k As Long, cles As Variant
    On Error GoTo Erreur
    Marquer "Test : puces"
    TesterPuce 0, "annee", "2022": TesterPuce 0, "annee", CStr(Param("annee_fin"))
    TesterPuce 0, "seg", "zone": TesterPuce 0, "seg", "age"
    TesterPuce 6, "var", "couleur": TesterPuce 6, "var", "age"
    TesterPuce 7, "var", "puissance_cv": TesterPuce 7, "var", "age"
    TesterPuce 9, "modele", "C": TesterPuce 9, "modele", "F"
    Marquer "Test : seuils"
    ChangerSeuilApplication CDbl(Param("seuil_1"))
    ChangerSeuilApplication CDbl(Param("seuil_3"))
    Marquer "Test : calculateur"
    TesterPuce 12, "zone", "A": TesterPuce 12, "usage", "Professionnel"
    cles = Array("age", "cv", "crm", "ch0", "ch1", "ch2", "ch3", "ch4")
    For k = 0 To UBound(cles)
        Feuille(F_CALCULATEUR).Unprotect MDP
        ModifierEntree CStr(cles(k)), True
        ModifierEntree CStr(cles(k)), False
        Feuille(F_CALCULATEUR).Calculate
        MajPageProtegee 12
    Next k
    Feuille(F_CALCULATEUR).Unprotect MDP
    ReinitialiserEntrees
    Feuille(F_CALCULATEUR).Calculate
    MajPageProtegee 12
    Marquer "Test : navigation"
    For k = 0 To NB_PAGES - 1: AllerPage k: Next k
    PageSuivante: PagePrecedente
    AfficherFeuille F_TARIF, "E2"
    RetourPage
    ModeAdmin
    ModeApplication
    AllerPage 0
    Marquer "Test : terminé"
    Exit Sub
Erreur:
    GererErreur
End Sub

Private Sub TesterPuce(ByVal page As Long, ByVal groupe As String, ByVal valeur As String)
    Dim ws As Worksheet
    Set ws = FeuillePage(page)
    If PuceActive(page, groupe) = valeur Then Exit Sub
    ws.Unprotect MDP
    AppliquerPuce ws, page, groupe, valeur
    ProtegerPage ws
End Sub
