Attribute VB_Name = "modDonnees"
Option Explicit
' =====================================================================
' modDonnees : étapes 01 à 05 (colonnes dérivées, qualité, journal,
' triangle, historique, écrêtement) et feuille Controles.
' Formules en anglais (Excel 2013 : .Formula / .FormulaArray, voir NOTES.md).
' =====================================================================

Public Const F_CONTRATS As String = "Contrats"
Public Const F_SINISTRES As String = "Sinistres"
Public Const F_TRIANGLE As String = "Triangle"
Public Const F_TARIF_ACTUEL As String = "TarifActuel"
Public Const F_PARAMETRES As String = "Parametres"
Public Const F_QUALITE As String = "Qualite"
Public Const F_JOURNAL As String = "Journal"
Public Const F_HISTORIQUE As String = "Historique_"   ' « Historique » est réservé par Excel français
Public Const F_GRAVES As String = "Graves"
Public Const F_CONTROLES As String = "Controles"

Public gLigC As Long    ' dernière ligne de données de Contrats (25 075)
Public gLigS As Long    ' dernière ligne de données de Sinistres (921)
Public gLigT As Long    ' dernière ligne du triangle (11)

Private Const COL_C_DERIVEE As Long = 15      ' O : première colonne dérivée de Contrats
Private Const COL_S_DERIVEE As Long = 8       ' H : première colonne dérivée de Sinistres
Private Const COL_T_DERIVEE As Long = 13      ' M : première colonne dérivée du triangle
Private Const LIG_T_FACTEURS As Long = 13
Private Const NB_DEV As Long = 10
Private Const NB_SEUILS As Long = 5
Private Const FMT_DATE As String = "dd/mm/yyyy"
Private Const FMT_MONTANT As String = "#,##0.00"
Private Const FMT_EXPO As String = "0.000"
Private Const FMT_TAUX As String = "0.00%"
Private Const FMT_REL As String = "0.000"
Private Const FMT_COEF As String = "0.0000"
Private Const SEUIL_COMPLETUDE As String = "0.995"
Private Const NB_CONTROLES As Long = 33

' ---------------------------------------------------------------------
' Préparation : bornes des tables, nettoyage des colonnes dérivées (idempotence)
' ---------------------------------------------------------------------
Public Sub BornesDonnees()
    Dim wc As Worksheet, wsn As Worksheet, wt As Worksheet
    Set wc = Feuille(F_CONTRATS): Set wsn = Feuille(F_SINISTRES): Set wt = Feuille(F_TRIANGLE)
    gLigC = wc.Cells(wc.Rows.Count, 1).End(xlUp).Row
    gLigS = wsn.Cells(wsn.Rows.Count, 1).End(xlUp).Row
    gLigT = wt.Cells(LIG_T_FACTEURS - 2, 1).End(xlUp).Row
    If wt.Cells(LIG_T_FACTEURS - 2, 1).Value2 <> "" Then gLigT = LIG_T_FACTEURS - 2
End Sub

Public Sub PreparerDonnees()
    Dim wc As Worksheet, wsn As Worksheet, wt As Worksheet
    Set wc = Feuille(F_CONTRATS): Set wsn = Feuille(F_SINISTRES): Set wt = Feuille(F_TRIANGLE)
    BornesDonnees
    wc.Range(wc.Columns(COL_C_DERIVEE), wc.Columns(80)).Delete
    wsn.Range(wsn.Columns(COL_S_DERIVEE), wsn.Columns(40)).Delete
    wt.Range(wt.Columns(COL_T_DERIVEE), wt.Columns(30)).Delete
    wt.Range(wt.Rows(LIG_T_FACTEURS - 1), wt.Rows(LIG_T_FACTEURS + 10)).Delete
End Sub

' Noms des paramètres (A:B de Parametres) et des colonnes brutes (6.0, point 16)
Public Sub CreerNomsDeBase()
    Dim wp As Worksheet, r As Long, nom As String
    Set wp = Feuille(F_PARAMETRES)
    r = 2
    Do While Len(CStr(wp.Cells(r, 1).Value2)) > 0
        nom = CStr(wp.Cells(r, 1).Value2)
        DefinirNom nom, wp.Cells(r, 2)
        r = r + 1
    Loop
    NommerColonnes Feuille(F_CONTRATS), gLigC, Array("c_id", "c_exercice", "c_debut", "c_fin", "c_naissance", _
        "c_date_permis", "c_sexe", "c_zone", "c_puissance_cv", "c_usage", "c_date_mise_circulation", _
        "c_couleur", "c_crm", "c_prime"), 1
    NommerColonnes Feuille(F_SINISTRES), gLigS, Array("s_id", "s_idpol", "s_date", "s_date_declaration", _
        "s_garantie", "s_charge_vue", "s_statut"), 1
    CreerNomsTarifActuel
End Sub

Public Sub NommerColonnes(ByVal ws As Worksheet, ByVal derniere As Long, ByVal noms As Variant, ByVal col1 As Long)
    Dim i As Long
    For i = LBound(noms) To UBound(noms)
        DefinirNom CStr(noms(i)), ws.Range(ws.Cells(2, col1 + i - LBound(noms)), ws.Cells(derniere, col1 + i - LBound(noms)))
    Next i
End Sub

' Noms ta_... depuis TarifActuel (6.11)
Private Sub CreerNomsTarifActuel()
    Dim wa As Worksheet, r As Long, der As Long, v As String, debut As Object, fin As Object
    Set wa = Feuille(F_TARIF_ACTUEL)
    der = wa.Cells(wa.Rows.Count, 1).End(xlUp).Row
    Set debut = Dico(): Set fin = Dico()
    For r = 2 To der
        v = CStr(wa.Cells(r, 1).Value2)
        If Not debut.Exists(v) Then debut(v) = r
        fin(v) = r
    Next r
    DefinirNom "base_actuelle", wa.Cells(debut("base"), 5)
    DefinirNom "ta_age_min", wa.Range(wa.Cells(debut("age"), 3), wa.Cells(fin("age"), 3))
    DefinirNom "ta_age_rel", wa.Range(wa.Cells(debut("age"), 5), wa.Cells(fin("age"), 5))
    DefinirNom "ta_zone_mod", wa.Range(wa.Cells(debut("zone"), 2), wa.Cells(fin("zone"), 2))
    DefinirNom "ta_zone_rel", wa.Range(wa.Cells(debut("zone"), 5), wa.Cells(fin("zone"), 5))
    DefinirNom "ta_cv_min", wa.Range(wa.Cells(debut("puissance_cv"), 3), wa.Cells(fin("puissance_cv"), 3))
    DefinirNom "ta_cv_rel", wa.Range(wa.Cells(debut("puissance_cv"), 5), wa.Cells(fin("puissance_cv"), 5))
    DefinirNom "ta_usage_mod", wa.Range(wa.Cells(debut("usage"), 2), wa.Cells(fin("usage"), 2))
    DefinirNom "ta_usage_rel", wa.Range(wa.Cells(debut("usage"), 5), wa.Cells(fin("usage"), 5))
End Sub

' ---------------------------------------------------------------------
' Feuille Controles : 33 contrôles (3 par étape)
' ---------------------------------------------------------------------
Public Sub CreerFeuilleControles()
    Dim ws As Worksheet
    Set ws = NouvelleFeuille(F_CONTROLES)
    EntetesTable ws, 1, 1, Array("etape", "numero", "description", "statut", "valeur_1", "valeur_2")
    DefinirNom "ctl_statut", ws.Range("D2:D" & NB_CONTROLES + 1)
End Sub

Public Sub AjouterControle(ByVal etape As Long, ByVal k As Long, ByVal description As String, _
                           ByVal formule As String, Optional ByVal matricielle As Boolean = False, _
                           Optional ByVal valeur1 As String = "", Optional ByVal valeur2 As String = "")
    Dim ws As Worksheet, r As Long
    Set ws = Feuille(F_CONTROLES)
    r = (etape - 1) * 3 + k + 1
    ws.Cells(r, 1).Value2 = "'" & Format$(etape, "00")
    ws.Cells(r, 2).Value2 = k
    ws.Cells(r, 3).Value2 = description
    If matricielle Then ws.Cells(r, 4).FormulaArray = formule Else ws.Cells(r, 4).Formula = formule
    If Len(valeur1) > 0 Then ws.Cells(r, 5).Formula = valeur1
    If Len(valeur2) > 0 Then ws.Cells(r, 6).Formula = valeur2
End Sub

' ---------------------------------------------------------------------
' Étape 01 : import et exposition
' ---------------------------------------------------------------------
Public Sub Etape01()
    Dim ws As Worksheet, n As String
    Set ws = Feuille(F_CONTRATS)
    n = CStr(gLigC)
    EntetesTable ws, 1, COL_C_DERIVEE, Array("cle", "exposition", "age_brut", "age", "anc_permis", _
        "anc_vehicule", "crm_c", "e_crm")
    NommerColonnes ws, gLigC, Array("c_cle", "c_expo", "c_age_brut", "c_age", "c_anc_permis", _
        "c_anc_vehicule", "c_crm_c", "c_e_crm"), COL_C_DERIVEE
    CreerQualiteMedianes
    ws.Range("O2:O" & n).Formula = "=A2&""|""&B2"
    ws.Range("P2:P" & n).Formula = "=MAX(0,MIN(D2,DATE(B2,12,31))-MAX(C2,DATE(B2,1,1))+1)/(DATE(B2,12,31)-DATE(B2,1,1)+1)"
    ws.Range("Q2:Q" & n).Formula = "=IF(E2="""","""",DATEDIF(E2,C2,""y""))"
    ws.Range("R2:R" & n).Formula = "=IF(Q2="""",INDEX(med_zone_val,MATCH(H2,med_zone_cle,0)),Q2)"
    ws.Range("S2:S" & n).Formula = "=DATEDIF(F2,C2,""y"")"
    ws.Range("T2:T" & n).Formula = "=DATEDIF(K2,C2,""y"")"
    ws.Range("U2:U" & n).Formula = "=MIN(crm_max,MAX(crm_min,M2))"
    ws.Range("V2:V" & n).Formula = "=P2*U2"
    ws.Range("P2:P" & n).NumberFormat = FMT_EXPO
    ws.Range("U2:U" & n).NumberFormat = "0.00"
    ws.Range("V2:V" & n).NumberFormat = FMT_EXPO
    AjouterControle 1, 1, "Dates au format date", _
        "=SUMPRODUCT(--ISTEXT(Contrats!C2:F" & n & "))+SUMPRODUCT(--ISTEXT(Contrats!K2:K" & n & "))=0"
    AjouterControle 1, 2, "Une ligne par police et par exercice", _
        "=SUMPRODUCT(--(Qualite!K3:K" & n & "=Qualite!K2:K" & (gLigC - 1) & "))=0"
    AjouterControle 1, 3, "Exposition entre 0 et 1", "=AND(MIN(c_expo)>=0,MAX(c_expo)<=1)", False, _
        "=COUNTIF(c_expo,0)"
End Sub

' Feuille Qualite, bloc des médianes (lit age_brut, jamais age : pas de circularité)
Private Sub CreerQualiteMedianes()
    Dim ws As Worksheet, i As Long, zones As Variant
    Set ws = NouvelleFeuille(F_QUALITE)
    zones = Array("A", "B", "C", "D")
    EntetesTable ws, 1, 1, Array("zone", "mediane_age")
    For i = 0 To 3
        ws.Cells(i + 2, 1).Value2 = zones(i)
        ws.Cells(i + 2, 2).FormulaArray = "=INT(MEDIAN(IF((c_zone=A" & (i + 2) & ")*(c_age_brut<>""""),c_age_brut)))"
    Next i
    DefinirNom "med_zone_cle", ws.Range("A2:A5")
    DefinirNom "med_zone_val", ws.Range("B2:B5")
End Sub

' ---------------------------------------------------------------------
' Étape 02 : qualité des données
' ---------------------------------------------------------------------
Public Sub Etape02()
    Dim ws As Worksheet, n As String
    Set ws = Feuille(F_SINISTRES)
    n = CStr(gLigS)
    EntetesTable ws, 1, COL_S_DERIVEE, Array("exercice", "cle", "controle", "retenu")
    NommerColonnes ws, gLigS, Array("s_exercice", "s_cle", "s_controle", "s_retenu"), COL_S_DERIVEE
    ws.Range("H2:H" & n).Formula = "=YEAR(C2)"
    ws.Range("I2:I" & n).Formula = "=B2&""|""&H2"
    ws.Range("J2:J" & n).Formula = "=IF(COUNTIFS(B$1:B1,B2,C$1:C1,C2,F$1:F1,F2)>0,""Doublon""," & _
        "IF(COUNTIF(c_id,B2)=0,""Orphelin"",IF(OR(H2<annee_debut,H2>annee_fin," & _
        "COUNTIFS(c_id,B2,c_debut,""<=""&C2,c_fin,"">=""&C2)=0),""Hors période""," & _
        "IF(F2<=0,""Montant nul"",""OK""))))"
    ws.Range("K2:K" & n).Formula = "=--(J2=""OK"")"
    CreerQualiteSynthese
    AjouterControle 2, 1, "Clé (police, date, montant) unique parmi les retenus", _
        "=SUMPRODUCT((s_retenu=1)*(COUNTIFS(s_idpol,s_idpol,s_date,s_date,s_charge_vue,s_charge_vue,s_retenu,1)>1))=0"
    AjouterControle 2, 2, "Chaque sinistre retenu couvert par un contrat", _
        "=SUMPRODUCT((s_retenu=1)*(COUNTIFS(c_id,s_idpol,c_debut,""<=""&s_date,c_fin,"">=""&s_date)=0))=0"
    AjouterControle 2, 3, "Complétude des colonnes tarifaires", "=MIN(Qualite!F2:F7)>=" & SEUIL_COMPLETUDE
End Sub

Private Sub CreerQualiteSynthese()
    Dim ws As Worksheet, cols As Variant, noms As Variant, i As Long
    Dim lib As Variant, frm As Variant, nm As Variant
    Set ws = Feuille(F_QUALITE)
    EntetesTable ws, 1, 4, Array("colonne", "manquants", "taux")
    cols = Array("id_police", "date_debut", "zone", "puissance_cv", "crm", "date_naissance")
    noms = Array("c_id", "c_debut", "c_zone", "c_puissance_cv", "c_crm", "c_naissance")
    For i = 0 To 5
        ws.Cells(i + 2, 4).Value2 = cols(i)
        ws.Cells(i + 2, 5).Formula = "=COUNTBLANK(" & noms(i) & ")"
        ws.Cells(i + 2, 6).Formula = "=1-E" & (i + 2) & "/ROWS(" & noms(i) & ")"
    Next i
    ws.Range("F2:F7").NumberFormat = "0.0000%"
    DefinirNom "q_completude", ws.Range("F2:F7")
    EntetesTable ws, 1, 8, Array("indicateur", "valeur")
    lib = Array("Doublon", "Hors période", "Orphelin", "Montant nul", "OK", "Sinistres exclus", _
        "Âges imputés", "Polices concernées", "CRM corrigés", "Lignes", "Polices distinctes", _
        "Sinistres bruts", "Exposition totale", "Lignes à exposition nulle", "Exercices")
    frm = Array("=COUNTIF(s_controle,""Doublon"")", "=COUNTIF(s_controle,""Hors période"")", _
        "=COUNTIF(s_controle,""Orphelin"")", "=COUNTIF(s_controle,""Montant nul"")", _
        "=COUNTIF(s_controle,""OK"")", "=I3+I4+I5", "=COUNTIF(c_age_brut,"""")", "", _
        "=SUMPRODUCT(--(c_crm<>c_crm_c))", "=ROWS(c_cle)", _
        "=SUMPRODUCT(--(Qualite!L3:L" & gLigC & "<>Qualite!L2:L" & (gLigC - 1) & "))+1", _
        "=ROWS(s_id)", "=SUM(c_expo)", "=COUNTIF(c_expo,0)", "=annee_fin-annee_debut+1")
    nm = Array("q_doublons", "q_hors_periode", "q_orphelins", "q_montant_nul", "q_ok", "q_exclus", _
        "q_ages_imputes", "q_polices_age", "q_crm_corriges", "q_lignes", "q_polices", _
        "q_sinistres_bruts", "q_expo_totale", "q_expo_nulle", "q_nb_exercices")
    For i = 0 To UBound(lib)
        ws.Cells(i + 2, 8).Value2 = lib(i)
        If Len(frm(i)) > 0 Then ws.Cells(i + 2, 9).Formula = frm(i)
        DefinirNom CStr(nm(i)), ws.Cells(i + 2, 9)
    Next i
    FormaterSynthese ws.Range("I2:I" & UBound(lib) + 2)
    EntetesTable ws, 1, 11, Array("cle_triee", "id_police_trie")
End Sub

' Colonnes triées de Qualite (unicité) et Journal : après le premier calcul
Public Sub EcrireTrisQualite()
    Dim ws As Worksheet, v As Variant, n As Long, i As Long
    Dim cles() As String, ids() As String, idx() As Long, sortie() As Variant
    Set ws = Feuille(F_QUALITE)
    n = gLigC - 1
    v = Feuille(F_CONTRATS).Range("A2:A" & gLigC).Value2
    ReDim ids(1 To n): ReDim cles(1 To n): ReDim idx(1 To n)
    For i = 1 To n: ids(i) = CStr(v(i, 1)): idx(i) = i: Next i
    v = Feuille(F_CONTRATS).Range("O2:O" & gLigC).Value2
    For i = 1 To n: cles(i) = CStr(v(i, 1)): Next i
    ReDim sortie(1 To n, 1 To 2)
    TriFusionTexte cles, idx, n
    For i = 1 To n: sortie(i, 1) = cles(idx(i)): Next i
    For i = 1 To n: idx(i) = i: Next i
    TriFusionTexte ids, idx, n
    For i = 1 To n: sortie(i, 2) = ids(idx(i)): Next i
    ws.Range("K2").Resize(n, 2).Value2 = sortie
End Sub

' ---------------------------------------------------------------------
' Journal des anomalies (VBA, valeurs) : 101 lignes attendues
' ---------------------------------------------------------------------
Public Sub CreerJournal()
    Dim ws As Worksheet, j() As Variant, nb As Long, types As Variant, t As Long
    Set ws = NouvelleFeuille(F_JOURNAL)
    EntetesTable ws, 1, 1, Array("numero", "type", "table", "ligne", "identifiant", "detail", "action")
    ReDim j(1 To 7, 1 To 1000)
    nb = 0
    types = Array("Doublon", "Hors période", "Orphelin", "Montant nul")
    For t = 0 To 3
        JournalSinistres CStr(types(t)), j, nb
    Next t
    JournalContrats j, nb
    EcrireJournal ws, j, nb
    Feuille(F_QUALITE).Range("I9").Formula = "=ROUND(SUMPRODUCT((Journal!B2:B" & nb + 1 & "=""Âge imputé"")/" & _
        "COUNTIFS(Journal!E2:E" & nb + 1 & ",Journal!E2:E" & nb + 1 & "&"""",Journal!B2:B" & nb + 1 & ",Journal!B2:B" & nb + 1 & "&"""")),0)"
End Sub

Private Sub JournalSinistres(ByVal typ As String, j() As Variant, nb As Long)
    Dim v As Variant, i As Long, k As Long, det As String, act As String
    v = Feuille(F_SINISTRES).Range("A2:J" & gLigS).Value2
    For i = 1 To UBound(v, 1)
        If CStr(v(i, 10)) = typ Then
            Select Case typ
                Case "Doublon"
                    For k = 1 To i - 1
                        If v(k, 2) = v(i, 2) And v(k, 3) = v(i, 3) And v(k, 6) = v(i, 6) Then Exit For
                    Next k
                    det = "Même police, date et montant que " & CStr(v(k, 1)) & " (ligne " & (k + 1) & ")"
                    act = "Supprimé de l" & Apos() & "étude"
                Case "Orphelin"
                    det = "Police " & CStr(v(i, 2)) & " absente de Contrats"
                    act = "Exclu"
                Case "Hors période"
                    det = "Survenance " & TexteDate(v(i, 3)) & " hors couverture " & Param("annee_debut") & _
                          DemiTiret() & Param("annee_fin")
                    act = "Exclu"
                Case Else
                    det = "Charge vue " & FormatEuro(CDbl(v(i, 6)), 2)
                    act = "Exclu (sans suite)"
            End Select
            AjouterLigneJournal j, nb, typ, F_SINISTRES, i + 1, CStr(v(i, 1)), det, act
        End If
    Next i
End Sub

Private Sub JournalContrats(j() As Variant, nb As Long)
    Dim v As Variant, i As Long
    v = Feuille(F_CONTRATS).Range("A2:U" & gLigC).Value2
    For i = 1 To UBound(v, 1)
        If CStr(v(i, 17)) = "" Then
            AjouterLigneJournal j, nb, "Âge imputé", F_CONTRATS, i + 1, CStr(v(i, 1)), _
                "date_naissance vide", "Imputé : médiane de la zone " & v(i, 8) & " = " & v(i, 18)
        End If
    Next i
    For i = 1 To UBound(v, 1)
        If v(i, 13) <> v(i, 21) Then
            AjouterLigneJournal j, nb, "CRM corrigé", F_CONTRATS, i + 1, CStr(v(i, 1)), _
                "CRM hors [" & FormatNombre(Param("crm_min"), 2) & " ; " & FormatNombre(Param("crm_max"), 2) & "]", _
                "Ramené de " & FormatNombre(CDbl(v(i, 13)), 2) & " à " & FormatNombre(CDbl(v(i, 21)), 2)
        End If
    Next i
    For i = 1 To UBound(v, 1)
        If v(i, 16) = 0 Then
            AjouterLigneJournal j, nb, "Exposition nulle", F_CONTRATS, i + 1, CStr(v(i, 1)), _
                "date_debut " & TexteDate(v(i, 3)) & ", date_fin " & TexteDate(v(i, 4)), _
                "date_fin antérieure à date_debut, ligne sans effet"
        End If
    Next i
End Sub

Private Sub AjouterLigneJournal(j() As Variant, nb As Long, ByVal typ As String, ByVal tbl As String, _
                                ByVal ligne As Long, ByVal ident As String, ByVal det As String, ByVal act As String)
    nb = nb + 1
    If nb > UBound(j, 2) Then ReDim Preserve j(1 To 7, 1 To nb + 500)
    j(1, nb) = nb: j(2, nb) = typ: j(3, nb) = tbl: j(4, nb) = ligne
    j(5, nb) = ident: j(6, nb) = det: j(7, nb) = act
End Sub

Private Sub EcrireJournal(ByVal ws As Worksheet, j() As Variant, ByVal nb As Long)
    Dim s() As Variant, i As Long, c As Long
    If nb = 0 Then Exit Sub
    ReDim s(1 To nb, 1 To 7)
    For i = 1 To nb
        For c = 1 To 7: s(i, c) = j(c, i): Next c
    Next i
    ws.Range("A2").Resize(nb, 7).Value2 = s
    AjusterColonnes ws
End Sub

Public Function TexteDate(ByVal v As Variant) As String
    Dim d As Date
    d = CDate(v)
    TexteDate = Right$("0" & Day(d), 2) & "/" & Right$("0" & Month(d), 2) & "/" & Year(d)
End Function

' ---------------------------------------------------------------------
' Étape 03 : base de modélisation
' ---------------------------------------------------------------------
Public Sub Etape03()
    Dim ws As Worksheet, wh As Worksheet, n As String, lib As Variant, frm As Variant, nm As Variant, i As Long
    Set ws = Feuille(F_CONTRATS)
    n = CStr(gLigC)
    EntetesTable ws, 1, 23, Array("nb_sin", "charge_vue", "charge_rev", "charge_ecr")
    NommerColonnes ws, gLigC, Array("c_nb_sin", "c_charge_vue", "c_charge_rev", "c_charge_ecr"), 23
    ws.Range("W2:W" & n).Formula = "=COUNTIFS(s_cle,O2,s_retenu,1)"
    ws.Range("X2:X" & n).Formula = "=SUMIFS(s_charge_vue,s_cle,O2,s_retenu,1)"
    ws.Range("Y2:Y" & n).Formula = "=SUMIFS(s_charge_rev,s_cle,O2,s_retenu,1)"
    ws.Range("Z2:Z" & n).Formula = "=SUMIFS(s_charge_ecr,s_cle,O2,s_retenu,1)"
    ws.Range("X2:Z" & n).NumberFormat = FMT_MONTANT
    Set wh = NouvelleFeuille(F_HISTORIQUE)
    EntetesTable wh, 10, 1, Array("sinistres_par_ligne", "observe", "attendu")
    wh.Range("A11:A13").Value2 = Application.WorksheetFunction.Transpose(Array("1", "2", "3+"))
    wh.Range("A15").Value2 = "lambda_crm"
    wh.Range("B15").Formula = "=SUM(c_nb_sin)/SUM(c_e_crm)"
    DefinirNom "hist_lam", wh.Range("B15")
    wh.Range("B11").Formula = "=COUNTIF(c_nb_sin,1)"
    wh.Range("B12").Formula = "=COUNTIF(c_nb_sin,2)"
    wh.Range("B13").Formula = "=COUNTIF(c_nb_sin,"">=3"")"
    wh.Range("C11").Formula = "=SUMPRODUCT(c_e_crm*hist_lam*EXP(-c_e_crm*hist_lam))"
    wh.Range("C12").Formula = "=SUMPRODUCT((c_e_crm*hist_lam)^2/2*EXP(-c_e_crm*hist_lam))"
    wh.Range("C13").Formula = "=SUMPRODUCT(1-EXP(-c_e_crm*hist_lam)*(1+c_e_crm*hist_lam+(c_e_crm*hist_lam)^2/2))"
    DefinirNom "hist_obs", wh.Range("B11:B13")
    DefinirNom "hist_att", wh.Range("C11:C13")
    FormaterSynthese wh.Range("B11:C13,B15")
    EntetesTable wh, 1, 20, Array("indicateur", "valeur")
    lib = Array("Sinistres rattachés", "Part des retenus", "Lignes sinistrées", "Part des lignes", _
                "Lignes à exposition non nulle", "Charge rattachée")
    frm = Array("=SUM(c_nb_sin)", "=U2/COUNTIF(s_retenu,1)", "=COUNTIF(c_nb_sin,"">0"")", "=U4/ROWS(c_cle)", _
                "=COUNTIF(c_expo,"">0"")", "=SUM(c_charge_vue)")
    nm = Array("b_sin_ratt", "b_part_ratt", "b_lignes_sin", "b_part_lignes", "b_lignes_base", "b_charge_ratt")
    For i = 0 To 5
        wh.Cells(i + 2, 20).Value2 = lib(i)
        wh.Cells(i + 2, 21).Formula = frm(i)
        DefinirNom CStr(nm(i)), wh.Cells(i + 2, 21)
    Next i
    FormaterSynthese wh.Range("U2:U7")
    AjouterControle 3, 1, "Jointure gauche", "=ROWS(c_cle)=COUNTA(c_id)", False, "=ROWS(c_cle)"
    AjouterControle 3, 2, "Somme des Ni = sinistres retenus", "=SUM(c_nb_sin)=COUNTIF(s_retenu,1)"
    AjouterControle 3, 3, "Charge identique avant et après jointure", _
        "=ABS(SUM(c_charge_vue)-SUMIFS(s_charge_vue,s_retenu,1))<0.01"
End Sub

' ---------------------------------------------------------------------
' Étape 04 : charge ultime et inflation
' ---------------------------------------------------------------------
Public Sub Etape04()
    Dim ws As Worksheet, n As String
    Set ws = Feuille(F_SINISTRES)
    n = CStr(gLigS)
    EntetesTable ws, 1, 12, Array("charge_reval")
    DefinirNom "s_charge_rev", ws.Range("L2:L" & n)
    ws.Range("L2:L" & n).Formula = "=IF(K2=1,F2*(1+taux_inflation)^(annee_milieu_application-(H2+0.5)),0)"
    ws.Range("F2:F" & n & ",L2:L" & n).NumberFormat = FMT_MONTANT
    ConstruireTriangle
    ConstruireHistorique
    AjouterControle 4, 1, "Dernière diagonale = sinistres retenus", _
        "=MAX(ABS(Historique_!D2:D6-Historique_!O2:O6)/Historique_!O2:O6)<0.005", True
    AjouterControle 4, 2, "Facteurs décroissants vers 1", "=AND(Triangle!B13:I13>=Triangle!C13:J13,Triangle!J13>=1)", True
    AjouterControle 4, 3, "IBNR positif sur chaque exercice", "=MIN(Historique_!J2:J6)>0"
End Sub

Private Sub ConstruireTriangle()
    Dim wt As Worksheet, l As String, ft As String
    Set wt = Feuille(F_TRIANGLE)
    l = CStr(gLigT): ft = CStr(LIG_T_FACTEURS)
    wt.Cells(LIG_T_FACTEURS, 1).Value2 = "facteur"
    wt.Cells(LIG_T_FACTEURS + 1, 1).Value2 = "facteur_cumule"
    FormaterEntetes wt.Range(wt.Cells(LIG_T_FACTEURS, 1), wt.Cells(LIG_T_FACTEURS + 1, 1)), True
    wt.Range(wt.Cells(LIG_T_FACTEURS, 2), wt.Cells(LIG_T_FACTEURS, NB_DEV)).Formula = _
        "=SUMIFS(C$2:C$" & l & ",C$2:C$" & l & ",""<>"")/SUMIFS(B$2:B$" & l & ",C$2:C$" & l & ",""<>"")"
    wt.Range(wt.Cells(LIG_T_FACTEURS + 1, 2), wt.Cells(LIG_T_FACTEURS + 1, NB_DEV)).Formula = _
        "=PRODUCT(B" & ft & ":$J$" & ft & ")"
    wt.Cells(LIG_T_FACTEURS + 1, NB_DEV + 1).Value2 = 1
    wt.Range(wt.Cells(LIG_T_FACTEURS, 2), wt.Cells(LIG_T_FACTEURS + 1, NB_DEV + 1)).NumberFormat = "0.00000"
    EntetesTable wt, 1, COL_T_DERIVEE, Array("diagonale", "nb_dev", "cdf", "ultime")
    wt.Range("M2:M" & l).Formula = "=LOOKUP(2,1/(B2:K2<>""""),B2:K2)"
    wt.Range("N2:N" & l).Formula = "=COUNT(B2:K2)"
    wt.Range("O2:O" & l).Formula = "=INDEX($B$" & (LIG_T_FACTEURS + 1) & ":$K$" & (LIG_T_FACTEURS + 1) & ",N2)"
    wt.Range("P2:P" & l).Formula = "=M2*O2"
    wt.Range("M2:M" & l & ",P2:P" & l).NumberFormat = FMT_MONTANT
    wt.Range("O2:O" & l).NumberFormat = "0.00000"
    DefinirNom "tri_exercice", wt.Range("A2:A" & l)
    DefinirNom "tri_diag", wt.Range("M2:M" & l)
    DefinirNom "tri_cdf", wt.Range("O2:O" & l)
    DefinirNom "tri_ult", wt.Range("P2:P" & l)
    DefinirNom "tri_facteurs", wt.Range(wt.Cells(LIG_T_FACTEURS, 2), wt.Cells(LIG_T_FACTEURS, NB_DEV))
End Sub

Private Sub ConstruireHistorique()
    Dim wh As Worksheet, ny As Long, d As String
    Set wh = Feuille(F_HISTORIQUE)
    ny = CLng(Param("annee_fin")) - CLng(Param("annee_debut")) + 1
    d = CStr(ny + 1)
    EntetesTable wh, 1, 1, Array("exercice", "exposition", "nb_sin", "charge_vue", "cdf", "charge_ult", "rho", _
        "charge_2027", "primes", "ibnr", "sp_vu", "sp", "cor", "resultat", "vue_sinistres", "frequence", _
        "cout_vu", "prime_moy")
    With wh
        .Range("A2:A" & d).Formula = "=annee_debut+ROW()-2"
        .Range("B2:B" & d).Formula = "=SUMIFS(c_expo,c_exercice,A2)"
        .Range("C2:C" & d).Formula = "=SUMIFS(c_nb_sin,c_exercice,A2)"
        .Range("D2:D" & d).Formula = "=INDEX(tri_diag,MATCH(A2,tri_exercice,0))"
        .Range("E2:E" & d).Formula = "=INDEX(tri_cdf,MATCH(A2,tri_exercice,0))"
        .Range("F2:F" & d).Formula = "=D2*E2"
        .Range("G2:G" & d).Formula = "=(1+taux_inflation)^(annee_milieu_application-(A2+0.5))"
        .Range("H2:H" & d).Formula = "=F2*G2"
        .Range("I2:I" & d).Formula = "=SUMIFS(c_prime,c_exercice,A2)"
        .Range("J2:J" & d).Formula = "=F2-D2"
        .Range("K2:K" & d).Formula = "=D2/I2"
        .Range("L2:L" & d).Formula = "=F2/I2"
        .Range("M2:M" & d).Formula = "=L2+taux_gestion+taux_acquisition"
        .Range("N2:N" & d).Formula = "=I2*(1-M2)"
        .Range("O2:O" & d).Formula = "=SUMIFS(s_charge_vue,s_exercice,A2,s_retenu,1)"
        .Range("P2:P" & d).Formula = "=C2/B2"
        .Range("Q2:Q" & d).Formula = "=D2/C2"
        .Range("R2:R" & d).Formula = "=I2/B2"
        .Range("A8").Value2 = "total"
        .Range("B8").Formula = "=SUM(B2:B" & d & ")"
        .Range("D8").Formula = "=SUM(D2:D" & d & ")"
        .Range("F8").Formula = "=SUM(F2:F" & d & ")"
        .Range("H8").Formula = "=SUM(H2:H" & d & ")"
        .Range("I8").Formula = "=SUM(I2:I" & d & ")"
        .Range("J8").Formula = "=SUM(J2:J" & d & ")"
        .Range("B2:B8").NumberFormat = FMT_EXPO
        .Range("D2:D8,F2:F8,H2:J8,N2:O8,Q2:R8").NumberFormat = FMT_MONTANT
        .Range("E2:E8,G2:G8").NumberFormat = "0.00000"
        .Range("K2:M8,P2:P8").NumberFormat = FMT_TAUX
    End With
    FormaterSynthese wh.Range("B8:J8")
    DefinirNom "charge_cible", wh.Range("H8")
    DefinirNom "hist_vue_tot", wh.Range("D8")
    DefinirNom "hist_ibnr_tot", wh.Range("J8")
    DefinirNom "hist_exercice", wh.Range("A2:A" & d)
    DefinirNom "hist_expo", wh.Range("B2:B" & d)
    DefinirNom "hist_vue", wh.Range("D2:D" & d)
    DefinirNom "hist_ult", wh.Range("F2:F" & d)
    DefinirNom "hist_primes", wh.Range("I2:I" & d)
    DefinirNom "hist_ibnr", wh.Range("J2:J" & d)
    DefinirNom "hist_sp_vu", wh.Range("K2:K" & d)
    DefinirNom "hist_sp", wh.Range("L2:L" & d)
    DefinirNom "hist_cor", wh.Range("M2:M" & d)
End Sub

' ---------------------------------------------------------------------
' Étape 05 : écrêtement
' ---------------------------------------------------------------------
Public Sub Etape05()
    Dim ws As Worksheet, wg As Worksheet, n As String, i As Long, lib As Variant, frm As Variant, nm As Variant
    Set ws = Feuille(F_SINISTRES)
    n = CStr(gLigS)
    EntetesTable ws, 1, 13, Array("grave", "charge_ecr", "excedent")
    NommerColonnes ws, gLigS, Array("s_grave", "s_charge_ecr", "s_excedent"), 13
    ws.Range("M2:M" & n).Formula = "=IF(K2=1,--(L2>seuil_ecretement),0)"
    ws.Range("N2:N" & n).Formula = "=IF(K2=1,MIN(L2,seuil_ecretement),0)"
    ws.Range("O2:O" & n).Formula = "=IF(K2=1,MAX(L2-seuil_ecretement,0),0)"
    ws.Range("N2:O" & n).NumberFormat = FMT_MONTANT
    Set wg = NouvelleFeuille(F_GRAVES)
    EntetesTable wg, 1, 8, Array("seuil", "n", "part", "e_emp")
    For i = 1 To NB_SEUILS
        wg.Cells(i + 1, 8).Formula = "=seuil_" & i
    Next i
    wg.Range("I2:I6").Formula = "=COUNTIF(s_charge_rev,"">""&H2)"
    wg.Range("J2:J6").Formula = "=SUMPRODUCT((s_charge_rev>H2)*(s_charge_rev-H2))/SUM(s_charge_rev)"
    wg.Range("K2:K6").Formula = "=IF(I2>0,SUMPRODUCT((s_charge_rev>H2)*(s_charge_rev-H2))/I2,NA())"
    wg.Range("J2:J6").NumberFormat = FMT_TAUX
    wg.Range("H2:H6,K2:K6").NumberFormat = FMT_MONTANT
    DefinirNom "seuils_val", wg.Range("H2:H6")
    DefinirNom "seuils_part", wg.Range("J2:J6")
    EntetesTable wg, 8, 8, Array("indicateur", "valeur")
    lib = Array("Seuil u", "Sinistres graves", "Part des retenus", "Charge écrêtée", "Excédent", _
                "Charge revalorisée", "Part de l" & Apos() & "excédent")
    frm = Array("=seuil_ecretement", "=SUM(s_grave)", "=I10/COUNTIF(s_retenu,1)", "=SUM(s_charge_ecr)", _
                "=SUM(s_excedent)", "=SUM(s_charge_rev)", "=I13/I14")
    nm = Array("ecr_seuil", "ecr_n_graves", "ecr_part_graves", "ecr_charge_ecr", "ecr_excedent", _
               "ecr_charge_rev", "ecr_part_exc")
    For i = 0 To 6
        wg.Cells(i + 9, 8).Value2 = lib(i)
        wg.Cells(i + 9, 9).Formula = frm(i)
        DefinirNom CStr(nm(i)), wg.Cells(i + 9, 9)
    Next i
    FormaterSynthese wg.Range("I9:I15")
    AjouterControle 5, 1, "Charge écrêtée + excédent = charge revalorisée", _
        "=ABS(SUM(s_charge_ecr)+SUM(s_excedent)-SUM(s_charge_rev))<0.01"
    AjouterControle 5, 2, "Au moins min_graves sinistres au-dessus de u", "=SUM(s_grave)>=min_graves", False, _
        "=SUM(s_grave)", "=min_graves"
    AjouterControle 5, 3, "Excédent sous part_excedent_max", "=SUM(s_excedent)/SUM(s_charge_rev)<part_excedent_max", _
        False, "=SUM(s_excedent)/SUM(s_charge_rev)", "=part_excedent_max"
End Sub

' Formats et volets des feuilles de données (section 7)
Public Sub FormaterFeuillesDonnees()
    Dim noms As Variant, i As Long
    Feuille(F_CONTRATS).Range("C2:F" & gLigC & ",K2:K" & gLigC).NumberFormat = FMT_DATE
    Feuille(F_SINISTRES).Range("C2:D" & gLigS).NumberFormat = FMT_DATE
    noms = Array(F_CONTRATS, F_SINISTRES, F_TRIANGLE, F_TARIF_ACTUEL, F_PARAMETRES)
    For i = 0 To UBound(noms)
        FormaterEntetes Feuille(CStr(noms(i))).Range("A1", Feuille(CStr(noms(i))).Cells(1, 14)).SpecialCells(xlCellTypeConstants), False
    Next i
    FormaterEntetes Feuille(F_CONTRATS).Range("O1", Feuille(F_CONTRATS).Cells(1, Feuille(F_CONTRATS).Columns.Count).End(xlToLeft)), True
    FormaterEntetes Feuille(F_SINISTRES).Range("H1", Feuille(F_SINISTRES).Cells(1, Feuille(F_SINISTRES).Columns.Count).End(xlToLeft)), True
End Sub

Public Function FormatMontant() As String: FormatMontant = FMT_MONTANT: End Function
Public Function FormatExpo() As String: FormatExpo = FMT_EXPO: End Function
Public Function FormatTaux() As String: FormatTaux = FMT_TAUX: End Function
Public Function FormatRel() As String: FormatRel = FMT_REL: End Function
Public Function FormatCoef() As String: FormatCoef = FMT_COEF: End Function
