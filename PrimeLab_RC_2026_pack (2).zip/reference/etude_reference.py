"""Implementation de reference de l'etude tarifaire PrimeLab (RC auto 2026).
Usage : python etude_reference.py 15000 ../donnees resultat.json  (lit PrimeLab_RC_2026_donnees.xlsx)
Dependances : pandas, numpy, scipy, openpyxl.

Reproduit exactement les regles du cahier des charges (section Moteur de calcul).
Sert a produire la recette chiffree et les tableaux des maquettes.
Usage : python3 etude.py [seuil_u] [dossier_donnees] [fichier_json_sortie]
"""
import sys, json, math
from datetime import date
import numpy as np
import pandas as pd
from scipy.stats import chi2, norm

DATA = sys.argv[2] if len(sys.argv) > 2 else "../donnees"
P = dict(annee_debut=2021, annee_fin=2025, t_milieu=2027.0, taux_inflation=0.05,
         seuil_u=float(sys.argv[1]) if len(sys.argv) > 1 else 15000.0,
         seuils=[5000, 10000, 15000, 25000, 50000], e_min=500.0, z_fusion=1.645, seuil_p=0.05,
         seuil_v=0.5, crm_min=0.5, crm_max=3.5, age_min=18, age_max=99,
         s=0.03, g=0.10, a=0.15, m=0.05, t=0.342, plafond=0.10, iter_max=25, tol=1e-10,
         min_graves=20, ecart_kappa=0.15, ratio_crm=(0.85, 1.15), equilibre_min=0.95,
         part_exc_max=0.35, ecart_survie=0.10)
P["sp_cible"] = (1 - P["g"] - P["a"] - P["m"]) / (1 + P["s"])
P["taux_frais"] = P["g"] + P["a"]
CHARG = (1 + P["s"]) / (1 - P["g"] - P["a"] - P["m"])
R = {}   # recette

def datedif_y(d1, d2):
    return d2.year - d1.year - ((d2.month, d2.day) < (d1.month, d1.day))

# ============================================================ 01 IMPORT ET EXPOSITION
import os
if os.path.exists(f"{DATA}/contrats.pkl"):
    C = pd.read_pickle(f"{DATA}/contrats.pkl").reset_index(drop=True)
    S = pd.read_pickle(f"{DATA}/sinistres.pkl").reset_index(drop=True)
    TRI = pd.read_pickle(f"{DATA}/triangle.pkl")
    TA = pd.read_pickle(f"{DATA}/tarif_actuel.pkl")
else:  # lecture directe du classeur de depart
    X_ = f"{DATA}/PrimeLab_RC_2026_donnees.xlsx"
    def todate(v): return None if pd.isna(v) else pd.Timestamp(v).date()
    C = pd.read_excel(X_, "Contrats")
    for c_ in ("date_debut", "date_fin", "date_naissance", "date_permis", "date_mise_circulation"):
        C[c_] = [todate(v) for v in C[c_]]
    C["date_naissance"] = C["date_naissance"].astype(object)
    S = pd.read_excel(X_, "Sinistres")
    for c_ in ("date_survenance", "date_declaration"): S[c_] = [todate(v) for v in S[c_]]
    TRI = pd.read_excel(X_, "Triangle"); TA = pd.read_excel(X_, "TarifActuel")

def expo(r):
    y = r.exercice; d0, d1 = date(y, 1, 1), date(y, 12, 31)
    num = (min(r.date_fin, d1) - max(r.date_debut, d0)).days + 1
    return max(0, num) / ((d1 - d0).days + 1)
C["exposition"] = [expo(r) for r in C.itertuples()]
C["age_brut"] = [datedif_y(n, d) if n is not None and not (isinstance(n, float)) else None
                 for n, d in zip(C["date_naissance"], C["date_debut"])]
C["anc_permis"] = [datedif_y(p, d) for p, d in zip(C["date_permis"], C["date_debut"])]
C["anc_vehicule"] = [datedif_y(p, d) for p, d in zip(C["date_mise_circulation"], C["date_debut"])]
R["import"] = dict(lignes=len(C), polices=int(C.id_police.nunique()), sinistres_bruts=len(S),
                   exposition=float(C.exposition.sum()),
                   expo_par_exercice={int(y): float(v) for y, v in C.groupby("exercice").exposition.sum().items()},
                   lignes_expo_nulle=int((C.exposition == 0).sum()),
                   cle_unique=bool(not C.duplicated(["id_police", "exercice"]).any()))

# ============================================================ 02 QUALITE
known = C[C.age_brut.notna()]
med = {z: int(math.floor(np.median(known[known.zone == z].age_brut))) for z in sorted(C.zone.unique())}
C["age_impute"] = C.age_brut.isna()
C["age"] = [int(a) if not imp else med[z] for a, imp, z in zip(C.age_brut, C.age_impute, C.zone)]
C["crm_c"] = C.crm.clip(P["crm_min"], P["crm_max"])
crm_corr = int((C.crm != C.crm_c).sum())
# sinistres
pol_set = set(C.id_police)
cov = {}
for r in C.itertuples():
    cov.setdefault(r.id_police, []).append((r.date_debut, r.date_fin, r.Index))
seen = set(); ctrl = []; line_idx = []
for r in S.itertuples():
    key = (r.id_police, r.date_survenance, r.charge_vue)
    li = None
    if key in seen:
        c = "Doublon"
    elif r.id_police not in pol_set:
        c = "Orphelin"
    else:
        hits = [ix for (a, b, ix) in cov[r.id_police] if a <= r.date_survenance <= b]
        if r.date_survenance.year < P["annee_debut"] or r.date_survenance.year > P["annee_fin"] or not hits:
            c = "Hors période"
        elif r.charge_vue <= 0:
            c = "Montant nul"
        else:
            c = "OK"; li = hits[0]
    seen.add(key); ctrl.append(c); line_idx.append(li)
S["controle"] = ctrl; S["ligne"] = line_idx
S["exercice"] = [d.year for d in S.date_survenance]
cnt = S.controle.value_counts().to_dict()
cols_compl = ["id_police", "date_debut", "zone", "puissance_cv", "crm", "date_naissance"]
compl = {c: float(1 - C[c].isna().sum() / len(C)) for c in cols_compl}
R["qualite"] = dict(controles={k: int(v) for k, v in cnt.items()}, ages_imputes=int(C.age_impute.sum()),
                    polices_age_manquant=int(C[C.age_impute].id_police.nunique()), medianes_zone=med,
                    crm_corriges=crm_corr, completude=compl,
                    sinistres_retenus=int(cnt.get("OK", 0)),
                    exclus=int(cnt.get("Hors période", 0) + cnt.get("Orphelin", 0) + cnt.get("Montant nul", 0)))
K = S[S.controle == "OK"].copy()

# ============================================================ 03 JOINTURE
nb = K.groupby("ligne").size(); ch = K.groupby("ligne").charge_vue.sum()
C["nb_sin"] = C.index.map(nb).fillna(0).astype(int)
C["charge_vue"] = C.index.map(ch).fillna(0.0)
B = C[C.exposition > 0]
lam_bar = K.shape[0] / (B.exposition * B.crm_c).sum()
mu = (B.exposition * B.crm_c * lam_bar).values
obs = {k: int((B.nb_sin == k).sum()) for k in (1, 2)}; obs[3] = int((B.nb_sin >= 3).sum())
pois = {1: float(np.sum(mu * np.exp(-mu))), 2: float(np.sum(mu ** 2 / 2 * np.exp(-mu)))}
pois[3] = float(np.sum(1 - np.exp(-mu) * (1 + mu + mu ** 2 / 2)))
R["jointure"] = dict(sinistres_rattaches=int(C.nb_sin.sum()), lignes_sinistrees=int((C.nb_sin > 0).sum()),
                     lignes_base=int((C.exposition > 0).sum()), charge_rattachee=float(C.charge_vue.sum()),
                     charge_sinistres=float(K.charge_vue.sum()), lignes_total=len(C),
                     poisson_obs=obs, poisson_att=pois)

# ============================================================ 04 CHARGE ULTIME ET INFLATION
T = TRI.set_index("exercice")
devs = [f"dev_{k}" for k in range(1, 11)]
f = []
for j in range(9):
    a, b = devs[j], devs[j + 1]
    rows = T[T[b].notna()]
    f.append(float(rows[b].sum() / rows[a].sum()))
ult = {}; diag = {}; cdf = {}
for y in T.index:
    vals = T.loc[y, devs].dropna().values
    d = len(vals); diag[y] = float(vals[-1])
    cdf[y] = float(np.prod(f[d - 1:])) if d < 10 else 1.0
    ult[y] = diag[y] * cdf[y]
frev = {y: (1 + P["taux_inflation"]) ** (P["t_milieu"] - (y + 0.5)) for y in range(2021, 2026)}
vue_k = K.groupby("exercice").charge_vue.sum().to_dict()
cible = sum(ult[y] * frev[y] for y in range(2021, 2026))
R["ultime"] = dict(ldf=f, cdf={int(y): cdf[y] for y in range(2021, 2026)},
                   diag={int(y): diag[y] for y in range(2021, 2026)}, vue_sinistres={int(y): float(vue_k[y]) for y in range(2021, 2026)},
                   ultime={int(y): ult[y] for y in range(2021, 2026)},
                   ibnr={int(y): ult[y] - diag[y] for y in range(2021, 2026)},
                   frev={int(y): frev[y] for y in range(2021, 2026)},
                   charge_vue_totale=sum(diag[y] for y in range(2021, 2026)),
                   ibnr_total=sum(ult[y] - diag[y] for y in range(2021, 2026)),
                   charge_cible=cible,
                   ecart_diag_max=max(abs(diag[y] - vue_k[y]) / vue_k[y] for y in range(2021, 2026)))

# ============================================================ 05 ECRETEMENT
u = P["seuil_u"]
K["fr"] = K.exercice.map(frev)
K["x_r"] = K.charge_vue * K.fr
K["x_c"] = K.x_r.clip(upper=u)
K["x_e"] = (K.x_r - u).clip(lower=0)
K["grave"] = K.x_r > u
def part_exc(v): return float((K.x_r - v).clip(lower=0).sum() / K.x_r.sum())
def e_emp(v):
    g = K[K.x_r > v]; return float((g.x_r - v).sum() / len(g)) if len(g) else float("nan")
R["ecretement"] = dict(seuil=u, n_graves=int(K.grave.sum()), pct_graves=float(K.grave.mean()),
                       charge_reval=float(K.x_r.sum()), charge_ecretee=float(K.x_c.sum()),
                       excedent=float(K.x_e.sum()), part_excedent=float(K.x_e.sum() / K.x_r.sum()),
                       part_par_seuil={int(v): part_exc(v) for v in P["seuils"]},
                       e_emp_par_seuil={int(v): e_emp(v) for v in P["seuils"]},
                       n_par_seuil={int(v): int((K.x_r > v).sum()) for v in P["seuils"]})
lc = K.groupby("ligne").x_c.sum(); lr = K.groupby("ligne").x_r.sum()
C["charge_ecr"] = C.index.map(lc).fillna(0.0); C["charge_rev"] = C.index.map(lr).fillna(0.0)
C["e_crm"] = C.exposition * C.crm_c

# ============================================================ 06 EXPLORATOIRE (tranches initiales)
ORD = {"age": [(18, "18-20"), (21, "21-24"), (25, "25-29"), (30, "30-39"), (40, "40-49"), (50, "50-64"), (65, "65-74"), (75, "75+")],
       "puissance_cv": [(0, "≤4"), (5, "5-6"), (7, "7-8"), (9, "9-10"), (11, "11+")],
       "anc_permis": [(0, "0-2"), (3, "3-5"), (6, "6-10"), (11, "11-20"), (21, "21+")],
       "anc_vehicule": [(0, "0-2"), (3, "3-5"), (6, "6-9"), (10, "10-14"), (15, "15+")]}
NOM = {"zone": ["A", "B", "C", "D"], "usage": ["Privé", "Trajet", "Professionnel"],
       "couleur": ["Blanc", "Gris", "Noir", "Bleu", "Rouge", "Vert"]}
CANDS = ["age", "zone", "puissance_cv", "usage", "anc_permis", "anc_vehicule", "couleur"]
B = C[C.exposition > 0].copy()
KB = K.copy()
for v, tr in ORD.items():
    mins = [m for m, _ in tr]
    B["t_" + v] = [sum(1 for m in mins if x >= m) - 1 for x in B[v]]
for v, mods in NOM.items():
    B["t_" + v] = [mods.index(x) for x in B[v]]
for v in CANDS:
    KB["t_" + v] = KB.ligne.map(B["t_" + v])

def agg(df, col, n):
    g = df.groupby(col)
    out = []
    for k in range(n):
        if k in g.groups:
            d = g.get_group(k)
            out.append(dict(E=float(d.exposition.sum()), Es=float(d.e_crm.sum()), N=int(d.nb_sin.sum()),
                            Sc=float(d.charge_ecr.sum())))
        else:
            out.append(dict(E=0.0, Es=0.0, N=0, Sc=0.0))
    return out
explo = {}
for v in CANDS:
    labels = [l for _, l in ORD[v]] if v in ORD else NOM[v]
    rows = agg(B, "t_" + v, len(labels))
    for lab, r in zip(labels, rows):
        r["label"] = lab
        r["freq"] = r["N"] / r["E"] if r["E"] else None
        r["freq_crm"] = r["N"] / r["Es"] if r["Es"] else None
        r["cout"] = r["Sc"] / r["N"] if r["N"] else None
        r["pp"] = r["Sc"] / r["E"] if r["E"] else None
        if r["Es"]:
            h = 1.96 * math.sqrt(r["freq_crm"] / r["Es"]); r["ic"] = (r["freq_crm"] - h, r["freq_crm"] + h)
    explo[v] = rows
Etot, Estot, Ntot, Sctot = B.exposition.sum(), B.e_crm.sum(), int(B.nb_sin.sum()), B.charge_ecr.sum()
R["exploratoire"] = dict(freq=Ntot / Etot, freq_crm=Ntot / Estot, cout_ecr=Sctot / Ntot, pp_ecr=Sctot / Etot,
                         variables=explo, E=Etot, Es=Estot, N=Ntot)

# ============================================================ 07 CLASSES
def zstat(a, b):
    la, lb = a["N"] / a["Es"], b["N"] / b["Es"]
    den = math.sqrt(la / a["Es"] + lb / b["Es"])
    return 0.0 if den == 0 else (la - lb) / den
def merge(a, b):
    return dict(E=a["E"] + b["E"], Es=a["Es"] + b["Es"], N=a["N"] + b["N"], Sc=a["Sc"] + b["Sc"],
                members=a["members"] + b["members"])
def classes_ordinal(rows):
    G = [dict(E=r["E"], Es=r["Es"], N=r["N"], Sc=r["Sc"], members=[i]) for i, r in enumerate(rows)]
    journal = []
    while True:
        small = [i for i, g in enumerate(G) if g["E"] < P["e_min"]]
        if small and len(G) > 1:
            i = min(small, key=lambda k: (G[k]["E"], k))
            nb = [j for j in (i - 1, i + 1) if 0 <= j < len(G)]
            li = G[i]["N"] / G[i]["Es"] if G[i]["Es"] else 0
            j = min(nb, key=lambda k: (abs(G[k]["N"] / G[k]["Es"] - li), k))
            a, b = min(i, j), max(i, j)
            journal.append(("E_min", a, b)); G[a:b + 1] = [merge(G[a], G[b])]; continue
        if len(G) < 2: break
        zs = [abs(zstat(G[k], G[k + 1])) for k in range(len(G) - 1)]
        k = min(range(len(zs)), key=lambda q: (zs[q], q))
        if zs[k] < P["z_fusion"]:
            journal.append(("z", k, round(zs[k], 4))); G[k:k + 2] = [merge(G[k], G[k + 1])]; continue
        break
    return G, journal
def classes_nominal(rows):
    G = [dict(E=r["E"], Es=r["Es"], N=r["N"], Sc=r["Sc"], members=[i]) for i, r in enumerate(rows)]
    journal = []
    while True:
        small = [i for i, g in enumerate(G) if g["E"] < P["e_min"]]
        if not small or len(G) < 2: break
        i = min(small, key=lambda k: (G[k]["E"], k))
        li = G[i]["N"] / G[i]["Es"]
        j = min([k for k in range(len(G)) if k != i], key=lambda k: (abs(G[k]["N"] / G[k]["Es"] - li), k))
        a, b = min(i, j), max(i, j)
        journal.append(("E_min", a, b)); G[a] = merge(G[a], G[b]); del G[b]
    return G, journal
def bornes(lab):
    if lab.startswith("≤"): return None, lab[1:]
    if lab.endswith("+"): return lab[:-1], "+"
    if "-" in lab: a, b = lab.split("-"); return a, b
    return lab, lab
def label_fusion(first, last):
    lo, _ = bornes(first); _, hi = bornes(last)
    if lo is None and hi == "+": return "Toutes"
    if lo is None: return "≤" + hi
    if hi == "+": return lo + "+"
    return lo if lo == hi else lo + "-" + hi
CL = {}
for v in CANDS:
    rows = explo[v]
    labels = [r["label"] for r in rows]
    G, jr = classes_ordinal(rows) if v in ORD else classes_nominal(rows)
    for g in G:
        if v in ORD:
            g["label"] = label_fusion(labels[g["members"][0]], labels[g["members"][-1]])
        else:
            g["label"] = "+".join(labels[m] for m in g["members"])
        g["freq_crm"] = g["N"] / g["Es"]
    ref = max(range(len(G)), key=lambda k: (G[k]["E"], -k))
    for k, g in enumerate(G):
        g["rel"] = g["freq_crm"] / G[ref]["freq_crm"]
        g["z_suiv"] = abs(zstat(g, G[k + 1])) if (v in ORD and k + 1 < len(G)) else None
    mp = {}
    for k, g in enumerate(G):
        for m in g["members"]: mp[m] = k
    B["c_" + v] = B["t_" + v].map(mp); KB["c_" + v] = KB["t_" + v].map(mp)
    CL[v] = dict(classes=G, ref=ref, journal=jr, map=mp, labels_init=labels)
R["classes"] = {v: dict(n_init=len(CL[v]["labels_init"]), n=len(CL[v]["classes"]), ref=CL[v]["ref"],
                        classes=[dict(label=g["label"], E=g["E"], Es=g["Es"], N=g["N"], freq_crm=g["freq_crm"],
                                      rel=g["rel"], z_suiv=g["z_suiv"], members=g["members"]) for g in CL[v]["classes"]],
                        journal=CL[v]["journal"]) for v in CANDS}

# ============================================================ GLM (IRLS)
def design(df, vars_, n_classes, refs):
    cols = [np.ones(len(df))]; names = [("Intercept", None)]
    for v in vars_:
        for k in range(n_classes[v]):
            if k == refs[v]: continue
            cols.append((df["c_" + v].values == k).astype(float)); names.append((v, k))
    return np.column_stack(cols), names
def irls_poisson(X, y, off):
    beta = np.zeros(X.shape[1]); beta[0] = math.log(y.sum() / np.exp(off).sum())
    dev_old = None; log = []
    for it in range(1, P["iter_max"] + 1):
        eta = off + X @ beta; mu = np.exp(eta)
        z = X @ beta + (y - mu) / mu
        W = mu
        XtW = X.T * W
        beta = np.linalg.solve(XtW @ X, XtW @ z)
        mu = np.exp(off + X @ beta)
        dev = 2 * np.sum(np.where(y > 0, y * np.log(np.where(y > 0, y, 1) / mu), 0) - (y - mu))
        log.append(dev)
        if dev_old is not None and abs(dev - dev_old) / (abs(dev) + 0.1) < P["tol"]: break
        dev_old = dev
    mu = np.exp(off + X @ beta)
    cov = np.linalg.inv((X.T * mu) @ X)
    return beta, cov, dev, log, mu
def irls_gamma(X, y, w):
    beta = np.zeros(X.shape[1]); beta[0] = math.log((y * w).sum() / w.sum())
    dev_old = None; log = []
    for it in range(1, P["iter_max"] + 1):
        eta = X @ beta; mu = np.exp(eta)
        z = eta + (y - mu) / mu
        XtW = X.T * w
        beta = np.linalg.solve(XtW @ X, XtW @ z)
        mu = np.exp(X @ beta)
        dev = 2 * np.sum(w * (-np.log(y / mu) + (y - mu) / mu))
        log.append(dev)
        if dev_old is not None and abs(dev - dev_old) / (abs(dev) + 0.1) < P["tol"]: break
        dev_old = dev
    return beta, np.linalg.inv((X.T * w) @ X), dev, log, np.exp(X @ beta)
def cells_freq(vars_):
    keys = ["c_" + v for v in vars_]
    g = B.groupby(keys, sort=True).agg(N=("nb_sin", "sum"), E=("exposition", "sum"), Es=("e_crm", "sum")).reset_index()
    return g
NCL = {v: len(CL[v]["classes"]) for v in CANDS}; REF = {v: CL[v]["ref"] for v in CANDS}
def fit_freq(vars_, cells_vars=None):
    cv = cells_vars or vars_
    g = cells_freq(cv)
    X, names = design(g, vars_, NCL, REF)
    return irls_poisson(X, g.N.values.astype(float), np.log(g.Es.values)), names, g

# ============================================================ 08 SELECTION
def assoc_v(v, w):
    t = B.pivot_table(index="c_" + v, columns="c_" + w, values="exposition", aggfunc="sum", fill_value=0).values
    n = t.sum(); ex = np.outer(t.sum(1), t.sum(0)) / n
    x2 = np.sum((t - ex) ** 2 / np.where(ex > 0, ex, 1))
    k = min(t.shape) - 1
    return math.sqrt(x2 / (n * k)) if k > 0 else 0.0
uni = {}
for v in CANDS:
    G = CL[v]["classes"]; lam = Ntot / Estot
    x2 = sum((g["N"] - g["Es"] * lam) ** 2 / (g["Es"] * lam) for g in G)
    ddl = len(G) - 1
    uni[v] = dict(chi2=x2, ddl=ddl, p=float(chi2.sf(x2, ddl)) if ddl > 0 else 1.0,
                  V=math.sqrt(x2 / Etot), att_min=min(g["Es"] * lam for g in G))
passing = [v for v in CANDS if uni[v]["p"] < P["seuil_p"]]
decision = {v: "Écartée (non significative)" for v in CANDS if v not in passing}
kept = []
for v in sorted(passing, key=lambda q: -uni[q]["V"]):
    red = [(assoc_v(v, w), w) for w in kept]
    hit = [x for x in red if x[0] >= P["seuil_v"]]
    if hit:
        vmax, w = max(hit); decision[v] = f"Écartée (redondante avec {w})"; uni[v]["v_assoc"] = (w, vmax)
    else:
        kept.append(v)
model_vars = [v for v in CANDS if v in kept]
lrt = {}
while True:
    (bf, cf, Df, lf, mf), names, g = fit_freq(model_vars)
    ps = {}
    for v in model_vars:
        red = [q for q in model_vars if q != v]
        (br, cr, Dr, lr_, mr), _, _ = fit_freq(red, cells_vars=model_vars)
        dD = Dr - Df; ddl = NCL[v] - 1
        ps[v] = (dD, ddl, float(chi2.sf(dD, ddl)))
    for v in model_vars: lrt[v] = ps[v]
    worst = max(model_vars, key=lambda q: ps[q][2])
    if ps[worst][2] >= P["seuil_p"]:
        decision[worst] = "Écartée (test du rapport de vraisemblance)"; model_vars.remove(worst); continue
    break
for v in model_vars: decision[v] = "Retenue"
assoc_retenues = {f"{a}×{b}": assoc_v(a, b) for i, a in enumerate(model_vars) for b in model_vars[i + 1:]}
R["selection"] = dict(univarie=uni, decision=decision, lrt={v: dict(dD=a, ddl=b, p=c) for v, (a, b, c) in lrt.items()},
                      retenues=model_vars, assoc_retenues=assoc_retenues,
                      v_max_retenues=max(assoc_retenues.values()) if assoc_retenues else 0.0)

# ============================================================ 09 MODELES
VARS = model_vars
(beta, covb, Dfr, logf, muf), names, gF = fit_freq(VARS)
D0 = 2 * np.sum(np.where(gF.N > 0, gF.N * np.log(np.where(gF.N > 0, gF.N, 1) / (gF.Es * Ntot / Estot)), 0) - (gF.N - gF.Es * Ntot / Estot))
se_b = np.sqrt(np.diag(covb))
# cout
gk = KB.groupby(["c_" + v for v in VARS]).agg(n=("x_c", "size"), Sc=("x_c", "sum")).reset_index()
Xc, _ = design(gk, VARS, NCL, REF)
gam, covg, Dc, logc, muc = irls_gamma(Xc, (gk.Sc / gk.n).values, gk.n.values.astype(float))
Xk, _ = design(KB, VARS, NCL, REF)
mu_k = np.exp(Xk @ gam)
phi = float(np.sum(((KB.x_c.values - mu_k) / mu_k) ** 2) / (len(KB) - len(gam)))
se_g = np.sqrt(phi * np.diag(covg))
D0c = 2 * np.sum(gk.n * (-np.log((gk.Sc / gk.n) / (Sctot / Ntot)) + ((gk.Sc / gk.n) - Sctot / Ntot) / (Sctot / Ntot)))
def coef_table(b, se):
    out = []
    for (v, k), bb, s in zip(names, b, se):
        lab = "Intercept" if v == "Intercept" else f"{v} {CL[v]['classes'][k]['label']}"
        zz = bb / s
        out.append(dict(param=lab, var=v, k=k, coef=float(bb), rel=float(math.exp(bb)), se=float(s), z=float(zz),
                        p=float(2 * norm.sf(abs(zz)))))
    return out
XB, _ = design(B, VARS, NCL, REF)
B["lam_hat"] = B.crm_c.values * np.exp(XB @ beta)
B["mu_hat"] = B.exposition * B.lam_hat
def quintiles_lines(df, score, w, obs, pred):
    d = df.assign(_s=score).reset_index().sort_values(["_s", "index"], kind="mergesort")
    cw = d[w].cumsum() - d[w] / 2
    q = np.minimum(5, 1 + np.floor(5 * cw / d[w].sum())).astype(int)
    d["q"] = q.values
    return [dict(q=int(k), obs=float(d[d.q == k][obs].sum() / d[d.q == k][w].sum()),
                 pred=float(d[d.q == k][pred].sum() / d[d.q == k][w].sum()), w=float(d[d.q == k][w].sum()))
            for k in range(1, 6)]
lift_f = quintiles_lines(B, B.lam_hat.values, "exposition", "nb_sin", "mu_hat")
KB["mu_c"] = mu_k; KB["one"] = 1.0
lift_c = quintiles_lines(KB, mu_k, "one", "x_c", "mu_c")
CRM_CL = [(0.50, 0.50, "0,50"), (0.51, 0.79, "0,51-0,79"), (0.80, 0.99, "0,80-0,99"), (1.00, 3.50, "≥ 1,00")]
ratio_crm = []
for lo, hi, lab in CRM_CL:
    d = B[(B.crm_c >= lo - 1e-9) & (B.crm_c <= hi + 1e-9)]
    ratio_crm.append(dict(classe=lab, E=float(d.exposition.sum()), N=int(d.nb_sin.sum()), pred=float(d.mu_hat.sum()),
                          ratio=float(d.nb_sin.sum() / d.mu_hat.sum())))
y_i = B.nb_sin.values.astype(float); m_i = B.mu_hat.values
m0_i = B.e_crm.values * Ntot / Estot
def devp(y, m): return 2 * np.sum(np.where(y > 0, y * np.log(np.where(y > 0, y, 1) / m), 0) - (y - m))
dev_ind, dev0_ind = devp(y_i, m_i), devp(y_i, m0_i)
xk = KB.x_c.values; mk0 = np.full(len(xk), Sctot / Ntot)
devg = lambda x, m: 2 * np.sum(-np.log(x / m) + (x - m) / m)
dgc, dgc0 = devg(xk, mu_k), devg(xk, mk0)
R["modeles"] = dict(dev_ind_freq=float(dev_ind), dev0_ind_freq=float(dev0_ind), dev_expl_ind_freq=float(1 - dev_ind / dev0_ind),
                    dev_ind_cout=float(dgc), dev0_ind_cout=float(dgc0), dev_expl_ind_cout=float(1 - dgc / dgc0),
                    vars=VARS, freq=coef_table(beta, se_b), cout=coef_table(gam, se_g),
                    iter_freq=len(logf), iter_cout=len(logc), log_freq=logf, log_cout=logc,
                    dev_freq=float(Dfr), dev0_freq=float(D0), dev_expl_freq=float(1 - Dfr / D0),
                    dev_cout=float(Dc), dev0_cout=float(D0c), dev_expl_cout=float(1 - Dc / D0c), phi=phi,
                    n_cellules_freq=len(gF), n_cellules_cout=len(gk),
                    freq_base=float(math.exp(beta[0])), cout_base=float(math.exp(gam[0])),
                    somme_pred=float(B.mu_hat.sum()), somme_obs=int(B.nb_sin.sum()),
                    lift_freq=lift_f, lift_cout=lift_c, ratio_crm=ratio_crm, n_param=len(beta))

# ============================================================ 10 GRAVES
G_ = K[K.x_r > u]
n_u = len(G_); N = len(K)
alpha = n_u / float(np.log(G_.x_r / u).sum()) if n_u else float("nan")
se_a = alpha / math.sqrt(n_u) if n_u else float("nan")
e_u = u / (alpha - 1) if alpha > 1 else None
kappa_emp = float(K.x_r.sum() / K.x_c.sum())
kappa = 1 + n_u * e_u / float(K.x_c.sum()) if e_u else kappa_emp
surv = []
for mlt in (1.5, 2, 3, 5, 10):
    x = u * mlt
    surv.append(dict(x=x, obs=float((G_.x_r > x).sum() / n_u), pareto=float((u / x) ** alpha)))
R["graves"] = dict(n_u=n_u, N=N, alpha=alpha, se=se_a, ic=(alpha - 1.96 * se_a, alpha + 1.96 * se_a),
                   e_u=e_u, e_emp=float((G_.x_r - u).sum() / n_u), p_u=n_u / N, mu_c=float(K.x_c.mean()),
                   kappa=kappa, kappa_emp=kappa_emp, ecart_kappa=kappa / kappa_emp - 1, survie=surv,
                   liste=G_.sort_values("x_r", ascending=False)[["id_sinistre", "garantie", "exercice", "x_r"]]
                   .head(8).assign(ln=lambda d: np.log(d.x_r / u), exc=lambda d: d.x_r - u).to_dict("records"))

# ============================================================ 11 TARIF ET IMPACT
relF = np.exp(XB[:, 1:] @ beta[1:]);
gam_sl = gam[1:]
relC = np.exp(XB[:, 1:] @ gam_sl)
B0 = math.exp(beta[0]) * math.exp(gam[0]) * kappa
B["pp0"] = B0 * relF * relC * B.crm_c
C_cal = cible / float((B.exposition * B.pp0).sum())
BASE = B0 * C_cal
B["pp"] = BASE * relF * relC * B.crm_c
B["ht_new"] = B.pp * CHARG
base25 = float(TA[TA.variable == "base"].relativite.iloc[0])
def rel_act(age, zone, cv, usage):
    r = 1.0
    for _, t in TA[TA.variable != "base"].iterrows():
        if t.variable == "age" and t.borne_min <= age <= t.borne_max: r *= t.relativite
        if t.variable == "zone" and t.modalite == zone: r *= t.relativite
        if t.variable == "puissance_cv" and t.borne_min <= cv <= t.borne_max: r *= t.relativite
        if t.variable == "usage" and t.modalite == usage: r *= t.relativite
    return r
REN = B[(B.exercice == 2025) & (B.date_fin == date(2025, 12, 31))].copy()
REN["ht_act"] = [base25 * rel_act(a, z, c, us) * cr for a, z, c, us, cr in
                 zip(REN.age, REN.zone, REN.puissance_cv, REN.usage, REN.crm_c)]
REN["evol"] = REN.ht_new / REN.ht_act - 1
REN["evol_p"] = REN.evol.clip(-P["plafond"], P["plafond"])
REN["ht_cap"] = REN.ht_act * (1 + REN.evol_p)
bins = [("< -10 %", lambda e: e < -0.10), ("-10 à -5 %", lambda e: (e >= -0.10) & (e < -0.05)),
        ("-5 à 0 %", lambda e: (e >= -0.05) & (e < 0)), ("0 à +5 %", lambda e: (e >= 0) & (e < 0.05)),
        ("+5 à +10 %", lambda e: (e >= 0.05) & (e <= 0.10)), ("> +10 %", lambda e: e > 0.10)]
disl = [dict(bin=b, n=int(fn(REN.evol).sum()), part=float(fn(REN.evol).mean())) for b, fn in bins]
rel_tab = []
for v in VARS:
    for k, gcl in enumerate(CL[v]["classes"]):
        iF = [i for i, nm in enumerate(names) if nm == (v, k)]
        rf = math.exp(beta[iF[0]]) if iF else 1.0
        rc = math.exp(gam[iF[0]]) if iF else 1.0
        d = REN[REN["c_" + v] == k]
        rel_tab.append(dict(var=v, classe=gcl["label"], relF=rf, relC=rc, relPP=rf * rc,
                            evol=float(d.ht_new.sum() / d.ht_act.sum() - 1) if len(d) else None, n=len(d)))
cellsPP = B.drop_duplicates(["c_" + v for v in VARS])
amp = (float((relF * relC).min()), float((relF * relC).max()))
R["tarif"] = dict(B0=B0, calage=C_cal, base=BASE, charge_cible=cible, somme_EPP=float((B.exposition * B.pp).sum()),
                  pp_moy=float((B.exposition * B.pp).sum() / B.exposition.sum()),
                  n_renouv=len(REN), evol_moy=float(REN.ht_new.sum() / REN.ht_act.sum() - 1),
                  equilibre_plaf=float(REN.ht_cap.sum() / REN.ht_new.sum()),
                  ttc_moy=float((REN.ht_new * (1 + P["t"])).mean()), ttc_moy_act=float((REN.ht_act * (1 + P["t"])).mean()),
                  ht_moy=float(REN.ht_new.mean()), evol_max_plaf=float(REN.evol_p.abs().max()),
                  dislocation=disl, relativites=rel_tab, amplitude=amp, chargement=CHARG,
                  base_actuelle=base25)

# ============================================================ TABLEAU DE BORD
hist = []
for y in range(2021, 2026):
    Ly = C[C.exercice == y]
    prim = float(Ly.prime_acquise.sum()); E = float(Ly.exposition.sum())
    Ny = int((K.exercice == y).sum())
    sp = ult[y] / prim; cor = sp + P["taux_frais"]
    hist.append(dict(exercice=y, E=E, N=Ny, freq=Ny / E, primes=prim, vue=diag[y], cdf=cdf[y], ult=ult[y],
                     ibnr=ult[y] - diag[y], cout_vu=diag[y] / Ny, pp_ult=ult[y] / E, prime_moy=prim / E,
                     sp_vu=diag[y] / prim, sp=sp, cor=cor, rt=prim * (1 - cor), frev=frev[y], charge_2027=ult[y] * frev[y]))
seg = {}
SEGV = [("age", "Âge"), ("zone", "Zone"), ("puissance_cv", "Puissance"), ("usage", "Usage")]
for y in range(2021, 2026):
    uy = u / frev[y]
    Ky = K[K.exercice == y].copy(); Ky["cap"] = Ky.charge_vue.clip(upper=uy)
    tot_cap = Ky.cap.sum()
    Ly = C[C.exercice == y].copy()
    seg[y] = {}
    for v, lab in SEGV:
        # classes finales (age, puissance) ou modalites (zone, usage)
        if v in ORD:
            mins = [m for m, _ in ORD[v]]
            t = [sum(1 for m in mins if x >= m) - 1 for x in Ly[v]]
            Ly["s"] = [CL[v]["map"][q] for q in t]; labs = [g["label"] for g in CL[v]["classes"]]
        else:
            Ly["s"] = [NOM[v].index(x) for x in Ly[v]]; labs = NOM[v]
        capmap = Ky.groupby("ligne").cap.sum()
        Ly["cap"] = Ly.index.map(capmap).fillna(0.0)
        rows = []
        for k, l in enumerate(labs):
            d = Ly[Ly.s == k]
            ch = ult[y] * d.cap.sum() / tot_cap
            rows.append(dict(label=l, E=float(d.exposition.sum()), primes=float(d.prime_acquise.sum()),
                             prime_moy=float(d.prime_acquise.sum() / d.exposition.sum()) if d.exposition.sum() else None,
                             charge=float(ch), sp=float(ch / d.prime_acquise.sum()) if d.prime_acquise.sum() else None))
        seg[y][v] = rows
R["tableau"] = dict(historique=hist, segments=seg, sp_cible=P["sp_cible"], taux_frais=P["taux_frais"])

# ============================================================ CALCULATEUR (profil par defaut)
def calc(age, zone, cv, usage, crm, s=P["s"], g=P["g"], a=P["a"], m=P["m"], t=P["t"]):
    vals = {"age": age, "zone": zone, "puissance_cv": cv, "usage": usage}
    rf = rc = 1.0; cls = {}
    for v in VARS:
        x = vals[v]
        if v in ORD:
            mins = [mm for mm, _ in ORD[v]]; ti = sum(1 for mm in mins if x >= mm) - 1
        else:
            ti = NOM[v].index(x)
        k = CL[v]["map"][ti]; cls[v] = CL[v]["classes"][k]["label"]
        iF = [i for i, nm in enumerate(names) if nm == (v, k)]
        if iF: rf *= math.exp(beta[iF[0]]); rc *= math.exp(gam[iF[0]])
    freq = math.exp(beta[0]) * rf * crm
    cout = math.exp(gam[0]) * rc * kappa * C_cal
    pp = freq * cout
    ht = pp * (1 + s) / (1 - g - a - m); ttc = ht * (1 + t)
    act = base25 * rel_act(age, zone, cv, usage) * crm
    return dict(classes=cls, rf=rf, rc=rc, freq=freq, cout=cout, pp=pp, securite=pp * s, frais=ht * (g + a),
                marge=ht * m, taxes=ht * t, ht=ht, ttc=ttc, mensuel=ttc / 12, ht_actuel=act,
                vs_actuel=ht / act - 1, vs_moyenne=ttc / R["tarif"]["ttc_moy"] - 1)
R["calculateur"] = dict(defaut=dict(age=23, zone="C", cv=6, usage="Trajet", crm=0.90),
                        resultat=calc(23, "C", 6, "Trajet", 0.90),
                        reference=calc(35, "B", 6, "Privé", 0.50))
R["parametres"] = {k: v for k, v in P.items()}
out = sys.argv[3] if len(sys.argv) > 3 else "recette_recalculee.json"
def conv(o):
    if isinstance(o, (np.integer,)): return int(o)
    if isinstance(o, (np.floating,)): return float(o)
    if isinstance(o, (date,)): return o.isoformat()
    if isinstance(o, tuple): return list(o)
    raise TypeError(type(o))
json.dump(R, open(out, "w"), default=conv, ensure_ascii=False, indent=1)
