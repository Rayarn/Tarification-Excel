# Installation (Excel 2013 ou plus récent, Windows)

1. Installer les polices du dossier `polices` (clic droit, « Installer »), puis redémarrer Excel.
2. Le classeur prêt à l'emploi est `PrimeLab_RC_2026.xlsm` ; le dossier `formules` doit rester à côté de lui.
3. Ouvrir le classeur et activer les macros : l'application s'ouvre en plein écran sur le tableau de bord.
4. Ctrl+Maj+M bascule entre mode application et mode administration (onglets, ruban, formules visibles).
5. Pour reconstruire depuis zéro : ouvrir `donnees/PrimeLab_RC_2026_donnees.xlsx`, l'enregistrer en `.xlsm` à la racine du pack,
   importer les 9 fichiers `src/*.bas` (Alt+F11, Fichier, Importer), coller `src/ThisWorkbook.txt` dans ThisWorkbook.
6. Exécuter `ConstruireApplication` (Alt+F8), puis `Recette` : la feuille Recette doit être entièrement verte. Enregistrer.
   Si Office se ferme en cours de route : `ConstruireMoteur`, enregistrer, puis `ConstruireInterface`.
7. Test automatisé (facultatif, exige l'accès approuvé au modèle objet VBA) :
   `powershell -File outils\piloter_excel.ps1 -Action complet -Macros ConstruireApplication,Recette`
