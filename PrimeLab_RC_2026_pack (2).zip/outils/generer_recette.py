"""Genere dev_utf8/modRecette.bas : logique de recette + valeurs attendues
recopiees de recette/*.json (section 15 du cahier), sans arrondi.
Usage : python outils/generer_recette.py"""
import json, os

RACINE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
J = lambda f: json.load(open(os.path.join(RACINE, "recette", f), encoding="utf-8"))
R, R10, R5 = J("recette.json"), J("recette_u10000.json"), J("recette_u5000.json")

def num(x):
    if isinstance(x, bool):
        return "True" if x else "False"
    if isinstance(x, int):
        return f"{x}#"
    r = repr(float(x))
    if "e" in r or "E" in r:
        m, e = r.lower().split("e")
        return f"{m}E{int(e)}"
    return r

def txt(s):
    s = s.replace("≤", "{inf}").replace("≥", "{sup}")
    s.encode("cp1252")
    return '"' + s.replace('"', '""') + '"'

lignes = []
def A(etape, lib, src, att, tol=0.0, mode="abs"):
    v = txt(att) if isinstance(att, str) else num(att)
    lignes.append(f'    A {txt(etape)}, {txt(lib)}, {txt(src)}, {v}, {num(float(tol))}, "{mode}"')

# ---------------------------------------------------------------- 01
im = R["import"]
A("01", "Lignes de la feuille Contrats", "N:q_lignes", im["lignes"], 0, "exact")
A("01", "Polices distinctes", "N:q_polices", im["polices"], 0, "exact")
A("01", "Sinistres bruts", "N:q_sinistres_bruts", im["sinistres_bruts"], 0, "exact")
A("01", "Exposition totale", "N:q_expo_totale", im["exposition"], 1e-6)
for y, v in im["expo_par_exercice"].items():
    A("01", f"Exposition {y}", f"H:{y}:B", v, 1e-6)
A("01", "Lignes à exposition nulle", "N:q_expo_nulle", im["lignes_expo_nulle"], 0, "exact")
# ---------------------------------------------------------------- 02
q = R["qualite"]
for st, nm in [("Doublon", "q_doublons"), ("Hors période", "q_hors_periode"), ("Orphelin", "q_orphelins"),
               ("Montant nul", "q_montant_nul"), ("OK", "q_ok")]:
    A("02", f"Sinistres « {st} »", f"N:{nm}", q["controles"][st], 0, "exact")
A("02", "Lignes à âge imputé", "N:q_ages_imputes", q["ages_imputes"], 0, "exact")
A("02", "Polices à âge imputé", "N:q_polices_age", q["polices_age_manquant"], 0, "exact")
for i, z in enumerate("ABCD"):
    A("02", f"Médiane d'âge zone {z}", f"C:Qualite!B{i + 2}", q["medianes_zone"][z], 0, "exact")
A("02", "CRM corrigés", "N:q_crm_corriges", q["crm_corriges"], 0, "exact")
A("02", "Complétude de date_naissance", "C:Qualite!F7", q["completude"]["date_naissance"], 1e-6)
# ---------------------------------------------------------------- 03
j = R["jointure"]
A("03", "Somme des nb_sin", "N:b_sin_ratt", j["sinistres_rattaches"], 0, "exact")
A("03", "Lignes sinistrées", "N:b_lignes_sin", j["lignes_sinistrees"], 0, "exact")
A("03", "Lignes à exposition non nulle", "N:b_lignes_base", j["lignes_base"], 0, "exact")
A("03", "Charge vue rattachée", "N:b_charge_ratt", j["charge_rattachee"], 0.01)
for k in ("1", "2", "3"):
    A("03", f"Lignes à {k}{'+' if k == '3' else ''} sinistre(s)", f"C:Historique_!B{10 + int(k)}", j["poisson_obs"][k], 0, "exact")
for k in ("1", "2", "3"):
    A("03", f"Attendu Poisson à {k}{'+' if k == '3' else ''}", f"C:Historique_!C{10 + int(k)}", j["poisson_att"][k], 0.01)
# ---------------------------------------------------------------- 04
u = R["ultime"]
for i, f in enumerate(u["ldf"]):
    A("04", f"Facteur f{i + 1}", f"C:Triangle!{chr(66 + i)}13", f, 1e-5)
for y in ("2021", "2022", "2023", "2024", "2025"):
    A("04", f"Exercice {y} : charge vue", f"H:{y}:D", u["diag"][y], 1e-5, "rel")
    A("04", f"Exercice {y} : CDF", f"H:{y}:E", u["cdf"][y], 1e-5, "rel")
    A("04", f"Exercice {y} : ultime", f"H:{y}:F", u["ultime"][y], 1e-5, "rel")
    A("04", f"Exercice {y} : rho", f"H:{y}:G", u["frev"][y], 1e-5, "rel")
A("04", "IBNR total 2021-2025", "N:hist_ibnr_tot", u["ibnr_total"], 1e-5, "rel")
A("04", "Charge cible C*", "N:charge_cible", u["charge_cible"], 1e-5, "rel")
# ---------------------------------------------------------------- 05
e = R["ecretement"]
A("05", "Sinistres au-dessus de u = 15 000", "N:ecr_n_graves", e["n_graves"], 0, "exact")
A("05", "Charge revalorisée", "N:ecr_charge_rev", e["charge_reval"], 0.01)
A("05", "Charge écrêtée", "N:ecr_charge_ecr", e["charge_ecretee"], 0.01)
A("05", "Excédent", "N:ecr_excedent", e["excedent"], 0.01)
for i, s in enumerate(("5000", "10000", "15000", "25000", "50000")):
    A("05", f"Part de l'excédent pour {int(s) // 1000} k€", f"C:Graves!J{i + 2}", e["part_par_seuil"][s], 1e-4)
# ---------------------------------------------------------------- 06
x = R["exploratoire"]
A("06", "Fréquence brute", "N:expl_freq", x["freq"], 1e-6)
A("06", "Fréquence à CRM 1,00", "N:expl_freq_crm", x["freq_crm"], 1e-6)
A("06", "Coût moyen écrêté", "N:expl_cout", x["cout_ecr"], 1e-4)
A("06", "Prime pure écrêtée", "N:expl_pp", x["pp_ecr"], 1e-4)
for t in x["variables"]["age"]:
    A("06", f"Tranche d'âge {t['label']} : E", f"E:age|{t['label']}:E", t["E"], 1e-3)
    A("06", f"Tranche d'âge {t['label']} : E*", f"E:age|{t['label']}:F", t["Es"], 1e-3)
    A("06", f"Tranche d'âge {t['label']} : N", f"E:age|{t['label']}:G", t["N"], 0, "exact")
# ---------------------------------------------------------------- 07
for v in ("age", "puissance_cv", "anc_permis", "anc_vehicule", "zone", "usage", "couleur"):
    c = R["classes"][v]
    A("07", f"Classes de {v} : nombre", f"N:cls_n_{v}", c["n"], 0, "exact")
    for g in c["classes"]:
        A("07", f"{v} {g['label']} : N", f"K:{v}|{g['label']}:H", g["N"], 0, "exact")
        A("07", f"{v} {g['label']} : relativité", f"K:{v}|{g['label']}:J", g["rel"], 1e-4)
# ---------------------------------------------------------------- 08
s = R["selection"]
for v in ("age", "zone", "puissance_cv", "usage", "anc_permis", "anc_vehicule", "couleur"):
    un = s["univarie"][v]
    A("08", f"{v} : chi2", f"S:{v}:B", un["chi2"], 1e-3)
    A("08", f"{v} : ddl", f"S:{v}:C", un["ddl"], 0, "exact")
    A("08", f"{v} : V", f"S:{v}:E", un["V"], 1e-3)
    if v in s["lrt"]:
        A("08", f"{v} : delta D", f"S:{v}:G", s["lrt"][v]["dD"], 1e-3)
    A("08", f"{v} : décision", f"S:{v}:J", s["decision"][v], 0, "txt")
A("08", "V maximal entre retenues", "N:assoc_vmax", s["v_max_retenues"], 1e-4)
paire = max(s["assoc_retenues"], key=s["assoc_retenues"].get).replace("×", "|")
A("08", "Paire de V maximal", "N:assoc_paire", paire, 0, "txt")
# ---------------------------------------------------------------- 09
m = R["modeles"]
for pre, cle, sh in (("freq", "Fréquence", "GF"), ("cout", "Coût", "GC")):
    for p in m[pre]:
        k = "Intercept" if p["var"] == "Intercept" else p["param"].replace(" ", "|", 1)
        A("09", f"{cle} : {p['param']} coefficient", f"{sh}:{k}:C", p["coef"], 1e-5)
        A("09", f"{cle} : {p['param']} erreur std", f"{sh}:{k}:E", p["se"], 1e-5)
A("09", "Déviance fréquence (cellules)", "N:glmf_dev_cel", m["dev_freq"], 1e-3)
A("09", "Déviance fréquence (lignes)", "N:glmf_dev_lig", m["dev_ind_freq"], 1e-3)
A("09", "Déviance nulle fréquence (lignes)", "N:glmf_dev0_lig", m["dev0_ind_freq"], 1e-3)
A("09", "Déviance coût (cellules)", "N:glmc_dev_cel", m["dev_cout"], 1e-3)
A("09", "Déviance coût (sinistres)", "N:glmc_dev_sin", m["dev_ind_cout"], 1e-3)
A("09", "Déviance nulle coût (sinistres)", "N:glmc_dev0_sin", m["dev0_ind_cout"], 1e-3)
A("09", "Dispersion phi (coût)", "N:glmc_phi", m["phi"], 1e-4)
A("09", "Cellules fréquence", "N:glmf_ncel", m["n_cellules_freq"], 0, "exact")
A("09", "Cellules coût", "N:glmc_ncel", m["n_cellules_cout"], 0, "exact")
A("09", "Itérations IRLS fréquence", "N:glmf_iter", m["iter_freq"], 1, "abs")
A("09", "Itérations IRLS coût", "N:glmc_iter", m["iter_cout"], 1, "abs")
for i, l in enumerate(m["lift_freq"]):
    A("09", f"Lift fréquence Q{i + 1} observé", f"I:glmf_q_obs:{i + 1}", l["obs"], 1e-5)
    A("09", f"Lift fréquence Q{i + 1} prédit", f"I:glmf_q_pred:{i + 1}", l["pred"], 1e-5)
for i, l in enumerate(m["lift_cout"]):
    A("09", f"Lift coût Q{i + 1} observé", f"I:glmc_q_obs:{i + 1}", l["obs"], 0.1)
    A("09", f"Lift coût Q{i + 1} prédit", f"I:glmc_q_pred:{i + 1}", l["pred"], 0.1)
for i, c in enumerate(m["ratio_crm"]):
    A("09", f"Observé / prédit CRM {c['classe']}", f"I:crm_ratio:{i + 1}", c["ratio"], 1e-4)
# ---------------------------------------------------------------- 10
g = R["graves"]
A("10", "n_u", "N:n_u", g["n_u"], 0, "exact")
A("10", "alpha", "N:alpha", g["alpha"], 1e-5)
A("10", "IC 95 % borne basse", "N:ic_bas", g["ic"][0], 1e-4)
A("10", "IC 95 % borne haute", "N:ic_haut", g["ic"][1], 1e-4)
A("10", "e(u) Pareto", "N:e_u", g["e_u"], 0.01)
A("10", "e(u) empirique", "N:e_emp", g["e_emp"], 0.01)
A("10", "kappa", "N:kappa", g["kappa"], 1e-6)
A("10", "kappa empirique", "N:kappa_emp", g["kappa_emp"], 1e-6)
A("10", "Écart kappa", "N:ecart_kappa", g["ecart_kappa"], 1e-6)
for i, sv in enumerate(g["survie"]):
    A("10", f"Survie observée {sv['x'] / g['survie'][0]['x'] * 1.5:g}u", f"I:surv_obs:{i + 1}", sv["obs"], 1e-4)
    A("10", f"Survie Pareto {sv['x'] / g['survie'][0]['x'] * 1.5:g}u", f"I:surv_par:{i + 1}", sv["pareto"], 1e-4)
# ---------------------------------------------------------------- 11
t = R["tarif"]
A("11", "B0", "N:B0", t["B0"], 1e-5, "rel")
A("11", "theta", "N:theta", t["calage"], 1e-5, "rel")
A("11", "B", "N:base_pp", t["base"], 1e-5, "rel")
A("11", "Prime pure moyenne", "N:pp_moy", t["pp_moy"], 1e-4)
A("11", "Polices renouvelées", "N:n_renouv", t["n_renouv"], 0, "exact")
A("11", "Évolution moyenne", "N:evol_moy", t["evol_moy"], 1e-5)
A("11", "Équilibre plafonné", "N:equilibre", t["equilibre_plaf"], 1e-5)
A("11", "Prime TTC moyenne nouvelle", "N:ttc_moy", t["ttc_moy"], 0.01)
A("11", "Prime TTC moyenne actuelle", "N:ttc_moy_act", t["ttc_moy_act"], 0.01)
for i, d in enumerate(t["dislocation"]):
    A("11", f"Dislocation {d['bin']}", f"I:disl_part:{i + 1}", d["part"], 1e-4)
for rl in t["relativites"]:
    k = f"{rl['var']}|{rl['classe']}"
    A("11", f"{rl['var']} {rl['classe']} : rel. F", f"T:{k}:C", rl["relF"], 1e-4)
    A("11", f"{rl['var']} {rl['classe']} : rel. C", f"T:{k}:D", rl["relC"], 1e-4)
    A("11", f"{rl['var']} {rl['classe']} : rel. PP", f"T:{k}:E", rl["relPP"], 1e-4)
    A("11", f"{rl['var']} {rl['classe']} : évolution", f"T:{k}:F", rl["evol"], 1e-4)
# ---------------------------------------------------------------- TB
for h in R["tableau"]["historique"]:
    y = h["exercice"]
    A("TB", f"Exercice {y} : primes", f"H:{y}:I", h["primes"], 1e-4)
    A("TB", f"Exercice {y} : ultime", f"H:{y}:F", h["ult"], 1e-4)
    A("TB", f"Exercice {y} : S/P", f"H:{y}:L", h["sp"], 1e-4)
    A("TB", f"Exercice {y} : ratio combiné", f"H:{y}:M", h["cor"], 1e-4)
for v in ("age", "zone", "puissance_cv", "usage"):
    for sg in R["tableau"]["segments"]["2025"][v]:
        A("TB", f"Segments 2025 {v} {sg['label']} : S/P", f"G:2025|{v}|{sg['label']}", sg["sp"], 1e-3)
A("TB", "Bandeau 2025", "B:2025", "La zone C et l’usage professionnel restent sous-tarifés : S/P 2025 de 101 % "
  "et 98 % (cible 68 %). Lancer la révision.", 0, "txt")
# ---------------------------------------------------------------- CA
ca = R["calculateur"]
for prof, lab in (("defaut", "Profil par défaut"), ("reference", "Profil de référence")):
    rr = ca["resultat"] if prof == "defaut" else ca["reference"]
    if prof == "defaut":
        A("CA", f"{lab} : fréquence", f"P:{prof}:calc_freq", rr["freq"], 1e-4)
        A("CA", f"{lab} : coût", f"P:{prof}:calc_cout", rr["cout"], 0.01)
        A("CA", f"{lab} : HT", f"P:{prof}:calc_ht", rr["ht"], 0.01)
        A("CA", f"{lab} : vs moyenne", f"P:{prof}:calc_vs_moyenne", rr["vs_moyenne"], 1e-4)
    A("CA", f"{lab} : prime pure", f"P:{prof}:calc_pp", rr["pp"], 0.01)
    A("CA", f"{lab} : TTC", f"P:{prof}:calc_ttc", rr["ttc"], 0.01)
    A("CA", f"{lab} : vs tarif actuel", f"P:{prof}:calc_vs_actuel", rr["vs_actuel"], 1e-4)
# ---------------------------------------------------------------- contrôles
for et in range(1, 12):
    for k in range(1, 4):
        A("CT", f"Contrôle {et:02d}-{k} vert à 15 000 €", f"X:{(et - 1) * 3 + k}", True, 0, "bool")

def scenario(nom, D, roses):
    out = []
    def S(lib, src, att, tol, mode="abs"):
        v = num(att)
        out.append(f'    A {txt(nom)}, {txt(lib)}, {txt(src)}, {v}, {num(float(tol))}, "{mode}"')
    S("n_u", "N:n_u", D["graves"]["n_u"], 0, "exact")
    S("Part de l'excédent", "N:ecr_part_exc", D["ecretement"]["part_excedent"], 1e-4)
    S("alpha", "N:alpha", D["graves"]["alpha"], 1e-4)
    S("kappa", "N:kappa", D["graves"]["kappa"], 1e-4)
    S("kappa empirique", "N:kappa_emp", D["graves"]["kappa_emp"], 1e-4)
    S("theta", "N:theta", D["tarif"]["calage"], 1e-4)
    S("B", "N:base_pp", D["tarif"]["base"], 0.01)
    S("Évolution moyenne", "N:evol_moy", D["tarif"]["evol_moy"], 1e-4)
    S("Équilibre plafonné", "N:equilibre", D["tarif"]["equilibre_plaf"], 1e-4)
    for et in range(1, 12):
        for k in range(1, 4):
            ok = f"{et:02d}-{k}" not in roses
            S(f"Contrôle {et:02d}-{k} {'vert' if ok else 'rose'}", f"X:{(et - 1) * 3 + k}", ok, 0, "bool")
    return out

sc10 = scenario("S10", R10, {"10-2"})
sc5 = scenario("S05", R5, {"05-3", "10-2"})

gabarit = open(os.path.join(RACINE, "outils", "modRecette_gabarit.txt"), encoding="utf-8").read()
def bloc(nom, l):
    corps = []
    for i in range(0, len(l), 90):
        corps.append(l[i:i + 90])
    subs = []
    for n, c in enumerate(corps):
        subs.append(f"Private Sub {nom}{n + 1}()\n" + "\n".join(c) + "\nEnd Sub\n")
    appel = "\n".join(f"    {nom}{n + 1}" for n in range(len(corps)))
    return "".join(subs), appel
b1, a1 = bloc("Attendus", lignes)
b2, a2 = bloc("AttendusS10_", sc10)
b3, a3 = bloc("AttendusS05_", sc5)
texte = (gabarit.replace("'@@APPELS_BASE@@", a1).replace("'@@APPELS_S10@@", a2).replace("'@@APPELS_S05@@", a3)
         + "\n" + b1 + "\n" + b2 + "\n" + b3)
open(os.path.join(RACINE, "dev_utf8", "modRecette.bas"), "w", encoding="utf-8", newline="\n").write(texte)
print("modRecette :", len(lignes), "indicateurs de base,", len(sc10), "+", len(sc5), "de scénarios")
