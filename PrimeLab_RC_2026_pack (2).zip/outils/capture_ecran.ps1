# Capture de l'écran principal (débogage des boîtes de dialogue d'Excel).
# Usage : powershell -File capture_ecran.ps1 -Sortie C:\chemin\capture.png
param([string]$Sortie = "$env:TEMP\capture_excel.png")
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$ecran = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds
$bmp = New-Object System.Drawing.Bitmap $ecran.Width, $ecran.Height
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.CopyFromScreen($ecran.Location, [System.Drawing.Point]::Empty, $ecran.Size)
$bmp.Save($Sortie, [System.Drawing.Imaging.ImageFormat]::Png)
$g.Dispose(); $bmp.Dispose()
Write-Output $Sortie
