"""Controle de src/ : Windows-1252 decodable, fins de ligne CRLF uniquement,
premiere ligne Attribute VB_Name pour les .bas, Option Explicit, longueur des modules et procedures.
Usage : python outils/verifier_encodage.py"""
import os, re, sys
RACINE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(RACINE, "src")
defauts = 0
def defaut(msg):
    global defauts
    defauts += 1
    print("DEFAUT", msg)
for nom in sorted(os.listdir(SRC)):
    chemin = os.path.join(SRC, nom)
    brut = open(chemin, "rb").read()
    try:
        texte = brut.decode("cp1252")
    except UnicodeDecodeError as e:
        defaut(f"{nom}: octet non Windows-1252 en position {e.start}")
        continue
    if b"\n" in brut.replace(b"\r\n", b""):
        defaut(f"{nom}: fin de ligne LF isolee")
    if b"\r" in brut.replace(b"\r\n", b""):
        defaut(f"{nom}: CR isole")
    if brut.startswith(b"\xef\xbb\xbf"):
        defaut(f"{nom}: BOM UTF-8")
    lignes = texte.split("\r\n")
    if nom.endswith(".bas"):
        attendu = f'Attribute VB_Name = "{nom[:-4]}"'
        if lignes[0] != attendu:
            defaut(f"{nom}: premiere ligne {lignes[0]!r}")
        if "Option Explicit" not in lignes[:5]:
            defaut(f"{nom}: Option Explicit absent")
        if len(lignes) > 1300:
            defaut(f"{nom}: {len(lignes)} lignes (> 1300)")
    debut = None
    for i, l in enumerate(lignes):
        if re.match(r"^(Public |Private )?(Sub|Function|Property \w+) ", l):
            debut = (i, l)
        elif re.match(r"^End (Sub|Function|Property)", l) and debut:
            if i - debut[0] + 1 > 120:
                defaut(f"{nom}: procedure de {i - debut[0] + 1} lignes : {debut[1][:60]}")
            debut = None
    print(f"{nom}: {len(lignes)} lignes, ok")
print("RESULTAT :", "CONFORME" if defauts == 0 else f"{defauts} defaut(s)")
sys.exit(1 if defauts else 0)
