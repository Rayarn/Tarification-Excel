# Pilotage d'Excel par COM pour les tests (exige l'acces approuve au modele objet du projet VBA).
# Usage :
#   powershell -File piloter_excel.ps1 -Action init            (xlsx de depart -> PrimeLab_RC_2026.xlsm + import)
#   powershell -File piloter_excel.ps1 -Action import          (reimporte src/ dans le xlsm existant)
#   powershell -File piloter_excel.ps1 -Action run -Macros ConstruireMoteurPartie:1,Recette
#   powershell -File piloter_excel.ps1 -Action dump -Feuille Recette
param(
    [string]$Action = "run",
    [string[]]$Macros = @(),
    [string]$Feuille = "Recette",
    [string]$Plage = "",
    [switch]$Visible,
    [switch]$SauverChaque
)
$ErrorActionPreference = "Stop"
$racine = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$xlsx = Join-Path $racine "donnees\PrimeLab_RC_2026_donnees.xlsx"
$xlsm = Join-Path $racine "PrimeLab_RC_2026.xlsm"
$src = Join-Path $racine "src"

function Nettoyer-Recuperation {
    # Entrees de recuperation laissees par un plantage d'Excel sur notre classeur (rejouees au demarrage)
    $cle = 'HKCU:\Software\Microsoft\Office\15.0\Excel\Resiliency\DocumentRecovery'
    if (Test-Path $cle) {
        foreach ($k in Get-ChildItem $cle) {
            $v = (Get-ItemProperty $k.PSPath).($k.PSChildName)
            if ($v -is [byte[]]) {
                if ([Text.Encoding]::Unicode.GetString($v) -match 'PrimeLab_RC_2026') { Remove-Item $k.PSPath -Recurse }
            }
        }
    }
}

function Arreter-Excel {
    Get-Process | Where-Object { $_.Name -eq 'EXCEL' } | Stop-Process -Force -ErrorAction SilentlyContinue
}

function Ouvrir-Excel {
    Arreter-Excel
    Start-Sleep -Seconds 2
    Nettoyer-Recuperation
    Get-ChildItem $racine -Filter '~$*' -Force -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
    $app = New-Object -ComObject Excel.Application
    $app.DisplayAlerts = $false
    $app.AutomationSecurity = 1
    $app.Visible = [bool]$Visible
    return $app
}

function Ouvrir-Classeur([string]$chemin, [bool]$lectureSeule) {
    for ($essai = 1; $essai -le 3; $essai++) {
        try {
            if ($script:xl -eq $null) { $script:xl = Ouvrir-Excel }
            return $script:xl.Workbooks.Open($chemin, 0, $lectureSeule)
        } catch {
            Write-Host ('ouverture, essai ' + $essai + ' : ' + $_.Exception.Message)
            try { $script:xl.Quit() } catch {}
            $script:xl = $null
        }
    }
    throw ('ouverture impossible : ' + $chemin)
}

function Importer-Modules($wb) {
    $proj = $wb.VBProject
    foreach ($f in Get-ChildItem $src -Filter *.bas) {
        $nom = [IO.Path]::GetFileNameWithoutExtension($f.Name)
        for ($i = $proj.VBComponents.Count; $i -ge 1; $i--) {
            $c = $proj.VBComponents.Item($i)
            if ($c.Name -eq $nom) { $proj.VBComponents.Remove($c) }
        }
        $t1 = Get-Date
        $proj.VBComponents.Import($f.FullName) | Out-Null
        Write-Output ('importe : ' + $nom + ' (' + [Math]::Round(((Get-Date) - $t1).TotalSeconds, 1) + ' s)')
    }
    $tw = Join-Path $src 'ThisWorkbook.txt'
    if (Test-Path $tw) {
        $code = [IO.File]::ReadAllText($tw, [Text.Encoding]::GetEncoding(1252))
        $cm = $proj.VBComponents.Item($wb.CodeName).CodeModule
        if ($cm.CountOfLines -gt 0) { $cm.DeleteLines(1, $cm.CountOfLines) }
        $cm.AddFromString($code)
        Write-Output 'importe : ThisWorkbook'
    }
}

function Executer([string]$macro) {
    for ($e = 1; $e -le 40; $e++) {
        try {
            if ($macro -match '^(\w+):(.+)$') { $script:xl.Run($Matches[1], [int]$Matches[2]) | Out-Null }
            elseif ($macro -eq 'ModeSilencieux') { $script:xl.Run('ModeSilencieux', $true) | Out-Null }
            else { $script:xl.Run($macro) | Out-Null }
            return
        } catch {
            if ($_.Exception.Message -notmatch '800AC472|80010001') { throw }
            Start-Sleep -Seconds 3
        }
    }
    throw ('Excel reste occupe : ' + $macro)
}

$script:xl = $null
try {
    switch ($Action) {
        'init' {
            $wb = Ouvrir-Classeur $xlsx $false
            if (Test-Path $xlsm) { Remove-Item $xlsm }
            $wb.SaveAs($xlsm, 52)
            Importer-Modules $wb
            $wb.Save()
            Write-Output ('classeur cree : ' + $xlsm)
        }
        'complet' {
            $t0 = Get-Date
            $wb = Ouvrir-Classeur $xlsx $false
            if (Test-Path $xlsm) { Remove-Item $xlsm }
            $wb.SaveAs($xlsm, 52)
            Write-Output ('ouverture et enregistrement : ' + [Math]::Round(((Get-Date) - $t0).TotalSeconds, 1) + ' s')
            Importer-Modules $wb
            Executer 'ModeSilencieux'
            foreach ($m in $Macros) {
                $t0 = Get-Date
                for ($e = 1; $e -le 20; $e++) {
                    try {
                        if ($m -match '^(\w+):(.+)$') { $script:xl.Run($Matches[1], [int]$Matches[2]) } else { $script:xl.Run($m) }
                        break
                    } catch {
                        if ($_.Exception.Message -notmatch '800AC472|80010001') { throw }
                        Start-Sleep -Seconds 3
                    }
                }
                $t1 = Get-Date
                if ($SauverChaque) { $wb.Save() }
                Write-Output ($m + ' : ' + [Math]::Round(($t1 - $t0).TotalSeconds, 1) + ' s')
                $err = ''
                try { $err = $wb.Worksheets.Item('CALC').Range('B12').Text } catch {}
                if ($err -ne '') { Write-Output ('ERREUR VBA : ' + $err); break }
            }
            $t1 = Get-Date
            for ($e = 1; $e -le 20; $e++) {
                try { $wb.Save(); break } catch { Start-Sleep -Seconds 3 }
            }
            Write-Output ('enregistrement final : ' + [Math]::Round(((Get-Date) - $t1).TotalSeconds, 1) + ' s')
            try { Write-Output ('Resume recette : ' + $wb.Worksheets.Item('Recette').Range('I2').Text) } catch {}
            try {
                $v = $wb.Worksheets.Item('Recette').UsedRange.Value2
                for ($i = 2; $i -le $v.GetLength(0); $i++) {
                    if ([string]$v[$i, 7] -eq 'non conforme') {
                        Write-Output ('KO ' + [string]$v[$i, 1] + ' | ' + [string]$v[$i, 2] + ' | attendu ' + [string]$v[$i, 3] + ' | obtenu ' + [string]$v[$i, 4])
                    }
                }
            } catch {}
            if ($Plage -ne '') {
                $v = $wb.Worksheets.Item($Feuille).Range($Plage).Value2
                for ($i = 1; $i -le $v.GetLength(0); $i++) {
                    $l = @(); for ($j = 1; $j -le $v.GetLength(1); $j++) { $l += [string]$v[$i, $j] }
                    Write-Output ($l -join ' | ')
                }
            }
        }
        'import' {
            $wb = Ouvrir-Classeur $xlsm $false
            Importer-Modules $wb
            $wb.Save()
        }
        'run' {
            $wb = Ouvrir-Classeur $xlsm $false
            Executer 'ModeSilencieux'
            foreach ($m in $Macros) {
                $t0 = Get-Date
                Executer $m
                $t1 = Get-Date
                $wb.Save()
                Write-Output ($m + ' : ' + [Math]::Round(($t1 - $t0).TotalSeconds, 1) + ' s (enregistrement ' + [Math]::Round(((Get-Date) - $t1).TotalSeconds, 1) + ' s)')
                $err = ''
                try { $err = $wb.Worksheets.Item('CALC').Range('B12').Text } catch {}
                if ($err -ne '') { Write-Output ('ERREUR VBA : ' + $err); break }
            }
            try { Write-Output ('Resume recette : ' + $wb.Worksheets.Item('Recette').Range('I2').Text) } catch {}
        }
        'dump' {
            $wb = Ouvrir-Classeur $xlsm $true
            $ws = $wb.Worksheets.Item($Feuille)
            if ($Plage -eq '') { $r = $ws.UsedRange } else { $r = $ws.Range($Plage) }
            $v = $r.Value2
            if ($v -is [array]) {
                for ($i = 1; $i -le $v.GetLength(0); $i++) {
                    $l = @()
                    for ($j = 1; $j -le $v.GetLength(1); $j++) { $l += [string]$v[$i, $j] }
                    if ($Feuille -ne 'Recette' -or $l[6] -ne 'conforme') { Write-Output ($l -join ' | ') }
                }
            } else { Write-Output ([string]$v) }
        }
    }
}
finally {
    try { $script:xl.Workbooks.Close() } catch {}
    try { $script:xl.Quit() } catch {}
    Start-Sleep -Seconds 2
    Arreter-Excel
}
