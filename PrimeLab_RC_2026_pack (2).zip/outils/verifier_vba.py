"""Revue statique heuristique des modules VBA de dev_utf8/ :
- appels à des procédures non définies (identifiants inconnus suivis d'arguments)
- variables utilisées mais non déclarées dans la procédure (Option Explicit)
- nombre de lignes par procédure.
Usage : python outils/verifier_vba.py"""
import os, re, sys

RACINE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DOSSIER = os.path.join(RACINE, "dev_utf8")
BUILTINS = set("""
MkDir RmDir FileCopy Abs Array Asc AscW CBool CByte CCur CDate CDbl CDec CInt CLng CSng CStr CVar CVErr Chr ChrW Chr$ Choose Close Cos
Date DateSerial Day Debug Dir Dir$ Do DoEvents Each Else ElseIf End Environ Environ$ EOF Erase Err Error Exit Exp False Fix For
Format Format$ FreeFile Function GoTo If IIf Input InStr InStrRev Int Is IsArray IsDate IsEmpty IsError IsMissing
IsNull IsNumeric IsObject LBound LCase LCase$ Left Left$ Len Let Line Log Loop LTrim Mid Mid$ Month MsgBox New Next Not Nothing Now
Null On Open Option Or Print Private Public ReDim Rem Replace Resume Return Right Right$ RGB Rnd Round RTrim Select Set Sgn
Sin Space Split Sqr Static Step Stop Str String String$ StrComp Sub Tan Then Time Timer TimeValue To Trim Trim$ True TypeName
UBound UCase UCase$ Until Val VarType Wend While With Year And Mod Xor Like Optional ByVal ByRef As Dim Const Call Case
Application ThisWorkbook ActiveWindow ActiveSheet ActiveCell Range Cells Columns Rows Worksheets Sheets Names Shapes
CreateObject GetObject Empty Preserve Append Output Binary Get Put Write Attribute Explicit Base Compare Text Integer Long
Double String Boolean Variant Object Worksheet Workbook Shape Chart ChartObject Series Axis Point Single Byte Currency Decimal
Collection Dictionary Error Name Lock Unlock Seek Width Kill Beep Shell AppActivate SendKeys Filter Join Hex Oct Weekday
In WorksheetFunction Caller Version Min Max Match Index CountIf Transpose ChiSq_Dist_RT PathSeparator Calculate Run Wait
Evaluate ExecuteExcel4Macro OnTime OnKey Intersect Union Count Item Add Delete Value Value2 Formula FormulaArray FormulaLocal
""".split())

def lire():
    mods = {}
    for f in sorted(os.listdir(DOSSIER)):
        if f.endswith(".bas") and not f.startswith("_"):
            mods[f] = open(os.path.join(DOSSIER, f), encoding="utf-8").read().replace("\r\n", "\n")
    tw = os.path.join(DOSSIER, "ThisWorkbook.txt")
    if os.path.exists(tw):
        mods["ThisWorkbook.txt"] = open(tw, encoding="utf-8").read()
    return mods

def joindre(lignes):
    out, cur = [], ""
    for l in lignes:
        s = re.sub(r"'.*$", "", re.sub(r'"[^"]*"', '""', l))
        if s.rstrip().endswith(" _"):
            cur += s.rstrip()[:-1] + " "
        else:
            out.append(cur + s)
            cur = ""
    return out

def main():
    mods = lire()
    procs, globaux = set(), set()
    for f, t in mods.items():
        for m in re.finditer(r"^(?:Public |Private )?(?:Sub|Function|Property Get|Property Let) (\w+)", t, re.M):
            procs.add(m.group(1))
        for m in re.finditer(r"^(?:Public|Private|Dim|Global)\s+(?:Const\s+)?(\w+)", t, re.M):
            if m.group(1) not in ("Sub", "Function", "Const"):
                globaux.add(m.group(1))
        for m in re.finditer(r"^(?:Public|Private)\s+Const\s+(\w+)", t, re.M):
            globaux.add(m.group(1))
        for m in re.finditer(r"^(?:Public|Private|Dim)\s+(\w+)\s*(?:\(|As)", t, re.M):
            globaux.add(m.group(1))
    defauts = 0
    for f, t in mods.items():
        lignes = joindre(t.split("\n"))
        locales, dans = set(), False
        nom, debut = "", 0
        for i, l in enumerate(lignes):
            m = re.match(r"^(?:Public |Private )?(?:Sub|Function) (\w+)\((.*)\)", l)
            if m:
                dans, nom, locales = True, m.group(1), set()
                for a in m.group(2).split(","):
                    a = re.sub(r"\b(Optional|ByVal|ByRef|ParamArray)\b", "", a).strip()
                    if a:
                        locales.add(re.split(r"[\s(=]", a)[0])
                continue
            if re.match(r"^End (Sub|Function)", l):
                dans = False
                continue
            if not dans:
                continue
            for d in re.finditer(r"\b(?:Dim|Static|ReDim(?: Preserve)?)\s+(.*)", l):
                for part in re.split(r",(?![^(]*\))", d.group(1)):
                    v = part.strip().split("(")[0].split(" ")[0]
                    if v:
                        locales.add(v)
            corps = re.sub(r"\b(?:Dim|Static)\s+.*", "", l)
            corps = re.sub(r"\b\w+:=", "", corps)
            corps = re.sub(r"GoTo \w+", "", corps)
            if re.match(r"^\s*\w+:\s*$", corps):
                continue
            corps = re.sub(r"\.\w+", "", corps)
            corps = re.sub(r"\b\d+(\.\d+)?(E[+-]?\d+)?#?\b", "", corps)
            for tok in re.findall(r"\b([A-Za-z_]\w*\$?)", corps):
                if tok in BUILTINS or tok in procs or tok in globaux or tok in locales or tok == nom:
                    continue
                if re.match(r"^(xl|mso|vb)", tok):
                    continue
                print(f"{f}:{nom}: identifiant inconnu « {tok} » : {l.strip()[:90]}")
                defauts += 1
    procs_min = {p.lower() for p in procs}
    # Déclarations en double dans une procédure (VBA ignore la casse) et paramètre homonyme de la procédure
    for f, t in mods.items():
        lignes = joindre(t.split("\n"))
        noms, nom = [], None
        for l in lignes:
            m = re.match(r"^(?:Public |Private )?(?:Sub|Function) (\w+)\((.*)\)", l)
            if m:
                nom = m.group(1)
                noms = []
                corps_lignes = []
                for a in m.group(2).split(","):
                    a = re.sub(r"\b(Optional|ByVal|ByRef|ParamArray)\b", "", a).strip()
                    if a:
                        noms.append(re.split(r"[\s(=]", a)[0])
                continue
            if re.match(r"^End (Sub|Function)", l):
                corps_proc = chr(10).join(corps_lignes)
                vus = {}
                for n in noms:
                    k = n.lower()
                    if k in vus:
                        print(f"{f}:{nom}: déclaration en double « {vus[k]} » / « {n} »")
                        defauts += 1
                    vus[k] = n
                    if nom and k == nom.lower():
                        print(f"{f}:{nom}: variable homonyme de la procédure « {n} »")
                        defauts += 1
                    elif k in procs_min and re.search(r"(?im)^\s*(?:Call\s+)?" + n + r"(?!\s*=)", corps_proc):
                        print(f"{f}:{nom}: variable « {n} » homonyme d'une procédure (masquage)")
                        defauts += 1
                nom = None
                continue
            if nom:
                corps_lignes.append(l)
                for d in re.finditer(r"\b(?:Dim|Static)\s+(.*)", l):
                    for part in re.split(r",(?![^(]*\))", d.group(1)):
                        v = part.strip().split("(")[0].split(" ")[0]
                        if v:
                            noms.append(v)
    # Noms publics en double (procédures, constantes, variables) entre modules : « nom ambigu »
    publics = {}
    for f, t in mods.items():
        for m in re.finditer(r"^Public (?:Const |Sub |Function )?(\w+)", t, re.M):
            k = m.group(1).lower()
            if k in ("sub", "function", "const"):
                continue
            publics.setdefault(k, set()).add(f)
        for m in re.finditer(r"^(?:Private )?(?:Sub|Function) (\w+)", t, re.M):
            publics.setdefault(m.group(1).lower(), set()).add(f)
    for k, fs in publics.items():
        if len(fs) > 1:
            print(f"nom défini dans plusieurs modules : {k} ({', '.join(sorted(fs))})")
            defauts += 1
    # Procédures privées appelées depuis un autre module
    privees = {}
    for f, t in mods.items():
        for m in re.finditer(r"^Private (?:Sub|Function) (\w+)", t, re.M):
            privees[m.group(1)] = f
    for f, t in mods.items():
        texte = "\n".join(joindre(t.split("\n")))
        for nomp, fp in privees.items():
            if fp != f and re.search(r"(?<![\w.])" + nomp + r"\b", texte):
                if not re.search(r"^(?:Public |Private )?(?:Sub|Function) " + nomp + r"\b", t, re.M):
                    print(f"{f}: appel de la procédure privée {nomp} de {fp}")
                    defauts += 1
    print("DEFAUTS :", defauts)
    return defauts

if __name__ == "__main__":
    sys.exit(1 if main() else 0)
