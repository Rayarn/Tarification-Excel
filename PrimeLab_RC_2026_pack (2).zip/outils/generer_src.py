"""Convertit les sources UTF-8 de dev_utf8/ en fichiers Windows-1252 + CRLF dans src/.
Usage : python outils/generer_src.py
Refuse tout caractere hors Windows-1252 (ils doivent passer par ChrW, regle R6)."""
import os, sys
RACINE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC, DST = os.path.join(RACINE, "dev_utf8"), os.path.join(RACINE, "src")
erreurs = 0
for nom in sorted(os.listdir(SRC)):
    if nom.startswith("_") or not (nom.endswith(".bas") or nom.endswith(".txt")):
        continue
    texte = open(os.path.join(SRC, nom), encoding="utf-8").read().replace("\r\n", "\n")
    for n, ligne in enumerate(texte.split("\n"), 1):
        try:
            ligne.encode("cp1252")
        except UnicodeEncodeError as e:
            print(f"{nom}:{n}: caractere hors Windows-1252 {ligne[e.start]!r}")
            erreurs += 1
    if erreurs:
        continue
    with open(os.path.join(DST, nom), "w", encoding="cp1252", newline="\r\n") as f:
        f.write(texte)
print("ERREURS" if erreurs else "OK", erreurs)
sys.exit(1 if erreurs else 0)
