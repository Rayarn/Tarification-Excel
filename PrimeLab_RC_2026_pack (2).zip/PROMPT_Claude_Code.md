# Mission : générer l'application Excel VBA « PrimeLab, étude tarifaire RC auto 2026 »

Tu es développeur VBA senior, avec une solide culture actuarielle. Tu écris le code VBA complet d'une application Excel qui réalise de A à Z une étude tarifaire RC automobile et la présente en 13 pages interactives. Tout est spécifié dans le cahier des charges joint : ton rôle est de l'implémenter fidèlement, pas de le réinterpréter.

## 1. Contenu du dossier

| Chemin | Contenu |
|---|---|
| `cahier_des_charges/PrimeLab_RC_2026_cahier_des_charges.md` | Spécification complète (même contenu que le `.docx` et le `.pdf`, à lire en priorité) |
| `maquettes/*.png` | Rendu cible des 13 pages + une variante (seuil 5 k€), 960 × 540 pt |
| `donnees/PrimeLab_RC_2026_donnees.xlsx` | Classeur de départ (Contrats, Sinistres, Triangle, TarifActuel, Parametres) |
| `formules/` | 33 formules en SVG et PNG + `manifeste.csv` (tailles en points) |
| `recette/*.json` | Valeurs attendues (seuil 15 000 €, 10 000 €, 5 000 €) |
| `reference/etude_reference.py` | Implémentation Python qui a produit la recette, à partir du classeur de départ |
| `polices/` | Plus Jakarta Sans (OFL), installée par l'utilisateur |

## 2. Méthode imposée

1. Lis **intégralement** le cahier des charges, puis regarde les 14 maquettes. Ne code rien avant.
2. Hiérarchie des sources (section 0.1) : cahier, puis recette, puis maquettes. Si un algorithme te paraît ambigu, aligne-toi sur `reference/etude_reference.py` : c'est lui qui a produit les valeurs attendues. Ne pose une question que si une contradiction te bloque réellement.
3. Travaille en **trois phases** (section 16). À la fin de chaque phase, livre les fichiers, une procédure de test courte, puis **arrête-toi et attends mon retour** (résultat de la feuille `Recette` ou captures) avant de continuer :
   - **Phase 1, moteur** : `modApp` (squelette : erreurs, état, noms, `ConstruireMoteur`), `modOutils`, `modDonnees`, `modEtude`, `modGLM`, `modRecette`. Critère : feuille `Recette` entièrement verte, scénarios de seuil compris.
   - **Phase 2, pages** : `modDesign`, `modContenu`, `modPages`, `modApp` complet, `ThisWorkbook`. Critère : pages superposables aux maquettes.
   - **Phase 3, interactions et robustesse** : puces, boutons, bulles, consultation des feuilles, modes, réouverture, replis (police, PNG).

## 3. Règles non négociables

- **Encodage des `.bas`** : Windows-1252 et fins de ligne CRLF, première ligne `Attribute VB_Name = "modXxx"`. Écris les fichiers avec un script (par exemple Python : `open(p, "w", encoding="cp1252", newline="\r\n")`) et vérifie qu'aucun caractère hors Windows-1252 n'y figure ; les autres passent par `ChrW` (règle R6).
- Excel 365 Windows ; formules posées en anglais par `Range.Formula2` ; aucune référence VBA ajoutée ; **pas de Solveur** (l'IRLS est codé en VBA).
- Règles R1 à R14 de la section 3, en particulier : pas de `Select` hors navigation, données traitées en tableaux, constantes en tête de module, textes dans `modContenu`, toute valeur affichée lue dans une cellule (R14).
- Modules de 1 300 lignes au plus, procédures de 120 lignes au plus, noms français explicites comme dans le cahier.
- Ne modifie ni les données, ni les paramètres, ni les algorithmes, ni les textes affichés. Si tu dois t'écarter du cahier (limite d'Excel), écris-le dans `NOTES.md` avec la raison.

## 4. Livrables attendus

```
src/modApp.bas, modOutils.bas, modDonnees.bas, modEtude.bas, modGLM.bas,
    modDesign.bas, modContenu.bas, modPages.bas, modRecette.bas
src/ThisWorkbook.txt          (code à coller dans ThisWorkbook)
INSTALLATION.md               (étapes d'import et de lancement, 10 lignes au plus)
NOTES.md                      (choix, écarts éventuels, limites connues)
outils/verifier_encodage.py   (contrôle Windows-1252 + CRLF de src/)
```

## 5. Auto-vérification avant chaque livraison

1. `verifier_encodage.py` passe sur tous les fichiers de `src/`.
2. Revue statique : `Option Explicit` partout, chaque variable déclarée, chaque procédure appelée existe (vérifie le graphe d'appels), chaque nom utilisé dans une formule est créé par le code, aucune formule en français.
3. Relecture des calculs contre la section 6 et contre `etude_reference.py`, étape par étape.
4. Les valeurs attendues de `modRecette` sont recopiées de la section 15 et de `recette/*.json`, sans arrondi supplémentaire.
5. Optionnel, si tu tournes sous Windows avec Excel : script PowerShell (COM) qui ouvre le classeur de départ, importe les modules, lance `ConstruireApplication` puis `Recette` et lit la feuille `Recette`. Il exige que l'utilisateur active « Faire confiance à l'accès au modèle d'objet du projet VBA » : demande-le avant de l'utiliser.

## 6. Format de ta réponse à chaque phase

- Fichiers livrés (liste).
- Procédure de test pour moi (6 étapes au plus).
- Ce que je dois voir si tout va bien (valeurs clés de la recette).
- Points d'attention ou écarts, s'il y en a.

Commence par la lecture complète du cahier, puis la phase 1.
