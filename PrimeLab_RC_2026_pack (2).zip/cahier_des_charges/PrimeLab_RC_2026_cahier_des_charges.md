**PRIMELAB**

**Étude tarifaire RC automobile 2026**

Cahier des charges de l'application Excel VBA

Version 1.0 · 17 octobre 2026

Arnaud MBARGA

Destinataire : Claude Code (génération du code VBA)

> Ce document est la spécification unique de l'application. Il décrit les données, le moteur de calcul actuariel, les feuilles de travail, la charte graphique, la géométrie et le contenu des 13 pages, les interactions, les pièges connus et la recette chiffrée qui fait foi.

**Sommaire**

0\. Mode d’emploi du document

1\. Objet, périmètre et principes

2\. Livrables, installation et points d’entrée

3\. Règles de développement VBA

4\. Données d’entrée

5\. Architecture du classeur

6\. Moteur de calcul (étapes 01 à 11, tableau de bord, calculateur)

7\. Feuilles de travail : présentation

8\. Charte graphique

9\. Canevas, zoom et navigation

10\. Géométrie des gabarits

11\. Contenu des pages

12\. Interactions et mise à jour

13\. Interface, protections et performances

14\. Pièges connus

15\. Recette chiffrée

16\. Phases de construction et critères d’acceptation

Annexe A. Maquettes de référence

Annexe B. Manifeste des formules

0\. Mode d’emploi du document

0.1 Hiérarchie des sources

1.  **Ce cahier des charges** : fait foi sur tout le reste.

2.  **La recette chiffrée** (section 15 et recette.json) : fait foi pour chaque valeur calculée. Un écart hors tolérance est un défaut.

3.  **Les maquettes** (maquettes/\*.png) : font foi pour l’apparence. Elles sont dessinées aux coordonnées de la section 10, avec les chiffres de la recette.

4.  **Le module de l’Observatoire des affiliés** (déjà connu) : source d’inspiration pour l’architecture (canevas, zoom, protections, bulles), jamais une référence de contenu.

0.2 Fichiers fournis

| **Fichier**                                              | **Contenu**                                                        | **Usage**                                                               |
|----------------------------------------------------------|--------------------------------------------------------------------|-------------------------------------------------------------------------|
| PrimeLab_RC_2026_donnees.xlsx                            | Feuilles Contrats, Sinistres, Triangle, TarifActuel, Parametres    | Classeur de départ : on y importe les modules, on l’enregistre en .xlsm |
| csv/\*.csv                                               | Mêmes tables (séparateur ;, virgule décimale, UTF-8 avec BOM)      | Secours, contrôle                                                       |
| formules/\*.svg, formules/\*.png, formules/manifeste.csv | 33 formules symboliques (3 par étape), taille naturelle en points  | Insérées par le VBA dans les cartes Formulation                         |
| maquettes/P00.png à P12.png, P05_variante_seuil_5k.png   | Rendu cible de chaque page (1920 × 1080 px pour 960 × 540 pt)      | Comparaison visuelle                                                    |
| recette.json, recette_u10000.json, recette_u5000.json    | Valeurs de référence calculées par une implémentation indépendante | Module de recette                                                       |
| polices/\*.ttf                                           | Plus Jakarta Sans (licence OFL)                                    | À installer sur le poste avant la construction                          |

0.3 Conventions

- Noms de feuilles, de colonnes, de noms définis et de procédures : en_code.

- Formules Excel : écrites **en anglais** avec la virgule comme séparateur, posées par Range.Formula2. La section 6 les donne pour la ligne 2 ; elles sont recopiées sur toute la colonne en une seule écriture.

- Coordonnées : en points, origine en haut à gauche du canevas 960 × 540. (L, T, W, H) = gauche, haut, largeur, hauteur.

- Libellés affichés : dans ce document, les intervalles s’écrivent avec un trait d’union (18-24 ans). Dans l’application, ce trait d’union est remplacé par le demi-tiret ChrW(8211) dans tous les libellés d’intervalles (classes, tranches, périodes), comme dans les maquettes.

- Les nombres affichés suivent la règle R8 (section 3).

1\. Objet, périmètre et principes

1.1 Objet

Construire, par une seule macro, un classeur Excel qui réalise de A à Z l’étude tarifaire de la garantie responsabilité civile (RC) d’un portefeuille automobile fictif, et qui la présente sous forme d’application : un tableau de bord, onze pages d’étape et un calculateur de prime, navigables comme un logiciel (plein écran, sans ruban ni onglets).

1.2 Périmètre actuariel

- Garantie : RC automobile, matérielle et corporelle, toutes deux modélisées ensemble.

- Observation : exercices de survenance 2021 à 2025, charges vues au 31/12/2025.

- Tarif cible : affaires souscrites ou renouvelées en 2026. Point milieu de l’exposition : 01/01/2027.

- Méthode : fréquence × coût moyen par GLM multiplicatifs (Poisson et Gamma, lien log), écrêtement des sinistres graves et mutualisation par une loi de Pareto, calage du niveau sur la charge ultime revalorisée, chargements, plafonnement de l’évolution.

- Bonus-malus : appliqué réglementairement en multiplicateur de la prime de référence (art. A121-1 du Code des assurances). Il entre dans le GLM fréquence comme offset ln(CRM), jamais comme variable tarifaire.

- Sexe : présent dans les données, exclu d’office (arrêt Test-Achats de la CJUE, 2011).

1.3 Principes directeurs

5.  **Déterministe et auditable.** Tout ce qui peut s’écrire en formule Excel est écrit en formule, dans des feuilles de travail lisibles. Le VBA ne calcule lui-même que les étapes itératives ou combinatoires (regroupement des classes, sélection, IRLS, tri des quintiles) et écrit ses résultats avec un journal.

6.  **Aucune dépendance.** Pas de Solveur, pas de complément, pas de référence VBA ajoutée, pas de connexion externe.

7.  **Idempotence.** ConstruireApplication supprime et recrée tout ce qu’elle produit ; les feuilles de données brutes ne sont jamais modifiées dans leurs colonnes d’origine.

8.  **Une seule source par information.** Les paramètres vivent dans la feuille Parametres, les textes dans modContenu, les constantes graphiques en tête de modDesign.

9.  **Même rendu que la maquette.** On ne réduit jamais une taille de police pour faire tenir un contenu : on raccourcit le texte ou on ajuste la mise en page dans les limites de la section 10.

2\. Livrables, installation et points d’entrée

2.1 Modules attendus

| **Module**                | **Rôle**                                                                                                                                              | **Taille indicative** |
|---------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------|
| ThisWorkbook (code collé) | Événements uniquement, chacun appelle une procédure publique de modApp                                                                                | \< 50 lignes          |
| modApp                    | Points d’entrée, interface plein écran, modes application et administration, protections, navigation, raccourcis, zoom, état (CALC), gestion d’erreur | 700 à 900             |
| modOutils                 | Formats français (R8), mesures de texte, couleurs, tri, algèbre matricielle (inversion), lecture des paramètres et des noms                           | 400 à 600             |
| modDonnees                | Étapes 01 à 05 : colonnes dérivées, qualité, journal, triangle, historique, écrêtement                                                                | 500 à 700             |
| modEtude                  | Étapes 06 à 08 et 11 : exploratoire, classes, sélection, tarif, impact, segments                                                                      | 700 à 900             |
| modGLM                    | Étape 09 et 10 : cellules, IRLS Poisson et Gamma, quintiles, ratios CRM, graves                                                                       | 500 à 700             |
| modDesign                 | Constantes de charte, primitives (cartes, textes, pilules, puces, barres, carte feuille, encadrés de formule), barre latérale, bulles                 | 900 à 1 200           |
| modPages                  | Construction et mise à jour des 13 pages                                                                                                              | 900 à 1 300           |
| modContenu                | Tous les textes affichés : titres, intros, libellés de KPI, contrôles, aides                                                                          | 400 à 600             |
| modRecette                | Valeurs attendues de la section 15, comparaison, feuille Recette                                                                                      | 300 à 500             |

> Encodage : chaque fichier .bas est enregistré en **Windows-1252 (ANSI) avec fins de ligne CRLF** et commence par Attribute VB_Name = "modXxx". Un fichier UTF-8 importé dans l’éditeur VBA produit des accents illisibles. Les caractères hors Windows-1252 passent par ChrW (règle R6).

2.2 Installation par l’utilisateur

10. Installer les polices du dossier polices (clic droit, « Installer pour tous les utilisateurs »), puis redémarrer Excel.

11. Ouvrir PrimeLab_RC_2026_donnees.xlsx, l’enregistrer sous PrimeLab_RC_2026.xlsm.

12. Éditeur VBA (Alt+F11) : Fichier, Importer pour chaque .bas ; coller le code de ThisWorkbook.

13. Placer le dossier formules à côté du classeur.

14. Exécuter ConstruireApplication (Alt+F8). Enregistrer.

15. Exécuter Recette : la feuille Recette doit être entièrement verte.

2.3 Points d’entrée publics

| **Procédure**                                         | **Effet**                                                                                                                            |
|-------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------|
| ConstruireApplication                                 | Construction complète et idempotente : colonnes dérivées, feuilles de travail, moteur, 13 pages, protections. Durée cible \< 90 s.   |
| RecalculerEtude                                       | Relance le moteur sans reconstruire les pages (après modification d’un paramètre en mode administration), puis rafraîchit les pages. |
| ModeApplication, ModeAdmin, BasculerMode (Ctrl+Maj+M) | Comme dans l’Observatoire : plein écran verrouillé, ou classeur ouvert avec onglets.                                                 |
| AllerPage n (0 à 12), PageSuivante, PagePrecedente    | Navigation. Ctrl+PgSuiv et Ctrl+PgPréc en mode application.                                                                          |
| Recette                                               | Compare les valeurs du classeur à la section 15, écrit la feuille Recette et la fenêtre Exécution.                                   |
| InitialiserApplication (ouverture)                    | Recharge l’état, reprotège, passe en mode application, va à la dernière page vue.                                                    |

2.4 Prérequis

- Excel 365 pour Windows : XLOOKUP, FILTER, LET, TEXTJOIN, Range.Formula2, insertion d’images SVG.

- Polices : Plus Jakarta Sans installée ; à défaut, repli automatique sur Segoe UI (section 8.2). Segoe UI Symbol et Consolas sont présentes sur tout Windows.

- Macros activées ; l’accès au modèle objet VBA n’est **pas** requis.

3\. Règles de développement VBA

| **Règle** | **Contenu**                                                                                                                                                                                                                                                                                                                                                                                                                                         |
|-----------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| R1        | Option Explicit partout, types explicites, pas de Variant sans nécessité. Une procédure ne dépasse pas 120 lignes.                                                                                                                                                                                                                                                                                                                                  |
| R2        | Formules écrites en anglais par .Formula2, séparateur virgule. FormulaLocal uniquement en lecture (carte « Dans le classeur »). Une colonne de formules s’écrit en une instruction sur toute la plage.                                                                                                                                                                                                                                              |
| R3        | Pas de Select, Selection, ActiveCell, sauf navigation, zoom et réglages de fenêtre (commentés « exception R3 »).                                                                                                                                                                                                                                                                                                                                    |
| R4        | Toute procédure publique : On Error GoTo Erreur, mise à jour de gEtape à chaque étape, sortie par GererErreur qui restaure ScreenUpdating, EnableEvents, Calculation, reprotège et affiche « Étape : … / Erreur n : … ». On Error Resume Next seulement dans des blocs courts commentés « toléré (R4) ».                                                                                                                                            |
| R5        | Données lues une fois en tableaux (Value2), traitées en mémoire, écrites par blocs (Range.Value = tableau). Jamais d’écriture cellule par cellule dans une boucle sur les 25 074 lignes.                                                                                                                                                                                                                                                            |
| R6        | Fichiers .bas en Windows-1252. Caractères hors Windows-1252 par ChrW via des fonctions nommées : CarInf ≤ 8804, CarSup ≥ 8805, Moins − 8722, DemiTiret – 8211, Alpha α 945, Kappa κ 954, Theta θ 952, Lambda λ 955, Mu μ 956, Sigma Σ 931, Chi χ 967, Pi Π 928, Coche ✓ 10003, Croix ✗ 10007, Recharger ↺ 8634, Fleche › 8250, ChevronG ‹ 8249, Insec 160, Indice0 ₀ 8320, Tiret 8212, PointMedian · 183 (présent en Windows-1252 mais centralisé). |
| R7        | Formes nommées pNN_type_nom (ex. p05_kpi2_val), uniques par feuille (contrôle VerifierNomsUniques). Les pages sont supprimées puis recréées à la construction ; la mise à jour ne recrée que les formes dynamiques.                                                                                                                                                                                                                                 |
| R8        | Nombres affichés indépendants des paramètres régionaux : arrondi arithmétique, virgule décimale, séparateur de milliers ChrW(160) (l’espace fine ChrW(8239) est absente de la police), unité précédée de ChrW(160) (1 044,21 €, 95,3 %, 3 852 k€). Signe moins affiché par Moins quand il est typographique (évolutions), par « - » dans les cellules. Valeur indéfinie : le tiret long seul, produit par la fonction Tiret (ChrW(8212)).           |
| R9        | Pendant tout traitement : ScreenUpdating = False, EnableEvents = False, calcul manuel, puis Application.Calculate explicite aux points prévus (section 6.0).                                                                                                                                                                                                                                                                                        |
| R10       | Aucun appel au Solveur, aucune référence ajoutée ; Scripting.Dictionary en liaison tardive (CreateObject).                                                                                                                                                                                                                                                                                                                                          |
| R11       | Toutes les constantes (géométrie, couleurs, tailles, polices, chemins) en Private Const en tête de module ; aucun nombre magique dans le corps des procédures.                                                                                                                                                                                                                                                                                      |
| R12       | Tous les textes affichés centralisés dans modContenu (fonctions TitrePage(n), IntroPage(n), LibelleKPI(n, k), TexteControle(n, k), TexteAide(cle)…).                                                                                                                                                                                                                                                                                                |
| R13       | Les plages nommées pointent sur des plages fixes recalculées à la construction (Contrats!\$P\$2:\$P\$25075), jamais sur des colonnes entières.                                                                                                                                                                                                                                                                                                      |
| R14       | Chaque calcul du moteur est vérifiable : toute valeur affichée dans une page provient d’une cellule nommée ou d’une cellule identifiée d’une feuille de travail, jamais d’une variable VBA seule.                                                                                                                                                                                                                                                   |

4\. Données d’entrée

Le classeur de départ contient cinq feuilles. Leurs colonnes d’origine ne sont jamais modifiées ; les colonnes dérivées sont ajoutées à droite (section 6) avec un en-tête de couleur différente.

4.1 Contrats (25 074 lignes, colonnes A à N)

Une ligne par police et par exercice. Les lignes partielles correspondent aux affaires nouvelles et aux résiliations en cours d’année.

| **Col.** | **Nom**               | **Type**     | **Description**                                                 |
|----------|-----------------------|--------------|-----------------------------------------------------------------|
| A        | id_police             | texte        | P000001 à P007281                                               |
| B        | exercice              | entier       | 2021 à 2025                                                     |
| C        | date_debut            | date         | Début de la période couverte dans l’exercice                    |
| D        | date_fin              | date         | Fin de la période couverte dans l’exercice                      |
| E        | date_naissance        | date ou vide | Vide pour 14 polices (56 lignes)                                |
| F        | date_permis           | date         | Obtention du permis                                             |
| G        | sexe                  | H / F        | Exclu d’office du tarif                                         |
| H        | zone                  | A, B, C, D   | Rural, périurbain, urbain, dense                                |
| I        | puissance_cv          | entier       | 3 à 15 CV fiscaux                                               |
| J        | usage                 | texte        | Privé, Trajet, Professionnel                                    |
| K        | date_mise_circulation | date         | Véhicule                                                        |
| L        | couleur               | texte        | 6 couleurs, sans effet attendu                                  |
| M        | crm                   | décimal      | CRM au début de la ligne ; 7 valeurs hors \[0,50 ; 3,50\]       |
| N        | prime_acquise         | €            | Prime HT acquise sur la ligne au tarif en vigueur de l’exercice |

4.2 Sinistres (920 lignes, colonnes A à G)

| **Col.** | **Nom**          | **Type** | **Description**                               |
|----------|------------------|----------|-----------------------------------------------|
| A        | id_sinistre      | texte    | S10001 à S10920, triés par date de survenance |
| B        | id_police        | texte    | Police rattachée                              |
| C        | date_survenance  | date     |                                               |
| D        | date_declaration | date     | Tous déclarés au plus tard le 31/12/2025      |
| E        | garantie         | texte    | RC matérielle, RC corporelle                  |
| F        | charge_vue       | €        | Payés + provisions au 31/12/2025              |
| G        | statut           | texte    | Clos, Ouvert                                  |

Anomalies présentes, à retrouver exactement : 22 doublons, 5 sinistres hors période, 3 orphelins, 6 montants nuls (sinistres sans suite). Il reste 884 sinistres retenus.

4.3 Triangle (10 lignes)

Charges cumulées vues par exercice de survenance (2016 à 2025, colonne A exercice) et année de développement (colonnes B à K, dev_1 à dev_10). Cellules vides sous la diagonale. La dernière diagonale des exercices 2021 à 2025 est égale à la charge vue des sinistres retenus.

4.4 TarifActuel (18 lignes)

Tarif en vigueur en 2025, utilisé pour l’impact et le calculateur. Colonnes : variable, modalite, borne_min, borne_max, relativite. Première ligne : base, prime de référence HT 2025 à CRM 1,00 (347,65 €). Puis age (6 tranches à bornes), zone (4 modalités), puissance_cv (4 tranches à bornes), usage (3 modalités). Ses tranches diffèrent volontairement des classes de l’étude.

4.5 Parametres

Colonnes A à D : nom, valeur, libelle, unite. La construction crée un nom défini par paramètre (=Parametres!\$B\$n). Colonnes F à H : tranches initiales (variable, borne_min, libelle_tranche). Colonnes J et K : classes de CRM du contrôle de l’étape 09 (0,50, 0,51-0,79, 0,80-0,99, ≥ 1,00).

| **Nom**                                      | **Valeur**                                | **Rôle**                                                    |
|----------------------------------------------|-------------------------------------------|-------------------------------------------------------------|
| annee_debut                                  | 2021                                      | Premier exercice observé                                    |
| annee_fin                                    | 2025                                      | Dernier exercice observé                                    |
| annee_milieu_application                     | 2027,0                                    | Point milieu de l’exposition du tarif 2026 (année décimale) |
| taux_inflation                               | 5,0 %                                     | Dérive annuelle du coût des sinistres                       |
| seuil_ecretement                             | 15 000                                    | Seuil u par défaut (€)                                      |
| seuil_1 … seuil_5                            | 5 000 ; 10 000 ; 15 000 ; 25 000 ; 50 000 | Seuils proposés par les puces de l’étape 05                 |
| exposition_min                               | 500                                       | Exposition minimale d’une classe (années-police)            |
| z_fusion                                     | 1,645                                     | Seuil \|z\| de fusion                                       |
| seuil_p                                      | 5 %                                       | Seuil des p-values                                          |
| seuil_v_redondance                           | 0,5                                       | V de Cramér de redondance entre variables                   |
| crm_min ; crm_max                            | 0,50 ; 3,50                               | Bornes réglementaires du CRM                                |
| age_min ; age_max                            | 18 ; 99                                   | Âges admis                                                  |
| taux_securite                                | 3 %                                       | Chargement de sécurité, sur prime pure                      |
| taux_gestion ; taux_acquisition ; taux_marge | 10 % ; 15 % ; 5 %                         | Chargements sur prime HT                                    |
| taux_taxe                                    | 34,2 %                                    | TSCA RC obligatoire 33 % + contribution FGAO 1,2 %          |
| plafond_evolution                            | 10 %                                      | Plafond ± de l’évolution par police                         |
| iter_max ; tolerance                         | 25 ; 1E-10                                | Arrêt IRLS                                                  |
| min_graves                                   | 20                                        | Nombre minimal de sinistres au-dessus de u                  |
| ecart_kappa_max ; ecart_survie_max           | 15 % ; 0,10                               | Contrôles de l’étape 10                                     |
| part_excedent_max                            | 35 %                                      | Contrôle de l’étape 05                                      |
| ratio_crm_min ; ratio_crm_max                | 0,85 ; 1,15                               | Contrôle de l’étape 09                                      |
| equilibre_min                                | 95 %                                      | Contrôle de l’étape 11                                      |
| defaut_age … defaut_crm                      | 23 ; C ; 6 ; Trajet ; 0,90                | Profil par défaut du calculateur                            |

Tranches initiales

| **Variable**         | **Tranches (borne basse incluse)**                                                                |
|----------------------|---------------------------------------------------------------------------------------------------|
| age (colonne R)      | 18-20, 21-24, 25-29, 30-39, 40-49, 50-64, 65-74, 75+                                              |
| puissance_cv (I)     | ≤4, 5-6, 7-8, 9-10, 11+                                                                           |
| anc_permis (S)       | 0-2, 3-5, 6-10, 11-20, 21+                                                                        |
| anc_vehicule (T)     | 0-2, 3-5, 6-9, 10-14, 15+                                                                         |
| zone, usage, couleur | Modalités, dans l’ordre A-D ; Privé, Trajet, Professionnel ; Blanc, Gris, Noir, Bleu, Rouge, Vert |

5\. Architecture du classeur

5.1 Feuilles

| **Feuille**                                            | **Rôle**                                     | **Mode application** |
|--------------------------------------------------------|----------------------------------------------|----------------------|
| P00_Tableau … P12_Calculateur                          | 13 pages de présentation (formes uniquement) | visibles, protégées  |
| Contrats, Sinistres, Triangle, TarifActuel, Parametres | Données d’entrée + colonnes dérivées         | masquées             |
| Qualite, Journal                                       | Étape 02                                     | masquées             |
| Historique                                             | Étape 04 et tableau de bord                  | masquée              |
| Exploratoire                                           | Étape 06                                     | masquée              |
| Bornes, Classes                                        | Étape 07                                     | masquées             |
| Selection, Associations                                | Étape 08                                     | masquées             |
| Cellules, GLM_Frequence, GLM_Cout                      | Étape 09                                     | masquées             |
| Graves                                                 | Étapes 05 et 10                              | masquée              |
| Tarif, Impact, Segments                                | Étape 11 et tableau de bord                  | masquées             |
| Calculateur                                            | Page 12                                      | masquée              |
| Recette                                                | Résultat de la recette                       | masquée              |
| CALC                                                   | État de l’interface                          | très masquée         |

Noms des pages : P00_Tableau, P01_Import, P02_Qualite, P03_Base, P04_Ultime, P05_Ecretement, P06_Exploratoire, P07_Classes, P08_Selection, P09_Modeles, P10_Graves, P11_Resultats, P12_Calculateur. Ordre des onglets : pages, puis feuilles de travail dans l’ordre des étapes, puis données.

Une feuille de travail est consultable en mode application par le bouton « Ouvrir l’onglet » (section 12.4) : elle s’affiche protégée, avec barre de formule et en-têtes, et un bouton flottant « ‹ Retour à la page ».

5.2 État de l’interface (feuille CALC)

| **Cellule** | **Contenu**                                                 | **Défaut** |
|-------------|-------------------------------------------------------------|------------|
| B2          | Page active (0 à 12)                                        | 0          |
| B3          | Mode administration (1) ou application (0)                  | 0          |
| B4          | Exercice affiché par le tableau de bord                     | 2025       |
| B5          | Onglet de segment (age, zone, puissance_cv, usage)          | age        |
| B6          | Variable de l’étape 06                                      | age        |
| B7          | Variable de l’étape 07 (ordinales)                          | age        |
| B8          | Modèle affiché à l’étape 09 (F ou C)                        | F          |
| B9          | Dernière feuille de travail ouverte (pour le retour)        | vide       |
| B10         | Police Plus Jakarta Sans détectée (1) ou repli Segoe UI (0) | calculé    |
| B11         | Date et durée de la dernière construction                   | calculé    |

Le seuil d’écrêtement actif est la cellule seuil_ecretement de Parametres ; les entrées du calculateur sont dans la feuille Calculateur.

5.3 Noms définis

Un nom par paramètre (section 4.5) ; un nom par colonne des feuilles Contrats et Sinistres, formé du préfixe c\_ ou s\_ et de l’en-tête de la colonne (c_nb_sin, s_charge_rev, c_cl_age…), avec ces exceptions : c_id (id_police), c_debut (date_debut), c_fin (date_fin), c_naissance (date_naissance), c_expo (exposition), s_id (id_sinistre), s_idpol (id_police), s_date (date_survenance) ; les sorties du moteur citées en section 6 (charge_cible, kappa, theta, base_pp, glmf_b0, glmf_cle, glmf_coef, glmc_g0, glmc_cle, glmc_coef, med_zone_cle, med_zone_val, bornes\_\<var\>\_min, bornes\_\<var\>\_mod, bornes\_\<var\>\_classe, ta\_…). Portée : classeur.

6\. Moteur de calcul

Cette section définit chaque calcul de façon exhaustive. Les valeurs attendues figurent en section 15. Les noms c_xxx désignent les colonnes de Contrats (lignes 2 à 25 075), s_xxx celles de Sinistres (lignes 2 à 921), créés à la construction (R13).

6.0 Ordre d’exécution

16. Créer les noms des paramètres et des colonnes brutes (c_id = A, c_exercice = B, c_debut = C, c_fin = D, c_naissance = E, c_zone = H, c_puissance_cv = I, c_usage = J, c_couleur = L, c_crm = M, c_prime = N ; s_id = A, s_idpol = B, s_date = C, s_garantie = E, s_charge_vue = F).

17. Étapes 01 et 02 : colonnes Contrats!O:V, Sinistres!H:K, feuille Qualite. Calcul.

18. Étapes 03 à 05 : Sinistres!L:O, Contrats!W:Z, triangle, Historique, table des seuils. Calcul. Journal (VBA).

19. Étape 06 : Exploratoire. Calcul.

20. Étape 07 : regroupement (VBA), Bornes, Classes. Calcul.

21. Étape 08 : Selection (formules), puis redondance et élimination descendante (VBA, IRLS en mémoire).

22. Étape 09 : Contrats!AA:AE, Cellules. Calcul. IRLS Poisson et Gamma (VBA). GLM_Frequence, GLM_Cout, Contrats!AF:AJ, Sinistres!P:Q. Calcul. Quintiles (VBA).

23. Étape 10 : Graves (liste VBA, formules). Calcul.

24. Étape 11 et tableau de bord : Tarif, Impact, Segments. Calcul.

25. Calculateur, Controles. Calcul. Rafraîchissement des pages.

> Changement de seuil (puces de l’étape 05) : écrire seuil_ecretement, calculer, relancer seulement l’IRLS Gamma, réécrire GLM_Cout, reconstruire la liste Graves, calculer, rafraîchir les pages. La fréquence, les classes et la sélection ne dépendent pas du seuil. Durée cible : moins de 5 s.

6.1 Étape 01 : import et exposition

| **Col.** | **Nom**      | **Formule (ligne 2, Formula2, anglais)**                                              |
|----------|--------------|---------------------------------------------------------------------------------------|
| O        | cle          | =A2&"\|"&B2                                                                           |
| P        | exposition   | =MAX(0,MIN(D2,DATE(B2,12,31))-MAX(C2,DATE(B2,1,1))+1)/(DATE(B2,12,31)-DATE(B2,1,1)+1) |
| Q        | age_brut     | =IF(E2="","",DATEDIF(E2,C2,"y"))                                                      |
| R        | age          | =IF(Q2="",INDEX(med_zone_val,MATCH(H2,med_zone_cle,0)),Q2)                            |
| S        | anc_permis   | =DATEDIF(F2,C2,"y")                                                                   |
| T        | anc_vehicule | =DATEDIF(K2,C2,"y")                                                                   |
| U        | crm_c        | =MIN(crm_max,MAX(crm_min,M2))                                                         |
| V        | e_crm        | =P2\*U2                                                                               |

Âges et anciennetés sont calculés au début de la ligne (date_debut). Noms : c_cle, c_expo, c_age_brut, c_age, c_anc_permis, c_anc_vehicule, c_crm_c, c_e_crm.

| **Contrôle**                                                              | **Formule de statut (feuille Controles)**                                            |
|---------------------------------------------------------------------------|--------------------------------------------------------------------------------------|
| Dates au format date, aucune en texte                                     | =SUMPRODUCT(--ISTEXT(Contrats!C2:F25075))+SUMPRODUCT(--ISTEXT(Contrats!K2:K25075))=0 |
| Une seule ligne par police et par exercice                                | =ROWS(c_cle)=ROWS(UNIQUE(c_cle))                                                     |
| Exposition entre 0 et 1 (le libellé cite COUNTIF(c_expo,0) lignes nulles) | =AND(MIN(c_expo)\>=0,MAX(c_expo)\<=1)                                                |

6.2 Étape 02 : qualité des données

| **Col.** | **Nom**  | **Formule (ligne 2, Formula2, anglais)**                                                                                                                                                                                              |
|----------|----------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| H        | exercice | =YEAR(C2)                                                                                                                                                                                                                             |
| I        | cle      | =B2&"\|"&H2                                                                                                                                                                                                                           |
| J        | controle | =IF(COUNTIFS(B\$1:B1,B2,C\$1:C1,C2,F\$1:F1,F2)\>0,"Doublon",IF(COUNTIF(c_id,B2)=0,"Orphelin",IF(OR(H2\<annee_debut,H2\>annee_fin,COUNTIFS(c_id,B2,c_debut,"\<="&C2,c_fin,"\>="&C2)=0),"Hors période",IF(F2\<=0,"Montant nul","OK")))) |
| K        | retenu   | =--(J2="OK")                                                                                                                                                                                                                          |

- Priorité : Doublon, puis Orphelin, puis Hors période, puis Montant nul. Le premier exemplaire d’un doublon reste évalué normalement (plage croissante B\$1:B1).

- Feuille Qualite, médianes : A2:A5 = A, B, C, D ; B2 =INT(MEDIAN(FILTER(c_age_brut,(c_zone=A2)\*(c_age_brut\<\>"")))). Noms med_zone_cle = A2:A5, med_zone_val = B2:B5. Pas de circularité : la médiane lit age_brut, jamais age.

- Complétude (D:F) pour id_police, date_debut, zone, puissance_cv, crm, date_naissance : manquants =COUNTBLANK(plage), taux =1-manquants/ROWS(plage).

- Comptages (H:I) : =COUNTIF(s_controle,"Doublon"), idem pour chaque statut. Âges imputés =COUNTIF(c_age_brut,""), polices concernées =ROWS(UNIQUE(FILTER(c_id,c_age_brut=""))). CRM corrigés =SUMPRODUCT(--(c_crm\<\>c_crm_c)).

- Feuille Journal (VBA, valeurs) : une ligne par anomalie : n°, type, table, ligne Excel, identifiant, détail, action. 22 doublons « Supprimé de l’étude », 5 hors période et 3 orphelins « Exclu », 6 montants nuls « Exclu (sans suite) », 56 âges « Imputé : médiane de la zone X = n », 7 CRM « Ramené de a à b », 2 expositions nulles « date_fin antérieure à date_debut, ligne sans effet ». Total 101 lignes.

| **Contrôle**                                            | **Formule de statut**                                                                                                                 |
|---------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------|
| Clé (police, date, montant) unique parmi les retenus    | =LET(k,FILTER(s_idpol&"\|"&s_date&"\|"&s_charge_vue,s_retenu=1),ROWS(k)=ROWS(UNIQUE(k)))                                              |
| Chaque sinistre retenu couvert par une ligne de contrat | =SUM(--(COUNTIFS(c_id,FILTER(s_idpol,s_retenu=1),c_debut,"\<="&FILTER(s_date,s_retenu=1),c_fin,"\>="&FILTER(s_date,s_retenu=1))=0))=0 |
| Aucune colonne tarifaire sous 99,5 % de complétude      | =MIN(Qualite!F2:F7)\>=0.995                                                                                                           |

6.3 Étape 03 : base de modélisation

| **Col.** | **Nom**    | **Formule (ligne 2, Formula2, anglais)**  |
|----------|------------|-------------------------------------------|
| W        | nb_sin     | =COUNTIFS(s_cle,O2,s_retenu,1)            |
| X        | charge_vue | =SUMIFS(s_charge_vue,s_cle,O2,s_retenu,1) |
| Y        | charge_rev | =SUMIFS(s_charge_rev,s_cle,O2,s_retenu,1) |
| Z        | charge_ecr | =SUMIFS(s_charge_ecr,s_cle,O2,s_retenu,1) |

Bloc « sinistres par ligne » de Historique (lignes 10 à 13) : observé =COUNTIF(c_nb_sin,1), =COUNTIF(c_nb_sin,2), =COUNTIF(c_nb_sin,"\>=3") ; attendu sous Poisson homogène à CRM neutralisé, avec lam = SUM(c_nb_sin)/SUM(c_e_crm) : =LET(m,c_e_crm\*lam,SUM(m\*EXP(-m))), =LET(m,c_e_crm\*lam,SUM(m^2/2\*EXP(-m))), =LET(m,c_e_crm\*lam,SUM(1-EXP(-m)\*(1+m+m^2/2))).

| **Contrôle**                                               | **Formule de statut**                                         |
|------------------------------------------------------------|---------------------------------------------------------------|
| Jointure gauche : toutes les lignes de contrats conservées | =ROWS(c_cle)=COUNTA(c_id)                                     |
| Somme des Nᵢ = sinistres retenus                           | =SUM(c_nb_sin)=COUNTIF(s_retenu,1)                            |
| Charge identique avant et après jointure                   | =ABS(SUM(c_charge_vue)-SUMIFS(s_charge_vue,s_retenu,1))\<0.01 |

6.4 Étape 04 : charge ultime et inflation

| **Col.** | **Nom**                  | **Formule (ligne 2, Formula2, anglais)**                               |
|----------|--------------------------|------------------------------------------------------------------------|
| L        | charge_reval (Sinistres) | =IF(K2=1,F2\*(1+taux_inflation)^(annee_milieu_application-(H2+0.5)),0) |

- Triangle, ligne 13, facteurs f1 à f9 (colonnes B à J) : B13 =SUMIFS(C\$2:C\$11,C\$2:C\$11,"\<\>")/SUMIFS(B\$2:B\$11,C\$2:C\$11,"\<\>"), recopiée à droite.

- Ligne 14, facteurs cumulés (B à K) : B14 =PRODUCT(B13:\$J\$13) recopiée jusqu’à J ; K14 = 1.

- Colonnes M à P par exercice : M2 =LOOKUP(2,1/(B2:K2\<\>""),B2:K2) (dernière diagonale), N2 =COUNT(B2:K2), O2 =INDEX(\$B\$14:\$K\$14,N2), P2 =M2\*O2. Noms tri_exercice, tri_diag, tri_cdf, tri_ult.

- Feuille Historique, lignes 2 à 6 (2021 à 2025) : A exercice ; B exposition =SUMIFS(c_expo,c_exercice,A2) ; C nb_sin =SUMIFS(c_nb_sin,c_exercice,A2) ; D charge_vue =XLOOKUP(A2,tri_exercice,tri_diag) ; E cdf =XLOOKUP(A2,tri_exercice,tri_cdf) ; F charge_ult =D2\*E2 ; G rho =(1+taux_inflation)^(annee_milieu_application-(A2+0.5)) ; H charge_2027 =F2\*G2 ; I primes =SUMIFS(c_prime,c_exercice,A2) ; J ibnr =F2-D2 ; K sp_vu =D2/I2 ; L sp =F2/I2 ; M cor =L2+taux_gestion+taux_acquisition ; N resultat =I2\*(1-M2) ; O vue_sinistres =SUMIFS(s_charge_vue,s_exercice,A2,s_retenu,1) ; P frequence =C2/B2 ; Q cout_vu =D2/C2 ; R prime_moy =I2/B2.

- charge_cible = Historique!H8 =SUM(H2:H6). Noms hist_exercice = A2:A6, hist_ult = F2:F6.

| **Contrôle**                                            | **Formule de statut**                                                |
|---------------------------------------------------------|----------------------------------------------------------------------|
| Dernière diagonale = sinistres retenus (écart \< 0,5 %) | =MAX(ABS(Historique!D2:D6-Historique!O2:O6)/Historique!O2:O6)\<0.005 |
| Facteurs décroissants vers 1                            | =AND(Triangle!B13:I13\>=Triangle!C13:J13,Triangle!J13\>=1)           |
| IBNR positif sur chaque exercice                        | =MIN(Historique!J2:J6)\>0                                            |

6.5 Étape 05 : écrêtement

| **Col.** | **Nom**    | **Formule (ligne 2, Formula2, anglais)** |
|----------|------------|------------------------------------------|
| M        | grave      | =IF(K2=1,--(L2\>seuil_ecretement),0)     |
| N        | charge_ecr | =IF(K2=1,MIN(L2,seuil_ecretement),0)     |
| O        | excedent   | =IF(K2=1,MAX(L2-seuil_ecretement,0),0)   |

Table des seuils (Graves!H1:K6), pour seuil_1 à seuil_5 : n =COUNTIF(s_charge_rev,"\>"&H2) ; part =SUMPRODUCT((s_charge_rev\>H2)\*(s_charge_rev-H2))/SUM(s_charge_rev) ; e_emp =IF(I2\>0,SUMPRODUCT((s_charge_rev\>H2)\*(s_charge_rev-H2))/I2,NA()).

| **Contrôle**                                   | **Formule de statut**                                           |
|------------------------------------------------|-----------------------------------------------------------------|
| Charge écrêtée + excédent = charge revalorisée | =ABS(SUM(s_charge_ecr)+SUM(s_excedent)-SUM(s_charge_rev))\<0.01 |
| Au moins min_graves sinistres au-dessus de u   | =SUM(s_grave)\>=min_graves                                      |
| Excédent sous part_excedent_max de la charge   | =SUM(s_excedent)/SUM(s_charge_rev)\<part_excedent_max           |

6.6 Étape 06 : analyse exploratoire

Feuille Exploratoire, une ligne par tranche initiale, variables dans l’ordre age, zone, puissance_cv, usage, anc_permis, anc_vehicule, couleur (36 lignes). Colonnes : A variable, B tranche, C borne_min, D borne_sup (borne min de la tranche suivante, 1E+9 pour la dernière, vide pour les nominales), E exposition, F e_crm, G nb_sin, H charge_ecr, I frequence, J freq_crm, K ic_bas, L ic_haut, M cout_moyen, N prime_pure.

- Ordinale : E2 =SUMIFS(c_expo,c_age,"\>="&C2,c_age,"\<"&D2) (même forme pour F, G, H avec c_e_crm, c_nb_sin, c_charge_ecr).

- Nominale : E2 =SUMIFS(c_expo,c_zone,B2).

- I2 =IF(E2\>0,G2/E2,NA()), J2 =IF(F2\>0,G2/F2,NA()), K2 =J2-1.96\*SQRT(J2/F2), L2 =J2+1.96\*SQRT(J2/F2), M2 =IF(G2\>0,H2/G2,NA()), N2 =H2/E2.

- Agrégats globaux : fréquence brute =SUM(c_nb_sin)/SUM(c_expo), à CRM 1,00 =SUM(c_nb_sin)/SUM(c_e_crm), coût moyen écrêté =SUM(c_charge_ecr)/SUM(c_nb_sin), prime pure écrêtée =SUM(c_charge_ecr)/SUM(c_expo).

- Pourquoi « à CRM 1,00 » : le CRM étant appliqué ensuite en multiplicateur, la segmentation se juge sur N / Σ E × CRM. Toutes les analyses à une dimension (classes, sélection) utilisent cette fréquence.

| **Contrôle**                                                            | **Formule de statut**                                                                                                                                   |
|-------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------|
| Somme des expositions par tranche = exposition totale (chaque variable) | =MAX(ABS(SUMIF(Exploratoire!A2:A37,{"age","zone","puissance_cv","usage","anc_permis","anc_vehicule","couleur"},Exploratoire!E2:E37)-SUM(c_expo)))\<1E-6 |
| Somme des sinistres par tranche = sinistres retenus                     | même forme sur G et SUM(c_nb_sin)                                                                                                                       |
| Charge écrêtée totale = valeur de l’étape 05                            | même forme sur H et SUM(s_charge_ecr), tolérance 0,01                                                                                                   |

6.7 Étape 07 : classes

Le regroupement est fait en VBA à partir des colonnes E, F, G de Exploratoire, pour chaque variable candidate. Algorithme exact :

> Pour chaque variable v : G = liste ordonnée des groupes {E, Es, N, membres}, un par tranche initiale
>
> Répéter
>
> \(a\) S = groupes dont E \< exposition_min
>
> Si S non vide et nb(G) \> 1 :
>
> i = groupe de S de plus petite exposition (égalité : le plus à gauche)
>
> ordinale : candidats = voisins i-1 et i+1 existants
>
> nominale : candidats = tous les autres groupes
>
> j = candidat dont lambda\* = N/Es est la plus proche de celle de i (égalité : le premier)
>
> fusionner i et j (le groupe fusionné prend la position min(i, j)) ; recommencer
>
> \(b\) Si v ordinale et nb(G) \>= 2 :
>
> z_k = \|lambda\*\_k - lambda\*\_k+1\| / RACINE(lambda\*\_k / Es_k + lambda\*\_k+1 / Es_k+1) (0 si dénominateur nul)
>
> k\* = argmin z_k (égalité : plus petit k)
>
> si z_k\* \< z_fusion : fusionner k\* et k\*+1 ; recommencer
>
> sortir
>
> Classe de référence = classe d’exposition maximale (égalité : la première)

- Libellé d’une classe ordinale : borne basse du premier membre, borne haute du dernier. 18-20 + 21-24 donne 18-24 ; 30-39 + … + 40-49 donne 30-49 ; si le dernier membre est ouvert (75+), la classe s’écrit borne basse suivie de « + » (65+) ; un premier membre ≤4 donne ≤6 ; ≤4 jusqu’à 11+ donne Toutes. Classe nominale fusionnée : libellés joints par « + ».

- Feuille Bornes : un bloc par variable (variable, tranche_min, tranche, classe). Noms bornes\_\<v\>\_min et bornes\_\<v\>\_classe (ordinales), bornes\_\<v\>\_mod et bornes\_\<v\>\_classe (nominales).

- Feuille Classes : A variable, B classe, C tranches, D borne_min, E borne_sup, F exposition, G e_crm, H nb_sin (SUMIFS sur bornes ; nominales : =SUM(SUMIFS(c_expo,c_zone,TEXTSPLIT(C2,"+")))), I freq_crm =H2/G2, J relativite =I2/I\$ref (ligne de référence de la variable, en absolu), K z_suivante =IF(A3=A2,ABS(I2-I3)/SQRT(I2/G2+I3/G3),"") (ordinales), L reference (VRAI/FAUX). Noms cls_var, cls_classe, cls_E, cls_Es, cls_N.

- Journal des fusions dans Classes!N:R : variable, rang, motif (exposition ou z), groupes fusionnés, valeur du critère.

| **Contrôle**                                   | **Formule de statut**                                            |
|------------------------------------------------|------------------------------------------------------------------|
| Chaque classe dépasse exposition_min           | =MIN(cls_E)\>=exposition_min                                     |
| Classes voisines significativement différentes | =MIN(Classes!K2:K60)\>=z_fusion (cellules vides ignorées)        |
| Classe de référence = la plus exposée          | VRAI si, pour chaque variable, reference est sur le maximum de F |

6.8 Étape 08 : sélection des variables

Feuille Selection, lignes 2 à 8 : les 7 candidates dans l’ordre ; ligne 9 : sexe, valeurs « tiret » et décision « Exclue d’office (réglementaire) ». Colonnes : A variable, B chi2, C ddl, D p_value, E v_cramer, F att_min, G delta_d, H ddl_lrt, I p_lrt, J decision.

- B2 =LET(n,FILTER(cls_N,cls_var=A2),e,FILTER(cls_Es,cls_var=A2),l,SUM(c_nb_sin)/SUM(c_e_crm),SUM((n-e\*l)^2/(e\*l)))

- C2 =COUNTIF(cls_var,A2)-1 ; D2 =IF(C2\>0,CHISQ.DIST.RT(B2,C2),1) ; E2 =SQRT(B2/SUM(c_expo)) ; F2 =MIN(FILTER(cls_Es,cls_var=A2))\*SUM(c_nb_sin)/SUM(c_e_crm) ; I2 =IF(H2\>0,CHISQ.DIST.RT(G2,H2),"").

- G, H, J sont écrites par le VBA selon l’algorithme ci-dessous.

> 1\. Filtre univarié : garder v si p_value \< seuil_p ; sinon « Écartée (non significative) » ;
>
> une variable à une seule classe est « Écartée (une seule classe) ».
>
> 2\. Redondance : trier les gardées par V décroissant ; pour chacune, calculer V(v, w) avec chaque w déjà gardée ;
>
> si un V(v, w) \>= seuil_v_redondance : « Écartée (redondante avec w) » (w = celle de V maximal) ; sinon garder.
>
> V(v, w) : table de contingence des classes de v et w pondérée par l’exposition, chi2 d’indépendance,
>
> V = RACINE(chi2 / (E_totale x (min(lignes, colonnes) - 1))). Matrice écrite dans « Associations ».
>
> 3\. Élimination descendante : cellules = combinaisons des classes des variables gardées (lignes à E \> 0) ;
>
> ajuster le Poisson complet (offset ln Σ E x CRM) ; pour chaque v, réajuster sans v sur les mêmes cellules ;
>
> delta_d = D(sans v) - D(complet), ddl_lrt = nb classes(v) - 1, p = CHISQ.DIST.RT ;
>
> si le plus grand p \>= seuil_p : écarter cette variable (« Écartée (rapport de vraisemblance) ») et recommencer.
>
> 4\. Les restantes sont « Retenue » ; G, H, I de la dernière itération où chacune figurait.

| **Contrôle**                                                   | **Formule de statut**                                              |
|----------------------------------------------------------------|--------------------------------------------------------------------|
| Effectif attendu ≥ 5 dans chaque classe                        | =MIN(Selection!F2:F8)\>=5                                          |
| Aucune paire de variables retenues avec V ≥ seuil_v_redondance | maximum de la sous-matrice des retenues dans Associations \< seuil |
| Sexe exclu d’office                                            | =COUNTIFS(Selection!A2:A9,"sexe",Selection!J2:J9,"Retenue")=0      |

6.9 Étape 09 : modèles GLM

| **Col.** | **Nom**   | **Formule (ligne 2, Formula2, anglais)**                                                                                                                                                           |
|----------|-----------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| AA:AD    | cl\_\<v\> | une colonne par variable retenue, dans l’ordre des candidates. Ordinale : =INDEX(bornes_age_classe,MATCH(R2,bornes_age_min,1)) ; nominale : =INDEX(bornes_zone_classe,MATCH(H2,bornes_zone_mod,0)) |
| AE       | cellule   | =TEXTJOIN("\|",FALSE,AA2:AD2)                                                                                                                                                                      |
| AF       | freq_pred | =U2\*EXP(glmf_b0+XLOOKUP("age\|"&AA2,glmf_cle,glmf_coef,0)+XLOOKUP("zone\|"&AB2,glmf_cle,glmf_coef,0)+…) (une recherche par variable retenue)                                                      |
| AG       | nb_pred   | =P2\*AF2                                                                                                                                                                                           |
| AH       | cout_pred | =EXP(glmc_g0+XLOOKUP("age\|"&AA2,glmc_cle,glmc_coef,0)+…)                                                                                                                                          |
| AI       | pp0       | =AF2\*AH2\*kappa                                                                                                                                                                                   |
| AJ       | pp        | =AI2\*theta                                                                                                                                                                                        |

Sinistres!P cellule =IF(K2=1,XLOOKUP(I2,c_cle,c_cellule),""), Sinistres!Q cout_pred =IF(K2=1,XLOOKUP(I2,c_cle,c_cout_pred),"").

- Feuille Cellules : le VBA écrit les cellules présentes parmi les lignes à exposition non nulle, triées par indices de classes (variable 1, puis 2…). Colonnes : A cellule, B à E classes, F exposition =SUMIFS(c_expo,c_cellule,A2), G e_crm, H nb_sin, I charge_ecr, J nb_pred =G2\*EXP(glmf_b0+…), K cout_moyen =IF(H2\>0,I2/H2,""), L cout_pred. 172 cellules ; 139 portent au moins un sinistre.

- Matrice X : intercept puis une indicatrice par classe non de référence, variables dans l’ordre des candidates, classes dans l’ordre. 12 paramètres.

- Poisson : cellules F \> 0, y = H, offset = ln(G). Gamma : cellules H \> 0, y = K, poids a priori w = H.

> Poisson
>
> beta = 0 ; beta0 = ln(Σy / Σexp(offset))
>
> Pour t = 1 à iter_max :
>
> eta = offset + X beta ; mu = exp(eta) ; z = X beta + (y - mu) / mu ; W = mu
>
> beta = (X' W X)^-1 X' W z
>
> mu = exp(offset + X beta) ; D_t = 2 Σ \[ y ln(y / mu) - (y - mu) \] (terme y ln(y/mu) nul si y = 0)
>
> si t \>= 2 et \|D_t - D_t-1\| / (\|D_t\| + 0,1) \< tolerance : arrêt
>
> écarts-types = racine de la diagonale de (X' W X)^-1, W = mu final
>
> Gamma
>
> gamma = 0 ; gamma0 = ln(Σ w y / Σ w)
>
> boucle identique avec eta = X gamma, mu = exp(eta), z = eta + (y - mu) / mu, W = w
>
> D_t = 2 Σ w \[ -ln(y / mu) + (y - mu) / mu \]
>
> phi = Σ_k ((X^c_k - mu_k) / mu_k)^2 / (K - p) sur les sinistres retenus (mu_k = cout_pred du sinistre)
>
> écarts-types = racine de phi x diagonale de (X' W X)^-1
>
> Inversion : Gauss-Jordan à pivot partiel ; pivot \< 1E-12 : erreur « matrice singulière ».

- Feuille GLM_Frequence : A parametre (« Intercept », « âge 18-24 »…), B cle (« Intercept », « age\|18-24 »…), C coefficient, D relativite =EXP(C2), E erreur_std, F z =C2/E2, G p_value =2\*(1-NORM.S.DIST(ABS(F2),TRUE)). Noms glmf_b0 = C2, glmf_cle et glmf_coef = lignes 3 et suivantes. Même structure pour GLM_Cout (glmc\_…).

- Journal IRLS (colonnes I:J : itération, déviance). Déviances au niveau des cellules et des lignes : =2\*SUM(IF(c_nb_sin\>0,c_nb_sin\*LN(c_nb_sin/c_nb_pred),0)-(c_nb_sin-c_nb_pred)), déviance nulle avec c_e_crm\*SUM(c_nb_sin)/SUM(c_e_crm). Déviance expliquée affichée = au niveau des lignes (sinistres pour le coût).

- Quintiles (VBA, valeurs) : fréquence : lignes à E \> 0 triées par freq_pred croissante (égalité : ordre des lignes), quintile q = min(5, 1 + Ent(5 × (E cumulée avant la ligne + E/2) / E totale)), observé = ΣN/ΣE, prédit = Σnb_pred/ΣE. Coût : sinistres retenus triés par cout_pred (égalité : ordre des lignes), q = min(5, 1 + Ent(5 × (rang - 0,5) / K)), observé et prédit = moyennes de charge_ecr et cout_pred. Tri non récursif (R1, pile explicite) ou tri fusion.

- Ratios CRM (formules) : classes de Parametres!J:K ; N =SUMIFS(c_nb_sin,c_crm_c,"\>="&borne,c_crm_c,"\<"&borne_suivante) (dernière classe sans borne haute), prédit idem sur c_nb_pred, ratio = N / prédit.

| **Contrôle**                                                               | **Formule de statut**                                         |
|----------------------------------------------------------------------------|---------------------------------------------------------------|
| Sinistres prédits = sinistres observés                                     | =ABS(SUM(c_nb_pred)-SUM(c_nb_sin))\<0.01                      |
| Convergence IRLS atteinte (libellé : nombre d’itérations des deux modèles) | itérations \< iter_max pour les deux modèles                  |
| Observé / prédit dans \[ratio_crm_min ; ratio_crm_max\] par classe de CRM  | =AND(MIN(ratios)\>=ratio_crm_min,MAX(ratios)\<=ratio_crm_max) |

6.10 Étape 10 : sinistres graves

- Feuille Graves, A:F : le VBA écrit les id_sinistre retenus dont charge_reval \> seuil_ecretement, triés par charge décroissante (égalité : ordre des lignes). B =XLOOKUP(A2,s_id,s_garantie), C exercice, D charge_reval =XLOOKUP(A2,s_id,s_charge_rev), E ln_x_u =LN(D2/seuil_ecretement), F excedent =D2-seuil_ecretement.

- Cellules nommées : n_u =SUM(s_grave) ; alpha =n_u/SUM(E2:En) ; alpha_se =alpha/SQRT(n_u) ; ic_bas, ic_haut = alpha ∓ 1,96 × alpha_se ; e_u =IF(alpha\>1,seuil_ecretement/(alpha-1),NA()) ; e_emp =SUM(F2:Fn)/n_u ; kappa_emp =SUM(s_charge_rev)/SUM(s_charge_ecr) ; kappa =IF(alpha\>1,1+n_u\*e_u/SUM(s_charge_ecr),kappa_emp) ; ecart_kappa =kappa/kappa_emp-1.

- Survie : multiples 1,5 ; 2 ; 3 ; 5 ; 10 de u ; observée =COUNTIF(D2:Dn,"\>"&x)/n_u, Pareto =(seuil_ecretement/x)^alpha.

> Pourquoi ce κ : la mutualisation doit utiliser la loi ajustée, pas le seul ratio observé, trop sensible au plus gros sinistre. κ = 1 + p × e(u) / μc, où p = n / N est la part des sinistres au-dessus de u (n leur nombre, N le nombre de sinistres retenus) et μc le coût moyen écrêté, soit κ = 1 + n × e(u) / Σ Xc. Si α ≤ 1, l’espérance est infinie : repli sur le κ empirique et contrôle en rose.

| **Contrôle**                                       | **Formule de statut**                   |
|----------------------------------------------------|-----------------------------------------|
| Borne basse de l’IC de α au-dessus de 1            | =ic_bas\>1                              |
| κ Pareto à moins de ecart_kappa_max du κ empirique | =ABS(ecart_kappa)\<ecart_kappa_max      |
| Survie observée proche de la Pareto                | =MAX(ABS(obs-pareto))\<ecart_survie_max |

6.11 Étape 11 : tarif et impact

- Feuille Tarif, cellules nommées : B0 =EXP(glmf_b0)\*EXP(glmc_g0)\*kappa ; somme_pp0 =SUMPRODUCT(c_expo,c_pp0) ; theta =charge_cible/somme_pp0 ; base_pp =B0\*theta ; pp_moy =SUMPRODUCT(c_expo,c_pp)/SUM(c_expo) ; chargement =(1+taux_securite)/(1-taux_gestion-taux_acquisition-taux_marge) ; sp_cible =(1-taux_gestion-taux_acquisition-taux_marge)/(1+taux_securite).

- Table des relativités (A:F), une ligne par classe de chaque variable retenue : rel_frequence =EXP(XLOOKUP(var&"\|"&classe,glmf_cle,glmf_coef,0)), rel_cout idem, rel_prime_pure =C\*D, evolution =SUMIFS(i_ht_new,i_cl\_\<v\>,classe)/SUMIFS(i_ht_act,i_cl\_\<v\>,classe)-1.

- Feuille Impact : le VBA écrit la cle des lignes en portefeuille au 31/12/annee_fin (exercice = annee_fin, date_fin = 31/12, exposition \> 0), dans l’ordre de Contrats. Colonnes : B age, C zone, D puissance_cv, E usage, F crm_c, G:J cl\_\<v\> (XLOOKUP sur c_cle) ; K ht_act =base_actuelle\*XLOOKUP(B2,ta_age_min,ta_age_rel,,-1)\*XLOOKUP(C2,ta_zone_mod,ta_zone_rel)\*XLOOKUP(D2,ta_cv_min,ta_cv_rel,,-1)\*XLOOKUP(E2,ta_usage_mod,ta_usage_rel)\*F2 ; L ht_new =XLOOKUP(A2,c_cle,c_pp)\*chargement ; M evol =L2/K2-1 ; N evol_p =MIN(MAX(M2,-plafond_evolution),plafond_evolution) ; O ht_cap =K2\*(1+N2) ; P ttc_new =L2\*(1+taux_taxe).

- Noms ta\_… créés depuis TarifActuel (base_actuelle = relativité de la ligne base).

- Synthèse : evol_moy =SUM(L)/SUM(K)-1 ; equilibre =SUM(O)/SUM(L) ; ttc_moy =AVERAGE(P) ; ttc_moy_act =AVERAGE(K)\*(1+taux_taxe). Dislocation (part des polices) : M \< -10 % ; -10 % ≤ M \< -5 % ; -5 % ≤ M \< 0 ; 0 ≤ M \< 5 % ; 5 % ≤ M ≤ 10 % ; M \> 10 %.

| **Contrôle**                                           | **Formule de statut**                              |
|--------------------------------------------------------|----------------------------------------------------|
| Σ exposition × prime pure = charge cible (calage θ)    | =ABS(SUMPRODUCT(c_expo,c_pp)/charge_cible-1)\<1E-9 |
| Aucune évolution au-delà du plafond après plafonnement | =MAX(ABS(Impact!N2:Nn))\<=plafond_evolution+1E-12  |
| Équilibre après plafonnement ≥ equilibre_min           | =equilibre\>=equilibre_min                         |

6.12 Tableau de bord

- Indicateurs annuels : feuille Historique (6.4).

- Feuille Segments : une ligne par exercice × dimension (age, zone, puissance_cv, usage) × classe retenue. D exposition =SUMIFS(c_expo,c_exercice,A2,c_cl\_\<dim\>,C2), E primes, F charge_ecr, G charge =XLOOKUP(A2,hist_exercice,hist_ult)\*F2/SUMIFS(c_charge_ecr,c_exercice,A2), H sp =G2/E2, I prime_moy =E2/D2.

- Principe : la charge ultime de l’exercice est répartie entre segments au prorata de la charge écrêtée. Les graves sont ainsi mutualisés et un sinistre exceptionnel ne fait pas exploser le S/P d’un petit segment.

- Bandeau (VBA) pour l’exercice affiché y : segments des 4 dimensions dont l’exposition ≥ 5 % de celle de y et dont le S/P \> sp_cible, triés par S/P décroissant. Deux ou plus : « {Segment 1} et {segment 2} restent sous-tarifés : S/P y de a % et b % (cible c %). Lancer la révision. » Un : « {Segment} reste sous-tarifé : S/P y de a % (cible c %). Lancer la révision. » Aucun : « Aucun segment significatif au-dessus du S/P cible en y. Consulter l’étude. » Désignations : « les 25-29 ans », « la zone C », « les 5-8 CV », « l’usage professionnel » ; S/P arrondis à l’unité ; première lettre en majuscule.

6.13 Calculateur

- Feuille Calculateur : entrées B2 age, B3 zone, B4 puissance_cv, B5 usage, B6 crm ; B8 à B12 sécurité, gestion, acquisition, marge, taxes (initialisées depuis Parametres).

- Classes : =INDEX(bornes_age_classe,MATCH(B2,bornes_age_min,1)), etc. ; rf =EXP(Σ XLOOKUP(var\|classe,glmf_cle,glmf_coef,0)), rc idem.

- freq =EXP(glmf_b0)\*rf\*B6 ; cout =EXP(glmc_g0)\*rc\*kappa\*theta ; pp =freq\*cout ; ht =pp\*(1+B8)/(1-B9-B10-B11) ; ttc =ht\*(1+B12) ; mensuel =ttc/12 ; securite =pp\*B8 ; frais =ht\*(B9+B10) ; marge =ht\*B11 ; taxes =ht\*B12.

- ht_act comme dans Impact avec les entrées ; vs_actuel =ht/ht_act-1 ; vs_moyenne =ttc/ttc_moy-1.

- Boutons : âge ±1 dans \[age_min ; age_max\] ; puissance ±1 dans \[3 ; 15\] ; CRM « − » : max(crm_min, arrondi inférieur à 2 décimales de crm × 0,95), « + » : min(crm_max, arrondi inférieur de crm × 1,25) ; chargements ±0,5 point dans \[0 % ; 50 %\], refusé si 1 − g − a − m \< 5 %. Réinitialiser restaure les valeurs par défaut.

7\. Feuilles de travail : présentation

- Chaque table commence en A1, en-têtes en ligne 1 (la carte « Dans le classeur » affiche la ligne 1 comme en-tête). Les blocs de synthèse sont placés à droite après une colonne vide, libellé à gauche de la valeur.

- En-têtes des colonnes d’origine : gras, fond violet_clair. En-têtes des colonnes dérivées (formules) : gras, fond violet_pale, texte violet_fonce, pour distinguer ce qui est calculé.

- Formats : dates dd/mm/yyyy ; montants \#,##0.00 ; exposition 0.000 ; taux 0.00% ; relativités 0.000 ; coefficients et écarts-types 0.0000 ; p-values 0.0000.

- Volets figés sous la ligne 1, quadrillage visible, largeurs ajustées (AutoFit puis minimum 9).

- Les cellules nommées de synthèse portent un fond formule_fond et une bordure bord.

- Ordre et couleur d’onglet : feuilles de travail en lavande, données en bord_2, Recette en vert.

8\. Charte graphique

Reprise stricte du design fourni (fichiers \*.dc.html), transposée à l’échelle 2/3 : 1 px de la maquette web = 0,667 pt du canevas.

8.1 Couleurs

| **Nom**        | **Hex**  | **RGB**            | **Long VBA** | **Usage**                                          |
|----------------|----------|--------------------|--------------|----------------------------------------------------|
| violet         | \#6B4EF6 | RGB(107, 78, 246)  | 16141931     | couleur de marque, actif, barres mises en avant    |
| violet_fonce   | \#5636E8 | RGB(86, 54, 232)   | 15218262     | texte actif, valeurs surlignées                    |
| violet_clair   | \#EFEBFF | RGB(239, 235, 255) | 16772079     | fond d'élément actif, en-têtes de feuilles         |
| violet_pale    | \#F3F0FF | RGB(243, 240, 255) | 16773363     | colonne surlignée, boutons −/+                     |
| lavande        | \#D9D1FF | RGB(217, 209, 255) | 16765401     | barres secondaires, halo                           |
| lavande_moyen  | \#B9AAFF | RGB(185, 170, 255) | 16755385     | point de l'eyebrow                                 |
| formule_fond   | \#FAF9FF | RGB(250, 249, 255) | 16775674     | fond des encadrés de formule                       |
| formule_bord   | \#EFEBFF | RGB(239, 235, 255) | 16772079     | bord des encadrés de formule                       |
| encre          | \#17152E | RGB(23, 21, 46)    | 3020055      | texte principal, bouton sombre                     |
| encre_2        | \#4A4960 | RGB(74, 73, 96)    | 6310218      | texte courant                                      |
| gris_1         | \#7C7B93 | RGB(124, 123, 147) | 9665404      | libellés                                           |
| gris_2         | \#9B9AB0 | RGB(155, 154, 176) | 11573915     | textes secondaires, axes                           |
| fond           | \#F6F6FB | RGB(246, 246, 251) | 16512758     | fond du canevas, pistes de barres                  |
| bord           | \#ECEBF4 | RGB(236, 235, 244) | 16051180     | bords des cartes, séparateurs                      |
| bord_2         | \#E6E5EF | RGB(230, 229, 239) | 15721958     | bords des pilules et de la carte feuille           |
| ligne          | \#F0EFF6 | RGB(240, 239, 246) | 16183280     | quadrillage des graphiques                         |
| piste          | \#F3F2F8 | RGB(243, 242, 248) | 16315123     | piste des barres S/P                               |
| rose           | \#D63C88 | RGB(214, 60, 136)  | 8928470      | ratio combiné, alerte                              |
| rose_fonce     | \#C2306F | RGB(194, 48, 111)  | 7286978      | texte d'alerte                                     |
| rose_texte     | \#B92F74 | RGB(185, 47, 116)  | 7614393      | étiquettes du ratio combiné, coût moyen            |
| rose_clair     | \#FDECF5 | RGB(253, 236, 245) | 16116989     | fond d'alerte                                      |
| vert           | \#1A9665 | RGB(26, 150, 101)  | 6657562      | contrôle réussi, variation favorable               |
| vert_clair     | \#E5F6EE | RGB(229, 246, 238) | 15660773     | fond de contrôle réussi                            |
| excel          | \#1F7A4D | RGB(31, 122, 77)   | 5077535      | icône Excel, onglet actif                          |
| excel_clair    | \#E8F4EE | RGB(232, 244, 238) | 15660264     | fond de l'onglet actif                             |
| feuille_entete | \#F7F7FB | RGB(247, 247, 251) | 16513015     | en-têtes de lignes et colonnes de la carte feuille |
| feuille_titre  | \#FBFBFE | RGB(251, 251, 254) | 16710651     | barre de titre de la carte feuille                 |
| feuille_ligne  | \#EFEEF5 | RGB(239, 238, 245) | 16117487     | lignes de la carte feuille                         |
| blanc          | \#FFFFFF | RGB(255, 255, 255) | 16777215     | cartes                                             |
| pile_securite  | \#F5A3CB | RGB(245, 163, 203) | 13345781     | barre empilée : sécurité                           |
| pile_frais     | \#8FE0BC | RGB(143, 224, 188) | 12378255     | barre empilée : frais                              |
| pile_marge     | \#B9AAFF | RGB(185, 170, 255) | 16755385     | barre empilée : marge                              |
| pile_taxes     | \#FFC58F | RGB(255, 197, 143) | 9422335      | barre empilée : taxes                              |

8.2 Polices

| **Constante** | **Police (Plus Jakarta Sans installée)**                       | **Repli (non installée)** |
|---------------|----------------------------------------------------------------|---------------------------|
| F_REG         | Plus Jakarta Sans                                              | Segoe UI                  |
| F_MED         | Plus Jakarta Sans Medium                                       | Segoe UI                  |
| F_SEMI        | Plus Jakarta Sans SemiBold                                     | Segoe UI Semibold         |
| F_BOLD        | Plus Jakarta Sans, Bold = True                                 | Segoe UI, Bold = True     |
| F_XBOLD       | Plus Jakarta Sans ExtraBold                                    | Segoe UI, Bold = True     |
| F_MONO        | Consolas                                                       | Consolas                  |
| F_SYM         | Segoe UI Symbol (✓, ✗, ↺)                                      | Segoe UI Symbol           |
| F_MATH        | Cambria Math (formules dynamiques du calculateur)              | Cambria Math              |
| F_ICONE       | Times New Roman, gras italique (« ƒ » de la carte Formulation) | Times New Roman           |

- Détection à la construction : la police est installée si PlusJakartaSans-ExtraBold.ttf existe dans %WINDIR%\Fonts ou %LOCALAPPDATA%\Microsoft\Windows\Fonts. Le résultat est mémorisé (CALC!B10) et affiché dans la bulle d’aide de la marque.

- Les graisses Medium, SemiBold et ExtraBold sont des familles distinctes sous Windows : ne jamais combiner Bold = True avec elles.

- La police ne contient ni l’espace fine (U+202F), ni ✓, ✗, ↺ : voir R6 et R8.

8.3 Échelle typographique (points)

| **Rôle**                                  | **Police**              | **Taille**                         | **Couleur**                       | **Espacement** |
|-------------------------------------------|-------------------------|------------------------------------|-----------------------------------|----------------|
| Marque « PrimeLab »                       | F_XBOLD                 | 12,5                               | encre                             | -0,4           |
| Sous-titre de marque                      | F_MED                   | 7                                  | gris_1                            | 0              |
| Entrée « Tableau de bord »                | F_MED (actif F_BOLD)    | 9                                  | encre_2 (actif violet_fonce)      | 0              |
| Entrée d’étape                            | F_MED (actif F_BOLD)    | 8,5                                | encre (actif violet_fonce)        | 0              |
| Titre de groupe                           | F_SEMI                  | 6,5                                | gris_2                            | 0,6            |
| Eyebrow de page                           | F_BOLD                  | 7,5                                | violet ; « ÉTAPE nn / 11 » gris_2 | 1,1            |
| Titre de page                             | F_XBOLD                 | 22                                 | encre                             | -0,8           |
| Introduction                              | F_REG                   | 9,5 (interligne 1,38)              | encre_2                           | 0              |
| KPI d’étape : libellé, valeur, sous-texte | F_SEMI, F_XBOLD, F_REG  | 8 ; 16 ; 7,5                       | gris_1 ; encre ; gris_2           | 0 ; -0,5 ; 0   |
| KPI du tableau de bord                    | F_SEMI, F_XBOLD, F_REG  | 8,5 ; 19 ; 7,5                     | gris_1 ; encre ; gris_2           | 0 ; -0,6 ; 0   |
| Badge de variation                        | F_BOLD                  | 7                                  | vert ou rose_fonce                | 0              |
| Titre de carte                            | F_BOLD                  | 11 (Contrôles 10,5 ; graphique 10) | encre                             | -0,2           |
| Libellé de formule                        | F_BOLD                  | 6,5                                | gris_1                            | 0,4            |
| Texte de contrôle                         | F_REG                   | 8                                  | encre_2                           | 0              |
| Carte feuille : nom ; méta                | F_BOLD ; F_REG          | 8,5 ; 7,5                          | encre ; gris_1                    | 0              |
| Carte feuille : référence, formule        | F_MONO                  | 7                                  | gris_1 ; encre                    | 0              |
| Carte feuille : lettres et numéros        | F_SEMI ; F_REG          | 6,5                                | gris_2                            | 0              |
| Carte feuille : en-têtes ; cellules       | F_BOLD ; F_REG          | 7,5                                | encre                             | 0              |
| Carte feuille : onglets                   | F_BOLD (actif) ; F_MED  | 7                                  | excel ; gris_1                    | 0              |
| Graphique en barres : libellé ; valeur    | F_SEMI ; F_XBOLD        | 8 ; 8 (7,5 à deux séries)          | encre_2 ; encre                   | 0              |
| Puces                                     | F_BOLD (actif) ; F_SEMI | 8 (années 8,5)                     | blanc ; encre_2                   | 0              |
| Boutons de navigation bas                 | F_BOLD                  | 8,5                                | encre ; blanc                     | 0              |
| Calculateur : prime TTC                   | F_XBOLD                 | 32                                 | blanc                             | -1,2           |
| Calculateur : mini-cartes                 | F_XBOLD                 | 14                                 | violet_fonce, rose_texte, encre   | -0,4           |
| Calculateur : formule appliquée           | F_MATH                  | 9,5                                | encre                             | 0              |

8.4 Formes

- Cartes : msoShapeRoundedRectangle, fond blanc, bord bord 0,75 pt (carte feuille : bord_2), sans ombre ni effet. Rayon en points converti : Adjustments(1) = rayon / Min(W, H).

- Barre de titre de la carte feuille : msoShapeRound2SameRectangle (angles hauts arrondis), même rayon que la carte.

- Pilules : rayon = H / 2. Cercles : msoShapeOval. Étoile de marque : msoShape4pointStar.

- Textes : TextFrame2, marges nulles, WordWrap vrai seulement pour les textes à largeur fixée, AutoSize nul, ancrage haut, alignement selon la colonne « Style » de la section 10.

- Transparences : Fill.Transparency (étoile du calculateur 0,9 ; textes blancs secondaires 0,1 à 0,15 via Font.Fill.Transparency).

9\. Canevas, zoom et navigation

- Canevas fixe 960 × 540 pt : grille A1:AV36 de cellules 20 × 15 pt (méthode de l’Observatoire, largeur de colonne quantifiée au pixel le plus proche), fond fond, quadrillage et en-têtes masqués, ScrollArea = "A1:AV36".

- Zoom automatique pour que le canevas tienne dans la fenêtre (procédure AjusterZoom de l’Observatoire, appelée à l’activation, au redimensionnement et à chaque navigation). Construction des formes au zoom 100.

- Ordre de construction d’une page : fond, barre latérale, en-tête, contenu, bulle d’aide (masquée).

- Aucune page ne défile : tout contenu doit tenir dans sa zone (section 10).

9.1 Carte de navigation

| **Déclencheur**                                                 | **Action**                                                                  |
|-----------------------------------------------------------------|-----------------------------------------------------------------------------|
| Entrées de la barre latérale                                    | AllerPage n                                                                 |
| Bouton « Calculateur de prime »                                 | AllerPage 12                                                                |
| Boutons « ‹ précédent » et « suivant › » des étapes             | Étape voisine ; P01 précédent = Tableau de bord ; P11 suivant = Calculateur |
| Bandeau du tableau de bord                                      | AllerPage 1                                                                 |
| « Ouvrir l’onglet » (carte feuille, carte Excel du calculateur) | Afficher la feuille de travail (12.4)                                       |
| Ctrl+PgSuiv / Ctrl+PgPréc                                       | Page suivante / précédente (cyclique)                                       |
| Échap                                                           | Fermer la bulle ; sur une feuille de travail : retour à la page             |
| Ctrl+Maj+M                                                      | Bascule application / administration                                        |

10\. Géométrie des gabarits

Coordonnées en points. Le texte est positionné par le coin haut gauche de sa zone. « fin x » signifie aligné à droite sur l’abscisse x. Les largeurs « texte + n » se calculent par mesure (forme provisoire en AutoSize, repli 0,58 × taille × nombre de caractères).

10.1 Barre latérale (toutes les pages)

| **Élément**                                 | **L** | **T**     | **W** | **H** | **Style**                                                                                                                                                                                                           |
|---------------------------------------------|-------|-----------|-------|-------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Panneau                                     | 0     | 0         | 176   | 540   | blanc ; filet vertical x = 176 couleur bord 0,75                                                                                                                                                                    |
| Logo                                        | 14    | 16        | 26    | 26    | violet, rayon 8 ; étoile blanche (20,5 ; 22,5 ; 13 ; 13)                                                                                                                                                            |
| « PrimeLab »                                | 48    | 15        |       |       | F_XBOLD 12,5                                                                                                                                                                                                        |
| Sous-titre « Étude tarifaire RC auto 2026 » | 48    | 31        |       |       | F_MED 7 gris_1                                                                                                                                                                                                      |
| Entrée Tableau de bord                      | 10    | 56        | 156   | 22    | pilule rayon 7 (actif : violet_clair) ; icône 4 carrés 4,5 pt bord 1 pt en (20,62) (26,62) (20,68) (26,68) ; texte en (36 ; 60,5)                                                                                   |
| Titre « PRÉPARER LES DONNÉES »              | 18    | 88        |       |       | F_SEMI 6,5 gris_2, espacement 0,6                                                                                                                                                                                   |
| Étapes 01 à 05, k = 0 à 4                   | 10    | 99 + 21k  | 156   | 19    | actif : pilule violet_clair rayon 6, halo lavande (18,5 ; T+3,5 ; 12 ; 12) et point violet (20,5 ; T+5,5 ; 8 ; 8) ; inactif : cercle violet (19,5 ; T+4,5 ; 10 ; 10) avec ✓ blanc F_SYM 5,5 ; libellé en (36 ; T+4) |
| Titre « CONSTRUIRE LE TARIF »               | 18    | 212       |       |       | idem titre de groupe                                                                                                                                                                                                |
| Étapes 06 à 11, k = 0 à 5                   | 10    | 223 + 21k | 156   | 19    | idem                                                                                                                                                                                                                |
| Bouton Calculateur                          | 10    | 494       | 156   | 30    | rayon 9, violet (encre sur la page 12) ; icône : rectangle (22,502,10,13) bord blanc 1 + (24,5 ; 505 ; 5 ; 3) blanc ; texte (40 ; 503,5) F_BOLD 9 blanc                                                             |

10.2 Gabarit des étapes (P01 à P11)

| **Élément**                 | **L**         | **T**     | **W**                | **H** | **Style**                                                                                                                     |
|-----------------------------|---------------|-----------|----------------------|-------|-------------------------------------------------------------------------------------------------------------------------------|
| Eyebrow : groupe            | 196           | 18        |                      |       | F_BOLD 7,5 violet ; puis point lavande_moyen 3,5 pt à (fin du texte + 6 ; 20,5) ; puis « ÉTAPE nn / 11 » gris_2 à point + 9,5 |
| Titre                       | 196           | 30        |                      | 28    | F_XBOLD 22                                                                                                                    |
| Introduction                | 196           | 61        | 520 (400 avec puces) | 28    | 2 lignes au plus                                                                                                              |
| Puces d’en-tête (option)    | fin 940       | 38        | Σ + 6                | 24    | conteneur blanc bord_2 rayon 12 ; puces à T+3, H 18, largeur texte + 18 ; active violet rayon 9                               |
| KPI k = 0 à 3               | 196 + 188k    | 96        | 180                  | 54    | rayon 12 ; libellé (L+12 ; 105) ; valeur (L+12 ; 116) ; sous-texte (L+12 ; 135)                                               |
| Carte Formulation           | 196           | 160       | 270                  | 214   | rayon 14 ; icône (210,172,22,22) rayon 7 violet_clair + « ƒ » ; titre (240 ; 176)                                             |
| Formule k = 0 à 2 : libellé | 210           | 204 + 56k |                      |       | libellé du manifeste                                                                                                          |
| Formule k : encadré         | 210           | 215 + 56k | 242                  | 40    | formule_fond, bord formule_bord, rayon 9 ; image centrée, échelle = min(1 ; 230 / w ; 34 / h)                                 |
| Carte Contrôles             | 196           | 382       | 270                  | 114   | rayon 14 ; titre (210 ; 393)                                                                                                  |
| Contrôle k = 0 à 2          | 210           | 416 + 26k |                      |       | pastille 11 pt en (210 ; T+1) : vert_clair + ✓ vert ou rose_clair + ✗ rose_fonce (F_SYM 6) ; texte (227 ; T-0,5 ; 225 ; 22)   |
| « Dans le classeur » ; note | 476 ; fin 940 | 159 ; 162 |                      |       | F_BOLD 11 ; F_REG 7,5 gris_1 « Cellule X sélectionnée »                                                                       |
| Carte feuille               | 476           | 178       | 464                  | 176   | rayon 11, bord bord_2 ; détail en 10.3                                                                                        |
| Carte graphique             | 476           | 362       | 464                  | 134   | rayon 14 ; détail en 10.4                                                                                                     |
| Filet de pied               | 196 à 940     | 502       |                      |       | bord 0,75                                                                                                                     |
| Bouton précédent            | 196           | 510       | texte + 38           | 24    | blanc, bord bord_2, rayon 12 ; cercle violet_pale 18 en (199 ; 513) avec ‹ ; libellé (223 ; 515,5)                            |
| Bouton suivant              | fin 940       | 510       | texte + 44           | 24    | encre, rayon 12 ; libellé blanc à L+14 ; cercle blanc 18 en (919 ; 513) avec ›                                                |

10.3 Carte « Dans le classeur »

| **Élément**                  | **L**   | **T**     | **W**      | **H** | **Style**                                                                                                                                                         |
|------------------------------|---------|-----------|------------|-------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Barre de titre               | 476     | 178       | 464        | 22    | feuille_titre ; filet bas feuille_ligne                                                                                                                           |
| Icône Excel                  | 486     | 182       | 14         | 14    | excel rayon 4, « X » F_XBOLD 7,5 blanc                                                                                                                            |
| Nom de la feuille            | 506     | 183,5     |            |       | F_BOLD 8,5                                                                                                                                                        |
| Méta                         | fin 862 | 184       |            |       | F_REG 7,5 gris_1                                                                                                                                                  |
| Bouton « Ouvrir l’onglet › » | 870     | 181       | 62         | 16    | blanc, bord bord_2, rayon 8, F_BOLD 6,8 violet                                                                                                                    |
| Barre de formule             | 476     | 200       | 464        | 18    | référence (484 ; 204) F_MONO 7 ; séparateurs x = 520 et 544 ; « fx » italique violet (526 ; 203) ; formule (550 ; 204) F_MONO 7, tronquée à 84 caractères + « … » |
| Lettres de colonnes          | 476     | 218       | 464        | 12    | feuille_entete                                                                                                                                                    |
| Colonne des numéros          | 476     | 230       | 20         | 102   | feuille_entete                                                                                                                                                    |
| Ligne d’en-tête              | 496     | 230       | 444        | 17    | F_BOLD 7,5                                                                                                                                                        |
| Lignes de données r = 0 à 4  | 496     | 247 + 17r | 444        | 17    | texte à (x + 5 ; T + 4,2) ; colonne surlignée violet_pale + violet_fonce F_SEMI ; cellule en erreur rose_clair + rose_fonce F_SEMI                                |
| Onglets                      | 486     | 336       | texte + 16 | 14    | écart 4 ; actif excel_clair rayon 4, texte excel F_BOLD 7                                                                                                         |

Largeur des colonnes : proportionnelle à (nombre maximal de caractères de la colonne × 4,4 + 12), ramenée à 444 pt au total. Filets verticaux aux limites de colonnes de y = 218 à 332, filets horizontaux feuille_ligne 0,5 sous chaque ligne. Les numéros de ligne affichés sont les vrais numéros Excel des lignes montrées.

10.4 Carte graphique en barres

- Titre (490 ; 373) F_BOLD 10. À droite (fin 926, T = 375) : soit une note F_REG 7,5 gris_2, soit une légende (carré 7 × 7 rayon 2 + libellé F_REG 7,5, écart 10).

- n lignes, pas = min(17 ; 94 / n), haut de ligne i = 394 + i × pas. Hauteur de barre bh = min(9 ; pas − 5) ; à deux séries, bh = min(10 ; pas − 3), deux barres de (bh − 1) / 2 séparées de 1 pt (série 1 lavande, série 2 violet).

- Libellé (490 ; ligne + (pas − 10) / 2 ; 92) F_SEMI 8 encre_2. Piste (588 ; centrée ; 272 ; bh) fond, rayon bh / 2. Barre = 272 × max(0,02 ; (v − vmin) / (vmax − vmin)), lavande ou violet si mise en avant. Valeur F_XBOLD 8 fin 926.

- vmax par défaut = 1,05 × maximum ; vmin et vmax particuliers précisés en section 11.

10.5 Tableau de bord (P00)

| **Élément**                  | **L**      | **T**        | **W** | **H** | **Style**                                                                                                                                                                                                                                                                                                                                                              |
|------------------------------|------------|--------------|-------|-------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Eyebrow ; titre ; sous-titre | 196        | 18 ; 30 ; 61 | 480   |       | comme 10.2                                                                                                                                                                                                                                                                                                                                                             |
| Puces d’années               | fin 940    | 36           | 226   | 26    | 5 puces de 44 × 20 à T+3 ; active violet F_BOLD 8,5 blanc                                                                                                                                                                                                                                                                                                              |
| KPI k = 0 à 3                | 196 + 188k | 92           | 180   | 72    | rayon 12 ; libellé (L+14 ; T+12) + icône « i » 9 pt (bord gris_2) à fin du libellé + 4 ; badge fin L+166, T+10, H 13, rayon 6,5 ; valeur (L+14 ; T+27) ; sous-texte (L+14 ; T+55)                                                                                                                                                                                      |
| Carte graphique              | 196        | 174          | 436   | 268   | rayon 16 ; titre (212 ; 187) ; légende à T = 207,5 depuis x = 212                                                                                                                                                                                                                                                                                                      |
| Graphique Excel              | 206        | 224          | 416   | 196   | colonnes groupées primes (lavande) et charge ultime (violet), axe 0 à 1 200 k€ pas 300 ; ratio combiné en courbe rose 1,6 pt sur axe secondaire 0,70 à 1,15 masqué, marqueurs ronds 6 pt blancs bord rose, étiquettes F_BOLD 7 rose_texte « 0,0 % » ; série constante 100 % en tirets rose transparence 0,45 ; barres de charge des autres exercices transparence 0,45 |
| Note du graphique            | 212        | 424          |       |       | F_REG 7 gris_2                                                                                                                                                                                                                                                                                                                                                         |
| Carte segments               | 642        | 174          | 298   | 268   | rayon 16 ; titre (658 ; 187) + « i » ; sous-titre (658 ; 203) ; onglets (658,220,266,22) fond rayon 11, 4 onglets de 65 × 18 à (661 + 65k ; 222)                                                                                                                                                                                                                       |
| Ligne de segment i = 0 à 4   | 658        | 252 + 30i    | 266   | 30    | libellé (658 ; T+9 ; 70) F_BOLD 8,5 ; exposition fin 766 F_REG 8 gris_1 ; prime moyenne fin 814 ; piste (826 ; T+12 ; 60 ; 6) piste ; barre 60 × min(1 ; S/P / 1,2) rose si S/P \> cible sinon violet ; S/P fin 926 F_XBOLD 8,5 ; filet pointillé bord 0,5 à T+30                                                                                                      |
| En-têtes de colonnes         | 658        | 410          |       |       | « SEGMENT », « EXPO. » fin 766, « PRIME MOY. » fin 814, « S/P (CIBLE 68 %) » fin 926 ; F_SEMI 6,5 gris_2, espacement 0,5                                                                                                                                                                                                                                               |
| Bandeau                      | 196        | 452          | 744   | 62    | violet rayon 16 ; eyebrow (216 ; 464) ; message (216 ; 478 ; 660) F_BOLD 11,5 blanc ; cercle blanc 28 en (898 ; 469) avec ›                                                                                                                                                                                                                                            |

10.6 Calculateur (P12)

| **Élément**                                                  | **L**        | **T**     | **W** | **H** | **Style**                                                                                                                                                                                                                                                                             |
|--------------------------------------------------------------|--------------|-----------|-------|-------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Intro                                                        | 196          | 61        | 470   |       |                                                                                                                                                                                                                                                                                       |
| Réinitialiser                                                | 850          | 40        | 90    | 24    | blanc bord_2 rayon 12 ; ↺ F_SYM 9 en (858 ; 45) ; texte (873 ; 45,5) F_BOLD 8,5                                                                                                                                                                                                       |
| Carte Profil                                                 | 196          | 96        | 252   | 268   | rayon 16 ; titre (212 ; 108)                                                                                                                                                                                                                                                          |
| Ligne à valeur (âge T = 132, puissance T = 224, CRM T = 306) | 212          | T         |       |       | libellé F_SEMI 8,5 encre_2 ; valeur fin 392 à T-1,5 F_XBOLD 10 ; boutons cercles 16 violet_pale en (398 ; T-2,5) et (418 ; T-2,5) « − » « + » ; légende (212 ; T+16) F_REG 7,5 gris_2                                                                                                 |
| Zone : libellé ; conteneur                                   | 212          | 168 ; 182 | 220   | 32    | fond rayon 10 ; puces (216 + 53k ; 184 ; 51 ; 28), active blanche rayon 8 ; lettre (T 186) 10 pt ; sous-libellé (T 199) F_MED 6,5                                                                                                                                                     |
| Usage : libellé ; conteneur                                  | 212          | 258 ; 272 | 220   | 22    | fond rayon 11 ; puces (215 + 71,3k ; 274 ; 71,3 ; 18), active blanche                                                                                                                                                                                                                 |
| Aide CRM                                                     | 212          | 322       | 222   |       | F_REG 7 gris_2, 2 lignes                                                                                                                                                                                                                                                              |
| Carte Chargements                                            | 196          | 372       | 252   | 124   | rayon 16 ; titre (212 ; 383) ; lignes T = 404 + 18k : libellé F_REG 8, valeur fin 392, boutons 14 pt en (398 ; T-1,5) et (416 ; T-1,5)                                                                                                                                                |
| Carte prime TTC                                              | 458          | 96        | 482   | 124   | violet rayon 18 ; étoile blanche (830,100,104,104) transparence 0,9 ; eyebrow (478 ; 110) ; montant (476 ; 120) ; mensualité (478 ; 160) ; pilule « vs tarif actuel » fin 924 T 116 H 18 ; texte « vs prime moyenne » fin 924 T 140 ; barre empilée (478,180,446,7) ; légende T 194,5 |
| Mini-cartes k = 0 à 3                                        | 458 + 122,5k | 228       | 114,5 | 58    | rayon 14 ; libellé (L+12 ; 237) ; valeur (L+12 ; 249) ; indication (L+12 ; 270) F_MONO 6,3                                                                                                                                                                                            |
| Carte Formule appliquée                                      | 458          | 294       | 482   | 128   | rayon 16 ; titre (474 ; 306) ; libellés T = 328 + 46k ; encadrés (474 ; 338 + 46k ; 450 ; 30) ; texte centré F_MATH 9,5                                                                                                                                                               |
| Carte Excel                                                  | 458          | 430       | 482   | 66    | rayon 16 ; icône (474,446,18,18) ; titre (500 ; 443) ; texte (500 ; 459 ; 320) ; bouton encre (836,449,90,24)                                                                                                                                                                         |

11\. Contenu des pages

Les textes ci-dessous sont repris tels quels dans modContenu. Les valeurs d’exemple sont celles de la recette (seuil 15 000 €) ; elles doivent apparaître à l’identique.

11.1 Tableau de bord (P00)

<table>
<colgroup>
<col style="width: 15%" />
<col style="width: 84%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>Zone</strong></th>
<th><strong>Contenu</strong></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td>En-tête</td>
<td>Eyebrow « PORTEFEUILLE AUTOMOBILE · RC · 2021–2025 » ; titre « Tableau de bord » ; sous-titre « Performance technique du portefeuille RC, charges à l’ultime. Base de l’étude tarifaire 2026. »</td>
</tr>
<tr class="even">
<td>Puces</td>
<td>Exercices annee_debut à annee_fin ; défaut annee_fin (CALC!B4).</td>
</tr>
<tr class="odd">
<td>KPI (exercice y)</td>
<td><p>1. Primes acquises : Historique!I en k€ ; sous-texte « n années-police » ; badge variation % vs y−1, favorable si hausse.</p>
<p>2. Charge ultime : Historique!F en k€ ; « dont IBNR x k€ » ; badge %, favorable si baisse.</p>
<p>3. S/P ultime : Historique!L, 1 décimale ; « vu à fin 2025 : sp_vu » ; badge en points, favorable si baisse.</p>
<p>4. Ratio combiné : Historique!M ; « dont frais 25,0 % » ; badge en points, favorable si baisse.</p>
<p>Pour y = annee_debut, badge neutre « tiret » (fond piste, texte gris_1). Exemple 2025 : 1 032 k€ (+2,9 %), 827 k€ (+30,8 %), 80,1 % (+17,1 pt), 105,1 % (+17,1 pt).</p></td>
</tr>
<tr class="even">
<td>Graphique</td>
<td>« Primes, sinistres et rentabilité » ; légende Primes acquises / Charge ultime / Ratio combiné ; note « Échelle de gauche en k€. Ratio combiné sur l’échelle de droite (70 % à 115 %). »</td>
</tr>
<tr class="odd">
<td>Segments</td>
<td>« Rentabilité par segment » ; sous-titre « Exercice y · S/P ultime, graves mutualisés » ; onglets Âge, Zone, Puissance, Usage (CALC!B5) ; libellés « 18–24 ans », « Zone A », « 5–8 CV », « Privé » ; S/P cible = sp_cible (68 %).</td>
</tr>
<tr class="even">
<td>Bandeau</td>
<td>Eyebrow « ÉTUDE TARIFAIRE 2026 » ; message selon 6.12. Exemple 2025 : « La zone C et l’usage professionnel restent sous-tarifés : S/P 2025 de 101 % et 98 % (cible 68 %). Lancer la révision. »</td>
</tr>
<tr class="odd">
<td>Bulles « i »</td>
<td><p>Primes acquises : « Primes hors taxes acquises sur l’exercice au tarif alors en vigueur : prime annuelle × exposition de chaque ligne. »</p>
<p>Charge ultime : « Charge vue au 31/12/2025 multipliée par le facteur de développement Chain Ladder de l’exercice. L’IBNR est l’écart entre charge ultime et charge vue. »</p>
<p>S/P ultime : « Charge ultime / primes acquises. Le S/P vu sous-estime les exercices récents, encore immatures : le tableau de bord raisonne donc à l’ultime. »</p>
<p>Ratio combiné : « S/P ultime + frais de gestion et d’acquisition (25 % des primes). Au-delà de 100 %, l’exercice est techniquement déficitaire. »</p>
<p>Segments : « La charge ultime de l’exercice est répartie entre segments au prorata de leur charge écrêtée : les graves sont mutualisés. S/P cible = (1 − frais − marge) / (1 + sécurité). »</p></td>
</tr>
</tbody>
</table>

11.2 Étape 01 : Import et exposition

<table>
<colgroup>
<col style="width: 15%" />
<col style="width: 84%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>Zone</strong></th>
<th><strong>Contenu</strong></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td>En-tête</td>
<td>PRÉPARER LES DONNÉES · ÉTAPE 01 / 11 ; titre « Import et exposition »</td>
</tr>
<tr class="even">
<td>Introduction</td>
<td>Chargement des tables contrats et sinistres 2021–2025, typage des colonnes et calcul de l’exposition de chaque ligne police × exercice sur la période d’observation.</td>
</tr>
<tr class="odd">
<td>KPI</td>
<td><p>1. Contrats : ROWS(c_cle) ; sous-texte « lignes · n polices » avec ROWS(UNIQUE(c_id)). Exemple : « 25 074 », sous-texte « lignes · 7 281 polices ».</p>
<p>2. Sinistres bruts : ROWS(s_id). Exemple : « 920 », sous-texte « avant contrôles ».</p>
<p>3. Exposition : SUM(c_expo), entier. Exemple : « 22 326 », sous-texte « années-police ».</p>
<p>4. Période : « annee_debut–annee_fin » ; « n exercices ». Exemple : « 2021–2025 », sous-texte « 5 exercices ».</p></td>
</tr>
<tr class="even">
<td>Formules</td>
<td>F01a, F01b, F01c</td>
</tr>
<tr class="odd">
<td>Contrôles</td>
<td><p>1. Dates au format date Excel, aucune stockée en texte</p>
<p>2. Une seule ligne par police et par exercice</p>
<p>3. Exposition comprise entre 0 et 1 (2 lignes nulles : dates incohérentes)</p>
<p>Statuts : feuille Controles (section 6). Les valeurs entre parenthèses sont dynamiques.</p></td>
</tr>
<tr class="even">
<td>Carte feuille</td>
<td>Feuille Contrats ; méta « 25 074 lignes » ; colonnes id_police, exercice, date_debut, date_fin, zone, puissance_cv, crm, exposition ; colonne surlignée exposition ; cellule montrée P2 (formule lue par FormulaLocal, exemple =MAX(0;MIN(D2;DATE(B2;12;31))-MAX(C2;DATE(B2;1;1))+1)/(DATE(B2;12;31)-DATE(B2;1;1)+1)) ; lignes : les 5 premières lignes ; onglets Contrats, Sinistres, Triangle, Parametres.</td>
</tr>
<tr class="odd">
<td>Graphique</td>
<td>« Exposition par exercice » ; note « années-police » ; une ligne par exercice ; vmin 0 ; mise en avant : annee_fin.</td>
</tr>
</tbody>
</table>

11.3 Étape 02 : Qualité des données

<table>
<colgroup>
<col style="width: 15%" />
<col style="width: 84%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>Zone</strong></th>
<th><strong>Contenu</strong></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td>En-tête</td>
<td>PRÉPARER LES DONNÉES · ÉTAPE 02 / 11 ; titre « Qualité des données »</td>
</tr>
<tr class="even">
<td>Introduction</td>
<td>Contrôles de complétude, de cohérence et d’unicité avant toute agrégation. Chaque anomalie est corrigée ou exclue, et tracée dans l’onglet Journal.</td>
</tr>
<tr class="odd">
<td>KPI</td>
<td><p>1. Doublons : comptage « Doublon ». Exemple : « 22 », sous-texte « sinistres supprimés ».</p>
<p>2. Sinistres exclus : Hors période + Orphelin + Montant nul. Exemple : « 14 », sous-texte « hors période, orphelins, sans suite ».</p>
<p>3. Âges imputés : COUNTIF(c_age_brut,""). Exemple : « 56 », sous-texte « lignes · médiane de la zone ».</p>
<p>4. CRM corrigés : CRM corrigés. Exemple : « 7 », sous-texte « ramenés dans [0,50 ; 3,50] ».</p></td>
</tr>
<tr class="even">
<td>Formules</td>
<td>F02a, F02b, F02c</td>
</tr>
<tr class="odd">
<td>Contrôles</td>
<td><p>1. Clé (police, date, montant) unique parmi les sinistres retenus</p>
<p>2. Chaque sinistre retenu est couvert par une ligne de contrat</p>
<p>3. Aucune colonne tarifaire sous 99,5 % de complétude</p>
<p>Statuts : feuille Controles (section 6). Les valeurs entre parenthèses sont dynamiques.</p></td>
</tr>
<tr class="even">
<td>Carte feuille</td>
<td>Feuille Sinistres ; méta « 920 lignes brutes » ; colonnes id_sinistre, id_police, date_survenance, garantie, charge_vue, controle ; colonne surlignée aucune ; cellule montrée J2 (formule lue par FormulaLocal, exemple =SI(NB.SI.ENS(B$1:B1;B2;C$1:C1;C2;F$1:F1;F2)&gt;0;"Doublon";SI(NB.SI(c_id;B2)=0;"Orphelin";SI(OU(H2&lt;annee_debut;H2&gt;annee_fin;…) ; lignes : la première ligne de chaque statut (OK, Doublon, Hors période, Orphelin, Montant nul), dans l’ordre de la feuille ; cellules controle différentes de « OK » en erreur ; onglets Sinistres, Qualite, Journal.</td>
</tr>
<tr class="odd">
<td>Graphique</td>
<td>« Complétude par colonne » ; note « seuil 99,5 % » ; une ligne par colonne contrôlée ; vmin 99 %, vmax 100 % ; mise en avant : colonnes sous 100 %.</td>
</tr>
</tbody>
</table>

11.4 Étape 03 : Base de modélisation

<table>
<colgroup>
<col style="width: 15%" />
<col style="width: 84%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>Zone</strong></th>
<th><strong>Contenu</strong></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td>En-tête</td>
<td>PRÉPARER LES DONNÉES · ÉTAPE 03 / 11 ; titre « Base de modélisation »</td>
</tr>
<tr class="even">
<td>Introduction</td>
<td>Agrégation des sinistres retenus au niveau ligne police × exercice, puis jointure gauche sur les contrats. Chaque ligne porte exposition, nombre de sinistres et charge.</td>
</tr>
<tr class="odd">
<td>KPI</td>
<td><p>1. Sinistres rattachés : SUM(c_nb_sin) ; pourcentage des retenus. Exemple : « 884 », sous-texte « 100 % des sinistres retenus ».</p>
<p>2. Lignes sinistrées : COUNTIF(c_nb_sin,"&gt;0") ; pourcentage des lignes (1 décimale). Exemple : « 848 », sous-texte « 3,4 % des lignes ».</p>
<p>3. Base de modélisation : COUNTIF(c_expo,"&gt;0"). Exemple : « 25 072 », sous-texte « lignes à exposition non nulle ».</p>
<p>4. Charge rattachée : SUM(c_charge_vue) en k€. Exemple : « 3 068 k€ », sous-texte « identique avant et après jointure ».</p></td>
</tr>
<tr class="even">
<td>Formules</td>
<td>F03a, F03b, F03c</td>
</tr>
<tr class="odd">
<td>Contrôles</td>
<td><p>1. Jointure gauche : les 25 074 lignes de contrats sont conservées</p>
<p>2. Somme des Nᵢ égale au nombre de sinistres retenus</p>
<p>3. Charge totale identique avant et après jointure</p>
<p>Statuts : feuille Controles (section 6). Les valeurs entre parenthèses sont dynamiques.</p></td>
</tr>
<tr class="even">
<td>Carte feuille</td>
<td>Feuille Contrats ; méta « 848 lignes sinistrées » ; colonnes id_police, exercice, exposition, age, zone, puissance_cv, nb_sin, charge_vue ; colonne surlignée nb_sin ; cellule montrée W80 (formule lue par FormulaLocal, exemple =NB.SI.ENS(s_cle;O80;s_retenu;1)) ; lignes : les 5 premières lignes sinistrées ; onglets Contrats, Sinistres.</td>
</tr>
<tr class="odd">
<td>Graphique</td>
<td>« Lignes par nombre de sinistres » ; légende Observé / Poisson ; deux séries (observé, Poisson) pour 1, 2, « 3 et plus » ; valeur « obs. / att. ».</td>
</tr>
</tbody>
</table>

11.5 Étape 04 : Charge ultime et inflation

<table>
<colgroup>
<col style="width: 15%" />
<col style="width: 84%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>Zone</strong></th>
<th><strong>Contenu</strong></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td>En-tête</td>
<td>PRÉPARER LES DONNÉES · ÉTAPE 04 / 11 ; titre « Charge ultime et inflation »</td>
</tr>
<tr class="even">
<td>Introduction</td>
<td>Développement des charges vues par Chain Ladder pour estimer la charge ultime de chaque exercice, puis revalorisation au point milieu de la période d’application du tarif.</td>
</tr>
<tr class="odd">
<td>KPI</td>
<td><p>1. Charge vue : Σ Historique!D2:D6 en k€. Exemple : « 3 068 k€ », sous-texte « 2021–2025, au 31/12/2025 ».</p>
<p>2. IBNR : Σ Historique!J2:J6 en k€ ; part de la charge vue. Exemple : « 205 k€ », sous-texte « 6,7 % de la charge vue ».</p>
<p>3. Inflation : taux_inflation, 1 décimale. Exemple : « 5,0 % », sous-texte « par an · coût des sinistres ».</p>
<p>4. Charge cible : charge_cible en k€. Exemple : « 3 852 k€ », sous-texte « ultime revalorisée 2027 ».</p></td>
</tr>
<tr class="even">
<td>Formules</td>
<td>F04a, F04b, F04c</td>
</tr>
<tr class="odd">
<td>Contrôles</td>
<td><p>1. Dernière diagonale du triangle = charge des sinistres retenus (écart &lt; 0,5 %)</p>
<p>2. Facteurs de développement décroissants vers 1</p>
<p>3. IBNR positif sur chaque exercice</p>
<p>Statuts : feuille Controles (section 6). Les valeurs entre parenthèses sont dynamiques.</p></td>
</tr>
<tr class="even">
<td>Carte feuille</td>
<td>Feuille Historique ; méta « 5 exercices » ; colonnes exercice, exposition, nb_sin, charge_vue, cdf, charge_ult, rho, charge_2027 ; colonne surlignée charge_ult ; cellule montrée F2 (formule lue par FormulaLocal, exemple =D2*E2) ; lignes : les 5 exercices ; onglets Historique, Triangle.</td>
</tr>
<tr class="odd">
<td>Graphique</td>
<td>« Charge vue et ultime par exercice » ; légende Vue / Ultime ; deux séries (vue, ultime) par exercice en k€.</td>
</tr>
</tbody>
</table>

11.6 Étape 05 : Écrêtement

<table>
<colgroup>
<col style="width: 15%" />
<col style="width: 84%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>Zone</strong></th>
<th><strong>Contenu</strong></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td>En-tête</td>
<td>PRÉPARER LES DONNÉES · ÉTAPE 05 / 11 ; titre « Écrêtement »</td>
</tr>
<tr class="even">
<td>Introduction</td>
<td>Les sinistres revalorisés au-delà du seuil u sont plafonnés pour stabiliser le coût moyen par segment. L’excédent est isolé puis mutualisé à l’étape Sinistres graves.</td>
</tr>
<tr class="odd">
<td>KPI</td>
<td><p>1. Seuil u : seuil_ecretement en €. Exemple : « 15 000 € », sous-texte « modifiable par les puces ».</p>
<p>2. Sinistres graves : SUM(s_grave) ; part des retenus. Exemple : « 45 », sous-texte « 5,1 % des sinistres ».</p>
<p>3. Charge écrêtée : SUM(s_charge_ecr) en k€. Exemple : « 2 908 k€ », sous-texte « base du modèle de coût ».</p>
<p>4. Excédent : SUM(s_excedent) en k€ ; part de SUM(s_charge_rev). Exemple : « 717 k€ », sous-texte « 19,8 % de la charge revalorisée ».</p></td>
</tr>
<tr class="even">
<td>Formules</td>
<td>F05a, F05b, F05c</td>
</tr>
<tr class="odd">
<td>Contrôles</td>
<td><p>1. Charge écrêtée + excédent = charge revalorisée</p>
<p>2. Au moins 20 sinistres au-dessus de u (45)</p>
<p>3. Excédent sous 35 % de la charge (19,8 %)</p>
<p>Statuts : feuille Controles (section 6). Les valeurs entre parenthèses sont dynamiques.</p></td>
</tr>
<tr class="even">
<td>Carte feuille</td>
<td>Feuille Sinistres ; méta « 884 sinistres retenus » ; colonnes id_sinistre, garantie, exercice, charge_vue, charge_reval, grave, charge_ecr, excedent ; colonne surlignée charge_ecr ; cellule montrée N4 (formule lue par FormulaLocal, exemple =SI(K4=1;MIN(L4;seuil_ecretement);0)) ; lignes : les 4 premiers sinistres retenus et le premier grave s’il n’y figure pas, dans l’ordre de la feuille ; onglets Sinistres, Parametres.</td>
</tr>
<tr class="odd">
<td>Graphique</td>
<td>« Part de la charge au-dessus du seuil » ; note « selon le seuil testé » ; une ligne par seuil proposé ; vmin 0, vmax 50 % ; mise en avant : seuil actif.</td>
</tr>
<tr class="even">
<td>Puces d’en-tête</td>
<td>5 k€ · 10 k€ · 15 k€ · 25 k€ · 50 k€ (seuils 5 000 à 50 000 €)</td>
</tr>
</tbody>
</table>

11.7 Étape 06 : Analyse exploratoire

<table>
<colgroup>
<col style="width: 15%" />
<col style="width: 84%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>Zone</strong></th>
<th><strong>Contenu</strong></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td>En-tête</td>
<td>CONSTRUIRE LE TARIF · ÉTAPE 06 / 11 ; titre « Analyse exploratoire »</td>
</tr>
<tr class="even">
<td>Introduction</td>
<td>Fréquence et coût moyen écrêté par tranche de chaque variable candidate. La fréquence à CRM 1,00 retire l’effet du bonus-malus, appliqué ensuite en multiplicateur.</td>
</tr>
<tr class="odd">
<td>KPI</td>
<td><p>1. Fréquence brute : fréquence brute, 2 décimales ; « N / E ». Exemple : « 3,96 % », sous-texte « 884 / 22 326 ».</p>
<p>2. Fréquence à CRM 1,00 : fréquence à CRM 1,00, 2 décimales. Exemple : « 6,76 % », sous-texte « N / Σ E × CRM ».</p>
<p>3. Coût moyen écrêté : coût moyen écrêté, entier. Exemple : « 3 289 € », sous-texte « charge écrêtée / N ».</p>
<p>4. Prime pure écrêtée : prime pure écrêtée, 2 décimales. Exemple : « 130,23 € », sous-texte « par année-police ».</p></td>
</tr>
<tr class="even">
<td>Formules</td>
<td>F06a, F06b, F06c</td>
</tr>
<tr class="odd">
<td>Contrôles</td>
<td><p>1. Somme des expositions par tranche = exposition totale</p>
<p>2. Somme des sinistres par tranche = sinistres retenus</p>
<p>3. Charge écrêtée totale = valeur de l’étape 05</p>
<p>Statuts : feuille Controles (section 6). Les valeurs entre parenthèses sont dynamiques.</p></td>
</tr>
<tr class="even">
<td>Carte feuille</td>
<td>Feuille Exploratoire ; méta « variable : âge » ; colonnes tranche, exposition, e_crm, nb_sin, frequence, freq_crm, cout_moyen ; colonne surlignée freq_crm ; cellule montrée J2 (formule lue par FormulaLocal, exemple =G2/F2) ; lignes : les 5 premières tranches de la variable choisie ; onglets Exploratoire, Contrats.</td>
</tr>
<tr class="odd">
<td>Graphique</td>
<td>« Fréquence par tranche d’âge » ; légende Brute / À CRM 1,00 ; deux séries (brute, à CRM 1,00) par tranche ; unités dans les libellés (« ans », « CV », « Zone A »).</td>
</tr>
<tr class="even">
<td>Puces d’en-tête</td>
<td>Âge · Zone · Puissance · Usage · Permis · Véhicule · Couleur</td>
</tr>
</tbody>
</table>

11.8 Étape 07 : Classes

<table>
<colgroup>
<col style="width: 15%" />
<col style="width: 84%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>Zone</strong></th>
<th><strong>Contenu</strong></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td>En-tête</td>
<td>CONSTRUIRE LE TARIF · ÉTAPE 07 / 11 ; titre « Classes »</td>
</tr>
<tr class="even">
<td>Introduction</td>
<td>Regroupement des tranches voisines en classes homogènes et assez exposées. Deux classes voisines fusionnent tant que leurs fréquences à CRM 1,00 ne diffèrent pas significativement.</td>
</tr>
<tr class="odd">
<td>KPI</td>
<td><p>1. Exposition min. : exposition_min. Exemple : « 500 », sous-texte « années-police par classe ».</p>
<p>2. Classes d’âge : nombre de classes d’âge ; « depuis n tranches ». Exemple : « 5 », sous-texte « depuis 8 tranches ».</p>
<p>3. Classes de puissance : nombre de classes de puissance. Exemple : « 3 », sous-texte « depuis 5 tranches ».</p>
<p>4. Seuil de fusion : z_fusion, 3 décimales. Exemple : « 1,645 », sous-texte « |z|, niveau 10 % bilatéral ».</p></td>
</tr>
<tr class="even">
<td>Formules</td>
<td>F07a, F07b, F07c</td>
</tr>
<tr class="odd">
<td>Contrôles</td>
<td><p>1. Chaque classe dépasse 500 années-police</p>
<p>2. Classes voisines significativement différentes (|z| ≥ 1,645)</p>
<p>3. Classe de référence = la plus exposée (30–49 ans)</p>
<p>Statuts : feuille Controles (section 6). Les valeurs entre parenthèses sont dynamiques.</p></td>
</tr>
<tr class="even">
<td>Carte feuille</td>
<td>Feuille Classes ; méta « variable : âge » ; colonnes classe, tranches, exposition, nb_sin, freq_crm, relativite, z_suivante ; colonne surlignée relativite ; cellule montrée J2 (formule lue par FormulaLocal, exemple =I2/$I$4) ; lignes : les classes de la variable choisie (5 au plus) ; onglets Classes, Bornes.</td>
</tr>
<tr class="odd">
<td>Graphique</td>
<td>« Relativité par classe d’âge » ; note « base 30–49 ans = 1,00 » ; une ligne par classe, relativité « ×1,57 » ; vmin 0 ; mise en avant : relativité ≥ 1,20.</td>
</tr>
<tr class="even">
<td>Puces d’en-tête</td>
<td>Âge · Puissance · Permis · Véhicule</td>
</tr>
</tbody>
</table>

11.9 Étape 08 : Sélection des variables

<table>
<colgroup>
<col style="width: 15%" />
<col style="width: 84%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>Zone</strong></th>
<th><strong>Contenu</strong></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td>En-tête</td>
<td>CONSTRUIRE LE TARIF · ÉTAPE 08 / 11 ; titre « Sélection des variables »</td>
</tr>
<tr class="even">
<td>Introduction</td>
<td>Chaque variable est d’abord testée seule (χ², V de Cramér), puis confirmée dans le GLM par le test du rapport de vraisemblance. Une variable trop liée à une variable déjà retenue est écartée.</td>
</tr>
<tr class="odd">
<td>KPI</td>
<td><p>1. Candidates : 7. Exemple : « 7 », sous-texte « le sexe est exclu d’office ».</p>
<p>2. Retenues : nombre de retenues ; liste en clair (âge, zone, puissance, usage). Exemple : « 4 », sous-texte « âge, zone, puissance, usage ».</p>
<p>3. Seuil : seuil_p. Exemple : « 5 % », sous-texte « sur toutes les p-values ».</p>
<p>4. Liaison max. : V maximal entre retenues, 2 décimales ; paire concernée. Exemple : « 0,07 », sous-texte « V entre retenues · âge × puissance ».</p></td>
</tr>
<tr class="even">
<td>Formules</td>
<td>F08a, F08b, F08c</td>
</tr>
<tr class="odd">
<td>Contrôles</td>
<td><p>1. Effectif attendu ≥ 5 dans chaque classe</p>
<p>2. Aucune paire de variables retenues avec V ≥ 0,5</p>
<p>3. Sexe exclu d’office (arrêt Test-Achats, 2011)</p>
<p>Statuts : feuille Controles (section 6). Les valeurs entre parenthèses sont dynamiques.</p></td>
</tr>
<tr class="even">
<td>Carte feuille</td>
<td>Feuille Selection ; méta « 7 variables candidates » ; colonnes variable, chi2, ddl, p_value, v_cramer, delta_d, decision ; colonne surlignée p_value ; cellule montrée D2 (formule lue par FormulaLocal, exemple =LOI.KHIDEUX.DROITE(B2;C2)) ; lignes : les lignes 2 à 6 ; onglets Selection, Associations.</td>
</tr>
<tr class="odd">
<td>Graphique</td>
<td>« V de Cramér » ; note « liaison avec la fréquence à CRM 1,00 » ; V des 7 candidates triés par ordre décroissant ; mise en avant : retenues.</td>
</tr>
</tbody>
</table>

11.10 Étape 09 : Modèles GLM

<table>
<colgroup>
<col style="width: 15%" />
<col style="width: 84%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>Zone</strong></th>
<th><strong>Contenu</strong></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td>En-tête</td>
<td>CONSTRUIRE LE TARIF · ÉTAPE 09 / 11 ; titre « Modèles GLM »</td>
</tr>
<tr class="even">
<td>Introduction</td>
<td>Deux GLM multiplicatifs ajustés par IRLS sur les cellules tarifaires : Poisson pour la fréquence, avec exposition et CRM en offset, Gamma pour le coût moyen écrêté.</td>
</tr>
<tr class="odd">
<td>KPI</td>
<td><p>1. Fréquence de base : EXP(glmf_b0), 2 décimales. Exemple : « 5,27 % », sous-texte « CRM 1,00 · classes de référence ».</p>
<p>2. Coût de base écrêté : EXP(glmc_g0), entier. Exemple : « 3 442 € », sous-texte « classes de référence ».</p>
<p>3. Déviance expliquée : déviance expliquée au niveau des lignes (puce Fréquence) ou des sinistres (puce Coût moyen), 1 décimale. Exemple : « 2,5 % », sous-texte « fréquence, au niveau des lignes ».</p>
<p>4. Paramètres : nombre de paramètres. Exemple : « 12 », sous-texte « par modèle ».</p></td>
</tr>
<tr class="even">
<td>Formules</td>
<td>F09a, F09b, F09c</td>
</tr>
<tr class="odd">
<td>Contrôles</td>
<td><p>1. Sinistres prédits = sinistres observés (884)</p>
<p>2. Convergence IRLS atteinte (5 et 7 itérations)</p>
<p>3. Observé / prédit entre 0,85 et 1,15 par classe de CRM</p>
<p>Statuts : feuille Controles (section 6). Les valeurs entre parenthèses sont dynamiques.</p></td>
</tr>
<tr class="even">
<td>Carte feuille</td>
<td>Feuille GLM_Frequence ; méta « IRLS · 172 cellules » ; colonnes parametre, coefficient, relativite, erreur_std, z, p_value ; colonne surlignée relativite ; cellule montrée D3 (formule lue par FormulaLocal, exemple =EXP(C3)) ; lignes : les 5 premiers paramètres du modèle choisi ; onglets GLM_Frequence, GLM_Cout, Cellules.</td>
</tr>
<tr class="odd">
<td>Graphique</td>
<td>« Fréquence observée et prédite par quintile » ; légende Observée / Prédite ; deux séries (observée, prédite) par quintile, en % (fréquence) ou en € (coût).</td>
</tr>
<tr class="even">
<td>Puces d’en-tête</td>
<td>Fréquence · Coût moyen</td>
</tr>
</tbody>
</table>

11.11 Étape 10 : Sinistres graves

<table>
<colgroup>
<col style="width: 15%" />
<col style="width: 84%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>Zone</strong></th>
<th><strong>Contenu</strong></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td>En-tête</td>
<td>CONSTRUIRE LE TARIF · ÉTAPE 10 / 11 ; titre « Sinistres graves »</td>
</tr>
<tr class="even">
<td>Introduction</td>
<td>L’excédent au-delà du seuil suit une loi de Pareto estimée sur les cinq exercices. Il est mutualisé sur tout le portefeuille par un coefficient appliqué au coût écrêté.</td>
</tr>
<tr class="odd">
<td>KPI</td>
<td><p>1. Sinistres &gt; u : n_u ; « sur N retenus ». Exemple : « 45 », sous-texte « sur 884 retenus ».</p>
<p>2. α̂ Pareto : alpha, 3 décimales ; IC à 2 décimales. Exemple : « 1,773 », sous-texte « IC 95 % : 1,26 à 2,29 ».</p>
<p>3. Excédent moyen : e_u, entier. Exemple : « 19 401 € », sous-texte « u / (α̂ − 1) ».</p>
<p>4. Coefficient κ : kappa, 3 décimales ; « empirique : kappa_emp ». Exemple : « 1,300 », sous-texte « empirique : 1,246 ».</p></td>
</tr>
<tr class="even">
<td>Formules</td>
<td>F10a, F10b, F10c</td>
</tr>
<tr class="odd">
<td>Contrôles</td>
<td><p>1. Borne basse de l’IC de α̂ au-dessus de 1 (espérance finie)</p>
<p>2. κ Pareto à moins de 15 % du κ empirique (+4,3 %)</p>
<p>3. Survie observée proche de la Pareto (écart &lt; 0,10)</p>
<p>Statuts : feuille Controles (section 6). Les valeurs entre parenthèses sont dynamiques.</p></td>
</tr>
<tr class="even">
<td>Carte feuille</td>
<td>Feuille Graves ; méta « 45 sinistres &gt; u » ; colonnes id_sinistre, garantie, exercice, charge_reval, ln_x_u, excedent ; colonne surlignée ln_x_u ; cellule montrée E2 (formule lue par FormulaLocal, exemple =LN(D2/seuil_ecretement)) ; lignes : les 5 plus gros sinistres graves ; onglets Graves, Pareto.</td>
</tr>
<tr class="odd">
<td>Graphique</td>
<td>« Survie au-delà de x » ; légende Observée / Pareto ; deux séries (observée, Pareto) pour 1,5u, 2u, 3u, 5u, 10u, en %.</td>
</tr>
</tbody>
</table>

11.12 Étape 11 : Résultats et impact

<table>
<colgroup>
<col style="width: 15%" />
<col style="width: 84%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>Zone</strong></th>
<th><strong>Contenu</strong></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td>En-tête</td>
<td>CONSTRUIRE LE TARIF · ÉTAPE 11 / 11 ; titre « Résultats et impact »</td>
</tr>
<tr class="even">
<td>Introduction</td>
<td>Assemblage du tarif : base, relativités, coefficient graves, calage sur la charge cible, puis chargements. Impact mesuré sur les 4 630 polices renouvelées au 01/01/2026.</td>
</tr>
<tr class="odd">
<td>KPI</td>
<td><p>1. Prime pure moyenne : pp_moy, 2 décimales. Exemple : « 172,53 € », sous-texte « par année-police · niveau 2027 ».</p>
<p>2. Évolution moyenne : evol_moy, signé, 1 décimale. Exemple : « +9,0 % », sous-texte « vs tarif en vigueur, avant plafond ».</p>
<p>3. Équilibre plafonné : equilibre, 1 décimale. Exemple : « 95,3 % », sous-texte « de la prime technique ».</p>
<p>4. Prime TTC moyenne : ttc_moy, 2 décimales ; « actuelle : ttc_moy_act ». Exemple : « 330,54 € », sous-texte « actuelle : 303,25 € ».</p></td>
</tr>
<tr class="even">
<td>Formules</td>
<td>F11a, F11b, F11c</td>
</tr>
<tr class="odd">
<td>Contrôles</td>
<td><p>1. Σ exposition × prime pure = charge cible (calage θ)</p>
<p>2. Aucune évolution au-delà de ±10 % après plafonnement</p>
<p>3. Équilibre après plafonnement ≥ 95 % (95,3 %)</p>
<p>Statuts : feuille Controles (section 6). Les valeurs entre parenthèses sont dynamiques.</p></td>
</tr>
<tr class="even">
<td>Carte feuille</td>
<td>Feuille Tarif ; méta « θ = 1,0176 · κ = 1,300 » ; colonnes variable, classe, rel_frequence, rel_cout, rel_prime_pure, evolution ; colonne surlignée rel_prime_pure ; cellule montrée E2 (formule lue par FormulaLocal, exemple =C2*D2) ; lignes : les 5 premières lignes de relativités ; onglets Tarif, Impact, Calculateur.</td>
</tr>
<tr class="odd">
<td>Graphique</td>
<td>« Évolution de prime des polices renouvelées » ; note « avant plafonnement · % des polices » ; part des polices par tranche d’évolution ; vmin 0 ; mise en avant : « &gt; +10 % ».</td>
</tr>
</tbody>
</table>

11.13 Calculateur (P12)

<table>
<colgroup>
<col style="width: 15%" />
<col style="width: 84%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>Zone</strong></th>
<th><strong>Contenu</strong></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td>En-tête</td>
<td>Eyebrow « TARIF RC AUTO 2026 » ; titre « Calculateur de prime » ; intro « Le tarif issu de l’étude, assemblé : relativités GLM, coefficient graves, calage et chargements. Modifiez le profil et les hypothèses, chaque étape du calcul se met à jour. »</td>
</tr>
<tr class="even">
<td>Profil</td>
<td>Âge (« 23 ans », légende « Classe 18–24 ans ») ; zone A Rural, B Périurb., C Urbain, D Dense ; puissance (« 6 CV », « Classe 5–8 CV ») ; usage Privé, Trajet, Professionnel ; CRM (« 0,90 », aide « − : un an sans sinistre (× 0,95) · + : un sinistre responsable (× 1,25) »).</td>
</tr>
<tr class="odd">
<td>Chargements</td>
<td>Sécurité (sur prime pure), Frais de gestion, Frais d’acquisition, Marge, Taxes ; valeurs en %, 1 décimale.</td>
</tr>
<tr class="even">
<td>Prime TTC</td>
<td>Eyebrow « PRIME COMMERCIALE TTC » ; montant 2 décimales ; « soit x € par mois » ; pilule « +45,6 % vs tarif actuel » ; « vs prime moyenne du portefeuille (330,54 €) : +215,9 % » ; barre empilée et légende Prime pure, Sécurité, Frais, Marge, Taxes avec montants.</td>
</tr>
<tr class="odd">
<td>Mini-cartes</td>
<td>Fréquence « 11,99 % » (« 5,27 % × 2,53 × 0,90 ») ; Coût moyen « 4 412,04 € » (« 3 442 € × 0,97 × κθ ») ; Prime pure « 528,81 € » (« fréq. × coût ») ; Prime HT « 778,10 € » (« × 1,03 / (1 − 0,30) »).</td>
</tr>
<tr class="even">
<td>Formule appliquée</td>
<td><p>« PRIME PURE » : « PP = 5,27 % × 2,53 × 0,90 × 3 442 € × 0,97 × 1,300 × 1,018 = 528,81 € » (fréquence de base, rf, CRM, coût de base, rc, κ, θ).</p>
<p>« PRIME COMMERCIALE TTC » : « Π = 528,81 × (1 + 0,030) / (1 − 0,300) × (1 + 0,342) = 1 044,21 € ».</p></td>
</tr>
<tr class="odd">
<td>Carte Excel</td>
<td>Titre « Le même calcul dans Excel » ; texte « Onglet Calculateur : chaque montant ci-dessus est une formule de la feuille, lisible en mode administration. » ; bouton « Ouvrir l’onglet › ».</td>
</tr>
</tbody>
</table>

12\. Interactions et mise à jour

| **Action**                       | **État modifié**    | **Recalcul**                             | **Pages rafraîchies**                                             |
|----------------------------------|---------------------|------------------------------------------|-------------------------------------------------------------------|
| Puce d’année (P00)               | CALC!B4             | aucun                                    | P00 : KPI, mise en avant du graphique, segments, bandeau          |
| Onglet de segment (P00)          | CALC!B5             | aucun                                    | P00 : carte segments                                              |
| Puce de seuil (P05)              | seuil_ecretement    | formules, IRLS Gamma, liste Graves (6.0) | toutes (le seuil touche coût, κ, θ, tarif, segments, calculateur) |
| Puce de variable (P06, P07)      | CALC!B6, B7         | aucun                                    | carte feuille, méta, graphique de la page                         |
| Puce de modèle (P09)             | CALC!B8             | aucun                                    | KPI 3, carte feuille (GLM_Frequence ou GLM_Cout), graphique       |
| Boutons du calculateur           | feuille Calculateur | Worksheets("Calculateur").Calculate      | formes dynamiques de P12 (\< 0,3 s)                               |
| Réinitialiser (P12)              | feuille Calculateur | idem                                     | P12                                                               |
| RecalculerEtude (administration) | tout                | moteur complet                           | toutes                                                            |

12.1 Puces

Même règle que les filtres de l’Observatoire : nom pNN_puce\_\<groupe\>\_\<valeur\>, OnAction vers une procédure unique ClicPuce qui lit Application.Caller. Active : fond violet, texte blanc F_BOLD ; inactive : sans fond, texte encre_2 F_SEMI. Un clic sur la puce active ne fait rien.

12.2 Mise à jour sans reconstruction

Chaque page possède une procédure MajPageNN qui ne modifie que les formes dynamiques (textes de valeurs, largeurs de barres, couleurs de pastilles, contenu de la carte feuille, séries du graphique). Les formes statiques ne sont jamais recréées hors ConstruireApplication. Les pages sont déprotégées puis reprotégées autour de la mise à jour (pas de UserInterfaceOnly après réouverture, voir pièges).

12.3 Bulles d’aide

Reprendre le mécanisme de l’Observatoire : icône « i » cliquable, bulle blanche (largeur 250, marges 14, titre F_BOLD 9, texte F_REG 7,8 encre_2), flèche vers l’icône, fermeture automatique après 8 s, par Échap ou par un clic sur « Fermer ».

12.4 Consultation d’une feuille de travail

26. AfficherFeuille nom, cellule : déprotéger la structure, rendre la feuille visible, l’activer, sélectionner la cellule de la carte (exception R3), afficher barre de formule et en-têtes, quitter le plein écran partiel sans ruban.

27. Ajouter une forme flottante « ‹ Retour à la page » (pilule encre, texte blanc F_BOLD 9) en haut à droite de la zone visible, OnAction RetourPage ; mémoriser la feuille en CALC!B9.

28. Protéger la feuille (sélection des cellules autorisée, aucune modification).

29. RetourPage (ou Échap) : supprimer la forme, masquer la feuille, reprotéger la structure, rétablir l’interface application, AllerPage CALC!B2.

13\. Interface, protections et performances

- Reprendre de l’Observatoire, sans les modifier dans leur principe : AppliquerInterfaceApp, RestaurerInterfaceExcel, MemoriserInterface, AfficherRuban, raccourcis (DefinirRaccourcis), minuterie de bulle, AjusterZoom, événements de ThisWorkbook (ouverture, fermeture, activation, désactivation, redimensionnement, clic droit et double-clic bloqués en mode application).

- Protection : pages protégées (DrawingObjects, Contents), sélection interdite, ScrollArea du canevas ; feuilles de travail et de données masquées ; CALC très masquée ; structure du classeur protégée. Mot de passe en constante MDP = "primelab2026".

- Graphique du tableau de bord : ProtectFormatting, ProtectData, ProtectSelection (ProtectContents est en lecture seule).

- Performances cibles : construction complète \< 90 s ; changement de seuil \< 5 s ; clic de puce sans recalcul \< 0,5 s ; bouton du calculateur \< 0,3 s.

- Mode de calcul laissé en automatique après construction. Les formules à 25 074 lignes s’écrivent en une instruction par colonne.

- Message final de construction : « Application construite en x s. Recette : n contrôles sur n conformes. »

14\. Pièges connus

| **Sujet**            | **Piège et parade**                                                                                                                                                                                               |
|----------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Encodage             | Un .bas en UTF-8 donne des accents illisibles : Windows-1252 + CRLF obligatoires ; caractères hors Windows-1252 par ChrW.                                                                                         |
| Formula2             | Avec Formula, Excel ajoute @ devant FILTER, UNIQUE, LET, XLOOKUP sur plages : toujours Formula2.                                                                                                                  |
| Noms définis         | Un nom ne peut ressembler à une référence (AA1, R1C1) ; c et r seuls sont interdits. Préfixes c\_, s\_ valides. Portée classeur.                                                                                  |
| Colonnes entières    | Les SUMIFS sur colonnes entières ralentissent le recalcul : plages fixes nommées (R13).                                                                                                                           |
| DATEDIF              | Renvoie \#NOMBRE! si la date de début dépasse la date de fin ; les données respectent l’ordre, mais le contrôle de l’étape 01 doit rester vert.                                                                   |
| COUNTIF(plage,"")    | Compte les vides et les chaînes vides : voulu pour age_brut.                                                                                                                                                      |
| FILTER vide          | Renvoie \#CALC! : entourer de IFERROR quand le filtre peut être vide (seuil 50 000 €).                                                                                                                            |
| XLOOKUP approché     | Ordre des arguments : XLOOKUP(valeur, plage, retour, si_absent, mode) ; mode -1 = valeur exacte ou immédiatement inférieure.                                                                                      |
| Graphiques           | Shapes.AddChart2 ajoute une série tirée de la sélection : supprimer toutes les séries avant d’ajouter les siennes. Fixer MinimumScale et MaximumScale des deux axes. Couleur par point via Points(i).Format.Fill. |
| Angles des colonnes  | Excel ne sait pas arrondir les colonnes d’un graphique : angles droits acceptés.                                                                                                                                  |
| Rayon des formes     | Adjustments(1) est relatif au plus petit côté : rayon / Min(W, H).                                                                                                                                                |
| Texte des formes     | Utiliser TextFrame2 ; marges à 0 ; l’espacement des lettres se règle par Font.Spacing ; la mesure de largeur se fait avec AutoSize provisoire puis retour à msoAutoSizeNone.                                      |
| Polices à graisses   | Medium, SemiBold et ExtraBold sont des familles : Bold = True seulement avec la famille de base.                                                                                                                  |
| Glyphes absents      | ✓, ✗, ↺ et U+202F absents de Plus Jakarta Sans : Segoe UI Symbol et ChrW(160).                                                                                                                                    |
| Images SVG           | Shapes.AddPicture(fichier, msoFalse, msoTrue, L, T, W, H) avec W et H explicites en points ; en cas d’erreur, insérer le PNG correspondant. Les images sont incorporées, pas liées.                               |
| UserInterfaceOnly    | Non conservé à la fermeture : reprotéger à l’ouverture.                                                                                                                                                           |
| Application.OnTime   | Annuler la minuterie avant toute nouvelle bulle et à la fermeture.                                                                                                                                                |
| Tri                  | Trier 25 072 lignes : algorithme non récursif ou tri fusion, avec départage par numéro de ligne pour un résultat reproductible.                                                                                   |
| Inversion de matrice | Gauss-Jordan à pivot partiel, contrôle du pivot ; jamais MINVERSE sur feuille pour l’IRLS (précision et vitesse).                                                                                                 |
| Arrondis             | Round de VBA arrondit au pair : utiliser l’arrondi arithmétique de R8 pour l’affichage ; ne jamais arrondir les valeurs de calcul.                                                                                |
| Exposition nulle     | Deux lignes ont une exposition nulle : les exclure des cellules du GLM et du tri des quintiles (division par zéro).                                                                                               |
| Feuilles masquées    | On ne peut pas activer une feuille masquée : la rendre visible avant, la masquer après.                                                                                                                           |
| Zoom                 | Construire les formes au zoom 100 pour que les mesures de texte soient justes.                                                                                                                                    |
| Format               | Dépend des paramètres régionaux (Windows français : U+202F comme séparateur) : ne pas l’utiliser pour l’affichage (R8).                                                                                           |

15\. Recette chiffrée

Valeurs produites par une implémentation indépendante des algorithmes de la section 6 sur les données fournies (fichier recette.json). modRecette contient ces valeurs attendues, lit les valeurs obtenues dans le classeur et écrit la feuille Recette : étape, indicateur, attendu, obtenu, écart, tolérance, statut (vert ou rose). La procédure Recette imprime aussi un résumé dans la fenêtre Exécution.

> Tolérances : « exact » pour les comptages ; 0,01 € pour les sommes de montants ; écart relatif indiqué sinon. Le nombre d’itérations IRLS peut différer d’une unité selon l’ordre des additions.

| **Étape** | **Indicateur**                                           | **Valeur attendue**                                                                                                                                                                                               | **Tolérance** | **Où**                    |
|-----------|----------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------|---------------------------|
| 01        | Lignes de la feuille Contrats                            | 25 074                                                                                                                                                                                                            | exact         | Contrats                  |
| 01        | Polices distinctes                                       | 7 281                                                                                                                                                                                                             | exact         | Contrats                  |
| 01        | Sinistres bruts                                          | 920                                                                                                                                                                                                               | exact         | Sinistres                 |
| 01        | Exposition totale (années-police)                        | 22 326,2556                                                                                                                                                                                                       | 1e-6          | somme Contrats!P          |
| 01        | Exposition 2021                                          | 4 336,8110                                                                                                                                                                                                        | 1e-6          | Historique!B              |
| 01        | Exposition 2022                                          | 4 409,1315                                                                                                                                                                                                        | 1e-6          | Historique!B              |
| 01        | Exposition 2023                                          | 4 469,4301                                                                                                                                                                                                        | 1e-6          | Historique!B              |
| 01        | Exposition 2024                                          | 4 508,6967                                                                                                                                                                                                        | 1e-6          | Historique!B              |
| 01        | Exposition 2025                                          | 4 602,1863                                                                                                                                                                                                        | 1e-6          | Historique!B              |
| 01        | Lignes à exposition nulle                                | 2                                                                                                                                                                                                                 | exact         | Contrats!P                |
| 02        | Sinistres « Doublon »                                    | 22                                                                                                                                                                                                                | exact         | Sinistres!J               |
| 02        | Sinistres « Hors période »                               | 5                                                                                                                                                                                                                 | exact         | Sinistres!J               |
| 02        | Sinistres « Orphelin »                                   | 3                                                                                                                                                                                                                 | exact         | Sinistres!J               |
| 02        | Sinistres « Montant nul »                                | 6                                                                                                                                                                                                                 | exact         | Sinistres!J               |
| 02        | Sinistres « OK »                                         | 884                                                                                                                                                                                                               | exact         | Sinistres!J               |
| 02        | Lignes à âge imputé (14 polices)                         | 56                                                                                                                                                                                                                | exact         | Contrats!Q vide           |
| 02        | Médianes d'âge par zone A, B, C, D                       | 48, 48, 47, 47                                                                                                                                                                                                    | exact         | Qualite                   |
| 02        | CRM corrigés                                             | 7                                                                                                                                                                                                                 | exact         | Contrats!U ≠ M            |
| 02        | Complétude de date_naissance                             | 99,7767 %                                                                                                                                                                                                         | 1e-6          | Qualite                   |
| 03        | Somme des nb_sin                                         | 884                                                                                                                                                                                                               | exact         | Contrats!W                |
| 03        | Lignes sinistrées                                        | 848                                                                                                                                                                                                               | exact         | Contrats!W \> 0           |
| 03        | Lignes à exposition non nulle                            | 25 072                                                                                                                                                                                                            | exact         | Contrats!P \> 0           |
| 03        | Charge vue rattachée (€)                                 | 3 067 850,61                                                                                                                                                                                                      | 0,01          | Contrats!X                |
| 03        | Lignes à 1, 2, 3+ sinistres                              | 814, 32, 2                                                                                                                                                                                                        | exact         | Contrats!W                |
| 03        | Attendu Poisson à 1, 2, 3+                               | 848,65, 17,26, 0,27                                                                                                                                                                                               | 0,01          | voir 6.3                  |
| 04        | Facteurs f1 à f9                                         | 1,10514 ; 1,03526 ; 1,01637 ; 1,00827 ; 1,00403 ; 1,00204 ; 1,00102 ; 1,00073 ; 1,00030                                                                                                                           | 1e-5          | Triangle                  |
| 04        | Exercice 2021 : vue, CDF, ultime, ρ                      | 477 429,63 ; 1,00814 ; 481 316,25 ; 1,30780                                                                                                                                                                       | 1e-5 relatif  | Historique                |
| 04        | Exercice 2022 : vue, CDF, ultime, ρ                      | 634 212,28 ; 1,01647 ; 644 660,87 ; 1,24552                                                                                                                                                                       | 1e-5 relatif  | Historique                |
| 04        | Exercice 2023 : vue, CDF, ultime, ρ                      | 666 170,01 ; 1,03311 ; 688 228,31 ; 1,18621                                                                                                                                                                       | 1e-5 relatif  | Historique                |
| 04        | Exercice 2024 : vue, CDF, ultime, ρ                      | 590 728,70 ; 1,06954 ; 631 805,41 ; 1,12973                                                                                                                                                                       | 1e-5 relatif  | Historique                |
| 04        | Exercice 2025 : vue, CDF, ultime, ρ                      | 699 309,99 ; 1,18199 ; 826 576,30 ; 1,07593                                                                                                                                                                       | 1e-5 relatif  | Historique                |
| 04        | IBNR total 2021-2025 (€)                                 | 204 736,53                                                                                                                                                                                                        | 1e-5 relatif  | Historique                |
| 04        | Charge cible C\* (€)                                     | 3 851 895,65                                                                                                                                                                                                      | 1e-5 relatif  | charge_cible              |
| 05        | Sinistres au-dessus de u = 15 000                        | 45                                                                                                                                                                                                                | exact         | Sinistres!M               |
| 05        | Charge revalorisée (€)                                   | 3 624 297,88                                                                                                                                                                                                      | 0,01          | Sinistres!L               |
| 05        | Charge écrêtée (€)                                       | 2 907 613,96                                                                                                                                                                                                      | 0,01          | Sinistres!N               |
| 05        | Excédent (€)                                             | 716 683,92                                                                                                                                                                                                        | 0,01          | Sinistres!O               |
| 05        | Part de l'excédent pour 5, 10, 15, 25, 50 k€             | 41,98 % ; 27,86 % ; 19,77 % ; 12,20 % ; 4,52 %                                                                                                                                                                    | 1e-4          | Graves (table des seuils) |
| 06        | Fréquence brute ; à CRM 1,00                             | 3,9595 % ; 6,7610 %                                                                                                                                                                                               | 1e-6          | Exploratoire              |
| 06        | Coût moyen écrêté ; prime pure écrêtée                   | 3 289,16 ; 130,2329                                                                                                                                                                                               | 1e-4          | Exploratoire              |
| 06        | Tranche d'âge 18-20 : E ; E\* ; N                        | 301,847 ; 303,559 ; 42                                                                                                                                                                                            | 1e-3          | Exploratoire              |
| 06        | Tranche d'âge 21-24 : E ; E\* ; N                        | 997,202 ; 922,636 ; 86                                                                                                                                                                                            | 1e-3          | Exploratoire              |
| 06        | Tranche d'âge 25-29 : E ; E\* ; N                        | 1 916,418 ; 1 557,541 ; 130                                                                                                                                                                                       | 1e-3          | Exploratoire              |
| 06        | Tranche d'âge 30-39 : E ; E\* ; N                        | 4 337,243 ; 2 646,753 ; 175                                                                                                                                                                                       | 1e-3          | Exploratoire              |
| 06        | Tranche d'âge 40-49 : E ; E\* ; N                        | 4 410,934 ; 2 315,997 ; 155                                                                                                                                                                                       | 1e-3          | Exploratoire              |
| 06        | Tranche d'âge 50-64 : E ; E\* ; N                        | 5 428,256 ; 2 782,335 ; 139                                                                                                                                                                                       | 1e-3          | Exploratoire              |
| 06        | Tranche d'âge 65-74 : E ; E\* ; N                        | 2 935,671 ; 1 513,424 ; 75                                                                                                                                                                                        | 1e-3          | Exploratoire              |
| 06        | Tranche d'âge 75+ : E ; E\* ; N                          | 1 998,685 ; 1 032,792 ; 82                                                                                                                                                                                        | 1e-3          | Exploratoire              |
| 07        | Classes de âge                                           | 18-24 (N=128, rel 1,5699) \| 25-29 (N=130, rel 1,2552) \| 30-49 (N=330, rel 1,0000) \| 50-74 (N=214, rel 0,7492) \| 75+ (N=82, rel 1,1940)                                                                        | exact / 1e-4  | Classes                   |
| 07        | Classes de puissance_cv                                  | ≤4 (N=122, rel 0,7339) \| 5-8 (N=581, rel 1,0000) \| 9+ (N=181, rel 1,3925)                                                                                                                                       | exact / 1e-4  | Classes                   |
| 07        | Classes de anc_permis                                    | 0-2 (N=86, rel 2,2541) \| 3-20 (N=374, rel 1,2485) \| 21+ (N=424, rel 1,0000)                                                                                                                                     | exact / 1e-4  | Classes                   |
| 07        | Classes de anc_vehicule                                  | 0-9 (N=454, rel 1,0000) \| 10-14 (N=195, rel 0,8603) \| 15+ (N=235, rel 1,0223)                                                                                                                                   | exact / 1e-4  | Classes                   |
| 07        | Classes de zone                                          | A (N=127, rel 0,8216) \| B (N=263, rel 1,0000) \| C (N=310, rel 1,3304) \| D (N=184, rel 1,3711)                                                                                                                  | exact / 1e-4  | Classes                   |
| 07        | Classes de usage                                         | Privé (N=502, rel 1,0000) \| Trajet (N=294, rel 1,0733) \| Professionnel (N=88, rel 1,6528)                                                                                                                       | exact / 1e-4  | Classes                   |
| 07        | Classes de couleur                                       | Blanc (N=216, rel 0,9722) \| Gris (N=230, rel 1,0000) \| Noir (N=155, rel 0,9178) \| Bleu (N=102, rel 0,9286) \| Rouge (N=91, rel 1,0355) \| Vert (N=90, rel 1,1952)                                              | exact / 1e-4  | Classes                   |
| 08        | âge : χ² ; ddl ; V ; ΔD                                  | 52,652 ; 4 ; 0,04856 ; 66,457                                                                                                                                                                                     | 1e-3          | Selection                 |
| 08        | zone : χ² ; ddl ; V ; ΔD                                 | 32,223 ; 3 ; 0,03799 ; 33,064                                                                                                                                                                                     | 1e-3          | Selection                 |
| 08        | puissance_cv : χ² ; ddl ; V ; ΔD                         | 31,493 ; 2 ; 0,03756 ; 40,431                                                                                                                                                                                     | 1e-3          | Selection                 |
| 08        | usage : χ² ; ddl ; V ; ΔD                                | 19,262 ; 2 ; 0,02937 ; 22,533                                                                                                                                                                                     | 1e-3          | Selection                 |
| 08        | anc_permis : χ² ; ddl ; V ; ΔD                           | 50,728 ; 2 ; 0,04767 ; -                                                                                                                                                                                          | 1e-3          | Selection                 |
| 08        | anc_vehicule : χ² ; ddl ; V ; ΔD                         | 3,874 ; 2 ; 0,01317 ; -                                                                                                                                                                                           | 1e-3          | Selection                 |
| 08        | couleur : χ² ; ddl ; V ; ΔD                              | 4,792 ; 5 ; 0,01465 ; -                                                                                                                                                                                           | 1e-3          | Selection                 |
| 08        | Décisions                                                | anc_vehicule : Écartée (non significative) \| couleur : Écartée (non significative) \| anc_permis : Écartée (redondante avec age) \| âge : Retenue \| zone : Retenue \| puissance_cv : Retenue \| usage : Retenue | exact         | Selection!J               |
| 08        | V maximal entre retenues                                 | 0,07309 (âge × puissance)                                                                                                                                                                                         | 1e-4          | Associations              |
| 09        | Fréquence : Intercept                                    | β = -2,943525 ; e.s. 0,085738                                                                                                                                                                                     | 1e-5          | GLM_Frequence             |
| 09        | Fréquence : age 18-24                                    | β = 0,550068 ; e.s. 0,105157                                                                                                                                                                                      | 1e-5          | GLM_Frequence             |
| 09        | Fréquence : age 25-29                                    | β = 0,308882 ; e.s. 0,104054                                                                                                                                                                                      | 1e-5          | GLM_Frequence             |
| 09        | Fréquence : age 50-74                                    | β = -0,299084 ; e.s. 0,087784                                                                                                                                                                                     | 1e-5          | GLM_Frequence             |
| 09        | Fréquence : age 75+                                      | β = 0,233971 ; e.s. 0,123805                                                                                                                                                                                      | 1e-5          | GLM_Frequence             |
| 09        | Fréquence : zone A                                       | β = -0,189507 ; e.s. 0,108114                                                                                                                                                                                     | 1e-5          | GLM_Frequence             |
| 09        | Fréquence : zone C                                       | β = 0,291493 ; e.s. 0,083883                                                                                                                                                                                      | 1e-5          | GLM_Frequence             |
| 09        | Fréquence : zone D                                       | β = 0,321890 ; e.s. 0,096143                                                                                                                                                                                      | 1e-5          | GLM_Frequence             |
| 09        | Fréquence : puissance_cv ≤4                              | β = -0,359516 ; e.s. 0,099858                                                                                                                                                                                     | 1e-5          | GLM_Frequence             |
| 09        | Fréquence : puissance_cv 9+                              | β = 0,382528 ; e.s. 0,085704                                                                                                                                                                                      | 1e-5          | GLM_Frequence             |
| 09        | Fréquence : usage Trajet                                 | β = 0,085853 ; e.s. 0,073480                                                                                                                                                                                      | 1e-5          | GLM_Frequence             |
| 09        | Fréquence : usage Professionnel                          | β = 0,590788 ; e.s. 0,116424                                                                                                                                                                                      | 1e-5          | GLM_Frequence             |
| 09        | Coût : Intercept                                         | γ = 8,143930 ; e.s. 0,095961                                                                                                                                                                                      | 1e-5          | GLM_Cout                  |
| 09        | Coût : age 18-24                                         | γ = 0,077182 ; e.s. 0,118706                                                                                                                                                                                      | 1e-5          | GLM_Cout                  |
| 09        | Coût : age 25-29                                         | γ = 0,084356 ; e.s. 0,116966                                                                                                                                                                                      | 1e-5          | GLM_Cout                  |
| 09        | Coût : age 50-74                                         | γ = -0,035929 ; e.s. 0,098902                                                                                                                                                                                     | 1e-5          | GLM_Cout                  |
| 09        | Coût : age 75+                                           | γ = -0,443206 ; e.s. 0,140048                                                                                                                                                                                     | 1e-5          | GLM_Cout                  |
| 09        | Coût : zone A                                            | γ = -0,128530 ; e.s. 0,121775                                                                                                                                                                                     | 1e-5          | GLM_Cout                  |
| 09        | Coût : zone C                                            | γ = -0,141167 ; e.s. 0,094714                                                                                                                                                                                     | 1e-5          | GLM_Cout                  |
| 09        | Coût : zone D                                            | γ = 0,113052 ; e.s. 0,108079                                                                                                                                                                                      | 1e-5          | GLM_Cout                  |
| 09        | Coût : puissance_cv ≤4                                   | γ = -0,125051 ; e.s. 0,112758                                                                                                                                                                                     | 1e-5          | GLM_Cout                  |
| 09        | Coût : puissance_cv 9+                                   | γ = 0,069872 ; e.s. 0,096174                                                                                                                                                                                      | 1e-5          | GLM_Cout                  |
| 09        | Coût : usage Trajet                                      | γ = 0,032145 ; e.s. 0,083132                                                                                                                                                                                      | 1e-5          | GLM_Cout                  |
| 09        | Coût : usage Professionnel                               | γ = 0,032573 ; e.s. 0,131636                                                                                                                                                                                      | 1e-5          | GLM_Cout                  |
| 09        | Déviance fréquence : cellules ; lignes ; nulle (lignes)  | 164,6026 ; 5 621,9225 ; 5 768,5167                                                                                                                                                                                | 1e-3          | GLM_Frequence             |
| 09        | Déviance coût : cellules ; sinistres ; nulle (sinistres) | 154,3062 ; 877,4683 ; 902,4713                                                                                                                                                                                    | 1e-3          | GLM_Cout                  |
| 09        | Dispersion φ (coût)                                      | 1,26237                                                                                                                                                                                                           | 1e-4          | GLM_Cout                  |
| 09        | Cellules fréquence ; coût                                | 172 ; 139                                                                                                                                                                                                         | exact         | Cellules                  |
| 09        | Itérations IRLS fréquence ; coût                         | 5 ; 7                                                                                                                                                                                                             | ± 1           | journal IRLS              |
| 09        | Lift fréquence (obs. / préd., %)                         | 1,859 / 1,805 \| 2,821 / 2,562 \| 2,956 / 3,204 \| 4,188 / 4,275 \| 7,972 / 7,951                                                                                                                                 | 1e-3          | GLM_Frequence             |
| 09        | Lift coût (obs. / préd., €)                              | 2 369,5 / 2 504,7 \| 3 131,2 / 3 061,5 \| 3 326,7 / 3 306,0 \| 3 771,6 / 3 569,3 \| 3 847,1 / 4 024,7                                                                                                             | 0,1           | GLM_Cout                  |
| 09        | Observé / prédit par classe de CRM                       | 0,50 : 1,0003 \| 0,51-0,79 : 0,9503 \| 0,80-0,99 : 1,0328 \| ≥ 1,00 : 1,0694                                                                                                                                      | 1e-4          | GLM_Frequence             |
| 10        | n_u ; α̂ ; IC 95 %                                        | 45 ; 1,77317 ; \[1,2551 ; 2,2912\]                                                                                                                                                                                | 1e-5          | Graves                    |
| 10        | e(u) Pareto ; e(u) empirique (€)                         | 19 400,75 ; 15 926,31                                                                                                                                                                                             | 0,01          | Graves                    |
| 10        | κ ; κ empirique ; écart                                  | 1,300258 ; 1,246485 ; 4,31 %                                                                                                                                                                                      | 1e-6          | kappa                     |
| 10        | Survie observée / Pareto (1,5u ; 2u ; 3u ; 5u ; 10u)     | 0,4444 / 0,4873 \| 0,3111 / 0,2926 \| 0,1778 / 0,1426 \| 0,0444 / 0,0576 \| 0,0000 / 0,0169                                                                                                                       | 1e-4          | Graves                    |
| 11        | B0 ; θ ; B (€)                                           | 235,7960 ; 1,017594 ; 239,9446                                                                                                                                                                                    | 1e-5 relatif  | Tarif                     |
| 11        | Prime pure moyenne (€ par année-police)                  | 172,5276                                                                                                                                                                                                          | 1e-4          | Tarif                     |
| 11        | Polices renouvelées                                      | 4 630                                                                                                                                                                                                             | exact         | Impact                    |
| 11        | Évolution moyenne ; équilibre plafonné                   | 8,999 % ; 95,298 %                                                                                                                                                                                                | 1e-5          | Impact                    |
| 11        | Prime TTC moyenne nouvelle ; actuelle (€)                | 330,54 ; 303,25                                                                                                                                                                                                   | 0,01          | Impact                    |
| 11        | Dislocation (% des polices)                              | \< -10 % : 13,95 % \| -10 à -5 % : 14,19 % \| -5 à 0 % : 15,79 % \| 0 à +5 % : 20,52 % \| +5 à +10 % : 10,80 % \| \> +10 % : 24,75 %                                                                              | 1e-4          | Impact                    |
| 11        | âge 18-24 : rel. F ; C ; PP ; évol.                      | 1,7334 ; 1,0802 ; 1,8725 ; 25,55 %                                                                                                                                                                                | 1e-4          | Tarif                     |
| 11        | âge 25-29 : rel. F ; C ; PP ; évol.                      | 1,3619 ; 1,0880 ; 1,4818 ; 17,05 %                                                                                                                                                                                | 1e-4          | Tarif                     |
| 11        | âge 30-49 : rel. F ; C ; PP ; évol.                      | 1,0000 ; 1,0000 ; 1,0000 ; 9,46 %                                                                                                                                                                                 | 1e-4          | Tarif                     |
| 11        | âge 50-74 : rel. F ; C ; PP ; évol.                      | 0,7415 ; 0,9647 ; 0,7153 ; 0,65 %                                                                                                                                                                                 | 1e-4          | Tarif                     |
| 11        | âge 75+ : rel. F ; C ; PP ; évol.                        | 1,2636 ; 0,6420 ; 0,8112 ; -7,62 %                                                                                                                                                                                | 1e-4          | Tarif                     |
| 11        | zone A : rel. F ; C ; PP ; évol.                         | 0,8274 ; 0,8794 ; 0,7276 ; 1,15 %                                                                                                                                                                                 | 1e-4          | Tarif                     |
| 11        | zone B : rel. F ; C ; PP ; évol.                         | 1,0000 ; 1,0000 ; 1,0000 ; 5,91 %                                                                                                                                                                                 | 1e-4          | Tarif                     |
| 11        | zone C : rel. F ; C ; PP ; évol.                         | 1,3384 ; 0,8683 ; 1,1622 ; 7,77 %                                                                                                                                                                                 | 1e-4          | Tarif                     |
| 11        | zone D : rel. F ; C ; PP ; évol.                         | 1,3797 ; 1,1197 ; 1,5449 ; 20,47 %                                                                                                                                                                                | 1e-4          | Tarif                     |
| 11        | puissance_cv ≤4 : rel. F ; C ; PP ; évol.                | 0,6980 ; 0,8825 ; 0,6160 ; 2,13 %                                                                                                                                                                                 | 1e-4          | Tarif                     |
| 11        | puissance_cv 5-8 : rel. F ; C ; PP ; évol.               | 1,0000 ; 1,0000 ; 1,0000 ; 7,55 %                                                                                                                                                                                 | 1e-4          | Tarif                     |
| 11        | puissance_cv 9+ : rel. F ; C ; PP ; évol.                | 1,4660 ; 1,0724 ; 1,5721 ; 18,57 %                                                                                                                                                                                | 1e-4          | Tarif                     |
| 11        | usage Privé : rel. F ; C ; PP ; évol.                    | 1,0000 ; 1,0000 ; 1,0000 ; 6,68 %                                                                                                                                                                                 | 1e-4          | Tarif                     |
| 11        | usage Trajet : rel. F ; C ; PP ; évol.                   | 1,0896 ; 1,0327 ; 1,1252 ; 9,04 %                                                                                                                                                                                 | 1e-4          | Tarif                     |
| 11        | usage Professionnel : rel. F ; C ; PP ; évol.            | 1,8054 ; 1,0331 ; 1,8652 ; 22,97 %                                                                                                                                                                                | 1e-4          | Tarif                     |
| TB        | Exercice 2021 : primes ; ultime ; S/P ; RC               | 949 080,42 ; 481 316,25 ; 50,71 % ; 75,71 %                                                                                                                                                                       | 1e-4          | Historique                |
| TB        | Exercice 2022 : primes ; ultime ; S/P ; RC               | 962 562,48 ; 644 660,87 ; 66,97 % ; 91,97 %                                                                                                                                                                       | 1e-4          | Historique                |
| TB        | Exercice 2023 : primes ; ultime ; S/P ; RC               | 987 273,30 ; 688 228,31 ; 69,71 % ; 94,71 %                                                                                                                                                                       | 1e-4          | Historique                |
| TB        | Exercice 2024 : primes ; ultime ; S/P ; RC               | 1 002 328,03 ; 631 805,41 ; 63,03 % ; 88,03 %                                                                                                                                                                     | 1e-4          | Historique                |
| TB        | Exercice 2025 : primes ; ultime ; S/P ; RC               | 1 031 663,54 ; 826 576,30 ; 80,12 % ; 105,12 %                                                                                                                                                                    | 1e-4          | Historique                |
| TB        | Segments 2025, âge : S/P                                 | 18-24 : 80,3 % \| 25-29 : 96,4 % \| 30-49 : 80,7 % \| 50-74 : 86,2 % \| 75+ : 29,6 %                                                                                                                              | 1e-3          | Segments                  |
| TB        | Segments 2025, zone : S/P                                | A : 83,8 % \| B : 63,8 % \| C : 101,3 % \| D : 68,7 %                                                                                                                                                             | 1e-3          | Segments                  |
| TB        | Segments 2025, puissance_cv : S/P                        | ≤4 : 57,3 % \| 5-8 : 86,4 % \| 9+ : 74,3 %                                                                                                                                                                        | 1e-3          | Segments                  |
| TB        | Segments 2025, usage : S/P                               | Privé : 71,6 % \| Trajet : 89,4 % \| Professionnel : 97,6 %                                                                                                                                                       | 1e-3          | Segments                  |
| TB        | Bandeau 2025                                             | La zone C et l’usage professionnel restent sous-tarifés : S/P 2025 de 101 % et 98 % (cible 68 %). Lancer la révision.                                                                                             | exact         | P00                       |
| CA        | Profil par défaut (23 ans, C, 6 CV, Trajet, CRM 0,90)    | fréq. 11,9855 % ; coût 4 412,04 ; PP 528,81 ; HT 778,10 ; TTC 1 044,21                                                                                                                                            | 0,01          | Calculateur               |
| CA        | Écarts du profil par défaut                              | vs tarif actuel 45,62 % ; vs moyenne 215,91 %                                                                                                                                                                     | 1e-4          | Calculateur               |
| CA        | Profil de référence (35 ans, B, 6 CV, Privé, CRM 0,50)   | PP 119,97 ; TTC 236,90 ; vs tarif actuel 1,56 %                                                                                                                                                                   | 0,01          | Calculateur               |

15.1 Scénarios de seuil

À vérifier en cliquant les puces de l’étape 05. Le niveau final varie peu grâce au calage θ : c’est l’effet recherché.

| **Scénario**        | **n_u** | **Part excédent** | **α**  | **κ**  | **κ emp.** | **θ**  | **B (€)** | **Évol.** | **Équil.** | **Contrôles 05 / 10** |
|---------------------|---------|-------------------|--------|--------|------------|--------|-----------|-----------|------------|-----------------------|
| u = 15 000 (défaut) | 45      | 19,77 %           | 1,7732 | 1,3003 | 1,2465     | 1,0176 | 239,94    | 9,00 %    | 95,30 %    | ok / ok               |
| u = 10 000          | 71      | 27,86 %           | 1,4357 | 1,6233 | 1,3862     | 0,9069 | 231,12    | 9,11 %    | 95,40 %    | ok / rose             |
| u = 5 000           | 166     | 41,98 %           | 1,3370 | 2,1714 | 1,7237     | 0,8437 | 226,78    | 9,41 %    | 95,78 %    | rose / rose           |

16\. Phases de construction et critères d’acceptation

16.1 Phase 1 : moteur et feuilles de travail

- Modules modApp (squelette : erreurs, état, noms), modOutils, modDonnees, modEtude, modGLM, modRecette.

- Macro provisoire ConstruireMoteur : colonnes dérivées, toutes les feuilles de travail, journal, IRLS, contrôles.

- Critère de sortie : feuille Recette entièrement verte, y compris les deux scénarios de seuil (macro RecetteSeuils).

16.2 Phase 2 : design et pages

- Modules modDesign, modContenu, modPages, interface complète de modApp, ThisWorkbook.

- Critère de sortie : chaque page superposable à sa maquette (écart de position \< 2 pt, mêmes polices, mêmes couleurs, mêmes textes et valeurs).

16.3 Phase 3 : interactions et robustesse

- Toutes les puces, boutons, bulles, consultation des feuilles, bascule de mode, fermeture et réouverture.

- Test du repli de police (désinstaller ou renommer la constante) et du repli PNG des formules.

16.4 Critères d’acceptation finaux

30. ConstruireApplication s’exécute sans erreur sur un poste propre, deux fois de suite (idempotence), en moins de 90 s.

31. Recette : 100 % des indicateurs conformes.

32. Les 33 contrôles des étapes sont verts au seuil de 15 000 € ; au seuil de 5 000 €, exactement les contrôles « Excédent sous 35 % » (05) et « κ Pareto à moins de 15 % » (10) passent au rose, comme sur P05_variante_seuil_5k.png.

33. Aucune page ne défile, aucun texte ne déborde de sa carte, aucune police n’est réduite.

34. Mode application : pas de ruban, d’onglets, de barre de formule ni de barres de défilement ; clic droit et double-clic bloqués ; Ctrl+Maj+M rend la main.

35. Toute valeur affichée est traçable jusqu’à une cellule de feuille de travail (R14).

Annexe A. Maquettes de référence

Rendu cible de chaque page, à 960 × 540 pt. Les fichiers PNG en pleine résolution sont fournis à part.

![P00](../maquettes/P00.png)

*P00.png : Tableau de bord*

![P01](../maquettes/P01.png)

*P01.png : Étape 01 : import et exposition*

![P02](../maquettes/P02.png)

*P02.png : Étape 02 : qualité des données*

![P03](../maquettes/P03.png)

*P03.png : Étape 03 : base de modélisation*

![P04](../maquettes/P04.png)

*P04.png : Étape 04 : charge ultime et inflation*

![P05](../maquettes/P05.png)

*P05.png : Étape 05 : écrêtement (seuil 15 000 €)*

![P05_variante_seuil_5k](../maquettes/P05_variante_seuil_5k.png)

*P05_variante_seuil_5k.png : Étape 05 : seuil 5 000 €, contrôle en rose*

![P06](../maquettes/P06.png)

*P06.png : Étape 06 : analyse exploratoire*

![P07](../maquettes/P07.png)

*P07.png : Étape 07 : classes*

![P08](../maquettes/P08.png)

*P08.png : Étape 08 : sélection des variables*

![P09](../maquettes/P09.png)

*P09.png : Étape 09 : modèles GLM*

![P10](../maquettes/P10.png)

*P10.png : Étape 10 : sinistres graves*

![P11](../maquettes/P11.png)

*P11.png : Étape 11 : résultats et impact*

![P12](../maquettes/P12.png)

*P12.png : Calculateur de prime*

Annexe B. Manifeste des formules

Taille naturelle à 10 pt par em ; le VBA applique l’échelle de la section 10.2. Clé = nom de fichier sans extension.

| **Clé** | **Libellé affiché**                      | **Largeur (pt)** | **Hauteur (pt)** |
|---------|------------------------------------------|------------------|------------------|
| F01a    | EXPOSITION D'UNE LIGNE                   | 210,48           | 27,43            |
| F01b    | BORNES DE L'EXERCICE y                   | 213,71           | 11,24            |
| F01c    | EXPOSITION TOTALE                        | 47,73            | 28,09            |
| F02a    | TAUX DE COMPLÉTUDE D'UNE COLONNE         | 135,11           | 22,01            |
| F02b    | RÈGLES DE COHÉRENCE                      | 224,50           | 8,99             |
| F02c    | BILAN                                    | 158,09           | 8,41             |
| F03a    | NOMBRE DE SINISTRES DE LA LIGNE i        | 82,82            | 29,99            |
| F03b    | CHARGE DE LA LIGNE i                     | 95,39            | 29,99            |
| F03c    | CONTRÔLE DE CONSERVATION                 | 67,74            | 21,66            |
| F04a    | FACTEUR DE DÉVELOPPEMENT                 | 69,93            | 27,81            |
| F04b    | CHARGE ULTIME DE L'EXERCICE y            | 73,36            | 23,66            |
| F04c    | REVALORISATION ET CHARGE CIBLE           | 180,50           | 22,45            |
| F05a    | CHARGE ÉCRÊTÉE                           | 77,01            | 10,23            |
| F05b    | EXCÉDENT                                 | 154,59           | 11,63            |
| F05c    | EXCÈS MOYEN EMPIRIQUE                    | 99,62            | 26,02            |
| F06a    | FRÉQUENCE DE LA TRANCHE j                | 61,73            | 27,79            |
| F06b    | FRÉQUENCE À CRM 1,00                     | 90,40            | 27,79            |
| F06c    | COÛT MOYEN ÉCRÊTÉ                        | 61,93            | 27,79            |
| F07a    | CONTRAINTE D'EXPOSITION                  | 64,14            | 9,88             |
| F07b    | TEST DE FUSION DE DEUX CLASSES VOISINES  | 116,29           | 37,49            |
| F07c    | RÈGLE                                    | 134,36           | 9,99             |
| F08a    | STATISTIQUE DU χ² (FRÉQUENCE À CRM 1,00) | 147,86           | 39,17            |
| F08b    | V DE CRAMÉR                              | 46,25            | 24,60            |
| F08c    | TEST DU RAPPORT DE VRAISEMBLANCE         | 140,75           | 12,53            |
| F09a    | FRÉQUENCE · POISSON, LIEN LOG            | 209,74           | 22,79            |
| F09b    | COÛT MOYEN · GAMMA, LIEN LOG             | 195,00           | 22,79            |
| F09c    | ITÉRATION IRLS                           | 151,34           | 19,97            |
| F10a    | QUEUE DE PARETO AU-DELÀ DE u             | 173,64           | 18,86            |
| F10b    | ESTIMATEUR DU MAXIMUM DE VRAISEMBLANCE   | 102,73           | 22,25            |
| F10c    | COEFFICIENT DE MUTUALISATION             | 105,63           | 21,53            |
| F11a    | PRIME PURE                               | 200,67           | 22,79            |
| F11b    | PRIME COMMERCIALE                        | 119,30           | 23,51            |
| F11c    | PLAFONNEMENT                             | 182,55           | 29,99            |
